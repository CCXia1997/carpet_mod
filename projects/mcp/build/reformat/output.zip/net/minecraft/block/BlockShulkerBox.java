package net.minecraft.block;

import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.block.material.EnumPushReaction;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.ItemStackHelper;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.item.EnumDyeColor;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.state.EnumProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.stats.StatList;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityShulkerBox;
import net.minecraft.util.EnumBlockRenderType;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.Mirror;
import net.minecraft.util.NonNullList;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.shapes.VoxelShapes;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.World;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class BlockShulkerBox extends BlockContainer
{
    public static final EnumProperty<EnumFacing> field_190957_a = BlockDirectional.field_176387_N;
    @Nullable
    private final EnumDyeColor field_190958_b;

    public BlockShulkerBox(@Nullable EnumDyeColor p_i48334_1_, Block.Properties p_i48334_2_)
    {
        super(p_i48334_2_);
        this.field_190958_b = p_i48334_1_;
        this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_190957_a, EnumFacing.UP));
    }

    public TileEntity func_196283_a_(IBlockReader p_196283_1_)
    {
        return new TileEntityShulkerBox(this.field_190958_b);
    }

    public boolean func_176214_u(IBlockState p_176214_1_)
    {
        return true;
    }

    public boolean func_149686_d(IBlockState p_149686_1_)
    {
        return false;
    }

    @OnlyIn(Dist.CLIENT)
    public boolean func_190946_v(IBlockState p_190946_1_)
    {
        return true;
    }

    public EnumBlockRenderType func_149645_b(IBlockState p_149645_1_)
    {
        return EnumBlockRenderType.ENTITYBLOCK_ANIMATED;
    }

    public boolean func_196250_a(IBlockState p_196250_1_, World p_196250_2_, BlockPos p_196250_3_, EntityPlayer p_196250_4_, EnumHand p_196250_5_, EnumFacing p_196250_6_, float p_196250_7_, float p_196250_8_, float p_196250_9_)
    {
        if (p_196250_2_.field_72995_K)
        {
            return true;
        }
        else if (p_196250_4_.func_175149_v())
        {
            return true;
        }
        else
        {
            TileEntity tileentity = p_196250_2_.func_175625_s(p_196250_3_);

            if (tileentity instanceof TileEntityShulkerBox)
            {
                EnumFacing enumfacing = p_196250_1_.func_177229_b(field_190957_a);
                boolean flag;

                if (((TileEntityShulkerBox)tileentity).func_190591_p() == TileEntityShulkerBox.AnimationStatus.CLOSED)
                {
                    AxisAlignedBB axisalignedbb = VoxelShapes.func_197868_b().func_197752_a().func_72321_a((double)(0.5F * (float)enumfacing.func_82601_c()), (double)(0.5F * (float)enumfacing.func_96559_d()), (double)(0.5F * (float)enumfacing.func_82599_e())).func_191195_a((double)enumfacing.func_82601_c(), (double)enumfacing.func_96559_d(), (double)enumfacing.func_82599_e());
                    flag = p_196250_2_.func_195586_b((Entity)null, axisalignedbb.func_186670_a(p_196250_3_.func_177972_a(enumfacing)));
                }
                else
                {
                    flag = true;
                }

                if (flag)
                {
                    p_196250_4_.func_195066_a(StatList.field_191272_ae);
                    p_196250_4_.func_71007_a((IInventory)tileentity);
                }

                return true;
            }
            else
            {
                return false;
            }
        }
    }

    public IBlockState func_196258_a(BlockItemUseContext p_196258_1_)
    {
        return this.func_176223_P().func_206870_a(field_190957_a, p_196258_1_.func_196000_l());
    }

    protected void func_206840_a(StateContainer.Builder<Block, IBlockState> p_206840_1_)
    {
        p_206840_1_.func_206894_a(field_190957_a);
    }

    public void func_176208_a(World p_176208_1_, BlockPos p_176208_2_, IBlockState p_176208_3_, EntityPlayer p_176208_4_)
    {
        if (p_176208_1_.func_175625_s(p_176208_2_) instanceof TileEntityShulkerBox)
        {
            TileEntityShulkerBox tileentityshulkerbox = (TileEntityShulkerBox)p_176208_1_.func_175625_s(p_176208_2_);
            tileentityshulkerbox.func_190579_a(p_176208_4_.field_71075_bZ.field_75098_d);
            tileentityshulkerbox.func_184281_d(p_176208_4_);
        }

        super.func_176208_a(p_176208_1_, p_176208_2_, p_176208_3_, p_176208_4_);
    }

    public void func_196255_a(IBlockState p_196255_1_, World p_196255_2_, BlockPos p_196255_3_, float p_196255_4_, int p_196255_5_)
    {
    }

    public void func_180633_a(World p_180633_1_, BlockPos p_180633_2_, IBlockState p_180633_3_, EntityLivingBase p_180633_4_, ItemStack p_180633_5_)
    {
        if (p_180633_5_.func_82837_s())
        {
            TileEntity tileentity = p_180633_1_.func_175625_s(p_180633_2_);

            if (tileentity instanceof TileEntityShulkerBox)
            {
                ((TileEntityShulkerBox)tileentity).func_200226_a(p_180633_5_.func_200301_q());
            }
        }
    }

    public void func_196243_a(IBlockState p_196243_1_, World p_196243_2_, BlockPos p_196243_3_, IBlockState p_196243_4_, boolean p_196243_5_)
    {
        if (p_196243_1_.func_177230_c() != p_196243_4_.func_177230_c())
        {
            TileEntity tileentity = p_196243_2_.func_175625_s(p_196243_3_);

            if (tileentity instanceof TileEntityShulkerBox)
            {
                TileEntityShulkerBox tileentityshulkerbox = (TileEntityShulkerBox)tileentity;

                if (!tileentityshulkerbox.func_190590_r() && tileentityshulkerbox.func_190582_F())
                {
                    ItemStack itemstack = new ItemStack(this);
                    itemstack.func_196082_o().func_74782_a("BlockEntityTag", ((TileEntityShulkerBox)tileentity).func_190580_f(new NBTTagCompound()));

                    if (tileentityshulkerbox.func_145818_k_())
                    {
                        itemstack.func_200302_a(tileentityshulkerbox.func_200201_e());
                        tileentityshulkerbox.func_200226_a((ITextComponent)null);
                    }

                    func_180635_a(p_196243_2_, p_196243_3_, itemstack);
                }

                p_196243_2_.func_175666_e(p_196243_3_, p_196243_1_.func_177230_c());
            }

            super.func_196243_a(p_196243_1_, p_196243_2_, p_196243_3_, p_196243_4_, p_196243_5_);
        }
    }

    @OnlyIn(Dist.CLIENT)
    public void func_190948_a(ItemStack p_190948_1_, @Nullable IBlockReader p_190948_2_, List<ITextComponent> p_190948_3_, ITooltipFlag p_190948_4_)
    {
        super.func_190948_a(p_190948_1_, p_190948_2_, p_190948_3_, p_190948_4_);
        NBTTagCompound nbttagcompound = p_190948_1_.func_179543_a("BlockEntityTag");

        if (nbttagcompound != null)
        {
            if (nbttagcompound.func_150297_b("LootTable", 8))
            {
                p_190948_3_.add(new TextComponentString("???????"));
            }

            if (nbttagcompound.func_150297_b("Items", 9))
            {
                NonNullList<ItemStack> nonnulllist = NonNullList.func_191197_a(27, ItemStack.field_190927_a);
                ItemStackHelper.func_191283_b(nbttagcompound, nonnulllist);
                int i = 0;
                int j = 0;

                for (ItemStack itemstack : nonnulllist)
                {
                    if (!itemstack.func_190926_b())
                    {
                        ++j;

                        if (i <= 4)
                        {
                            ++i;
                            ITextComponent itextcomponent = itemstack.func_200301_q().func_212638_h();
                            itextcomponent.func_150258_a(" x").func_150258_a(String.valueOf(itemstack.func_190916_E()));
                            p_190948_3_.add(itextcomponent);
                        }
                    }
                }

                if (j - i > 0)
                {
                    p_190948_3_.add((new TextComponentTranslation("container.shulkerBox.more", j - i)).func_211708_a(TextFormatting.ITALIC));
                }
            }
        }
    }

    public EnumPushReaction func_149656_h(IBlockState p_149656_1_)
    {
        return EnumPushReaction.DESTROY;
    }

    public VoxelShape func_196244_b(IBlockState p_196244_1_, IBlockReader p_196244_2_, BlockPos p_196244_3_)
    {
        TileEntity tileentity = p_196244_2_.func_175625_s(p_196244_3_);
        return tileentity instanceof TileEntityShulkerBox ? VoxelShapes.func_197881_a(((TileEntityShulkerBox)tileentity).func_190584_a(p_196244_1_)) : VoxelShapes.func_197868_b();
    }

    public boolean func_200124_e(IBlockState p_200124_1_)
    {
        return false;
    }

    public boolean func_149740_M(IBlockState p_149740_1_)
    {
        return true;
    }

    public int func_180641_l(IBlockState p_180641_1_, World p_180641_2_, BlockPos p_180641_3_)
    {
        return Container.func_94526_b((IInventory)p_180641_2_.func_175625_s(p_180641_3_));
    }

    public ItemStack func_185473_a(IBlockReader p_185473_1_, BlockPos p_185473_2_, IBlockState p_185473_3_)
    {
        ItemStack itemstack = super.func_185473_a(p_185473_1_, p_185473_2_, p_185473_3_);
        TileEntityShulkerBox tileentityshulkerbox = (TileEntityShulkerBox)p_185473_1_.func_175625_s(p_185473_2_);
        NBTTagCompound nbttagcompound = tileentityshulkerbox.func_190580_f(new NBTTagCompound());

        if (!nbttagcompound.isEmpty())
        {
            itemstack.func_77983_a("BlockEntityTag", nbttagcompound);
        }

        return itemstack;
    }

    @OnlyIn(Dist.CLIENT)
    public static EnumDyeColor func_190955_b(Item p_190955_0_)
    {
        return func_190954_c(Block.func_149634_a(p_190955_0_));
    }

    @OnlyIn(Dist.CLIENT)
    public static EnumDyeColor func_190954_c(Block p_190954_0_)
    {
        return p_190954_0_ instanceof BlockShulkerBox ? ((BlockShulkerBox)p_190954_0_).func_190956_e() : null;
    }

    public static Block func_190952_a(EnumDyeColor p_190952_0_)
    {
        if (p_190952_0_ == null)
        {
            return Blocks.field_204409_il;
        }
        else
        {
            switch (p_190952_0_)
            {
                case WHITE:
                    return Blocks.field_190977_dl;
                case ORANGE:
                    return Blocks.field_190978_dm;
                case MAGENTA:
                    return Blocks.field_190979_dn;
                case LIGHT_BLUE:
                    return Blocks.field_190980_do;
                case YELLOW:
                    return Blocks.field_190981_dp;
                case LIME:
                    return Blocks.field_190982_dq;
                case PINK:
                    return Blocks.field_190983_dr;
                case GRAY:
                    return Blocks.field_190984_ds;
                case LIGHT_GRAY:
                    return Blocks.field_196875_ie;
                case CYAN:
                    return Blocks.field_190986_du;
                case PURPLE:
                default:
                    return Blocks.field_190987_dv;
                case BLUE:
                    return Blocks.field_190988_dw;
                case BROWN:
                    return Blocks.field_190989_dx;
                case GREEN:
                    return Blocks.field_190990_dy;
                case RED:
                    return Blocks.field_190991_dz;
                case BLACK:
                    return Blocks.field_190975_dA;
            }
        }
    }

    @OnlyIn(Dist.CLIENT)
    public EnumDyeColor func_190956_e()
    {
        return this.field_190958_b;
    }

    public static ItemStack func_190953_b(EnumDyeColor p_190953_0_)
    {
        return new ItemStack(func_190952_a(p_190953_0_));
    }

    public IBlockState func_185499_a(IBlockState p_185499_1_, Rotation p_185499_2_)
    {
        return p_185499_1_.func_206870_a(field_190957_a, p_185499_2_.func_185831_a(p_185499_1_.func_177229_b(field_190957_a)));
    }

    public IBlockState func_185471_a(IBlockState p_185471_1_, Mirror p_185471_2_)
    {
        return p_185471_1_.func_185907_a(p_185471_2_.func_185800_a(p_185471_1_.func_177229_b(field_190957_a)));
    }

    public BlockFaceShape func_193383_a(IBlockReader p_193383_1_, IBlockState p_193383_2_, BlockPos p_193383_3_, EnumFacing p_193383_4_)
    {
        EnumFacing enumfacing = p_193383_2_.func_177229_b(field_190957_a);
        TileEntityShulkerBox.AnimationStatus tileentityshulkerbox$animationstatus = ((TileEntityShulkerBox)p_193383_1_.func_175625_s(p_193383_3_)).func_190591_p();
        return tileentityshulkerbox$animationstatus != TileEntityShulkerBox.AnimationStatus.CLOSED && (tileentityshulkerbox$animationstatus != TileEntityShulkerBox.AnimationStatus.OPENED || enumfacing != p_193383_4_.func_176734_d() && enumfacing != p_193383_4_) ? BlockFaceShape.UNDEFINED : BlockFaceShape.SOLID;
    }
}
