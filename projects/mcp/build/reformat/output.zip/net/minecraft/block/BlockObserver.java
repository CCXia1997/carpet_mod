package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.state.IBlockState;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.World;

public class BlockObserver extends BlockDirectional
{
    public static final BooleanProperty field_190963_a = BlockStateProperties.field_208194_u;

    public BlockObserver(Block.Properties p_i48358_1_)
    {
        super(p_i48358_1_);
        this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_176387_N, EnumFacing.SOUTH).func_206870_a(field_190963_a, Boolean.valueOf(false)));
    }

    protected void func_206840_a(StateContainer.Builder<Block, IBlockState> p_206840_1_)
    {
        p_206840_1_.func_206894_a(field_176387_N, field_190963_a);
    }

    public IBlockState func_185499_a(IBlockState p_185499_1_, Rotation p_185499_2_)
    {
        return p_185499_1_.func_206870_a(field_176387_N, p_185499_2_.func_185831_a(p_185499_1_.func_177229_b(field_176387_N)));
    }

    public IBlockState func_185471_a(IBlockState p_185471_1_, Mirror p_185471_2_)
    {
        return p_185471_1_.func_185907_a(p_185471_2_.func_185800_a(p_185471_1_.func_177229_b(field_176387_N)));
    }

    public void func_196267_b(IBlockState p_196267_1_, World p_196267_2_, BlockPos p_196267_3_, Random p_196267_4_)
    {
        if (p_196267_1_.func_177229_b(field_190963_a))
        {
            p_196267_2_.func_180501_a(p_196267_3_, p_196267_1_.func_206870_a(field_190963_a, Boolean.valueOf(false)), 2);
        }
        else
        {
            p_196267_2_.func_180501_a(p_196267_3_, p_196267_1_.func_206870_a(field_190963_a, Boolean.valueOf(true)), 2);
            p_196267_2_.func_205220_G_().func_205360_a(p_196267_3_, this, 2);
        }

        this.func_190961_e(p_196267_2_, p_196267_3_, p_196267_1_);
    }

    public IBlockState func_196271_a(IBlockState p_196271_1_, EnumFacing p_196271_2_, IBlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_)
    {
        if (p_196271_1_.func_177229_b(field_176387_N) == p_196271_2_ && !p_196271_1_.func_177229_b(field_190963_a))
        {
            this.func_203420_a(p_196271_4_, p_196271_5_);
        }

        return super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
    }

    private void func_203420_a(IWorld p_203420_1_, BlockPos p_203420_2_)
    {
        if (!p_203420_1_.func_201670_d() && !p_203420_1_.func_205220_G_().func_205359_a(p_203420_2_, this))
        {
            p_203420_1_.func_205220_G_().func_205360_a(p_203420_2_, this, 2);
        }
    }

    protected void func_190961_e(World p_190961_1_, BlockPos p_190961_2_, IBlockState p_190961_3_)
    {
        EnumFacing enumfacing = p_190961_3_.func_177229_b(field_176387_N);
        BlockPos blockpos = p_190961_2_.func_177972_a(enumfacing.func_176734_d());
        p_190961_1_.func_190524_a(blockpos, this, p_190961_2_);
        p_190961_1_.func_175695_a(blockpos, this, enumfacing);
    }

    public boolean func_149744_f(IBlockState p_149744_1_)
    {
        return true;
    }

    public int func_176211_b(IBlockState p_176211_1_, IBlockReader p_176211_2_, BlockPos p_176211_3_, EnumFacing p_176211_4_)
    {
        return p_176211_1_.func_185911_a(p_176211_2_, p_176211_3_, p_176211_4_);
    }

    public int func_180656_a(IBlockState p_180656_1_, IBlockReader p_180656_2_, BlockPos p_180656_3_, EnumFacing p_180656_4_)
    {
        return p_180656_1_.func_177229_b(field_190963_a) && p_180656_1_.func_177229_b(field_176387_N) == p_180656_4_ ? 15 : 0;
    }

    public void func_196259_b(IBlockState p_196259_1_, World p_196259_2_, BlockPos p_196259_3_, IBlockState p_196259_4_)
    {
        if (p_196259_1_.func_177230_c() != p_196259_4_.func_177230_c())
        {
            if (!p_196259_2_.func_201670_d() && p_196259_1_.func_177229_b(field_190963_a) && !p_196259_2_.func_205220_G_().func_205359_a(p_196259_3_, this))
            {
                IBlockState iblockstate = p_196259_1_.func_206870_a(field_190963_a, Boolean.valueOf(false));
                p_196259_2_.func_180501_a(p_196259_3_, iblockstate, 18);
                this.func_190961_e(p_196259_2_, p_196259_3_, iblockstate);
            }
        }
    }

    public void func_196243_a(IBlockState p_196243_1_, World p_196243_2_, BlockPos p_196243_3_, IBlockState p_196243_4_, boolean p_196243_5_)
    {
        if (p_196243_1_.func_177230_c() != p_196243_4_.func_177230_c())
        {
            if (!p_196243_2_.field_72995_K && p_196243_1_.func_177229_b(field_190963_a) && p_196243_2_.func_205220_G_().func_205359_a(p_196243_3_, this))
            {
                this.func_190961_e(p_196243_2_, p_196243_3_, p_196243_1_.func_206870_a(field_190963_a, Boolean.valueOf(false)));
            }
        }
    }

    public IBlockState func_196258_a(BlockItemUseContext p_196258_1_)
    {
        return this.func_176223_P().func_206870_a(field_176387_N, p_196258_1_.func_196010_d().func_176734_d().func_176734_d());
    }
}
