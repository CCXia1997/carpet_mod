package net.minecraft.block;

import net.minecraft.block.state.IBlockState;
import net.minecraft.item.EnumDyeColor;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class BlockStainedGlassPane extends BlockGlassPane
{
    private final EnumDyeColor field_196420_C;

    public BlockStainedGlassPane(EnumDyeColor p_i48322_1_, Block.Properties p_i48322_2_)
    {
        super(p_i48322_2_);
        this.field_196420_C = p_i48322_1_;
        this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_196409_a, Boolean.valueOf(false)).func_206870_a(field_196411_b, Boolean.valueOf(false)).func_206870_a(field_196413_c, Boolean.valueOf(false)).func_206870_a(field_196414_y, Boolean.valueOf(false)).func_206870_a(field_204514_u, Boolean.valueOf(false)));
    }

    public EnumDyeColor func_196419_d()
    {
        return this.field_196420_C;
    }

    public BlockRenderLayer func_180664_k()
    {
        return BlockRenderLayer.TRANSLUCENT;
    }

    public void func_196259_b(IBlockState p_196259_1_, World p_196259_2_, BlockPos p_196259_3_, IBlockState p_196259_4_)
    {
        if (p_196259_4_.func_177230_c() != p_196259_1_.func_177230_c())
        {
            if (!p_196259_2_.field_72995_K)
            {
                BlockBeacon.func_176450_d(p_196259_2_, p_196259_3_);
            }
        }
    }

    public void func_196243_a(IBlockState p_196243_1_, World p_196243_2_, BlockPos p_196243_3_, IBlockState p_196243_4_, boolean p_196243_5_)
    {
        if (p_196243_1_.func_177230_c() != p_196243_4_.func_177230_c())
        {
            if (!p_196243_2_.field_72995_K)
            {
                BlockBeacon.func_176450_d(p_196243_2_, p_196243_3_);
            }
        }
    }
}
