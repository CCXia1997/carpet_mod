package net.minecraft.block;

public abstract class BlockStemGrown extends Block
{
    public BlockStemGrown(Block.Properties p_i48317_1_)
    {
        super(p_i48317_1_);
    }

    public abstract BlockStem func_196524_d();

    public abstract BlockAttachedStem func_196523_e();
}
