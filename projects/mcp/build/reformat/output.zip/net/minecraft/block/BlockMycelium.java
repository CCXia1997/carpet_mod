package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Particles;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class BlockMycelium extends BlockDirtSnowySpreadable
{
    public BlockMycelium(Block.Properties p_i48362_1_)
    {
        super(p_i48362_1_);
    }

    @OnlyIn(Dist.CLIENT)
    public void func_180655_c(IBlockState p_180655_1_, World p_180655_2_, BlockPos p_180655_3_, Random p_180655_4_)
    {
        super.func_180655_c(p_180655_1_, p_180655_2_, p_180655_3_, p_180655_4_);

        if (p_180655_4_.nextInt(10) == 0)
        {
            p_180655_2_.func_195594_a(Particles.field_197596_G, (double)((float)p_180655_3_.func_177958_n() + p_180655_4_.nextFloat()), (double)((float)p_180655_3_.func_177956_o() + 1.1F), (double)((float)p_180655_3_.func_177952_p() + p_180655_4_.nextFloat()), 0.0D, 0.0D, 0.0D);
        }
    }
}
