package net.minecraft.block;

import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.IBlockState;
import net.minecraft.fluid.Fluid;
import net.minecraft.fluid.IFluidState;
import net.minecraft.init.Blocks;
import net.minecraft.init.Fluids;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.state.IntegerProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.IWorldReaderBase;
import net.minecraft.world.World;

public class BlockKelpTop extends Block implements ILiquidContainer
{
    public static final IntegerProperty field_203163_a = BlockStateProperties.field_208172_Y;
    protected static final VoxelShape field_207797_b = Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 9.0D, 16.0D);

    protected BlockKelpTop(Block.Properties p_i48781_1_)
    {
        super(p_i48781_1_);
        this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_203163_a, Integer.valueOf(0)));
    }

    public boolean func_149686_d(IBlockState p_149686_1_)
    {
        return false;
    }

    public VoxelShape func_196244_b(IBlockState p_196244_1_, IBlockReader p_196244_2_, BlockPos p_196244_3_)
    {
        return field_207797_b;
    }

    @Nullable
    public IBlockState func_196258_a(BlockItemUseContext p_196258_1_)
    {
        IFluidState ifluidstate = p_196258_1_.func_195991_k().func_204610_c(p_196258_1_.func_195995_a());
        return ifluidstate.func_206884_a(FluidTags.field_206959_a) && ifluidstate.func_206882_g() == 8 ? this.func_209906_a(p_196258_1_.func_195991_k()) : null;
    }

    public IBlockState func_209906_a(IWorld p_209906_1_)
    {
        return this.func_176223_P().func_206870_a(field_203163_a, Integer.valueOf(p_209906_1_.func_201674_k().nextInt(25)));
    }

    public BlockRenderLayer func_180664_k()
    {
        return BlockRenderLayer.CUTOUT;
    }

    public BlockFaceShape func_193383_a(IBlockReader p_193383_1_, IBlockState p_193383_2_, BlockPos p_193383_3_, EnumFacing p_193383_4_)
    {
        return BlockFaceShape.UNDEFINED;
    }

    public IFluidState func_204507_t(IBlockState p_204507_1_)
    {
        return Fluids.field_204546_a.func_207204_a(false);
    }

    public void func_196267_b(IBlockState p_196267_1_, World p_196267_2_, BlockPos p_196267_3_, Random p_196267_4_)
    {
        if (!p_196267_1_.func_196955_c(p_196267_2_, p_196267_3_))
        {
            p_196267_2_.func_175655_b(p_196267_3_, true);
        }
        else
        {
            BlockPos blockpos = p_196267_3_.func_177984_a();
            IBlockState iblockstate = p_196267_2_.func_180495_p(blockpos);

            if (iblockstate.func_177230_c() == Blocks.field_150355_j && p_196267_1_.func_177229_b(field_203163_a) < 25 && p_196267_4_.nextDouble() < 0.14D)
            {
                p_196267_2_.func_175656_a(blockpos, p_196267_1_.func_177231_a(field_203163_a));
            }
        }
    }

    public boolean func_196260_a(IBlockState p_196260_1_, IWorldReaderBase p_196260_2_, BlockPos p_196260_3_)
    {
        BlockPos blockpos = p_196260_3_.func_177977_b();
        IBlockState iblockstate = p_196260_2_.func_180495_p(blockpos);
        Block block = iblockstate.func_177230_c();

        if (block == Blocks.field_196814_hQ)
        {
            return false;
        }
        else
        {
            return block == this || block == Blocks.field_203215_jy || Block.func_208061_a(iblockstate.func_196952_d(p_196260_2_, blockpos), EnumFacing.UP);
        }
    }

    public IBlockState func_196271_a(IBlockState p_196271_1_, EnumFacing p_196271_2_, IBlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_)
    {
        if (!p_196271_1_.func_196955_c(p_196271_4_, p_196271_5_))
        {
            if (p_196271_2_ == EnumFacing.DOWN)
            {
                return Blocks.field_150350_a.func_176223_P();
            }

            p_196271_4_.func_205220_G_().func_205360_a(p_196271_5_, this, 1);
        }

        if (p_196271_2_ == EnumFacing.UP && p_196271_3_.func_177230_c() == this)
        {
            return Blocks.field_203215_jy.func_176223_P();
        }
        else
        {
            p_196271_4_.func_205219_F_().func_205360_a(p_196271_5_, Fluids.field_204546_a, Fluids.field_204546_a.func_205569_a(p_196271_4_));
            return super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
        }
    }

    protected void func_206840_a(StateContainer.Builder<Block, IBlockState> p_206840_1_)
    {
        p_206840_1_.func_206894_a(field_203163_a);
    }

    public boolean func_204510_a(IBlockReader p_204510_1_, BlockPos p_204510_2_, IBlockState p_204510_3_, Fluid p_204510_4_)
    {
        return false;
    }

    public boolean func_204509_a(IWorld p_204509_1_, BlockPos p_204509_2_, IBlockState p_204509_3_, IFluidState p_204509_4_)
    {
        return false;
    }
}
