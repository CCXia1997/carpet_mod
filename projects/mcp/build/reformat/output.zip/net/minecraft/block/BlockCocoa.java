package net.minecraft.block;

import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.item.ItemStack;
import net.minecraft.state.IntegerProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.IWorldReaderBase;
import net.minecraft.world.World;

public class BlockCocoa extends BlockHorizontal implements IGrowable
{
    public static final IntegerProperty field_176501_a = BlockStateProperties.field_208167_T;
    protected static final VoxelShape[] field_185535_b = new VoxelShape[] {Block.func_208617_a(11.0D, 7.0D, 6.0D, 15.0D, 12.0D, 10.0D), Block.func_208617_a(9.0D, 5.0D, 5.0D, 15.0D, 12.0D, 11.0D), Block.func_208617_a(7.0D, 3.0D, 4.0D, 15.0D, 12.0D, 12.0D)};
    protected static final VoxelShape[] field_185536_c = new VoxelShape[] {Block.func_208617_a(1.0D, 7.0D, 6.0D, 5.0D, 12.0D, 10.0D), Block.func_208617_a(1.0D, 5.0D, 5.0D, 7.0D, 12.0D, 11.0D), Block.func_208617_a(1.0D, 3.0D, 4.0D, 9.0D, 12.0D, 12.0D)};
    protected static final VoxelShape[] field_185537_d = new VoxelShape[] {Block.func_208617_a(6.0D, 7.0D, 1.0D, 10.0D, 12.0D, 5.0D), Block.func_208617_a(5.0D, 5.0D, 1.0D, 11.0D, 12.0D, 7.0D), Block.func_208617_a(4.0D, 3.0D, 1.0D, 12.0D, 12.0D, 9.0D)};
    protected static final VoxelShape[] field_185538_e = new VoxelShape[] {Block.func_208617_a(6.0D, 7.0D, 11.0D, 10.0D, 12.0D, 15.0D), Block.func_208617_a(5.0D, 5.0D, 9.0D, 11.0D, 12.0D, 15.0D), Block.func_208617_a(4.0D, 3.0D, 7.0D, 12.0D, 12.0D, 15.0D)};

    public BlockCocoa(Block.Properties p_i48426_1_)
    {
        super(p_i48426_1_);
        this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_185512_D, EnumFacing.NORTH).func_206870_a(field_176501_a, Integer.valueOf(0)));
    }

    public void func_196267_b(IBlockState p_196267_1_, World p_196267_2_, BlockPos p_196267_3_, Random p_196267_4_)
    {
        if (p_196267_2_.field_73012_v.nextInt(5) == 0)
        {
            int i = p_196267_1_.func_177229_b(field_176501_a);

            if (i < 2)
            {
                p_196267_2_.func_180501_a(p_196267_3_, p_196267_1_.func_206870_a(field_176501_a, Integer.valueOf(i + 1)), 2);
            }
        }
    }

    public boolean func_196260_a(IBlockState p_196260_1_, IWorldReaderBase p_196260_2_, BlockPos p_196260_3_)
    {
        Block block = p_196260_2_.func_180495_p(p_196260_3_.func_177972_a(p_196260_1_.func_177229_b(field_185512_D))).func_177230_c();
        return block.func_203417_a(BlockTags.field_203289_r);
    }

    public boolean func_149686_d(IBlockState p_149686_1_)
    {
        return false;
    }

    public VoxelShape func_196244_b(IBlockState p_196244_1_, IBlockReader p_196244_2_, BlockPos p_196244_3_)
    {
        int i = p_196244_1_.func_177229_b(field_176501_a);

        switch ((EnumFacing)p_196244_1_.func_177229_b(field_185512_D))
        {
            case SOUTH:
                return field_185538_e[i];
            case NORTH:
            default:
                return field_185537_d[i];
            case WEST:
                return field_185536_c[i];
            case EAST:
                return field_185535_b[i];
        }
    }

    @Nullable
    public IBlockState func_196258_a(BlockItemUseContext p_196258_1_)
    {
        IBlockState iblockstate = this.func_176223_P();
        IWorldReaderBase iworldreaderbase = p_196258_1_.func_195991_k();
        BlockPos blockpos = p_196258_1_.func_195995_a();

        for (EnumFacing enumfacing : p_196258_1_.func_196009_e())
        {
            if (enumfacing.func_176740_k().func_176722_c())
            {
                iblockstate = iblockstate.func_206870_a(field_185512_D, enumfacing);

                if (iblockstate.func_196955_c(iworldreaderbase, blockpos))
                {
                    return iblockstate;
                }
            }
        }

        return null;
    }

    public IBlockState func_196271_a(IBlockState p_196271_1_, EnumFacing p_196271_2_, IBlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_)
    {
        return p_196271_2_ == p_196271_1_.func_177229_b(field_185512_D) && !p_196271_1_.func_196955_c(p_196271_4_, p_196271_5_) ? Blocks.field_150350_a.func_176223_P() : super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
    }

    public void func_196255_a(IBlockState p_196255_1_, World p_196255_2_, BlockPos p_196255_3_, float p_196255_4_, int p_196255_5_)
    {
        int i = p_196255_1_.func_177229_b(field_176501_a);
        int j = 1;

        if (i >= 2)
        {
            j = 3;
        }

        for (int k = 0; k < j; ++k)
        {
            func_180635_a(p_196255_2_, p_196255_3_, new ItemStack(Items.field_196130_bo));
        }
    }

    public ItemStack func_185473_a(IBlockReader p_185473_1_, BlockPos p_185473_2_, IBlockState p_185473_3_)
    {
        return new ItemStack(Items.field_196130_bo);
    }

    public boolean func_176473_a(IBlockReader p_176473_1_, BlockPos p_176473_2_, IBlockState p_176473_3_, boolean p_176473_4_)
    {
        return p_176473_3_.func_177229_b(field_176501_a) < 2;
    }

    public boolean func_180670_a(World p_180670_1_, Random p_180670_2_, BlockPos p_180670_3_, IBlockState p_180670_4_)
    {
        return true;
    }

    public void func_176474_b(World p_176474_1_, Random p_176474_2_, BlockPos p_176474_3_, IBlockState p_176474_4_)
    {
        p_176474_1_.func_180501_a(p_176474_3_, p_176474_4_.func_206870_a(field_176501_a, Integer.valueOf(p_176474_4_.func_177229_b(field_176501_a) + 1)), 2);
    }

    public BlockRenderLayer func_180664_k()
    {
        return BlockRenderLayer.CUTOUT;
    }

    protected void func_206840_a(StateContainer.Builder<Block, IBlockState> p_206840_1_)
    {
        p_206840_1_.func_206894_a(field_185512_D, field_176501_a);
    }

    public BlockFaceShape func_193383_a(IBlockReader p_193383_1_, IBlockState p_193383_2_, BlockPos p_193383_3_, EnumFacing p_193383_4_)
    {
        return BlockFaceShape.UNDEFINED;
    }
}
