package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.state.IBlockState;
import net.minecraft.item.EnumDyeColor;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.World;

public class BlockStainedGlass extends BlockBreakable
{
    private final EnumDyeColor field_196458_a;

    public BlockStainedGlass(EnumDyeColor p_i48323_1_, Block.Properties p_i48323_2_)
    {
        super(p_i48323_2_);
        this.field_196458_a = p_i48323_1_;
    }

    public boolean func_200123_i(IBlockState p_200123_1_, IBlockReader p_200123_2_, BlockPos p_200123_3_)
    {
        return true;
    }

    public EnumDyeColor func_196457_d()
    {
        return this.field_196458_a;
    }

    public BlockRenderLayer func_180664_k()
    {
        return BlockRenderLayer.TRANSLUCENT;
    }

    public int func_196264_a(IBlockState p_196264_1_, Random p_196264_2_)
    {
        return 0;
    }

    protected boolean func_149700_E()
    {
        return true;
    }

    public boolean func_149686_d(IBlockState p_149686_1_)
    {
        return false;
    }

    public void func_196259_b(IBlockState p_196259_1_, World p_196259_2_, BlockPos p_196259_3_, IBlockState p_196259_4_)
    {
        if (p_196259_4_.func_177230_c() != p_196259_1_.func_177230_c())
        {
            if (!p_196259_2_.field_72995_K)
            {
                BlockBeacon.func_176450_d(p_196259_2_, p_196259_3_);
            }
        }
    }

    public void func_196243_a(IBlockState p_196243_1_, World p_196243_2_, BlockPos p_196243_3_, IBlockState p_196243_4_, boolean p_196243_5_)
    {
        if (p_196243_1_.func_177230_c() != p_196243_4_.func_177230_c())
        {
            if (!p_196243_2_.field_72995_K)
            {
                BlockBeacon.func_176450_d(p_196243_2_, p_196243_3_);
            }
        }
    }
}
