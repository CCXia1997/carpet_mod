package net.minecraft.block;

import java.util.function.Predicate;
import net.minecraft.advancements.CriteriaTriggers;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.BlockWorldState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.block.state.pattern.BlockMaterialMatcher;
import net.minecraft.block.state.pattern.BlockPattern;
import net.minecraft.block.state.pattern.BlockStateMatcher;
import net.minecraft.block.state.pattern.FactoryBlockPattern;
import net.minecraft.entity.monster.EntityIronGolem;
import net.minecraft.entity.monster.EntitySnowman;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.Blocks;
import net.minecraft.init.Particles;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.state.DirectionProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IWorldReaderBase;
import net.minecraft.world.World;

public class BlockCarvedPumpkin extends BlockHorizontal
{
    public static final DirectionProperty field_196359_a = BlockHorizontal.field_185512_D;
    private BlockPattern field_196361_b;
    private BlockPattern field_196362_c;
    private BlockPattern field_196363_y;
    private BlockPattern field_196364_z;
    private static final Predicate<IBlockState> field_196360_A = (p_210301_0_) ->
    {
        return p_210301_0_ != null && (p_210301_0_.func_177230_c() == Blocks.field_196625_cS || p_210301_0_.func_177230_c() == Blocks.field_196628_cT);
    };

    protected BlockCarvedPumpkin(Block.Properties p_i48432_1_)
    {
        super(p_i48432_1_);
        this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_196359_a, EnumFacing.NORTH));
    }

    public void func_196259_b(IBlockState p_196259_1_, World p_196259_2_, BlockPos p_196259_3_, IBlockState p_196259_4_)
    {
        if (p_196259_4_.func_177230_c() != p_196259_1_.func_177230_c())
        {
            this.func_196358_b(p_196259_2_, p_196259_3_);
        }
    }

    public boolean func_196354_a(IWorldReaderBase p_196354_1_, BlockPos p_196354_2_)
    {
        return this.func_196353_d().func_177681_a(p_196354_1_, p_196354_2_) != null || this.func_196356_f().func_177681_a(p_196354_1_, p_196354_2_) != null;
    }

    private void func_196358_b(World p_196358_1_, BlockPos p_196358_2_)
    {
        BlockPattern.PatternHelper blockpattern$patternhelper = this.func_196355_e().func_177681_a(p_196358_1_, p_196358_2_);

        if (blockpattern$patternhelper != null)
        {
            for (int i = 0; i < this.func_196355_e().func_177685_b(); ++i)
            {
                BlockWorldState blockworldstate = blockpattern$patternhelper.func_177670_a(0, i, 0);
                p_196358_1_.func_180501_a(blockworldstate.func_177508_d(), Blocks.field_150350_a.func_176223_P(), 2);
            }

            EntitySnowman entitysnowman = new EntitySnowman(p_196358_1_);
            BlockPos blockpos1 = blockpattern$patternhelper.func_177670_a(0, 2, 0).func_177508_d();
            entitysnowman.func_70012_b((double)blockpos1.func_177958_n() + 0.5D, (double)blockpos1.func_177956_o() + 0.05D, (double)blockpos1.func_177952_p() + 0.5D, 0.0F, 0.0F);
            p_196358_1_.func_72838_d(entitysnowman);

            for (EntityPlayerMP entityplayermp : p_196358_1_.func_72872_a(EntityPlayerMP.class, entitysnowman.func_174813_aQ().func_186662_g(5.0D)))
            {
                CriteriaTriggers.field_192133_m.func_192229_a(entityplayermp, entitysnowman);
            }

            int l = Block.func_196246_j(Blocks.field_196604_cC.func_176223_P());
            p_196358_1_.func_175718_b(2001, blockpos1, l);
            p_196358_1_.func_175718_b(2001, blockpos1.func_177984_a(), l);

            for (int k1 = 0; k1 < this.func_196355_e().func_177685_b(); ++k1)
            {
                BlockWorldState blockworldstate1 = blockpattern$patternhelper.func_177670_a(0, k1, 0);
                p_196358_1_.func_195592_c(blockworldstate1.func_177508_d(), Blocks.field_150350_a);
            }
        }
        else
        {
            blockpattern$patternhelper = this.func_196357_g().func_177681_a(p_196358_1_, p_196358_2_);

            if (blockpattern$patternhelper != null)
            {
                for (int j = 0; j < this.func_196357_g().func_177684_c(); ++j)
                {
                    for (int k = 0; k < this.func_196357_g().func_177685_b(); ++k)
                    {
                        p_196358_1_.func_180501_a(blockpattern$patternhelper.func_177670_a(j, k, 0).func_177508_d(), Blocks.field_150350_a.func_176223_P(), 2);
                    }
                }

                BlockPos blockpos = blockpattern$patternhelper.func_177670_a(1, 2, 0).func_177508_d();
                EntityIronGolem entityirongolem = new EntityIronGolem(p_196358_1_);
                entityirongolem.func_70849_f(true);
                entityirongolem.func_70012_b((double)blockpos.func_177958_n() + 0.5D, (double)blockpos.func_177956_o() + 0.05D, (double)blockpos.func_177952_p() + 0.5D, 0.0F, 0.0F);
                p_196358_1_.func_72838_d(entityirongolem);

                for (EntityPlayerMP entityplayermp1 : p_196358_1_.func_72872_a(EntityPlayerMP.class, entityirongolem.func_174813_aQ().func_186662_g(5.0D)))
                {
                    CriteriaTriggers.field_192133_m.func_192229_a(entityplayermp1, entityirongolem);
                }

                for (int i1 = 0; i1 < 120; ++i1)
                {
                    p_196358_1_.func_195594_a(Particles.field_197593_D, (double)blockpos.func_177958_n() + p_196358_1_.field_73012_v.nextDouble(), (double)blockpos.func_177956_o() + p_196358_1_.field_73012_v.nextDouble() * 3.9D, (double)blockpos.func_177952_p() + p_196358_1_.field_73012_v.nextDouble(), 0.0D, 0.0D, 0.0D);
                }

                for (int j1 = 0; j1 < this.func_196357_g().func_177684_c(); ++j1)
                {
                    for (int l1 = 0; l1 < this.func_196357_g().func_177685_b(); ++l1)
                    {
                        BlockWorldState blockworldstate2 = blockpattern$patternhelper.func_177670_a(j1, l1, 0);
                        p_196358_1_.func_195592_c(blockworldstate2.func_177508_d(), Blocks.field_150350_a);
                    }
                }
            }
        }
    }

    public IBlockState func_196258_a(BlockItemUseContext p_196258_1_)
    {
        return this.func_176223_P().func_206870_a(field_196359_a, p_196258_1_.func_195992_f().func_176734_d());
    }

    protected void func_206840_a(StateContainer.Builder<Block, IBlockState> p_206840_1_)
    {
        p_206840_1_.func_206894_a(field_196359_a);
    }

    protected BlockPattern func_196353_d()
    {
        if (this.field_196361_b == null)
        {
            this.field_196361_b = FactoryBlockPattern.func_177660_a().func_177659_a(" ", "#", "#").func_177662_a('#', BlockWorldState.func_177510_a(BlockStateMatcher.func_177638_a(Blocks.field_196604_cC))).func_177661_b();
        }

        return this.field_196361_b;
    }

    protected BlockPattern func_196355_e()
    {
        if (this.field_196362_c == null)
        {
            this.field_196362_c = FactoryBlockPattern.func_177660_a().func_177659_a("^", "#", "#").func_177662_a('^', BlockWorldState.func_177510_a(field_196360_A)).func_177662_a('#', BlockWorldState.func_177510_a(BlockStateMatcher.func_177638_a(Blocks.field_196604_cC))).func_177661_b();
        }

        return this.field_196362_c;
    }

    protected BlockPattern func_196356_f()
    {
        if (this.field_196363_y == null)
        {
            this.field_196363_y = FactoryBlockPattern.func_177660_a().func_177659_a("~ ~", "###", "~#~").func_177662_a('#', BlockWorldState.func_177510_a(BlockStateMatcher.func_177638_a(Blocks.field_150339_S))).func_177662_a('~', BlockWorldState.func_177510_a(BlockMaterialMatcher.func_189886_a(Material.field_151579_a))).func_177661_b();
        }

        return this.field_196363_y;
    }

    protected BlockPattern func_196357_g()
    {
        if (this.field_196364_z == null)
        {
            this.field_196364_z = FactoryBlockPattern.func_177660_a().func_177659_a("~^~", "###", "~#~").func_177662_a('^', BlockWorldState.func_177510_a(field_196360_A)).func_177662_a('#', BlockWorldState.func_177510_a(BlockStateMatcher.func_177638_a(Blocks.field_150339_S))).func_177662_a('~', BlockWorldState.func_177510_a(BlockMaterialMatcher.func_189886_a(Material.field_151579_a))).func_177661_b();
        }

        return this.field_196364_z;
    }
}
