package net.minecraft.block;

import javax.annotation.Nullable;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.pathfinding.PathType;
import net.minecraft.state.DirectionProperty;
import net.minecraft.state.EnumProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.PistonType;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityPiston;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.IItemProvider;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.shapes.VoxelShapes;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.World;

public class BlockPistonMoving extends BlockContainer
{
    public static final DirectionProperty field_196344_a = BlockPistonExtension.field_176387_N;
    public static final EnumProperty<PistonType> field_196345_b = BlockPistonExtension.field_176325_b;

    public BlockPistonMoving(Block.Properties p_i48282_1_)
    {
        super(p_i48282_1_);
        this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_196344_a, EnumFacing.NORTH).func_206870_a(field_196345_b, PistonType.DEFAULT));
    }

    @Nullable
    public TileEntity func_196283_a_(IBlockReader p_196283_1_)
    {
        return null;
    }

    public static TileEntity func_196343_a(IBlockState p_196343_0_, EnumFacing p_196343_1_, boolean p_196343_2_, boolean p_196343_3_)
    {
        return new TileEntityPiston(p_196343_0_, p_196343_1_, p_196343_2_, p_196343_3_);
    }

    public void func_196243_a(IBlockState p_196243_1_, World p_196243_2_, BlockPos p_196243_3_, IBlockState p_196243_4_, boolean p_196243_5_)
    {
        if (p_196243_1_.func_177230_c() != p_196243_4_.func_177230_c())
        {
            TileEntity tileentity = p_196243_2_.func_175625_s(p_196243_3_);

            if (tileentity instanceof TileEntityPiston)
            {
                ((TileEntityPiston)tileentity).func_145866_f();
            }
            else
            {
                super.func_196243_a(p_196243_1_, p_196243_2_, p_196243_3_, p_196243_4_, p_196243_5_);
            }
        }
    }

    public void func_176206_d(IWorld p_176206_1_, BlockPos p_176206_2_, IBlockState p_176206_3_)
    {
        BlockPos blockpos = p_176206_2_.func_177972_a(p_176206_3_.func_177229_b(field_196344_a).func_176734_d());
        IBlockState iblockstate = p_176206_1_.func_180495_p(blockpos);

        if (iblockstate.func_177230_c() instanceof BlockPistonBase && iblockstate.func_177229_b(BlockPistonBase.field_176320_b))
        {
            p_176206_1_.func_175698_g(blockpos);
        }
    }

    public boolean func_200124_e(IBlockState p_200124_1_)
    {
        return false;
    }

    public boolean func_149686_d(IBlockState p_149686_1_)
    {
        return false;
    }

    public boolean func_196250_a(IBlockState p_196250_1_, World p_196250_2_, BlockPos p_196250_3_, EntityPlayer p_196250_4_, EnumHand p_196250_5_, EnumFacing p_196250_6_, float p_196250_7_, float p_196250_8_, float p_196250_9_)
    {
        if (!p_196250_2_.field_72995_K && p_196250_2_.func_175625_s(p_196250_3_) == null)
        {
            p_196250_2_.func_175698_g(p_196250_3_);
            return true;
        }
        else
        {
            return false;
        }
    }

    public IItemProvider func_199769_a(IBlockState p_199769_1_, World p_199769_2_, BlockPos p_199769_3_, int p_199769_4_)
    {
        return Items.field_190931_a;
    }

    public void func_196255_a(IBlockState p_196255_1_, World p_196255_2_, BlockPos p_196255_3_, float p_196255_4_, int p_196255_5_)
    {
        if (!p_196255_2_.field_72995_K)
        {
            TileEntityPiston tileentitypiston = this.func_196342_a(p_196255_2_, p_196255_3_);

            if (tileentitypiston != null)
            {
                tileentitypiston.func_200230_i().func_196949_c(p_196255_2_, p_196255_3_, 0);
            }
        }
    }

    public VoxelShape func_196244_b(IBlockState p_196244_1_, IBlockReader p_196244_2_, BlockPos p_196244_3_)
    {
        return VoxelShapes.func_197880_a();
    }

    public VoxelShape func_196268_f(IBlockState p_196268_1_, IBlockReader p_196268_2_, BlockPos p_196268_3_)
    {
        TileEntityPiston tileentitypiston = this.func_196342_a(p_196268_2_, p_196268_3_);
        return tileentitypiston != null ? tileentitypiston.func_195508_a(p_196268_2_, p_196268_3_) : VoxelShapes.func_197880_a();
    }

    @Nullable
    private TileEntityPiston func_196342_a(IBlockReader p_196342_1_, BlockPos p_196342_2_)
    {
        TileEntity tileentity = p_196342_1_.func_175625_s(p_196342_2_);
        return tileentity instanceof TileEntityPiston ? (TileEntityPiston)tileentity : null;
    }

    public ItemStack func_185473_a(IBlockReader p_185473_1_, BlockPos p_185473_2_, IBlockState p_185473_3_)
    {
        return ItemStack.field_190927_a;
    }

    public IBlockState func_185499_a(IBlockState p_185499_1_, Rotation p_185499_2_)
    {
        return p_185499_1_.func_206870_a(field_196344_a, p_185499_2_.func_185831_a(p_185499_1_.func_177229_b(field_196344_a)));
    }

    public IBlockState func_185471_a(IBlockState p_185471_1_, Mirror p_185471_2_)
    {
        return p_185471_1_.func_185907_a(p_185471_2_.func_185800_a(p_185471_1_.func_177229_b(field_196344_a)));
    }

    protected void func_206840_a(StateContainer.Builder<Block, IBlockState> p_206840_1_)
    {
        p_206840_1_.func_206894_a(field_196344_a, field_196345_b);
    }

    public BlockFaceShape func_193383_a(IBlockReader p_193383_1_, IBlockState p_193383_2_, BlockPos p_193383_3_, EnumFacing p_193383_4_)
    {
        return BlockFaceShape.UNDEFINED;
    }

    public boolean func_196266_a(IBlockState p_196266_1_, IBlockReader p_196266_2_, BlockPos p_196266_3_, PathType p_196266_4_)
    {
        return false;
    }
}
