package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IWorldReaderBase;
import net.minecraft.world.World;

public abstract class BlockDirtSnowySpreadable extends BlockDirtSnowy
{
    protected BlockDirtSnowySpreadable(Block.Properties p_i48324_1_)
    {
        super(p_i48324_1_);
    }

    private static boolean func_196383_a(IWorldReaderBase p_196383_0_, BlockPos p_196383_1_)
    {
        BlockPos blockpos = p_196383_1_.func_177984_a();
        return p_196383_0_.func_201696_r(blockpos) >= 4 || p_196383_0_.func_180495_p(blockpos).func_200016_a(p_196383_0_, blockpos) < p_196383_0_.func_201572_C();
    }

    private static boolean func_196384_b(IWorldReaderBase p_196384_0_, BlockPos p_196384_1_)
    {
        BlockPos blockpos = p_196384_1_.func_177984_a();
        return p_196384_0_.func_201696_r(blockpos) >= 4 && p_196384_0_.func_180495_p(blockpos).func_200016_a(p_196384_0_, blockpos) < p_196384_0_.func_201572_C() && !p_196384_0_.func_204610_c(blockpos).func_206884_a(FluidTags.field_206959_a);
    }

    public void func_196267_b(IBlockState p_196267_1_, World p_196267_2_, BlockPos p_196267_3_, Random p_196267_4_)
    {
        if (!p_196267_2_.field_72995_K)
        {
            if (!func_196383_a(p_196267_2_, p_196267_3_))
            {
                p_196267_2_.func_175656_a(p_196267_3_, Blocks.field_150346_d.func_176223_P());
            }
            else
            {
                if (p_196267_2_.func_201696_r(p_196267_3_.func_177984_a()) >= 9)
                {
                    for (int i = 0; i < 4; ++i)
                    {
                        BlockPos blockpos = p_196267_3_.func_177982_a(p_196267_4_.nextInt(3) - 1, p_196267_4_.nextInt(5) - 3, p_196267_4_.nextInt(3) - 1);

                        if (!p_196267_2_.func_195588_v(blockpos))
                        {
                            return;
                        }

                        if (p_196267_2_.func_180495_p(blockpos).func_177230_c() == Blocks.field_150346_d && func_196384_b(p_196267_2_, blockpos))
                        {
                            p_196267_2_.func_175656_a(blockpos, this.func_176223_P());
                        }
                    }
                }
            }
        }
    }
}
