package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.pathfinding.PathType;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.EnumProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.state.properties.PistonType;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.shapes.VoxelShapes;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.IWorldReaderBase;
import net.minecraft.world.World;

public class BlockPistonExtension extends BlockDirectional
{
    public static final EnumProperty<PistonType> field_176325_b = BlockStateProperties.field_208144_as;
    public static final BooleanProperty field_176327_M = BlockStateProperties.field_208195_v;
    protected static final VoxelShape field_185635_c = Block.func_208617_a(12.0D, 0.0D, 0.0D, 16.0D, 16.0D, 16.0D);
    protected static final VoxelShape field_185637_d = Block.func_208617_a(0.0D, 0.0D, 0.0D, 4.0D, 16.0D, 16.0D);
    protected static final VoxelShape field_185639_e = Block.func_208617_a(0.0D, 0.0D, 12.0D, 16.0D, 16.0D, 16.0D);
    protected static final VoxelShape field_185641_f = Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 16.0D, 4.0D);
    protected static final VoxelShape field_185643_g = Block.func_208617_a(0.0D, 12.0D, 0.0D, 16.0D, 16.0D, 16.0D);
    protected static final VoxelShape field_185634_B = Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 4.0D, 16.0D);
    protected static final VoxelShape field_185636_C = Block.func_208617_a(6.0D, -4.0D, 6.0D, 10.0D, 12.0D, 10.0D);
    protected static final VoxelShape field_185638_D = Block.func_208617_a(6.0D, 4.0D, 6.0D, 10.0D, 20.0D, 10.0D);
    protected static final VoxelShape field_185640_E = Block.func_208617_a(6.0D, 6.0D, -4.0D, 10.0D, 10.0D, 12.0D);
    protected static final VoxelShape field_185642_F = Block.func_208617_a(6.0D, 6.0D, 4.0D, 10.0D, 10.0D, 20.0D);
    protected static final VoxelShape field_185644_G = Block.func_208617_a(-4.0D, 6.0D, 6.0D, 12.0D, 10.0D, 10.0D);
    protected static final VoxelShape field_185645_I = Block.func_208617_a(4.0D, 6.0D, 6.0D, 20.0D, 10.0D, 10.0D);
    protected static final VoxelShape field_190964_J = Block.func_208617_a(6.0D, 0.0D, 6.0D, 10.0D, 12.0D, 10.0D);
    protected static final VoxelShape field_190965_K = Block.func_208617_a(6.0D, 4.0D, 6.0D, 10.0D, 16.0D, 10.0D);
    protected static final VoxelShape field_190966_L = Block.func_208617_a(6.0D, 6.0D, 0.0D, 10.0D, 10.0D, 12.0D);
    protected static final VoxelShape field_190967_M = Block.func_208617_a(6.0D, 6.0D, 4.0D, 10.0D, 10.0D, 16.0D);
    protected static final VoxelShape field_190968_N = Block.func_208617_a(0.0D, 6.0D, 6.0D, 12.0D, 10.0D, 10.0D);
    protected static final VoxelShape field_190969_O = Block.func_208617_a(4.0D, 6.0D, 6.0D, 16.0D, 10.0D, 10.0D);

    public BlockPistonExtension(Block.Properties p_i48280_1_)
    {
        super(p_i48280_1_);
        this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_176387_N, EnumFacing.NORTH).func_206870_a(field_176325_b, PistonType.DEFAULT).func_206870_a(field_176327_M, Boolean.valueOf(false)));
    }

    private VoxelShape func_196424_i(IBlockState p_196424_1_)
    {
        switch ((EnumFacing)p_196424_1_.func_177229_b(field_176387_N))
        {
            case DOWN:
            default:
                return field_185634_B;
            case UP:
                return field_185643_g;
            case NORTH:
                return field_185641_f;
            case SOUTH:
                return field_185639_e;
            case WEST:
                return field_185637_d;
            case EAST:
                return field_185635_c;
        }
    }

    public VoxelShape func_196244_b(IBlockState p_196244_1_, IBlockReader p_196244_2_, BlockPos p_196244_3_)
    {
        return VoxelShapes.func_197872_a(this.func_196424_i(p_196244_1_), this.func_196425_x(p_196244_1_));
    }

    private VoxelShape func_196425_x(IBlockState p_196425_1_)
    {
        boolean flag = p_196425_1_.func_177229_b(field_176327_M);

        switch ((EnumFacing)p_196425_1_.func_177229_b(field_176387_N))
        {
            case DOWN:
            default:
                return flag ? field_190965_K : field_185638_D;
            case UP:
                return flag ? field_190964_J : field_185636_C;
            case NORTH:
                return flag ? field_190967_M : field_185642_F;
            case SOUTH:
                return flag ? field_190966_L : field_185640_E;
            case WEST:
                return flag ? field_190969_O : field_185645_I;
            case EAST:
                return flag ? field_190968_N : field_185644_G;
        }
    }

    public boolean func_185481_k(IBlockState p_185481_1_)
    {
        return p_185481_1_.func_177229_b(field_176387_N) == EnumFacing.UP;
    }

    public void func_176208_a(World p_176208_1_, BlockPos p_176208_2_, IBlockState p_176208_3_, EntityPlayer p_176208_4_)
    {
        if (!p_176208_1_.field_72995_K && p_176208_4_.field_71075_bZ.field_75098_d)
        {
            BlockPos blockpos = p_176208_2_.func_177972_a(p_176208_3_.func_177229_b(field_176387_N).func_176734_d());
            Block block = p_176208_1_.func_180495_p(blockpos).func_177230_c();

            if (block == Blocks.field_150331_J || block == Blocks.field_150320_F)
            {
                p_176208_1_.func_175698_g(blockpos);
            }
        }

        super.func_176208_a(p_176208_1_, p_176208_2_, p_176208_3_, p_176208_4_);
    }

    public void func_196243_a(IBlockState p_196243_1_, World p_196243_2_, BlockPos p_196243_3_, IBlockState p_196243_4_, boolean p_196243_5_)
    {
        if (p_196243_1_.func_177230_c() != p_196243_4_.func_177230_c())
        {
            super.func_196243_a(p_196243_1_, p_196243_2_, p_196243_3_, p_196243_4_, p_196243_5_);
            EnumFacing enumfacing = p_196243_1_.func_177229_b(field_176387_N).func_176734_d();
            p_196243_3_ = p_196243_3_.func_177972_a(enumfacing);
            IBlockState iblockstate = p_196243_2_.func_180495_p(p_196243_3_);

            if ((iblockstate.func_177230_c() == Blocks.field_150331_J || iblockstate.func_177230_c() == Blocks.field_150320_F) && iblockstate.func_177229_b(BlockPistonBase.field_176320_b))
            {
                iblockstate.func_196949_c(p_196243_2_, p_196243_3_, 0);
                p_196243_2_.func_175698_g(p_196243_3_);
            }
        }
    }

    public boolean func_149686_d(IBlockState p_149686_1_)
    {
        return false;
    }

    public int func_196264_a(IBlockState p_196264_1_, Random p_196264_2_)
    {
        return 0;
    }

    public IBlockState func_196271_a(IBlockState p_196271_1_, EnumFacing p_196271_2_, IBlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_)
    {
        return p_196271_2_.func_176734_d() == p_196271_1_.func_177229_b(field_176387_N) && !p_196271_1_.func_196955_c(p_196271_4_, p_196271_5_) ? Blocks.field_150350_a.func_176223_P() : super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
    }

    public boolean func_196260_a(IBlockState p_196260_1_, IWorldReaderBase p_196260_2_, BlockPos p_196260_3_)
    {
        Block block = p_196260_2_.func_180495_p(p_196260_3_.func_177972_a(p_196260_1_.func_177229_b(field_176387_N).func_176734_d())).func_177230_c();
        return block == Blocks.field_150331_J || block == Blocks.field_150320_F || block == Blocks.field_196603_bb;
    }

    public void func_189540_a(IBlockState p_189540_1_, World p_189540_2_, BlockPos p_189540_3_, Block p_189540_4_, BlockPos p_189540_5_)
    {
        if (p_189540_1_.func_196955_c(p_189540_2_, p_189540_3_))
        {
            BlockPos blockpos = p_189540_3_.func_177972_a(p_189540_1_.func_177229_b(field_176387_N).func_176734_d());
            p_189540_2_.func_180495_p(blockpos).func_189546_a(p_189540_2_, blockpos, p_189540_4_, p_189540_5_);
        }
    }

    public ItemStack func_185473_a(IBlockReader p_185473_1_, BlockPos p_185473_2_, IBlockState p_185473_3_)
    {
        return new ItemStack(p_185473_3_.func_177229_b(field_176325_b) == PistonType.STICKY ? Blocks.field_150320_F : Blocks.field_150331_J);
    }

    public IBlockState func_185499_a(IBlockState p_185499_1_, Rotation p_185499_2_)
    {
        return p_185499_1_.func_206870_a(field_176387_N, p_185499_2_.func_185831_a(p_185499_1_.func_177229_b(field_176387_N)));
    }

    public IBlockState func_185471_a(IBlockState p_185471_1_, Mirror p_185471_2_)
    {
        return p_185471_1_.func_185907_a(p_185471_2_.func_185800_a(p_185471_1_.func_177229_b(field_176387_N)));
    }

    protected void func_206840_a(StateContainer.Builder<Block, IBlockState> p_206840_1_)
    {
        p_206840_1_.func_206894_a(field_176387_N, field_176325_b, field_176327_M);
    }

    public BlockFaceShape func_193383_a(IBlockReader p_193383_1_, IBlockState p_193383_2_, BlockPos p_193383_3_, EnumFacing p_193383_4_)
    {
        return p_193383_4_ == p_193383_2_.func_177229_b(field_176387_N) ? BlockFaceShape.SOLID : BlockFaceShape.UNDEFINED;
    }

    public boolean func_196266_a(IBlockState p_196266_1_, IBlockReader p_196266_2_, BlockPos p_196266_3_, PathType p_196266_4_)
    {
        return false;
    }
}
