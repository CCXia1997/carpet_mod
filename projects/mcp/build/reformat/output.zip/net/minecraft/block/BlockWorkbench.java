package net.minecraft.block;

import javax.annotation.Nullable;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.ContainerWorkbench;
import net.minecraft.stats.StatList;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.world.IInteractionObject;
import net.minecraft.world.World;

public class BlockWorkbench extends Block
{
    protected BlockWorkbench(Block.Properties p_i48422_1_)
    {
        super(p_i48422_1_);
    }

    public boolean func_196250_a(IBlockState p_196250_1_, World p_196250_2_, BlockPos p_196250_3_, EntityPlayer p_196250_4_, EnumHand p_196250_5_, EnumFacing p_196250_6_, float p_196250_7_, float p_196250_8_, float p_196250_9_)
    {
        if (p_196250_2_.field_72995_K)
        {
            return true;
        }
        else
        {
            p_196250_4_.func_180468_a(new BlockWorkbench.InterfaceCraftingTable(p_196250_2_, p_196250_3_));
            p_196250_4_.func_195066_a(StatList.field_188062_ab);
            return true;
        }
    }

    public static class InterfaceCraftingTable implements IInteractionObject
        {
            private final World field_175128_a;
            private final BlockPos field_175127_b;

            public InterfaceCraftingTable(World p_i45730_1_, BlockPos p_i45730_2_)
            {
                this.field_175128_a = p_i45730_1_;
                this.field_175127_b = p_i45730_2_;
            }

            public ITextComponent func_200200_C_()
            {
                return new TextComponentTranslation(Blocks.field_150462_ai.func_149739_a() + ".name");
            }

            public boolean func_145818_k_()
            {
                return false;
            }

            @Nullable
            public ITextComponent func_200201_e()
            {
                return null;
            }

            public Container func_174876_a(InventoryPlayer p_174876_1_, EntityPlayer p_174876_2_)
            {
                return new ContainerWorkbench(p_174876_1_, this.field_175128_a, this.field_175127_b);
            }

            public String func_174875_k()
            {
                return "minecraft:crafting_table";
            }
        }
}
