package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Items;
import net.minecraft.state.IntegerProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.util.IItemProvider;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.World;

public class BlockBeetroot extends BlockCrops
{
    public static final IntegerProperty field_185531_a = BlockStateProperties.field_208168_U;
    private static final VoxelShape[] field_196394_c = new VoxelShape[] {Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 2.0D, 16.0D), Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 4.0D, 16.0D), Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 6.0D, 16.0D), Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 8.0D, 16.0D)};

    public BlockBeetroot(Block.Properties p_i48441_1_)
    {
        super(p_i48441_1_);
    }

    public IntegerProperty func_185524_e()
    {
        return field_185531_a;
    }

    public int func_185526_g()
    {
        return 3;
    }

    protected IItemProvider func_199772_f()
    {
        return Items.field_185163_cU;
    }

    protected IItemProvider func_199773_g()
    {
        return Items.field_185164_cV;
    }

    public void func_196267_b(IBlockState p_196267_1_, World p_196267_2_, BlockPos p_196267_3_, Random p_196267_4_)
    {
        if (p_196267_4_.nextInt(3) != 0)
        {
            super.func_196267_b(p_196267_1_, p_196267_2_, p_196267_3_, p_196267_4_);
        }
    }

    protected int func_185529_b(World p_185529_1_)
    {
        return super.func_185529_b(p_185529_1_) / 3;
    }

    protected void func_206840_a(StateContainer.Builder<Block, IBlockState> p_206840_1_)
    {
        p_206840_1_.func_206894_a(field_185531_a);
    }

    public VoxelShape func_196244_b(IBlockState p_196244_1_, IBlockReader p_196244_2_, BlockPos p_196244_3_)
    {
        return field_196394_c[p_196244_1_.func_177229_b(this.func_185524_e())];
    }
}
