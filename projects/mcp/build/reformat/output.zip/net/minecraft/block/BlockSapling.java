package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.state.IBlockState;
import net.minecraft.block.trees.AbstractTree;
import net.minecraft.state.IntegerProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.World;

public class BlockSapling extends BlockBush implements IGrowable
{
    public static final IntegerProperty field_176479_b = BlockStateProperties.field_208137_al;
    protected static final VoxelShape field_196386_b = Block.func_208617_a(2.0D, 0.0D, 2.0D, 14.0D, 12.0D, 14.0D);
    private final AbstractTree field_196387_c;

    protected BlockSapling(AbstractTree p_i48337_1_, Block.Properties p_i48337_2_)
    {
        super(p_i48337_2_);
        this.field_196387_c = p_i48337_1_;
        this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_176479_b, Integer.valueOf(0)));
    }

    public VoxelShape func_196244_b(IBlockState p_196244_1_, IBlockReader p_196244_2_, BlockPos p_196244_3_)
    {
        return field_196386_b;
    }

    public void func_196267_b(IBlockState p_196267_1_, World p_196267_2_, BlockPos p_196267_3_, Random p_196267_4_)
    {
        super.func_196267_b(p_196267_1_, p_196267_2_, p_196267_3_, p_196267_4_);

        if (p_196267_2_.func_201696_r(p_196267_3_.func_177984_a()) >= 9 && p_196267_4_.nextInt(7) == 0)
        {
            this.func_176478_d(p_196267_2_, p_196267_3_, p_196267_1_, p_196267_4_);
        }
    }

    public void func_176478_d(IWorld p_176478_1_, BlockPos p_176478_2_, IBlockState p_176478_3_, Random p_176478_4_)
    {
        if (p_176478_3_.func_177229_b(field_176479_b) == 0)
        {
            p_176478_1_.func_180501_a(p_176478_2_, p_176478_3_.func_177231_a(field_176479_b), 4);
        }
        else
        {
            this.field_196387_c.func_196935_a(p_176478_1_, p_176478_2_, p_176478_3_, p_176478_4_);
        }
    }

    public boolean func_176473_a(IBlockReader p_176473_1_, BlockPos p_176473_2_, IBlockState p_176473_3_, boolean p_176473_4_)
    {
        return true;
    }

    public boolean func_180670_a(World p_180670_1_, Random p_180670_2_, BlockPos p_180670_3_, IBlockState p_180670_4_)
    {
        return (double)p_180670_1_.field_73012_v.nextFloat() < 0.45D;
    }

    public void func_176474_b(World p_176474_1_, Random p_176474_2_, BlockPos p_176474_3_, IBlockState p_176474_4_)
    {
        this.func_176478_d(p_176474_1_, p_176474_3_, p_176474_4_, p_176474_2_);
    }

    protected void func_206840_a(StateContainer.Builder<Block, IBlockState> p_206840_1_)
    {
        p_206840_1_.func_206894_a(field_176479_b);
    }
}
