package net.minecraft.block;

import net.minecraft.block.state.IBlockState;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.EnumProperty;
import net.minecraft.state.IProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.state.properties.RailShape;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class BlockRailPowered extends BlockRailBase
{
    public static final EnumProperty<RailShape> field_176568_b = BlockStateProperties.field_208166_S;
    public static final BooleanProperty field_176569_M = BlockStateProperties.field_208194_u;

    protected BlockRailPowered(Block.Properties p_i48349_1_)
    {
        super(true, p_i48349_1_);
        this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_176568_b, RailShape.NORTH_SOUTH).func_206870_a(field_176569_M, Boolean.valueOf(false)));
    }

    protected boolean func_176566_a(World p_176566_1_, BlockPos p_176566_2_, IBlockState p_176566_3_, boolean p_176566_4_, int p_176566_5_)
    {
        if (p_176566_5_ >= 8)
        {
            return false;
        }
        else
        {
            int i = p_176566_2_.func_177958_n();
            int j = p_176566_2_.func_177956_o();
            int k = p_176566_2_.func_177952_p();
            boolean flag = true;
            RailShape railshape = p_176566_3_.func_177229_b(field_176568_b);

            switch (railshape)
            {
                case NORTH_SOUTH:

                    if (p_176566_4_)
                    {
                        ++k;
                    }
                    else
                    {
                        --k;
                    }

                    break;
                case EAST_WEST:

                    if (p_176566_4_)
                    {
                        --i;
                    }
                    else
                    {
                        ++i;
                    }

                    break;
                case ASCENDING_EAST:

                    if (p_176566_4_)
                    {
                        --i;
                    }
                    else
                    {
                        ++i;
                        ++j;
                        flag = false;
                    }

                    railshape = RailShape.EAST_WEST;
                    break;
                case ASCENDING_WEST:

                    if (p_176566_4_)
                    {
                        --i;
                        ++j;
                        flag = false;
                    }
                    else
                    {
                        ++i;
                    }

                    railshape = RailShape.EAST_WEST;
                    break;
                case ASCENDING_NORTH:

                    if (p_176566_4_)
                    {
                        ++k;
                    }
                    else
                    {
                        --k;
                        ++j;
                        flag = false;
                    }

                    railshape = RailShape.NORTH_SOUTH;
                    break;
                case ASCENDING_SOUTH:

                    if (p_176566_4_)
                    {
                        ++k;
                        ++j;
                        flag = false;
                    }
                    else
                    {
                        --k;
                    }

                    railshape = RailShape.NORTH_SOUTH;
            }

            if (this.func_208071_a(p_176566_1_, new BlockPos(i, j, k), p_176566_4_, p_176566_5_, railshape))
            {
                return true;
            }
            else
            {
                return flag && this.func_208071_a(p_176566_1_, new BlockPos(i, j - 1, k), p_176566_4_, p_176566_5_, railshape);
            }
        }
    }

    protected boolean func_208071_a(World p_208071_1_, BlockPos p_208071_2_, boolean p_208071_3_, int p_208071_4_, RailShape p_208071_5_)
    {
        IBlockState iblockstate = p_208071_1_.func_180495_p(p_208071_2_);

        if (iblockstate.func_177230_c() != this)
        {
            return false;
        }
        else
        {
            RailShape railshape = iblockstate.func_177229_b(field_176568_b);

            if (p_208071_5_ != RailShape.EAST_WEST || railshape != RailShape.NORTH_SOUTH && railshape != RailShape.ASCENDING_NORTH && railshape != RailShape.ASCENDING_SOUTH)
            {
                if (p_208071_5_ != RailShape.NORTH_SOUTH || railshape != RailShape.EAST_WEST && railshape != RailShape.ASCENDING_EAST && railshape != RailShape.ASCENDING_WEST)
                {
                    if (iblockstate.func_177229_b(field_176569_M))
                    {
                        return p_208071_1_.func_175640_z(p_208071_2_) ? true : this.func_176566_a(p_208071_1_, p_208071_2_, iblockstate, p_208071_3_, p_208071_4_ + 1);
                    }
                    else
                    {
                        return false;
                    }
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }
    }

    protected void func_189541_b(IBlockState p_189541_1_, World p_189541_2_, BlockPos p_189541_3_, Block p_189541_4_)
    {
        boolean flag = p_189541_1_.func_177229_b(field_176569_M);
        boolean flag1 = p_189541_2_.func_175640_z(p_189541_3_) || this.func_176566_a(p_189541_2_, p_189541_3_, p_189541_1_, true, 0) || this.func_176566_a(p_189541_2_, p_189541_3_, p_189541_1_, false, 0);

        if (flag1 != flag)
        {
            p_189541_2_.func_180501_a(p_189541_3_, p_189541_1_.func_206870_a(field_176569_M, Boolean.valueOf(flag1)), 3);
            p_189541_2_.func_195593_d(p_189541_3_.func_177977_b(), this);

            if (p_189541_1_.func_177229_b(field_176568_b).func_208092_c())
            {
                p_189541_2_.func_195593_d(p_189541_3_.func_177984_a(), this);
            }
        }
    }

    public IProperty<RailShape> func_176560_l()
    {
        return field_176568_b;
    }

    public IBlockState func_185499_a(IBlockState p_185499_1_, Rotation p_185499_2_)
    {
        switch (p_185499_2_)
        {
            case CLOCKWISE_180:

                switch ((RailShape)p_185499_1_.func_177229_b(field_176568_b))
                {
                    case ASCENDING_EAST:
                        return p_185499_1_.func_206870_a(field_176568_b, RailShape.ASCENDING_WEST);
                    case ASCENDING_WEST:
                        return p_185499_1_.func_206870_a(field_176568_b, RailShape.ASCENDING_EAST);
                    case ASCENDING_NORTH:
                        return p_185499_1_.func_206870_a(field_176568_b, RailShape.ASCENDING_SOUTH);
                    case ASCENDING_SOUTH:
                        return p_185499_1_.func_206870_a(field_176568_b, RailShape.ASCENDING_NORTH);
                    case SOUTH_EAST:
                        return p_185499_1_.func_206870_a(field_176568_b, RailShape.NORTH_WEST);
                    case SOUTH_WEST:
                        return p_185499_1_.func_206870_a(field_176568_b, RailShape.NORTH_EAST);
                    case NORTH_WEST:
                        return p_185499_1_.func_206870_a(field_176568_b, RailShape.SOUTH_EAST);
                    case NORTH_EAST:
                        return p_185499_1_.func_206870_a(field_176568_b, RailShape.SOUTH_WEST);
                }

            case COUNTERCLOCKWISE_90:

                switch ((RailShape)p_185499_1_.func_177229_b(field_176568_b))
                {
                    case NORTH_SOUTH:
                        return p_185499_1_.func_206870_a(field_176568_b, RailShape.EAST_WEST);
                    case EAST_WEST:
                        return p_185499_1_.func_206870_a(field_176568_b, RailShape.NORTH_SOUTH);
                    case ASCENDING_EAST:
                        return p_185499_1_.func_206870_a(field_176568_b, RailShape.ASCENDING_NORTH);
                    case ASCENDING_WEST:
                        return p_185499_1_.func_206870_a(field_176568_b, RailShape.ASCENDING_SOUTH);
                    case ASCENDING_NORTH:
                        return p_185499_1_.func_206870_a(field_176568_b, RailShape.ASCENDING_WEST);
                    case ASCENDING_SOUTH:
                        return p_185499_1_.func_206870_a(field_176568_b, RailShape.ASCENDING_EAST);
                    case SOUTH_EAST:
                        return p_185499_1_.func_206870_a(field_176568_b, RailShape.NORTH_EAST);
                    case SOUTH_WEST:
                        return p_185499_1_.func_206870_a(field_176568_b, RailShape.SOUTH_EAST);
                    case NORTH_WEST:
                        return p_185499_1_.func_206870_a(field_176568_b, RailShape.SOUTH_WEST);
                    case NORTH_EAST:
                        return p_185499_1_.func_206870_a(field_176568_b, RailShape.NORTH_WEST);
                }

            case CLOCKWISE_90:

                switch ((RailShape)p_185499_1_.func_177229_b(field_176568_b))
                {
                    case NORTH_SOUTH:
                        return p_185499_1_.func_206870_a(field_176568_b, RailShape.EAST_WEST);
                    case EAST_WEST:
                        return p_185499_1_.func_206870_a(field_176568_b, RailShape.NORTH_SOUTH);
                    case ASCENDING_EAST:
                        return p_185499_1_.func_206870_a(field_176568_b, RailShape.ASCENDING_SOUTH);
                    case ASCENDING_WEST:
                        return p_185499_1_.func_206870_a(field_176568_b, RailShape.ASCENDING_NORTH);
                    case ASCENDING_NORTH:
                        return p_185499_1_.func_206870_a(field_176568_b, RailShape.ASCENDING_EAST);
                    case ASCENDING_SOUTH:
                        return p_185499_1_.func_206870_a(field_176568_b, RailShape.ASCENDING_WEST);
                    case SOUTH_EAST:
                        return p_185499_1_.func_206870_a(field_176568_b, RailShape.SOUTH_WEST);
                    case SOUTH_WEST:
                        return p_185499_1_.func_206870_a(field_176568_b, RailShape.NORTH_WEST);
                    case NORTH_WEST:
                        return p_185499_1_.func_206870_a(field_176568_b, RailShape.NORTH_EAST);
                    case NORTH_EAST:
                        return p_185499_1_.func_206870_a(field_176568_b, RailShape.SOUTH_EAST);
                }

            default:
                return p_185499_1_;
        }
    }

    public IBlockState func_185471_a(IBlockState p_185471_1_, Mirror p_185471_2_)
    {
        RailShape railshape = p_185471_1_.func_177229_b(field_176568_b);

        switch (p_185471_2_)
        {
            case LEFT_RIGHT:

                switch (railshape)
                {
                    case ASCENDING_NORTH:
                        return p_185471_1_.func_206870_a(field_176568_b, RailShape.ASCENDING_SOUTH);
                    case ASCENDING_SOUTH:
                        return p_185471_1_.func_206870_a(field_176568_b, RailShape.ASCENDING_NORTH);
                    case SOUTH_EAST:
                        return p_185471_1_.func_206870_a(field_176568_b, RailShape.NORTH_EAST);
                    case SOUTH_WEST:
                        return p_185471_1_.func_206870_a(field_176568_b, RailShape.NORTH_WEST);
                    case NORTH_WEST:
                        return p_185471_1_.func_206870_a(field_176568_b, RailShape.SOUTH_WEST);
                    case NORTH_EAST:
                        return p_185471_1_.func_206870_a(field_176568_b, RailShape.SOUTH_EAST);
                    default:
                        return super.func_185471_a(p_185471_1_, p_185471_2_);
                }

            case FRONT_BACK:

                switch (railshape)
                {
                    case ASCENDING_EAST:
                        return p_185471_1_.func_206870_a(field_176568_b, RailShape.ASCENDING_WEST);
                    case ASCENDING_WEST:
                        return p_185471_1_.func_206870_a(field_176568_b, RailShape.ASCENDING_EAST);
                    case ASCENDING_NORTH:
                    case ASCENDING_SOUTH:
                    default:
                        break;
                    case SOUTH_EAST:
                        return p_185471_1_.func_206870_a(field_176568_b, RailShape.SOUTH_WEST);
                    case SOUTH_WEST:
                        return p_185471_1_.func_206870_a(field_176568_b, RailShape.SOUTH_EAST);
                    case NORTH_WEST:
                        return p_185471_1_.func_206870_a(field_176568_b, RailShape.NORTH_EAST);
                    case NORTH_EAST:
                        return p_185471_1_.func_206870_a(field_176568_b, RailShape.NORTH_WEST);
                }
        }

        return super.func_185471_a(p_185471_1_, p_185471_2_);
    }

    protected void func_206840_a(StateContainer.Builder<Block, IBlockState> p_206840_1_)
    {
        p_206840_1_.func_206894_a(field_176568_b, field_176569_M);
    }
}
