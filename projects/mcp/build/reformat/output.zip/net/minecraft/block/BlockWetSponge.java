package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Particles;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class BlockWetSponge extends Block
{
    protected BlockWetSponge(Block.Properties p_i48294_1_)
    {
        super(p_i48294_1_);
    }

    @OnlyIn(Dist.CLIENT)
    public void func_180655_c(IBlockState p_180655_1_, World p_180655_2_, BlockPos p_180655_3_, Random p_180655_4_)
    {
        EnumFacing enumfacing = EnumFacing.func_176741_a(p_180655_4_);

        if (enumfacing != EnumFacing.UP && !p_180655_2_.func_180495_p(p_180655_3_.func_177972_a(enumfacing)).func_185896_q())
        {
            double d0 = (double)p_180655_3_.func_177958_n();
            double d1 = (double)p_180655_3_.func_177956_o();
            double d2 = (double)p_180655_3_.func_177952_p();

            if (enumfacing == EnumFacing.DOWN)
            {
                d1 = d1 - 0.05D;
                d0 += p_180655_4_.nextDouble();
                d2 += p_180655_4_.nextDouble();
            }
            else
            {
                d1 = d1 + p_180655_4_.nextDouble() * 0.8D;

                if (enumfacing.func_176740_k() == EnumFacing.Axis.X)
                {
                    d2 += p_180655_4_.nextDouble();

                    if (enumfacing == EnumFacing.EAST)
                    {
                        ++d0;
                    }
                    else
                    {
                        d0 += 0.05D;
                    }
                }
                else
                {
                    d0 += p_180655_4_.nextDouble();

                    if (enumfacing == EnumFacing.SOUTH)
                    {
                        ++d2;
                    }
                    else
                    {
                        d2 += 0.05D;
                    }
                }
            }

            p_180655_2_.func_195594_a(Particles.field_197618_k, d0, d1, d2, 0.0D, 0.0D, 0.0D);
        }
    }
}
