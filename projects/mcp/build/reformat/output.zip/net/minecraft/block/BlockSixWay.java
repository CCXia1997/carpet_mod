package net.minecraft.block;

import com.google.common.collect.Maps;
import java.util.Map;
import net.minecraft.block.state.IBlockState;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.Util;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.shapes.VoxelShapes;
import net.minecraft.world.IBlockReader;

public class BlockSixWay extends Block
{
    private static final EnumFacing[] field_196494_D = EnumFacing.values();
    public static final BooleanProperty field_196488_a = BlockStateProperties.field_208151_D;
    public static final BooleanProperty field_196490_b = BlockStateProperties.field_208152_E;
    public static final BooleanProperty field_196492_c = BlockStateProperties.field_208153_F;
    public static final BooleanProperty field_196495_y = BlockStateProperties.field_208154_G;
    public static final BooleanProperty field_196496_z = BlockStateProperties.field_208149_B;
    public static final BooleanProperty field_196489_A = BlockStateProperties.field_208150_C;
    public static final Map<EnumFacing, BooleanProperty> field_196491_B = Util.func_200696_a(Maps.newEnumMap(EnumFacing.class), (p_203421_0_) ->
    {
        p_203421_0_.put(EnumFacing.NORTH, field_196488_a);
        p_203421_0_.put(EnumFacing.EAST, field_196490_b);
        p_203421_0_.put(EnumFacing.SOUTH, field_196492_c);
        p_203421_0_.put(EnumFacing.WEST, field_196495_y);
        p_203421_0_.put(EnumFacing.UP, field_196496_z);
        p_203421_0_.put(EnumFacing.DOWN, field_196489_A);
    });
    protected final VoxelShape[] field_196493_C;

    protected BlockSixWay(float p_i48355_1_, Block.Properties p_i48355_2_)
    {
        super(p_i48355_2_);
        this.field_196493_C = this.func_196487_d(p_i48355_1_);
    }

    private VoxelShape[] func_196487_d(float p_196487_1_)
    {
        float f = 0.5F - p_196487_1_;
        float f1 = 0.5F + p_196487_1_;
        VoxelShape voxelshape = Block.func_208617_a((double)(f * 16.0F), (double)(f * 16.0F), (double)(f * 16.0F), (double)(f1 * 16.0F), (double)(f1 * 16.0F), (double)(f1 * 16.0F));
        VoxelShape[] avoxelshape = new VoxelShape[field_196494_D.length];

        for (int i = 0; i < field_196494_D.length; ++i)
        {
            EnumFacing enumfacing = field_196494_D[i];
            avoxelshape[i] = VoxelShapes.func_197873_a(0.5D + Math.min((double)(-p_196487_1_), (double)enumfacing.func_82601_c() * 0.5D), 0.5D + Math.min((double)(-p_196487_1_), (double)enumfacing.func_96559_d() * 0.5D), 0.5D + Math.min((double)(-p_196487_1_), (double)enumfacing.func_82599_e() * 0.5D), 0.5D + Math.max((double)p_196487_1_, (double)enumfacing.func_82601_c() * 0.5D), 0.5D + Math.max((double)p_196487_1_, (double)enumfacing.func_96559_d() * 0.5D), 0.5D + Math.max((double)p_196487_1_, (double)enumfacing.func_82599_e() * 0.5D));
        }

        VoxelShape[] avoxelshape1 = new VoxelShape[64];

        for (int k = 0; k < 64; ++k)
        {
            VoxelShape voxelshape1 = voxelshape;

            for (int j = 0; j < field_196494_D.length; ++j)
            {
                if ((k & 1 << j) != 0)
                {
                    voxelshape1 = VoxelShapes.func_197872_a(voxelshape1, avoxelshape[j]);
                }
            }

            avoxelshape1[k] = voxelshape1;
        }

        return avoxelshape1;
    }

    public VoxelShape func_196244_b(IBlockState p_196244_1_, IBlockReader p_196244_2_, BlockPos p_196244_3_)
    {
        return this.field_196493_C[this.func_196486_i(p_196244_1_)];
    }

    protected int func_196486_i(IBlockState p_196486_1_)
    {
        int i = 0;

        for (int j = 0; j < field_196494_D.length; ++j)
        {
            if (p_196486_1_.func_177229_b(field_196491_B.get(field_196494_D[j])))
            {
                i |= 1 << j;
            }
        }

        return i;
    }
}
