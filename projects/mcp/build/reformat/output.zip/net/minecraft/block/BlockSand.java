package net.minecraft.block;

import net.minecraft.block.state.IBlockState;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class BlockSand extends BlockFalling
{
    private final int field_196445_a;

    public BlockSand(int p_i48338_1_, Block.Properties p_i48338_2_)
    {
        super(p_i48338_2_);
        this.field_196445_a = p_i48338_1_;
    }

    @OnlyIn(Dist.CLIENT)
    public int func_189876_x(IBlockState p_189876_1_)
    {
        return this.field_196445_a;
    }
}
