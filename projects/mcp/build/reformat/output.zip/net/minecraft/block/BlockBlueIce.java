package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.state.IBlockState;

public class BlockBlueIce extends BlockBreakable
{
    public BlockBlueIce(Block.Properties p_i48931_1_)
    {
        super(p_i48931_1_);
    }

    public int func_196264_a(IBlockState p_196264_1_, Random p_196264_2_)
    {
        return 0;
    }
}
