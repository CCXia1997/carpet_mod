package net.minecraft.block;

import java.util.Map;
import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.item.ItemStack;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.stats.StatList;
import net.minecraft.tags.BlockTags;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.IItemProvider;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.Util;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.shapes.VoxelShapes;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.IWorldReaderBase;
import net.minecraft.world.World;

public class BlockVine extends Block
{
    public static final BooleanProperty field_176277_a = BlockSixWay.field_196496_z;
    public static final BooleanProperty field_176273_b = BlockSixWay.field_196488_a;
    public static final BooleanProperty field_176278_M = BlockSixWay.field_196490_b;
    public static final BooleanProperty field_176279_N = BlockSixWay.field_196492_c;
    public static final BooleanProperty field_176280_O = BlockSixWay.field_196495_y;
    public static final Map<EnumFacing, BooleanProperty> field_196546_A = BlockSixWay.field_196491_B.entrySet().stream().filter((p_199782_0_) ->
    {
        return p_199782_0_.getKey() != EnumFacing.DOWN;
    }).collect(Util.func_199749_a());
    protected static final VoxelShape field_185757_g = Block.func_208617_a(0.0D, 15.0D, 0.0D, 16.0D, 16.0D, 16.0D);
    protected static final VoxelShape field_185753_B = Block.func_208617_a(0.0D, 0.0D, 0.0D, 1.0D, 16.0D, 16.0D);
    protected static final VoxelShape field_185754_C = Block.func_208617_a(15.0D, 0.0D, 0.0D, 16.0D, 16.0D, 16.0D);
    protected static final VoxelShape field_185755_D = Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 16.0D, 1.0D);
    protected static final VoxelShape field_185756_E = Block.func_208617_a(0.0D, 0.0D, 15.0D, 16.0D, 16.0D, 16.0D);

    public BlockVine(Block.Properties p_i48303_1_)
    {
        super(p_i48303_1_);
        this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_176277_a, Boolean.valueOf(false)).func_206870_a(field_176273_b, Boolean.valueOf(false)).func_206870_a(field_176278_M, Boolean.valueOf(false)).func_206870_a(field_176279_N, Boolean.valueOf(false)).func_206870_a(field_176280_O, Boolean.valueOf(false)));
    }

    public VoxelShape func_196244_b(IBlockState p_196244_1_, IBlockReader p_196244_2_, BlockPos p_196244_3_)
    {
        VoxelShape voxelshape = VoxelShapes.func_197880_a();

        if (p_196244_1_.func_177229_b(field_176277_a))
        {
            voxelshape = VoxelShapes.func_197872_a(voxelshape, field_185757_g);
        }

        if (p_196244_1_.func_177229_b(field_176273_b))
        {
            voxelshape = VoxelShapes.func_197872_a(voxelshape, field_185755_D);
        }

        if (p_196244_1_.func_177229_b(field_176278_M))
        {
            voxelshape = VoxelShapes.func_197872_a(voxelshape, field_185754_C);
        }

        if (p_196244_1_.func_177229_b(field_176279_N))
        {
            voxelshape = VoxelShapes.func_197872_a(voxelshape, field_185756_E);
        }

        if (p_196244_1_.func_177229_b(field_176280_O))
        {
            voxelshape = VoxelShapes.func_197872_a(voxelshape, field_185753_B);
        }

        return voxelshape;
    }

    public boolean func_149686_d(IBlockState p_149686_1_)
    {
        return false;
    }

    public boolean func_196260_a(IBlockState p_196260_1_, IWorldReaderBase p_196260_2_, BlockPos p_196260_3_)
    {
        return this.func_196543_i(this.func_196545_h(p_196260_1_, p_196260_2_, p_196260_3_));
    }

    private boolean func_196543_i(IBlockState p_196543_1_)
    {
        return this.func_208496_w(p_196543_1_) > 0;
    }

    private int func_208496_w(IBlockState p_208496_1_)
    {
        int i = 0;

        for (BooleanProperty booleanproperty : field_196546_A.values())
        {
            if (p_208496_1_.func_177229_b(booleanproperty))
            {
                ++i;
            }
        }

        return i;
    }

    private boolean func_196541_a(IBlockReader p_196541_1_, BlockPos p_196541_2_, EnumFacing p_196541_3_)
    {
        if (p_196541_3_ == EnumFacing.DOWN)
        {
            return false;
        }
        else
        {
            BlockPos blockpos = p_196541_2_.func_177972_a(p_196541_3_);

            if (this.func_196542_b(p_196541_1_, blockpos, p_196541_3_))
            {
                return true;
            }
            else if (p_196541_3_.func_176740_k() == EnumFacing.Axis.Y)
            {
                return false;
            }
            else
            {
                BooleanProperty booleanproperty = field_196546_A.get(p_196541_3_);
                IBlockState iblockstate = p_196541_1_.func_180495_p(p_196541_2_.func_177984_a());
                return iblockstate.func_177230_c() == this && iblockstate.func_177229_b(booleanproperty);
            }
        }
    }

    private boolean func_196542_b(IBlockReader p_196542_1_, BlockPos p_196542_2_, EnumFacing p_196542_3_)
    {
        IBlockState iblockstate = p_196542_1_.func_180495_p(p_196542_2_);
        return iblockstate.func_193401_d(p_196542_1_, p_196542_2_, p_196542_3_.func_176734_d()) == BlockFaceShape.SOLID && !func_193397_e(iblockstate.func_177230_c());
    }

    protected static boolean func_193397_e(Block p_193397_0_)
    {
        return p_193397_0_ instanceof BlockShulkerBox || p_193397_0_ instanceof BlockStainedGlass || p_193397_0_ == Blocks.field_150461_bJ || p_193397_0_ == Blocks.field_150383_bp || p_193397_0_ == Blocks.field_150359_w || p_193397_0_ == Blocks.field_150331_J || p_193397_0_ == Blocks.field_150320_F || p_193397_0_ == Blocks.field_150332_K || p_193397_0_.func_203417_a(BlockTags.field_212186_k);
    }

    private IBlockState func_196545_h(IBlockState p_196545_1_, IBlockReader p_196545_2_, BlockPos p_196545_3_)
    {
        BlockPos blockpos = p_196545_3_.func_177984_a();

        if (p_196545_1_.func_177229_b(field_176277_a))
        {
            p_196545_1_ = p_196545_1_.func_206870_a(field_176277_a, Boolean.valueOf(this.func_196542_b(p_196545_2_, blockpos, EnumFacing.DOWN)));
        }

        IBlockState iblockstate = null;

        for (EnumFacing enumfacing : EnumFacing.Plane.HORIZONTAL)
        {
            BooleanProperty booleanproperty = func_176267_a(enumfacing);

            if (p_196545_1_.func_177229_b(booleanproperty))
            {
                boolean flag = this.func_196541_a(p_196545_2_, p_196545_3_, enumfacing);

                if (!flag)
                {
                    if (iblockstate == null)
                    {
                        iblockstate = p_196545_2_.func_180495_p(blockpos);
                    }

                    flag = iblockstate.func_177230_c() == this && iblockstate.func_177229_b(booleanproperty);
                }

                p_196545_1_ = p_196545_1_.func_206870_a(booleanproperty, Boolean.valueOf(flag));
            }
        }

        return p_196545_1_;
    }

    public IBlockState func_196271_a(IBlockState p_196271_1_, EnumFacing p_196271_2_, IBlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_)
    {
        if (p_196271_2_ == EnumFacing.DOWN)
        {
            return super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
        }
        else
        {
            IBlockState iblockstate = this.func_196545_h(p_196271_1_, p_196271_4_, p_196271_5_);
            return !this.func_196543_i(iblockstate) ? Blocks.field_150350_a.func_176223_P() : iblockstate;
        }
    }

    public void func_196267_b(IBlockState p_196267_1_, World p_196267_2_, BlockPos p_196267_3_, Random p_196267_4_)
    {
        if (!p_196267_2_.field_72995_K)
        {
            IBlockState iblockstate = this.func_196545_h(p_196267_1_, p_196267_2_, p_196267_3_);

            if (iblockstate != p_196267_1_)
            {
                if (this.func_196543_i(iblockstate))
                {
                    p_196267_2_.func_180501_a(p_196267_3_, iblockstate, 2);
                }
                else
                {
                    p_196267_1_.func_196949_c(p_196267_2_, p_196267_3_, 0);
                    p_196267_2_.func_175698_g(p_196267_3_);
                }
            }
            else if (p_196267_2_.field_73012_v.nextInt(4) == 0)
            {
                EnumFacing enumfacing = EnumFacing.func_176741_a(p_196267_4_);
                BlockPos blockpos = p_196267_3_.func_177984_a();

                if (enumfacing.func_176740_k().func_176722_c() && !p_196267_1_.func_177229_b(func_176267_a(enumfacing)))
                {
                    if (this.func_196539_a(p_196267_2_, p_196267_3_))
                    {
                        BlockPos blockpos4 = p_196267_3_.func_177972_a(enumfacing);
                        IBlockState iblockstate5 = p_196267_2_.func_180495_p(blockpos4);

                        if (iblockstate5.func_196958_f())
                        {
                            EnumFacing enumfacing3 = enumfacing.func_176746_e();
                            EnumFacing enumfacing4 = enumfacing.func_176735_f();
                            boolean flag = p_196267_1_.func_177229_b(func_176267_a(enumfacing3));
                            boolean flag1 = p_196267_1_.func_177229_b(func_176267_a(enumfacing4));
                            BlockPos blockpos2 = blockpos4.func_177972_a(enumfacing3);
                            BlockPos blockpos3 = blockpos4.func_177972_a(enumfacing4);

                            if (flag && this.func_196542_b(p_196267_2_, blockpos2, enumfacing3))
                            {
                                p_196267_2_.func_180501_a(blockpos4, this.func_176223_P().func_206870_a(func_176267_a(enumfacing3), Boolean.valueOf(true)), 2);
                            }
                            else if (flag1 && this.func_196542_b(p_196267_2_, blockpos3, enumfacing4))
                            {
                                p_196267_2_.func_180501_a(blockpos4, this.func_176223_P().func_206870_a(func_176267_a(enumfacing4), Boolean.valueOf(true)), 2);
                            }
                            else
                            {
                                EnumFacing enumfacing1 = enumfacing.func_176734_d();

                                if (flag && p_196267_2_.func_175623_d(blockpos2) && this.func_196542_b(p_196267_2_, p_196267_3_.func_177972_a(enumfacing3), enumfacing1))
                                {
                                    p_196267_2_.func_180501_a(blockpos2, this.func_176223_P().func_206870_a(func_176267_a(enumfacing1), Boolean.valueOf(true)), 2);
                                }
                                else if (flag1 && p_196267_2_.func_175623_d(blockpos3) && this.func_196542_b(p_196267_2_, p_196267_3_.func_177972_a(enumfacing4), enumfacing1))
                                {
                                    p_196267_2_.func_180501_a(blockpos3, this.func_176223_P().func_206870_a(func_176267_a(enumfacing1), Boolean.valueOf(true)), 2);
                                }
                                else if ((double)p_196267_2_.field_73012_v.nextFloat() < 0.05D && this.func_196542_b(p_196267_2_, blockpos4.func_177984_a(), EnumFacing.UP))
                                {
                                    p_196267_2_.func_180501_a(blockpos4, this.func_176223_P().func_206870_a(field_176277_a, Boolean.valueOf(true)), 2);
                                }
                            }
                        }
                        else if (this.func_196542_b(p_196267_2_, blockpos4, enumfacing))
                        {
                            p_196267_2_.func_180501_a(p_196267_3_, p_196267_1_.func_206870_a(func_176267_a(enumfacing), Boolean.valueOf(true)), 2);
                        }
                    }
                }
                else
                {
                    if (enumfacing == EnumFacing.UP && p_196267_3_.func_177956_o() < 255)
                    {
                        if (this.func_196541_a(p_196267_2_, p_196267_3_, enumfacing))
                        {
                            p_196267_2_.func_180501_a(p_196267_3_, p_196267_1_.func_206870_a(field_176277_a, Boolean.valueOf(true)), 2);
                            return;
                        }

                        if (p_196267_2_.func_175623_d(blockpos))
                        {
                            if (!this.func_196539_a(p_196267_2_, p_196267_3_))
                            {
                                return;
                            }

                            IBlockState iblockstate4 = p_196267_1_;

                            for (EnumFacing enumfacing2 : EnumFacing.Plane.HORIZONTAL)
                            {
                                if (p_196267_4_.nextBoolean() || !this.func_196542_b(p_196267_2_, blockpos.func_177972_a(enumfacing2), EnumFacing.UP))
                                {
                                    iblockstate4 = iblockstate4.func_206870_a(func_176267_a(enumfacing2), Boolean.valueOf(false));
                                }
                            }

                            if (this.func_196540_x(iblockstate4))
                            {
                                p_196267_2_.func_180501_a(blockpos, iblockstate4, 2);
                            }

                            return;
                        }
                    }

                    if (p_196267_3_.func_177956_o() > 0)
                    {
                        BlockPos blockpos1 = p_196267_3_.func_177977_b();
                        IBlockState iblockstate1 = p_196267_2_.func_180495_p(blockpos1);

                        if (iblockstate1.func_196958_f() || iblockstate1.func_177230_c() == this)
                        {
                            IBlockState iblockstate2 = iblockstate1.func_196958_f() ? this.func_176223_P() : iblockstate1;
                            IBlockState iblockstate3 = this.func_196544_a(p_196267_1_, iblockstate2, p_196267_4_);

                            if (iblockstate2 != iblockstate3 && this.func_196540_x(iblockstate3))
                            {
                                p_196267_2_.func_180501_a(blockpos1, iblockstate3, 2);
                            }
                        }
                    }
                }
            }
        }
    }

    private IBlockState func_196544_a(IBlockState p_196544_1_, IBlockState p_196544_2_, Random p_196544_3_)
    {
        for (EnumFacing enumfacing : EnumFacing.Plane.HORIZONTAL)
        {
            if (p_196544_3_.nextBoolean())
            {
                BooleanProperty booleanproperty = func_176267_a(enumfacing);

                if (p_196544_1_.func_177229_b(booleanproperty))
                {
                    p_196544_2_ = p_196544_2_.func_206870_a(booleanproperty, Boolean.valueOf(true));
                }
            }
        }

        return p_196544_2_;
    }

    private boolean func_196540_x(IBlockState p_196540_1_)
    {
        return p_196540_1_.func_177229_b(field_176273_b) || p_196540_1_.func_177229_b(field_176278_M) || p_196540_1_.func_177229_b(field_176279_N) || p_196540_1_.func_177229_b(field_176280_O);
    }

    private boolean func_196539_a(IBlockReader p_196539_1_, BlockPos p_196539_2_)
    {
        int i = 4;
        Iterable<BlockPos.MutableBlockPos> iterable = BlockPos.MutableBlockPos.func_191531_b(p_196539_2_.func_177958_n() - 4, p_196539_2_.func_177956_o() - 1, p_196539_2_.func_177952_p() - 4, p_196539_2_.func_177958_n() + 4, p_196539_2_.func_177956_o() + 1, p_196539_2_.func_177952_p() + 4);
        int j = 5;

        for (BlockPos blockpos : iterable)
        {
            if (p_196539_1_.func_180495_p(blockpos).func_177230_c() == this)
            {
                --j;

                if (j <= 0)
                {
                    return false;
                }
            }
        }

        return true;
    }

    public boolean func_196253_a(IBlockState p_196253_1_, BlockItemUseContext p_196253_2_)
    {
        IBlockState iblockstate = p_196253_2_.func_195991_k().func_180495_p(p_196253_2_.func_195995_a());

        if (iblockstate.func_177230_c() == this)
        {
            return this.func_208496_w(iblockstate) < field_196546_A.size();
        }
        else
        {
            return super.func_196253_a(p_196253_1_, p_196253_2_);
        }
    }

    @Nullable
    public IBlockState func_196258_a(BlockItemUseContext p_196258_1_)
    {
        IBlockState iblockstate = p_196258_1_.func_195991_k().func_180495_p(p_196258_1_.func_195995_a());
        boolean flag = iblockstate.func_177230_c() == this;
        IBlockState iblockstate1 = flag ? iblockstate : this.func_176223_P();

        for (EnumFacing enumfacing : p_196258_1_.func_196009_e())
        {
            if (enumfacing != EnumFacing.DOWN)
            {
                BooleanProperty booleanproperty = func_176267_a(enumfacing);
                boolean flag1 = flag && iblockstate.func_177229_b(booleanproperty);

                if (!flag1 && this.func_196541_a(p_196258_1_.func_195991_k(), p_196258_1_.func_195995_a(), enumfacing))
                {
                    return iblockstate1.func_206870_a(booleanproperty, Boolean.valueOf(true));
                }
            }
        }

        return flag ? iblockstate1 : null;
    }

    public IItemProvider func_199769_a(IBlockState p_199769_1_, World p_199769_2_, BlockPos p_199769_3_, int p_199769_4_)
    {
        return Items.field_190931_a;
    }

    public void func_180657_a(World p_180657_1_, EntityPlayer p_180657_2_, BlockPos p_180657_3_, IBlockState p_180657_4_, @Nullable TileEntity p_180657_5_, ItemStack p_180657_6_)
    {
        if (!p_180657_1_.field_72995_K && p_180657_6_.func_77973_b() == Items.field_151097_aZ)
        {
            p_180657_2_.func_71029_a(StatList.field_188065_ae.func_199076_b(this));
            p_180657_2_.func_71020_j(0.005F);
            func_180635_a(p_180657_1_, p_180657_3_, new ItemStack(Blocks.field_150395_bd));
        }
        else
        {
            super.func_180657_a(p_180657_1_, p_180657_2_, p_180657_3_, p_180657_4_, p_180657_5_, p_180657_6_);
        }
    }

    public BlockRenderLayer func_180664_k()
    {
        return BlockRenderLayer.CUTOUT;
    }

    protected void func_206840_a(StateContainer.Builder<Block, IBlockState> p_206840_1_)
    {
        p_206840_1_.func_206894_a(field_176277_a, field_176273_b, field_176278_M, field_176279_N, field_176280_O);
    }

    public IBlockState func_185499_a(IBlockState p_185499_1_, Rotation p_185499_2_)
    {
        switch (p_185499_2_)
        {
            case CLOCKWISE_180:
                return p_185499_1_.func_206870_a(field_176273_b, p_185499_1_.func_177229_b(field_176279_N)).func_206870_a(field_176278_M, p_185499_1_.func_177229_b(field_176280_O)).func_206870_a(field_176279_N, p_185499_1_.func_177229_b(field_176273_b)).func_206870_a(field_176280_O, p_185499_1_.func_177229_b(field_176278_M));
            case COUNTERCLOCKWISE_90:
                return p_185499_1_.func_206870_a(field_176273_b, p_185499_1_.func_177229_b(field_176278_M)).func_206870_a(field_176278_M, p_185499_1_.func_177229_b(field_176279_N)).func_206870_a(field_176279_N, p_185499_1_.func_177229_b(field_176280_O)).func_206870_a(field_176280_O, p_185499_1_.func_177229_b(field_176273_b));
            case CLOCKWISE_90:
                return p_185499_1_.func_206870_a(field_176273_b, p_185499_1_.func_177229_b(field_176280_O)).func_206870_a(field_176278_M, p_185499_1_.func_177229_b(field_176273_b)).func_206870_a(field_176279_N, p_185499_1_.func_177229_b(field_176278_M)).func_206870_a(field_176280_O, p_185499_1_.func_177229_b(field_176279_N));
            default:
                return p_185499_1_;
        }
    }

    public IBlockState func_185471_a(IBlockState p_185471_1_, Mirror p_185471_2_)
    {
        switch (p_185471_2_)
        {
            case LEFT_RIGHT:
                return p_185471_1_.func_206870_a(field_176273_b, p_185471_1_.func_177229_b(field_176279_N)).func_206870_a(field_176279_N, p_185471_1_.func_177229_b(field_176273_b));
            case FRONT_BACK:
                return p_185471_1_.func_206870_a(field_176278_M, p_185471_1_.func_177229_b(field_176280_O)).func_206870_a(field_176280_O, p_185471_1_.func_177229_b(field_176278_M));
            default:
                return super.func_185471_a(p_185471_1_, p_185471_2_);
        }
    }

    public static BooleanProperty func_176267_a(EnumFacing p_176267_0_)
    {
        return field_196546_A.get(p_176267_0_);
    }

    public BlockFaceShape func_193383_a(IBlockReader p_193383_1_, IBlockState p_193383_2_, BlockPos p_193383_3_, EnumFacing p_193383_4_)
    {
        return BlockFaceShape.UNDEFINED;
    }
}
