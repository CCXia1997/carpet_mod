package net.minecraft.block;

import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Particles;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.EnumProperty;
import net.minecraft.state.IntegerProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.state.properties.NoteBlockInstrument;
import net.minecraft.stats.StatList;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IWorld;
import net.minecraft.world.World;

public class BlockNote extends Block
{
    public static final EnumProperty<NoteBlockInstrument> field_196483_a = BlockStateProperties.field_208143_ar;
    public static final BooleanProperty field_196484_b = BlockStateProperties.field_208194_u;
    public static final IntegerProperty field_196485_c = BlockStateProperties.field_208134_ai;

    public BlockNote(Block.Properties p_i48359_1_)
    {
        super(p_i48359_1_);
        this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_196483_a, NoteBlockInstrument.HARP).func_206870_a(field_196485_c, Integer.valueOf(0)).func_206870_a(field_196484_b, Boolean.valueOf(false)));
    }

    public IBlockState func_196258_a(BlockItemUseContext p_196258_1_)
    {
        return this.func_176223_P().func_206870_a(field_196483_a, NoteBlockInstrument.func_208087_a(p_196258_1_.func_195991_k().func_180495_p(p_196258_1_.func_195995_a().func_177977_b())));
    }

    public IBlockState func_196271_a(IBlockState p_196271_1_, EnumFacing p_196271_2_, IBlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_)
    {
        return p_196271_2_ == EnumFacing.DOWN ? p_196271_1_.func_206870_a(field_196483_a, NoteBlockInstrument.func_208087_a(p_196271_3_)) : super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
    }

    public void func_189540_a(IBlockState p_189540_1_, World p_189540_2_, BlockPos p_189540_3_, Block p_189540_4_, BlockPos p_189540_5_)
    {
        boolean flag = p_189540_2_.func_175640_z(p_189540_3_);

        if (flag != p_189540_1_.func_177229_b(field_196484_b))
        {
            if (flag)
            {
                this.func_196482_a(p_189540_2_, p_189540_3_);
            }

            p_189540_2_.func_180501_a(p_189540_3_, p_189540_1_.func_206870_a(field_196484_b, Boolean.valueOf(flag)), 3);
        }
    }

    private void func_196482_a(World p_196482_1_, BlockPos p_196482_2_)
    {
        if (p_196482_1_.func_180495_p(p_196482_2_.func_177984_a()).func_196958_f())
        {
            p_196482_1_.func_175641_c(p_196482_2_, this, 0, 0);
        }
    }

    public boolean func_196250_a(IBlockState p_196250_1_, World p_196250_2_, BlockPos p_196250_3_, EntityPlayer p_196250_4_, EnumHand p_196250_5_, EnumFacing p_196250_6_, float p_196250_7_, float p_196250_8_, float p_196250_9_)
    {
        if (p_196250_2_.field_72995_K)
        {
            return true;
        }
        else
        {
            p_196250_1_ = p_196250_1_.func_177231_a(field_196485_c);
            p_196250_2_.func_180501_a(p_196250_3_, p_196250_1_, 3);
            this.func_196482_a(p_196250_2_, p_196250_3_);
            p_196250_4_.func_195066_a(StatList.field_188087_U);
            return true;
        }
    }

    public void func_196270_a(IBlockState p_196270_1_, World p_196270_2_, BlockPos p_196270_3_, EntityPlayer p_196270_4_)
    {
        if (!p_196270_2_.field_72995_K)
        {
            this.func_196482_a(p_196270_2_, p_196270_3_);
            p_196270_4_.func_195066_a(StatList.field_188086_T);
        }
    }

    public boolean func_189539_a(IBlockState p_189539_1_, World p_189539_2_, BlockPos p_189539_3_, int p_189539_4_, int p_189539_5_)
    {
        int i = p_189539_1_.func_177229_b(field_196485_c);
        float f = (float)Math.pow(2.0D, (double)(i - 12) / 12.0D);
        p_189539_2_.func_184133_a((EntityPlayer)null, p_189539_3_, p_189539_1_.func_177229_b(field_196483_a).func_208088_a(), SoundCategory.RECORDS, 3.0F, f);
        p_189539_2_.func_195594_a(Particles.field_197597_H, (double)p_189539_3_.func_177958_n() + 0.5D, (double)p_189539_3_.func_177956_o() + 1.2D, (double)p_189539_3_.func_177952_p() + 0.5D, (double)i / 24.0D, 0.0D, 0.0D);
        return true;
    }

    protected void func_206840_a(StateContainer.Builder<Block, IBlockState> p_206840_1_)
    {
        p_206840_1_.func_206894_a(field_196483_a, field_196484_b, field_196485_c);
    }
}
