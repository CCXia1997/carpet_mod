package net.minecraft.block;

import net.minecraft.block.state.IBlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.IBlockReader;

public class BlockFlower extends BlockBush
{
    protected static final VoxelShape field_196398_a = Block.func_208617_a(5.0D, 0.0D, 5.0D, 11.0D, 10.0D, 11.0D);

    public BlockFlower(Block.Properties p_i48396_1_)
    {
        super(p_i48396_1_);
    }

    public VoxelShape func_196244_b(IBlockState p_196244_1_, IBlockReader p_196244_2_, BlockPos p_196244_3_)
    {
        Vec3d vec3d = p_196244_1_.func_191059_e(p_196244_2_, p_196244_3_);
        return field_196398_a.func_197751_a(vec3d.field_72450_a, vec3d.field_72448_b, vec3d.field_72449_c);
    }

    public Block.EnumOffsetType func_176218_Q()
    {
        return Block.EnumOffsetType.XZ;
    }
}
