package net.minecraft.block;

import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.passive.EntityOcelot;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.fluid.Fluid;
import net.minecraft.fluid.IFluidState;
import net.minecraft.init.Fluids;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.InventoryHelper;
import net.minecraft.inventory.InventoryLargeChest;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.item.ItemStack;
import net.minecraft.pathfinding.PathType;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.DirectionProperty;
import net.minecraft.state.EnumProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.state.properties.ChestType;
import net.minecraft.stats.Stat;
import net.minecraft.stats.StatList;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityChest;
import net.minecraft.util.EnumBlockRenderType;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.Mirror;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.ILockableContainer;
import net.minecraft.world.IWorld;
import net.minecraft.world.World;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class BlockChest extends BlockContainer implements IBucketPickupHandler, ILiquidContainer
{
    public static final DirectionProperty field_176459_a = BlockHorizontal.field_185512_D;
    public static final EnumProperty<ChestType> field_196314_b = BlockStateProperties.field_208140_ao;
    public static final BooleanProperty field_204511_c = BlockStateProperties.field_208198_y;
    protected static final VoxelShape field_196316_c = Block.func_208617_a(1.0D, 0.0D, 0.0D, 15.0D, 14.0D, 15.0D);
    protected static final VoxelShape field_196317_y = Block.func_208617_a(1.0D, 0.0D, 1.0D, 15.0D, 14.0D, 16.0D);
    protected static final VoxelShape field_196318_z = Block.func_208617_a(0.0D, 0.0D, 1.0D, 15.0D, 14.0D, 15.0D);
    protected static final VoxelShape field_196313_A = Block.func_208617_a(1.0D, 0.0D, 1.0D, 16.0D, 14.0D, 15.0D);
    protected static final VoxelShape field_196315_B = Block.func_208617_a(1.0D, 0.0D, 1.0D, 15.0D, 14.0D, 15.0D);

    protected BlockChest(Block.Properties p_i48430_1_)
    {
        super(p_i48430_1_);
        this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_176459_a, EnumFacing.NORTH).func_206870_a(field_196314_b, ChestType.SINGLE).func_206870_a(field_204511_c, Boolean.valueOf(false)));
    }

    public boolean func_149686_d(IBlockState p_149686_1_)
    {
        return false;
    }

    @OnlyIn(Dist.CLIENT)
    public boolean func_190946_v(IBlockState p_190946_1_)
    {
        return true;
    }

    public EnumBlockRenderType func_149645_b(IBlockState p_149645_1_)
    {
        return EnumBlockRenderType.ENTITYBLOCK_ANIMATED;
    }

    public IBlockState func_196271_a(IBlockState p_196271_1_, EnumFacing p_196271_2_, IBlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_)
    {
        if (p_196271_1_.func_177229_b(field_204511_c))
        {
            p_196271_4_.func_205219_F_().func_205360_a(p_196271_5_, Fluids.field_204546_a, Fluids.field_204546_a.func_205569_a(p_196271_4_));
        }

        if (p_196271_3_.func_177230_c() == this && p_196271_2_.func_176740_k().func_176722_c())
        {
            ChestType chesttype = p_196271_3_.func_177229_b(field_196314_b);

            if (p_196271_1_.func_177229_b(field_196314_b) == ChestType.SINGLE && chesttype != ChestType.SINGLE && p_196271_1_.func_177229_b(field_176459_a) == p_196271_3_.func_177229_b(field_176459_a) && func_196311_i(p_196271_3_) == p_196271_2_.func_176734_d())
            {
                return p_196271_1_.func_206870_a(field_196314_b, chesttype.func_208081_a());
            }
        }
        else if (func_196311_i(p_196271_1_) == p_196271_2_)
        {
            return p_196271_1_.func_206870_a(field_196314_b, ChestType.SINGLE);
        }

        return super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
    }

    public VoxelShape func_196244_b(IBlockState p_196244_1_, IBlockReader p_196244_2_, BlockPos p_196244_3_)
    {
        if (p_196244_1_.func_177229_b(field_196314_b) == ChestType.SINGLE)
        {
            return field_196315_B;
        }
        else
        {
            switch (func_196311_i(p_196244_1_))
            {
                case NORTH:
                default:
                    return field_196316_c;
                case SOUTH:
                    return field_196317_y;
                case WEST:
                    return field_196318_z;
                case EAST:
                    return field_196313_A;
            }
        }
    }

    public static EnumFacing func_196311_i(IBlockState p_196311_0_)
    {
        EnumFacing enumfacing = p_196311_0_.func_177229_b(field_176459_a);
        return p_196311_0_.func_177229_b(field_196314_b) == ChestType.LEFT ? enumfacing.func_176746_e() : enumfacing.func_176735_f();
    }

    public IBlockState func_196258_a(BlockItemUseContext p_196258_1_)
    {
        ChestType chesttype = ChestType.SINGLE;
        EnumFacing enumfacing = p_196258_1_.func_195992_f().func_176734_d();
        IFluidState ifluidstate = p_196258_1_.func_195991_k().func_204610_c(p_196258_1_.func_195995_a());
        boolean flag = p_196258_1_.func_195998_g();
        EnumFacing enumfacing1 = p_196258_1_.func_196000_l();

        if (enumfacing1.func_176740_k().func_176722_c() && flag)
        {
            EnumFacing enumfacing2 = this.func_196312_a(p_196258_1_, enumfacing1.func_176734_d());

            if (enumfacing2 != null && enumfacing2.func_176740_k() != enumfacing1.func_176740_k())
            {
                enumfacing = enumfacing2;
                chesttype = enumfacing2.func_176735_f() == enumfacing1.func_176734_d() ? ChestType.RIGHT : ChestType.LEFT;
            }
        }

        if (chesttype == ChestType.SINGLE && !flag)
        {
            if (enumfacing == this.func_196312_a(p_196258_1_, enumfacing.func_176746_e()))
            {
                chesttype = ChestType.LEFT;
            }
            else if (enumfacing == this.func_196312_a(p_196258_1_, enumfacing.func_176735_f()))
            {
                chesttype = ChestType.RIGHT;
            }
        }

        return this.func_176223_P().func_206870_a(field_176459_a, enumfacing).func_206870_a(field_196314_b, chesttype).func_206870_a(field_204511_c, Boolean.valueOf(ifluidstate.func_206886_c() == Fluids.field_204546_a));
    }

    public Fluid func_204508_a(IWorld p_204508_1_, BlockPos p_204508_2_, IBlockState p_204508_3_)
    {
        if (p_204508_3_.func_177229_b(field_204511_c))
        {
            p_204508_1_.func_180501_a(p_204508_2_, p_204508_3_.func_206870_a(field_204511_c, Boolean.valueOf(false)), 3);
            return Fluids.field_204546_a;
        }
        else
        {
            return Fluids.field_204541_a;
        }
    }

    public IFluidState func_204507_t(IBlockState p_204507_1_)
    {
        return p_204507_1_.func_177229_b(field_204511_c) ? Fluids.field_204546_a.func_207204_a(false) : super.func_204507_t(p_204507_1_);
    }

    public boolean func_204510_a(IBlockReader p_204510_1_, BlockPos p_204510_2_, IBlockState p_204510_3_, Fluid p_204510_4_)
    {
        return !p_204510_3_.func_177229_b(field_204511_c) && p_204510_4_ == Fluids.field_204546_a;
    }

    public boolean func_204509_a(IWorld p_204509_1_, BlockPos p_204509_2_, IBlockState p_204509_3_, IFluidState p_204509_4_)
    {
        if (!p_204509_3_.func_177229_b(field_204511_c) && p_204509_4_.func_206886_c() == Fluids.field_204546_a)
        {
            if (!p_204509_1_.func_201670_d())
            {
                p_204509_1_.func_180501_a(p_204509_2_, p_204509_3_.func_206870_a(field_204511_c, Boolean.valueOf(true)), 3);
                p_204509_1_.func_205219_F_().func_205360_a(p_204509_2_, Fluids.field_204546_a, Fluids.field_204546_a.func_205569_a(p_204509_1_));
            }

            return true;
        }
        else
        {
            return false;
        }
    }

    @Nullable
    private EnumFacing func_196312_a(BlockItemUseContext p_196312_1_, EnumFacing p_196312_2_)
    {
        IBlockState iblockstate = p_196312_1_.func_195991_k().func_180495_p(p_196312_1_.func_195995_a().func_177972_a(p_196312_2_));
        return iblockstate.func_177230_c() == this && iblockstate.func_177229_b(field_196314_b) == ChestType.SINGLE ? iblockstate.func_177229_b(field_176459_a) : null;
    }

    public void func_180633_a(World p_180633_1_, BlockPos p_180633_2_, IBlockState p_180633_3_, EntityLivingBase p_180633_4_, ItemStack p_180633_5_)
    {
        if (p_180633_5_.func_82837_s())
        {
            TileEntity tileentity = p_180633_1_.func_175625_s(p_180633_2_);

            if (tileentity instanceof TileEntityChest)
            {
                ((TileEntityChest)tileentity).func_200226_a(p_180633_5_.func_200301_q());
            }
        }
    }

    public void func_196243_a(IBlockState p_196243_1_, World p_196243_2_, BlockPos p_196243_3_, IBlockState p_196243_4_, boolean p_196243_5_)
    {
        if (p_196243_1_.func_177230_c() != p_196243_4_.func_177230_c())
        {
            TileEntity tileentity = p_196243_2_.func_175625_s(p_196243_3_);

            if (tileentity instanceof IInventory)
            {
                InventoryHelper.func_180175_a(p_196243_2_, p_196243_3_, (IInventory)tileentity);
                p_196243_2_.func_175666_e(p_196243_3_, this);
            }

            super.func_196243_a(p_196243_1_, p_196243_2_, p_196243_3_, p_196243_4_, p_196243_5_);
        }
    }

    public boolean func_196250_a(IBlockState p_196250_1_, World p_196250_2_, BlockPos p_196250_3_, EntityPlayer p_196250_4_, EnumHand p_196250_5_, EnumFacing p_196250_6_, float p_196250_7_, float p_196250_8_, float p_196250_9_)
    {
        if (p_196250_2_.field_72995_K)
        {
            return true;
        }
        else
        {
            ILockableContainer ilockablecontainer = this.func_196309_a(p_196250_1_, p_196250_2_, p_196250_3_, false);

            if (ilockablecontainer != null)
            {
                p_196250_4_.func_71007_a(ilockablecontainer);
                p_196250_4_.func_71029_a(this.func_196310_d());
            }

            return true;
        }
    }

    protected Stat<ResourceLocation> func_196310_d()
    {
        return StatList.field_199092_j.func_199076_b(StatList.field_188063_ac);
    }

    @Nullable
    public ILockableContainer func_196309_a(IBlockState p_196309_1_, World p_196309_2_, BlockPos p_196309_3_, boolean p_196309_4_)
    {
        TileEntity tileentity = p_196309_2_.func_175625_s(p_196309_3_);

        if (!(tileentity instanceof TileEntityChest))
        {
            return null;
        }
        else if (!p_196309_4_ && this.func_176457_m(p_196309_2_, p_196309_3_))
        {
            return null;
        }
        else
        {
            ILockableContainer ilockablecontainer = (TileEntityChest)tileentity;
            ChestType chesttype = p_196309_1_.func_177229_b(field_196314_b);

            if (chesttype == ChestType.SINGLE)
            {
                return ilockablecontainer;
            }
            else
            {
                BlockPos blockpos = p_196309_3_.func_177972_a(func_196311_i(p_196309_1_));
                IBlockState iblockstate = p_196309_2_.func_180495_p(blockpos);

                if (iblockstate.func_177230_c() == this)
                {
                    ChestType chesttype1 = iblockstate.func_177229_b(field_196314_b);

                    if (chesttype1 != ChestType.SINGLE && chesttype != chesttype1 && iblockstate.func_177229_b(field_176459_a) == p_196309_1_.func_177229_b(field_176459_a))
                    {
                        if (!p_196309_4_ && this.func_176457_m(p_196309_2_, blockpos))
                        {
                            return null;
                        }

                        TileEntity tileentity1 = p_196309_2_.func_175625_s(blockpos);

                        if (tileentity1 instanceof TileEntityChest)
                        {
                            ILockableContainer ilockablecontainer1 = chesttype == ChestType.RIGHT ? ilockablecontainer : (ILockableContainer)tileentity1;
                            ILockableContainer ilockablecontainer2 = chesttype == ChestType.RIGHT ? (ILockableContainer)tileentity1 : ilockablecontainer;
                            ilockablecontainer = new InventoryLargeChest(new TextComponentTranslation("container.chestDouble"), ilockablecontainer1, ilockablecontainer2);
                        }
                    }
                }

                return ilockablecontainer;
            }
        }
    }

    public TileEntity func_196283_a_(IBlockReader p_196283_1_)
    {
        return new TileEntityChest();
    }

    private boolean func_176457_m(World p_176457_1_, BlockPos p_176457_2_)
    {
        return this.func_176456_n(p_176457_1_, p_176457_2_) || this.func_176453_o(p_176457_1_, p_176457_2_);
    }

    private boolean func_176456_n(IBlockReader p_176456_1_, BlockPos p_176456_2_)
    {
        return p_176456_1_.func_180495_p(p_176456_2_.func_177984_a()).func_185915_l();
    }

    private boolean func_176453_o(World p_176453_1_, BlockPos p_176453_2_)
    {
        List<EntityOcelot> list = p_176453_1_.func_72872_a(EntityOcelot.class, new AxisAlignedBB((double)p_176453_2_.func_177958_n(), (double)(p_176453_2_.func_177956_o() + 1), (double)p_176453_2_.func_177952_p(), (double)(p_176453_2_.func_177958_n() + 1), (double)(p_176453_2_.func_177956_o() + 2), (double)(p_176453_2_.func_177952_p() + 1)));

        if (!list.isEmpty())
        {
            for (EntityOcelot entityocelot : list)
            {
                if (entityocelot.func_70906_o())
                {
                    return true;
                }
            }
        }

        return false;
    }

    public boolean func_149740_M(IBlockState p_149740_1_)
    {
        return true;
    }

    public int func_180641_l(IBlockState p_180641_1_, World p_180641_2_, BlockPos p_180641_3_)
    {
        return Container.func_94526_b(this.func_196309_a(p_180641_1_, p_180641_2_, p_180641_3_, false));
    }

    public IBlockState func_185499_a(IBlockState p_185499_1_, Rotation p_185499_2_)
    {
        return p_185499_1_.func_206870_a(field_176459_a, p_185499_2_.func_185831_a(p_185499_1_.func_177229_b(field_176459_a)));
    }

    public IBlockState func_185471_a(IBlockState p_185471_1_, Mirror p_185471_2_)
    {
        return p_185471_1_.func_185907_a(p_185471_2_.func_185800_a(p_185471_1_.func_177229_b(field_176459_a)));
    }

    protected void func_206840_a(StateContainer.Builder<Block, IBlockState> p_206840_1_)
    {
        p_206840_1_.func_206894_a(field_176459_a, field_196314_b, field_204511_c);
    }

    public BlockFaceShape func_193383_a(IBlockReader p_193383_1_, IBlockState p_193383_2_, BlockPos p_193383_3_, EnumFacing p_193383_4_)
    {
        return BlockFaceShape.UNDEFINED;
    }

    public boolean func_196266_a(IBlockState p_196266_1_, IBlockReader p_196266_2_, BlockPos p_196266_3_, PathType p_196266_4_)
    {
        return false;
    }
}
