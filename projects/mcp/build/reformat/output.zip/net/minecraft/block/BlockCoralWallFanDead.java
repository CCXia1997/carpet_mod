package net.minecraft.block;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Maps;
import java.util.Map;
import javax.annotation.Nullable;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.init.Fluids;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.state.DirectionProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.IWorldReaderBase;

public class BlockCoralWallFanDead extends BlockCoralFan
{
    public static final DirectionProperty field_211884_b = BlockHorizontal.field_185512_D;
    private static final Map<EnumFacing, VoxelShape> field_211885_c = Maps.newEnumMap(ImmutableMap.of(EnumFacing.NORTH, Block.func_208617_a(0.0D, 4.0D, 5.0D, 16.0D, 12.0D, 16.0D), EnumFacing.SOUTH, Block.func_208617_a(0.0D, 4.0D, 0.0D, 16.0D, 12.0D, 11.0D), EnumFacing.WEST, Block.func_208617_a(5.0D, 4.0D, 0.0D, 16.0D, 12.0D, 16.0D), EnumFacing.EAST, Block.func_208617_a(0.0D, 4.0D, 0.0D, 11.0D, 12.0D, 16.0D)));

    protected BlockCoralWallFanDead(Block.Properties p_i49776_1_)
    {
        super(p_i49776_1_);
        this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_211884_b, EnumFacing.NORTH).func_206870_a(field_212560_b, Boolean.valueOf(true)));
    }

    public VoxelShape func_196244_b(IBlockState p_196244_1_, IBlockReader p_196244_2_, BlockPos p_196244_3_)
    {
        return field_211885_c.get(p_196244_1_.func_177229_b(field_211884_b));
    }

    public IBlockState func_185499_a(IBlockState p_185499_1_, Rotation p_185499_2_)
    {
        return p_185499_1_.func_206870_a(field_211884_b, p_185499_2_.func_185831_a(p_185499_1_.func_177229_b(field_211884_b)));
    }

    public IBlockState func_185471_a(IBlockState p_185471_1_, Mirror p_185471_2_)
    {
        return p_185471_1_.func_185907_a(p_185471_2_.func_185800_a(p_185471_1_.func_177229_b(field_211884_b)));
    }

    protected void func_206840_a(StateContainer.Builder<Block, IBlockState> p_206840_1_)
    {
        p_206840_1_.func_206894_a(field_211884_b, field_212560_b);
    }

    public IBlockState func_196271_a(IBlockState p_196271_1_, EnumFacing p_196271_2_, IBlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_)
    {
        if (p_196271_1_.func_177229_b(field_212560_b))
        {
            p_196271_4_.func_205219_F_().func_205360_a(p_196271_5_, Fluids.field_204546_a, Fluids.field_204546_a.func_205569_a(p_196271_4_));
        }

        return p_196271_2_.func_176734_d() == p_196271_1_.func_177229_b(field_211884_b) && !p_196271_1_.func_196955_c(p_196271_4_, p_196271_5_) ? Blocks.field_150350_a.func_176223_P() : p_196271_1_;
    }

    public boolean func_196260_a(IBlockState p_196260_1_, IWorldReaderBase p_196260_2_, BlockPos p_196260_3_)
    {
        EnumFacing enumfacing = p_196260_1_.func_177229_b(field_211884_b);
        BlockPos blockpos = p_196260_3_.func_177972_a(enumfacing.func_176734_d());
        IBlockState iblockstate = p_196260_2_.func_180495_p(blockpos);
        return iblockstate.func_193401_d(p_196260_2_, blockpos, enumfacing) == BlockFaceShape.SOLID && !func_193382_c(iblockstate.func_177230_c());
    }

    @Nullable
    public IBlockState func_196258_a(BlockItemUseContext p_196258_1_)
    {
        IBlockState iblockstate = super.func_196258_a(p_196258_1_);
        IWorldReaderBase iworldreaderbase = p_196258_1_.func_195991_k();
        BlockPos blockpos = p_196258_1_.func_195995_a();
        EnumFacing[] aenumfacing = p_196258_1_.func_196009_e();

        for (EnumFacing enumfacing : aenumfacing)
        {
            if (enumfacing.func_176740_k().func_176722_c())
            {
                iblockstate = iblockstate.func_206870_a(field_211884_b, enumfacing.func_176734_d());

                if (iblockstate.func_196955_c(iworldreaderbase, blockpos))
                {
                    return iblockstate;
                }
            }
        }

        return null;
    }
}
