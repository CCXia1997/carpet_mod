package net.minecraft.block;

import java.util.List;
import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.item.EntityItemFrame;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.state.EnumProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.state.properties.ComparatorMode;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityComparator;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.TickPriority;
import net.minecraft.world.World;

public class BlockRedstoneComparator extends BlockRedstoneDiode implements ITileEntityProvider
{
    public static final EnumProperty<ComparatorMode> field_176463_b = BlockStateProperties.field_208141_ap;

    public BlockRedstoneComparator(Block.Properties p_i48424_1_)
    {
        super(p_i48424_1_);
        this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_185512_D, EnumFacing.NORTH).func_206870_a(field_196348_c, Boolean.valueOf(false)).func_206870_a(field_176463_b, ComparatorMode.COMPARE));
    }

    protected int func_196346_i(IBlockState p_196346_1_)
    {
        return 2;
    }

    protected int func_176408_a(IBlockReader p_176408_1_, BlockPos p_176408_2_, IBlockState p_176408_3_)
    {
        TileEntity tileentity = p_176408_1_.func_175625_s(p_176408_2_);
        return tileentity instanceof TileEntityComparator ? ((TileEntityComparator)tileentity).func_145996_a() : 0;
    }

    private int func_176460_j(World p_176460_1_, BlockPos p_176460_2_, IBlockState p_176460_3_)
    {
        return p_176460_3_.func_177229_b(field_176463_b) == ComparatorMode.SUBTRACT ? Math.max(this.func_176397_f(p_176460_1_, p_176460_2_, p_176460_3_) - this.func_176407_c(p_176460_1_, p_176460_2_, p_176460_3_), 0) : this.func_176397_f(p_176460_1_, p_176460_2_, p_176460_3_);
    }

    protected boolean func_176404_e(World p_176404_1_, BlockPos p_176404_2_, IBlockState p_176404_3_)
    {
        int i = this.func_176397_f(p_176404_1_, p_176404_2_, p_176404_3_);

        if (i >= 15)
        {
            return true;
        }
        else if (i == 0)
        {
            return false;
        }
        else
        {
            return i >= this.func_176407_c(p_176404_1_, p_176404_2_, p_176404_3_);
        }
    }

    protected void func_211326_a(World p_211326_1_, BlockPos p_211326_2_)
    {
        p_211326_1_.func_175713_t(p_211326_2_);
    }

    protected int func_176397_f(World p_176397_1_, BlockPos p_176397_2_, IBlockState p_176397_3_)
    {
        int i = super.func_176397_f(p_176397_1_, p_176397_2_, p_176397_3_);
        EnumFacing enumfacing = p_176397_3_.func_177229_b(field_185512_D);
        BlockPos blockpos = p_176397_2_.func_177972_a(enumfacing);
        IBlockState iblockstate = p_176397_1_.func_180495_p(blockpos);

        if (iblockstate.func_185912_n())
        {
            i = iblockstate.func_185888_a(p_176397_1_, blockpos);
        }
        else if (i < 15 && iblockstate.func_185915_l())
        {
            blockpos = blockpos.func_177972_a(enumfacing);
            iblockstate = p_176397_1_.func_180495_p(blockpos);

            if (iblockstate.func_185912_n())
            {
                i = iblockstate.func_185888_a(p_176397_1_, blockpos);
            }
            else if (iblockstate.func_196958_f())
            {
                EntityItemFrame entityitemframe = this.func_176461_a(p_176397_1_, enumfacing, blockpos);

                if (entityitemframe != null)
                {
                    i = entityitemframe.func_174866_q();
                }
            }
        }

        return i;
    }

    @Nullable
    private EntityItemFrame func_176461_a(World p_176461_1_, EnumFacing p_176461_2_, BlockPos p_176461_3_)
    {
        List<EntityItemFrame> list = p_176461_1_.func_175647_a(EntityItemFrame.class, new AxisAlignedBB((double)p_176461_3_.func_177958_n(), (double)p_176461_3_.func_177956_o(), (double)p_176461_3_.func_177952_p(), (double)(p_176461_3_.func_177958_n() + 1), (double)(p_176461_3_.func_177956_o() + 1), (double)(p_176461_3_.func_177952_p() + 1)), (p_210304_1_) ->
        {
            return p_210304_1_ != null && p_210304_1_.func_174811_aO() == p_176461_2_;
        });
        return list.size() == 1 ? list.get(0) : null;
    }

    public boolean func_196250_a(IBlockState p_196250_1_, World p_196250_2_, BlockPos p_196250_3_, EntityPlayer p_196250_4_, EnumHand p_196250_5_, EnumFacing p_196250_6_, float p_196250_7_, float p_196250_8_, float p_196250_9_)
    {
        if (!p_196250_4_.field_71075_bZ.field_75099_e)
        {
            return false;
        }
        else
        {
            p_196250_1_ = p_196250_1_.func_177231_a(field_176463_b);
            float f = p_196250_1_.func_177229_b(field_176463_b) == ComparatorMode.SUBTRACT ? 0.55F : 0.5F;
            p_196250_2_.func_184133_a(p_196250_4_, p_196250_3_, SoundEvents.field_187556_aj, SoundCategory.BLOCKS, 0.3F, f);
            p_196250_2_.func_180501_a(p_196250_3_, p_196250_1_, 2);
            this.func_176462_k(p_196250_2_, p_196250_3_, p_196250_1_);
            return true;
        }
    }

    protected void func_176398_g(World p_176398_1_, BlockPos p_176398_2_, IBlockState p_176398_3_)
    {
        if (!p_176398_1_.func_205220_G_().func_205361_b(p_176398_2_, this))
        {
            int i = this.func_176460_j(p_176398_1_, p_176398_2_, p_176398_3_);
            TileEntity tileentity = p_176398_1_.func_175625_s(p_176398_2_);
            int j = tileentity instanceof TileEntityComparator ? ((TileEntityComparator)tileentity).func_145996_a() : 0;

            if (i != j || p_176398_3_.func_177229_b(field_196348_c) != this.func_176404_e(p_176398_1_, p_176398_2_, p_176398_3_))
            {
                TickPriority tickpriority = this.func_176402_i(p_176398_1_, p_176398_2_, p_176398_3_) ? TickPriority.HIGH : TickPriority.NORMAL;
                p_176398_1_.func_205220_G_().func_205362_a(p_176398_2_, this, 2, tickpriority);
            }
        }
    }

    private void func_176462_k(World p_176462_1_, BlockPos p_176462_2_, IBlockState p_176462_3_)
    {
        int i = this.func_176460_j(p_176462_1_, p_176462_2_, p_176462_3_);
        TileEntity tileentity = p_176462_1_.func_175625_s(p_176462_2_);
        int j = 0;

        if (tileentity instanceof TileEntityComparator)
        {
            TileEntityComparator tileentitycomparator = (TileEntityComparator)tileentity;
            j = tileentitycomparator.func_145996_a();
            tileentitycomparator.func_145995_a(i);
        }

        if (j != i || p_176462_3_.func_177229_b(field_176463_b) == ComparatorMode.COMPARE)
        {
            boolean flag1 = this.func_176404_e(p_176462_1_, p_176462_2_, p_176462_3_);
            boolean flag = p_176462_3_.func_177229_b(field_196348_c);

            if (flag && !flag1)
            {
                p_176462_1_.func_180501_a(p_176462_2_, p_176462_3_.func_206870_a(field_196348_c, Boolean.valueOf(false)), 2);
            }
            else if (!flag && flag1)
            {
                p_176462_1_.func_180501_a(p_176462_2_, p_176462_3_.func_206870_a(field_196348_c, Boolean.valueOf(true)), 2);
            }

            this.func_176400_h(p_176462_1_, p_176462_2_, p_176462_3_);
        }
    }

    public void func_196267_b(IBlockState p_196267_1_, World p_196267_2_, BlockPos p_196267_3_, Random p_196267_4_)
    {
        this.func_176462_k(p_196267_2_, p_196267_3_, p_196267_1_);
    }

    public boolean func_189539_a(IBlockState p_189539_1_, World p_189539_2_, BlockPos p_189539_3_, int p_189539_4_, int p_189539_5_)
    {
        super.func_189539_a(p_189539_1_, p_189539_2_, p_189539_3_, p_189539_4_, p_189539_5_);
        TileEntity tileentity = p_189539_2_.func_175625_s(p_189539_3_);
        return tileentity != null && tileentity.func_145842_c(p_189539_4_, p_189539_5_);
    }

    public TileEntity func_196283_a_(IBlockReader p_196283_1_)
    {
        return new TileEntityComparator();
    }

    protected void func_206840_a(StateContainer.Builder<Block, IBlockState> p_206840_1_)
    {
        p_206840_1_.func_206894_a(field_185512_D, field_176463_b, field_196348_c);
    }
}
