package net.minecraft.block;

import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class BlockPumpkin extends BlockStemGrown
{
    protected BlockPumpkin(Block.Properties p_i48347_1_)
    {
        super(p_i48347_1_);
    }

    public boolean func_196250_a(IBlockState p_196250_1_, World p_196250_2_, BlockPos p_196250_3_, EntityPlayer p_196250_4_, EnumHand p_196250_5_, EnumFacing p_196250_6_, float p_196250_7_, float p_196250_8_, float p_196250_9_)
    {
        ItemStack itemstack = p_196250_4_.func_184586_b(p_196250_5_);

        if (itemstack.func_77973_b() == Items.field_151097_aZ)
        {
            if (!p_196250_2_.field_72995_K)
            {
                EnumFacing enumfacing = p_196250_6_.func_176740_k() == EnumFacing.Axis.Y ? p_196250_4_.func_174811_aO().func_176734_d() : p_196250_6_;
                p_196250_2_.func_184133_a((EntityPlayer)null, p_196250_3_, SoundEvents.field_199059_fV, SoundCategory.BLOCKS, 1.0F, 1.0F);
                p_196250_2_.func_180501_a(p_196250_3_, Blocks.field_196625_cS.func_176223_P().func_206870_a(BlockCarvedPumpkin.field_196359_a, enumfacing), 11);
                EntityItem entityitem = new EntityItem(p_196250_2_, (double)p_196250_3_.func_177958_n() + 0.5D + (double)enumfacing.func_82601_c() * 0.65D, (double)p_196250_3_.func_177956_o() + 0.1D, (double)p_196250_3_.func_177952_p() + 0.5D + (double)enumfacing.func_82599_e() * 0.65D, new ItemStack(Items.field_151080_bb, 4));
                entityitem.field_70159_w = 0.05D * (double)enumfacing.func_82601_c() + p_196250_2_.field_73012_v.nextDouble() * 0.02D;
                entityitem.field_70181_x = 0.05D;
                entityitem.field_70179_y = 0.05D * (double)enumfacing.func_82599_e() + p_196250_2_.field_73012_v.nextDouble() * 0.02D;
                p_196250_2_.func_72838_d(entityitem);
                itemstack.func_77972_a(1, p_196250_4_);
            }

            return true;
        }
        else
        {
            return super.func_196250_a(p_196250_1_, p_196250_2_, p_196250_3_, p_196250_4_, p_196250_5_, p_196250_6_, p_196250_7_, p_196250_8_, p_196250_9_);
        }
    }

    public BlockStem func_196524_d()
    {
        return (BlockStem)Blocks.field_150393_bb;
    }

    public BlockAttachedStem func_196523_e()
    {
        return (BlockAttachedStem)Blocks.field_196711_ds;
    }
}
