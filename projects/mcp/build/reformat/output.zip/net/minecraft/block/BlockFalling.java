package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.item.EntityFallingBlock;
import net.minecraft.init.Blocks;
import net.minecraft.init.Particles;
import net.minecraft.particles.BlockParticleData;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IWorld;
import net.minecraft.world.IWorldReaderBase;
import net.minecraft.world.World;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class BlockFalling extends Block
{
    public static boolean field_149832_M;

    public BlockFalling(Block.Properties p_i48401_1_)
    {
        super(p_i48401_1_);
    }

    public void func_196259_b(IBlockState p_196259_1_, World p_196259_2_, BlockPos p_196259_3_, IBlockState p_196259_4_)
    {
        p_196259_2_.func_205220_G_().func_205360_a(p_196259_3_, this, this.func_149738_a(p_196259_2_));
    }

    public IBlockState func_196271_a(IBlockState p_196271_1_, EnumFacing p_196271_2_, IBlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_)
    {
        p_196271_4_.func_205220_G_().func_205360_a(p_196271_5_, this, this.func_149738_a(p_196271_4_));
        return super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
    }

    public void func_196267_b(IBlockState p_196267_1_, World p_196267_2_, BlockPos p_196267_3_, Random p_196267_4_)
    {
        if (!p_196267_2_.field_72995_K)
        {
            this.func_176503_e(p_196267_2_, p_196267_3_);
        }
    }

    private void func_176503_e(World p_176503_1_, BlockPos p_176503_2_)
    {
        if (func_185759_i(p_176503_1_.func_180495_p(p_176503_2_.func_177977_b())) && p_176503_2_.func_177956_o() >= 0)
        {
            int i = 32;

            if (!field_149832_M && p_176503_1_.func_175707_a(p_176503_2_.func_177982_a(-32, -32, -32), p_176503_2_.func_177982_a(32, 32, 32)))
            {
                if (!p_176503_1_.field_72995_K)
                {
                    EntityFallingBlock entityfallingblock = new EntityFallingBlock(p_176503_1_, (double)p_176503_2_.func_177958_n() + 0.5D, (double)p_176503_2_.func_177956_o(), (double)p_176503_2_.func_177952_p() + 0.5D, p_176503_1_.func_180495_p(p_176503_2_));
                    this.func_149829_a(entityfallingblock);
                    p_176503_1_.func_72838_d(entityfallingblock);
                }
            }
            else
            {
                if (p_176503_1_.func_180495_p(p_176503_2_).func_177230_c() == this)
                {
                    p_176503_1_.func_175698_g(p_176503_2_);
                }

                BlockPos blockpos;

                for (blockpos = p_176503_2_.func_177977_b(); func_185759_i(p_176503_1_.func_180495_p(blockpos)) && blockpos.func_177956_o() > 0; blockpos = blockpos.func_177977_b())
                {
                    ;
                }

                if (blockpos.func_177956_o() > 0)
                {
                    p_176503_1_.func_175656_a(blockpos.func_177984_a(), this.func_176223_P());
                }
            }
        }
    }

    protected void func_149829_a(EntityFallingBlock p_149829_1_)
    {
    }

    public int func_149738_a(IWorldReaderBase p_149738_1_)
    {
        return 2;
    }

    public static boolean func_185759_i(IBlockState p_185759_0_)
    {
        Block block = p_185759_0_.func_177230_c();
        Material material = p_185759_0_.func_185904_a();
        return p_185759_0_.func_196958_f() || block == Blocks.field_150480_ab || material.func_76224_d() || material.func_76222_j();
    }

    public void func_176502_a_(World p_176502_1_, BlockPos p_176502_2_, IBlockState p_176502_3_, IBlockState p_176502_4_)
    {
    }

    public void func_190974_b(World p_190974_1_, BlockPos p_190974_2_)
    {
    }

    @OnlyIn(Dist.CLIENT)
    public void func_180655_c(IBlockState p_180655_1_, World p_180655_2_, BlockPos p_180655_3_, Random p_180655_4_)
    {
        if (p_180655_4_.nextInt(16) == 0)
        {
            BlockPos blockpos = p_180655_3_.func_177977_b();

            if (func_185759_i(p_180655_2_.func_180495_p(blockpos)))
            {
                double d0 = (double)((float)p_180655_3_.func_177958_n() + p_180655_4_.nextFloat());
                double d1 = (double)p_180655_3_.func_177956_o() - 0.05D;
                double d2 = (double)((float)p_180655_3_.func_177952_p() + p_180655_4_.nextFloat());
                p_180655_2_.func_195594_a(new BlockParticleData(Particles.field_197628_u, p_180655_1_), d0, d1, d2, 0.0D, 0.0D, 0.0D);
            }
        }
    }

    @OnlyIn(Dist.CLIENT)
    public int func_189876_x(IBlockState p_189876_1_)
    {
        return -16777216;
    }
}
