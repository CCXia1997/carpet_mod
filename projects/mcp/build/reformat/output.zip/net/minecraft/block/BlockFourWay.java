package net.minecraft.block;

import java.util.Map;
import net.minecraft.block.state.IBlockState;
import net.minecraft.fluid.Fluid;
import net.minecraft.fluid.IFluidState;
import net.minecraft.init.Fluids;
import net.minecraft.pathfinding.PathType;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.Util;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.shapes.VoxelShapes;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;

public class BlockFourWay extends Block implements IBucketPickupHandler, ILiquidContainer
{
    public static final BooleanProperty field_196409_a = BlockSixWay.field_196488_a;
    public static final BooleanProperty field_196411_b = BlockSixWay.field_196490_b;
    public static final BooleanProperty field_196413_c = BlockSixWay.field_196492_c;
    public static final BooleanProperty field_196414_y = BlockSixWay.field_196495_y;
    public static final BooleanProperty field_204514_u = BlockStateProperties.field_208198_y;
    protected static final Map<EnumFacing, BooleanProperty> field_196415_z = BlockSixWay.field_196491_B.entrySet().stream().filter((p_199775_0_) ->
    {
        return p_199775_0_.getKey().func_176740_k().func_176722_c();
    }).collect(Util.func_199749_a());
    protected final VoxelShape[] field_196410_A;
    protected final VoxelShape[] field_196412_B;

    protected BlockFourWay(float p_i48420_1_, float p_i48420_2_, float p_i48420_3_, float p_i48420_4_, float p_i48420_5_, Block.Properties p_i48420_6_)
    {
        super(p_i48420_6_);
        this.field_196410_A = this.func_196408_a(p_i48420_1_, p_i48420_2_, p_i48420_5_, 0.0F, p_i48420_5_);
        this.field_196412_B = this.func_196408_a(p_i48420_1_, p_i48420_2_, p_i48420_3_, 0.0F, p_i48420_4_);
    }

    protected VoxelShape[] func_196408_a(float p_196408_1_, float p_196408_2_, float p_196408_3_, float p_196408_4_, float p_196408_5_)
    {
        float f = 8.0F - p_196408_1_;
        float f1 = 8.0F + p_196408_1_;
        float f2 = 8.0F - p_196408_2_;
        float f3 = 8.0F + p_196408_2_;
        VoxelShape voxelshape = Block.func_208617_a((double)f, 0.0D, (double)f, (double)f1, (double)p_196408_3_, (double)f1);
        VoxelShape voxelshape1 = Block.func_208617_a((double)f2, (double)p_196408_4_, 0.0D, (double)f3, (double)p_196408_5_, (double)f3);
        VoxelShape voxelshape2 = Block.func_208617_a((double)f2, (double)p_196408_4_, (double)f2, (double)f3, (double)p_196408_5_, 16.0D);
        VoxelShape voxelshape3 = Block.func_208617_a(0.0D, (double)p_196408_4_, (double)f2, (double)f3, (double)p_196408_5_, (double)f3);
        VoxelShape voxelshape4 = Block.func_208617_a((double)f2, (double)p_196408_4_, (double)f2, 16.0D, (double)p_196408_5_, (double)f3);
        VoxelShape voxelshape5 = VoxelShapes.func_197872_a(voxelshape1, voxelshape4);
        VoxelShape voxelshape6 = VoxelShapes.func_197872_a(voxelshape2, voxelshape3);
        VoxelShape[] avoxelshape = new VoxelShape[] {VoxelShapes.func_197880_a(), voxelshape2, voxelshape3, voxelshape6, voxelshape1, VoxelShapes.func_197872_a(voxelshape2, voxelshape1), VoxelShapes.func_197872_a(voxelshape3, voxelshape1), VoxelShapes.func_197872_a(voxelshape6, voxelshape1), voxelshape4, VoxelShapes.func_197872_a(voxelshape2, voxelshape4), VoxelShapes.func_197872_a(voxelshape3, voxelshape4), VoxelShapes.func_197872_a(voxelshape6, voxelshape4), voxelshape5, VoxelShapes.func_197872_a(voxelshape2, voxelshape5), VoxelShapes.func_197872_a(voxelshape3, voxelshape5), VoxelShapes.func_197872_a(voxelshape6, voxelshape5)};

        for (int i = 0; i < 16; ++i)
        {
            avoxelshape[i] = VoxelShapes.func_197872_a(voxelshape, avoxelshape[i]);
        }

        return avoxelshape;
    }

    public VoxelShape func_196244_b(IBlockState p_196244_1_, IBlockReader p_196244_2_, BlockPos p_196244_3_)
    {
        return this.field_196412_B[this.func_196406_i(p_196244_1_)];
    }

    public VoxelShape func_196268_f(IBlockState p_196268_1_, IBlockReader p_196268_2_, BlockPos p_196268_3_)
    {
        return this.field_196410_A[this.func_196406_i(p_196268_1_)];
    }

    private static int func_196407_a(EnumFacing p_196407_0_)
    {
        return 1 << p_196407_0_.func_176736_b();
    }

    protected int func_196406_i(IBlockState p_196406_1_)
    {
        int i = 0;

        if (p_196406_1_.func_177229_b(field_196409_a))
        {
            i |= func_196407_a(EnumFacing.NORTH);
        }

        if (p_196406_1_.func_177229_b(field_196411_b))
        {
            i |= func_196407_a(EnumFacing.EAST);
        }

        if (p_196406_1_.func_177229_b(field_196413_c))
        {
            i |= func_196407_a(EnumFacing.SOUTH);
        }

        if (p_196406_1_.func_177229_b(field_196414_y))
        {
            i |= func_196407_a(EnumFacing.WEST);
        }

        return i;
    }

    public Fluid func_204508_a(IWorld p_204508_1_, BlockPos p_204508_2_, IBlockState p_204508_3_)
    {
        if (p_204508_3_.func_177229_b(field_204514_u))
        {
            p_204508_1_.func_180501_a(p_204508_2_, p_204508_3_.func_206870_a(field_204514_u, Boolean.valueOf(false)), 3);
            return Fluids.field_204546_a;
        }
        else
        {
            return Fluids.field_204541_a;
        }
    }

    public IFluidState func_204507_t(IBlockState p_204507_1_)
    {
        return p_204507_1_.func_177229_b(field_204514_u) ? Fluids.field_204546_a.func_207204_a(false) : super.func_204507_t(p_204507_1_);
    }

    public boolean func_204510_a(IBlockReader p_204510_1_, BlockPos p_204510_2_, IBlockState p_204510_3_, Fluid p_204510_4_)
    {
        return !p_204510_3_.func_177229_b(field_204514_u) && p_204510_4_ == Fluids.field_204546_a;
    }

    public boolean func_204509_a(IWorld p_204509_1_, BlockPos p_204509_2_, IBlockState p_204509_3_, IFluidState p_204509_4_)
    {
        if (!p_204509_3_.func_177229_b(field_204514_u) && p_204509_4_.func_206886_c() == Fluids.field_204546_a)
        {
            if (!p_204509_1_.func_201670_d())
            {
                p_204509_1_.func_180501_a(p_204509_2_, p_204509_3_.func_206870_a(field_204514_u, Boolean.valueOf(true)), 3);
                p_204509_1_.func_205219_F_().func_205360_a(p_204509_2_, p_204509_4_.func_206886_c(), p_204509_4_.func_206886_c().func_205569_a(p_204509_1_));
            }

            return true;
        }
        else
        {
            return false;
        }
    }

    public boolean func_196266_a(IBlockState p_196266_1_, IBlockReader p_196266_2_, BlockPos p_196266_3_, PathType p_196266_4_)
    {
        return false;
    }

    public IBlockState func_185499_a(IBlockState p_185499_1_, Rotation p_185499_2_)
    {
        switch (p_185499_2_)
        {
            case CLOCKWISE_180:
                return p_185499_1_.func_206870_a(field_196409_a, p_185499_1_.func_177229_b(field_196413_c)).func_206870_a(field_196411_b, p_185499_1_.func_177229_b(field_196414_y)).func_206870_a(field_196413_c, p_185499_1_.func_177229_b(field_196409_a)).func_206870_a(field_196414_y, p_185499_1_.func_177229_b(field_196411_b));
            case COUNTERCLOCKWISE_90:
                return p_185499_1_.func_206870_a(field_196409_a, p_185499_1_.func_177229_b(field_196411_b)).func_206870_a(field_196411_b, p_185499_1_.func_177229_b(field_196413_c)).func_206870_a(field_196413_c, p_185499_1_.func_177229_b(field_196414_y)).func_206870_a(field_196414_y, p_185499_1_.func_177229_b(field_196409_a));
            case CLOCKWISE_90:
                return p_185499_1_.func_206870_a(field_196409_a, p_185499_1_.func_177229_b(field_196414_y)).func_206870_a(field_196411_b, p_185499_1_.func_177229_b(field_196409_a)).func_206870_a(field_196413_c, p_185499_1_.func_177229_b(field_196411_b)).func_206870_a(field_196414_y, p_185499_1_.func_177229_b(field_196413_c));
            default:
                return p_185499_1_;
        }
    }

    public IBlockState func_185471_a(IBlockState p_185471_1_, Mirror p_185471_2_)
    {
        switch (p_185471_2_)
        {
            case LEFT_RIGHT:
                return p_185471_1_.func_206870_a(field_196409_a, p_185471_1_.func_177229_b(field_196413_c)).func_206870_a(field_196413_c, p_185471_1_.func_177229_b(field_196409_a));
            case FRONT_BACK:
                return p_185471_1_.func_206870_a(field_196411_b, p_185471_1_.func_177229_b(field_196414_y)).func_206870_a(field_196414_y, p_185471_1_.func_177229_b(field_196411_b));
            default:
                return super.func_185471_a(p_185471_1_, p_185471_2_);
        }
    }
}
