package net.minecraft.client.gui.inventory;

import net.minecraft.block.BlockStandingSign;
import net.minecraft.block.BlockWallSign;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.tileentity.TileEntityRendererDispatcher;
import net.minecraft.client.resources.I18n;
import net.minecraft.init.Blocks;
import net.minecraft.network.play.client.CPacketUpdateSign;
import net.minecraft.tileentity.TileEntitySign;
import net.minecraft.util.SharedConstants;
import net.minecraft.util.text.TextComponentString;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class GuiEditSign extends GuiScreen
{
    private final TileEntitySign field_146848_f;
    private int field_146849_g;
    private int field_146851_h;
    private GuiButton field_146852_i;

    public GuiEditSign(TileEntitySign p_i1097_1_)
    {
        this.field_146848_f = p_i1097_1_;
    }

    protected void func_73866_w_()
    {
        this.field_146297_k.field_195559_v.func_197967_a(true);
        this.field_146852_i = this.func_189646_b(new GuiButton(0, this.field_146294_l / 2 - 100, this.field_146295_m / 4 + 120, I18n.func_135052_a("gui.done"))
        {
            public void func_194829_a(double p_194829_1_, double p_194829_3_)
            {
                GuiEditSign.this.func_195269_h();
            }
        });
        this.field_146848_f.func_145913_a(false);
    }

    public void func_146281_b()
    {
        this.field_146297_k.field_195559_v.func_197967_a(false);
        NetHandlerPlayClient nethandlerplayclient = this.field_146297_k.func_147114_u();

        if (nethandlerplayclient != null)
        {
            nethandlerplayclient.func_147297_a(new CPacketUpdateSign(this.field_146848_f.func_174877_v(), this.field_146848_f.func_212366_a(0), this.field_146848_f.func_212366_a(1), this.field_146848_f.func_212366_a(2), this.field_146848_f.func_212366_a(3)));
        }

        this.field_146848_f.func_145913_a(true);
    }

    public void func_73876_c()
    {
        ++this.field_146849_g;
    }

    private void func_195269_h()
    {
        this.field_146848_f.func_70296_d();
        this.field_146297_k.func_147108_a((GuiScreen)null);
    }

    public boolean charTyped(char p_charTyped_1_, int p_charTyped_2_)
    {
        String s = this.field_146848_f.func_212366_a(this.field_146851_h).getString();

        if (SharedConstants.func_71566_a(p_charTyped_1_) && this.field_146289_q.func_78256_a(s + p_charTyped_1_) <= 90)
        {
            s = s + p_charTyped_1_;
        }

        this.field_146848_f.func_212365_a(this.field_146851_h, new TextComponentString(s));
        return true;
    }

    public void func_195122_V_()
    {
        this.func_195269_h();
    }

    public boolean keyPressed(int p_keyPressed_1_, int p_keyPressed_2_, int p_keyPressed_3_)
    {
        if (p_keyPressed_1_ == 265)
        {
            this.field_146851_h = this.field_146851_h - 1 & 3;
            return true;
        }
        else if (p_keyPressed_1_ != 264 && p_keyPressed_1_ != 257 && p_keyPressed_1_ != 335)
        {
            if (p_keyPressed_1_ == 259)
            {
                String s = this.field_146848_f.func_212366_a(this.field_146851_h).getString();

                if (!s.isEmpty())
                {
                    s = s.substring(0, s.length() - 1);
                    this.field_146848_f.func_212365_a(this.field_146851_h, new TextComponentString(s));
                }

                return true;
            }
            else
            {
                return super.keyPressed(p_keyPressed_1_, p_keyPressed_2_, p_keyPressed_3_);
            }
        }
        else
        {
            this.field_146851_h = this.field_146851_h + 1 & 3;
            return true;
        }
    }

    public void func_73863_a(int p_73863_1_, int p_73863_2_, float p_73863_3_)
    {
        this.func_146276_q_();
        this.func_73732_a(this.field_146289_q, I18n.func_135052_a("sign.edit"), this.field_146294_l / 2, 40, 16777215);
        GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
        GlStateManager.func_179094_E();
        GlStateManager.func_179109_b((float)(this.field_146294_l / 2), 0.0F, 50.0F);
        float f = 93.75F;
        GlStateManager.func_179152_a(-93.75F, -93.75F, -93.75F);
        GlStateManager.func_179114_b(180.0F, 0.0F, 1.0F, 0.0F);
        IBlockState iblockstate = this.field_146848_f.func_195044_w();
        float f1;

        if (iblockstate.func_177230_c() == Blocks.field_196649_cc)
        {
            f1 = (float)(iblockstate.func_177229_b(BlockStandingSign.field_176413_a) * 360) / 16.0F;
        }
        else
        {
            f1 = iblockstate.func_177229_b(BlockWallSign.field_176412_a).func_185119_l();
        }

        GlStateManager.func_179114_b(f1, 0.0F, 1.0F, 0.0F);
        GlStateManager.func_179109_b(0.0F, -1.0625F, 0.0F);

        if (this.field_146849_g / 6 % 2 == 0)
        {
            this.field_146848_f.field_145918_i = this.field_146851_h;
        }

        TileEntityRendererDispatcher.field_147556_a.func_147549_a(this.field_146848_f, -0.5D, -0.75D, -0.5D, 0.0F);
        this.field_146848_f.field_145918_i = -1;
        GlStateManager.func_179121_F();
        super.func_73863_a(p_73863_1_, p_73863_2_, p_73863_3_);
    }
}
