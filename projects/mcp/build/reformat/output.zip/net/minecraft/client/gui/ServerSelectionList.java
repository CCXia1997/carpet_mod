package net.minecraft.client.gui;

import com.google.common.collect.Lists;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ServerList;
import net.minecraft.client.network.LanServerInfo;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class ServerSelectionList extends GuiListExtended<ServerSelectionList.Entry>
{
    private final GuiMultiplayer field_148200_k;
    private final List<ServerListEntryNormal> field_148198_l = Lists.newArrayList();
    private final ServerSelectionList.Entry field_148196_n = new ServerListEntryLanScan();
    private final List<ServerListEntryLanDetected> field_148199_m = Lists.newArrayList();
    private int field_148197_o = -1;

    private void func_195094_h()
    {
        this.func_195086_c();
        this.field_148198_l.forEach(this::func_195085_a);
        this.func_195085_a(this.field_148196_n);
        this.field_148199_m.forEach(this::func_195085_a);
    }

    public ServerSelectionList(GuiMultiplayer p_i45049_1_, Minecraft p_i45049_2_, int p_i45049_3_, int p_i45049_4_, int p_i45049_5_, int p_i45049_6_, int p_i45049_7_)
    {
        super(p_i45049_2_, p_i45049_3_, p_i45049_4_, p_i45049_5_, p_i45049_6_, p_i45049_7_);
        this.field_148200_k = p_i45049_1_;
    }

    public void func_148192_c(int p_148192_1_)
    {
        this.field_148197_o = p_148192_1_;
    }

    protected boolean func_148131_a(int p_148131_1_)
    {
        return p_148131_1_ == this.field_148197_o;
    }

    public int func_148193_k()
    {
        return this.field_148197_o;
    }

    public void func_148195_a(ServerList p_148195_1_)
    {
        this.field_148198_l.clear();

        for (int i = 0; i < p_148195_1_.func_78856_c(); ++i)
        {
            this.field_148198_l.add(new ServerListEntryNormal(this.field_148200_k, p_148195_1_.func_78850_a(i)));
        }

        this.func_195094_h();
    }

    public void func_148194_a(List<LanServerInfo> p_148194_1_)
    {
        this.field_148199_m.clear();

        for (LanServerInfo lanserverinfo : p_148194_1_)
        {
            this.field_148199_m.add(new ServerListEntryLanDetected(this.field_148200_k, lanserverinfo));
        }

        this.func_195094_h();
    }

    protected int func_148137_d()
    {
        return super.func_148137_d() + 30;
    }

    public int func_148139_c()
    {
        return super.func_148139_c() + 85;
    }

    @OnlyIn(Dist.CLIENT)
    public abstract static class Entry extends GuiListExtended.IGuiListEntry<ServerSelectionList.Entry>
        {
        }
}
