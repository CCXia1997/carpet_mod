package net.minecraft.client.gui.recipebook;

import com.google.common.collect.Lists;
import it.unimi.dsi.fastutil.objects.ObjectLinkedOpenHashSet;
import it.unimi.dsi.fastutil.objects.ObjectSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import javax.annotation.Nullable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiButtonToggle;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;
import net.minecraft.client.gui.IGuiEventListener;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.resources.Language;
import net.minecraft.client.resources.LanguageManager;
import net.minecraft.client.util.RecipeBookCategories;
import net.minecraft.client.util.RecipeBookClient;
import net.minecraft.client.util.SearchTreeManager;
import net.minecraft.inventory.ContainerRecipeBook;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.IRecipe;
import net.minecraft.item.crafting.IRecipePlacer;
import net.minecraft.item.crafting.Ingredient;
import net.minecraft.item.crafting.RecipeItemHelper;
import net.minecraft.network.play.client.CPacketRecipeInfo;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class GuiRecipeBook extends Gui implements IGuiEventListener, IRecipeUpdateListener, IRecipePlacer<Ingredient>
{
    protected static final ResourceLocation field_191894_a = new ResourceLocation("textures/gui/recipe_book.png");
    private int field_191903_n;
    private int field_191904_o;
    private int field_191905_p;
    protected final GhostRecipe field_191915_z = new GhostRecipe();
    private final List<GuiButtonRecipeTab> field_193018_j = Lists.newArrayList();
    private GuiButtonRecipeTab field_191913_x;
    protected GuiButtonToggle field_193960_m;
    protected ContainerRecipeBook field_201522_g;
    protected Minecraft field_191888_F;
    private GuiTextField field_193962_q;
    private String field_193963_r = "";
    protected RecipeBookClient field_193964_s;
    protected final RecipeBookPage field_193022_s = new RecipeBookPage();
    protected final RecipeItemHelper field_193965_u = new RecipeItemHelper();
    private int field_193966_v;
    private boolean field_199738_u;

    public void func_201520_a(int p_201520_1_, int p_201520_2_, Minecraft p_201520_3_, boolean p_201520_4_, ContainerRecipeBook p_201520_5_)
    {
        this.field_191888_F = p_201520_3_;
        this.field_191904_o = p_201520_1_;
        this.field_191905_p = p_201520_2_;
        this.field_201522_g = p_201520_5_;
        p_201520_3_.field_71439_g.field_71070_bA = p_201520_5_;
        this.field_193964_s = p_201520_3_.field_71439_g.func_199507_B();
        this.field_193966_v = p_201520_3_.field_71439_g.field_71071_by.func_194015_p();

        if (this.func_191878_b())
        {
            this.func_201518_a(p_201520_4_);
        }

        p_201520_3_.field_195559_v.func_197967_a(true);
    }

    public void func_201518_a(boolean p_201518_1_)
    {
        this.field_191903_n = p_201518_1_ ? 0 : 86;
        int i = (this.field_191904_o - 147) / 2 - this.field_191903_n;
        int j = (this.field_191905_p - 166) / 2;
        this.field_193965_u.func_194119_a();
        this.field_191888_F.field_71439_g.field_71071_by.func_201571_a(this.field_193965_u);
        this.field_201522_g.func_201771_a(this.field_193965_u);
        String s = this.field_193962_q != null ? this.field_193962_q.func_146179_b() : "";
        this.field_193962_q = new GuiTextField(0, this.field_191888_F.field_71466_p, i + 25, j + 14, 80, this.field_191888_F.field_71466_p.field_78288_b + 5);
        this.field_193962_q.func_146203_f(50);
        this.field_193962_q.func_146185_a(false);
        this.field_193962_q.func_146189_e(true);
        this.field_193962_q.func_146193_g(16777215);
        this.field_193962_q.func_146180_a(s);
        this.field_193022_s.func_194194_a(this.field_191888_F, i, j);
        this.field_193022_s.func_193732_a(this);
        this.field_193960_m = new GuiButtonToggle(0, i + 110, j + 12, 26, 16, this.field_193964_s.func_203432_a(this.field_201522_g));
        this.func_205702_a();
        this.field_193018_j.clear();

        for (RecipeBookCategories recipebookcategories : RecipeBookClient.func_202888_a(this.field_201522_g))
        {
            this.field_193018_j.add(new GuiButtonRecipeTab(0, recipebookcategories));
        }

        if (this.field_191913_x != null)
        {
            this.field_191913_x = this.field_193018_j.stream().filter((p_209505_1_) ->
            {
                return p_209505_1_.func_201503_d().equals(this.field_191913_x.func_201503_d());
            }).findFirst().orElse((GuiButtonRecipeTab)null);
        }

        if (this.field_191913_x == null)
        {
            this.field_191913_x = this.field_193018_j.get(0);
        }

        this.field_191913_x.func_191753_b(true);
        this.func_193003_g(false);
        this.func_193949_f();
    }

    protected void func_205702_a()
    {
        this.field_193960_m.func_191751_a(152, 41, 28, 18, field_191894_a);
    }

    public void func_191871_c()
    {
        this.field_193962_q = null;
        this.field_191913_x = null;
        this.field_191888_F.field_195559_v.func_197967_a(false);
    }

    public int func_193011_a(boolean p_193011_1_, int p_193011_2_, int p_193011_3_)
    {
        int i;

        if (this.func_191878_b() && !p_193011_1_)
        {
            i = 177 + (p_193011_2_ - p_193011_3_ - 200) / 2;
        }
        else
        {
            i = (p_193011_2_ - p_193011_3_) / 2;
        }

        return i;
    }

    public void func_191866_a()
    {
        this.func_193006_a(!this.func_191878_b());
    }

    public boolean func_191878_b()
    {
        return this.field_193964_s.func_192812_b();
    }

    protected void func_193006_a(boolean p_193006_1_)
    {
        this.field_193964_s.func_192813_a(p_193006_1_);

        if (!p_193006_1_)
        {
            this.field_193022_s.func_194200_c();
        }

        this.func_193956_j();
    }

    public void func_191874_a(@Nullable Slot p_191874_1_)
    {
        if (p_191874_1_ != null && p_191874_1_.field_75222_d < this.field_201522_g.func_203721_h())
        {
            this.field_191915_z.func_192682_a();

            if (this.func_191878_b())
            {
                this.func_193942_g();
            }
        }
    }

    private void func_193003_g(boolean p_193003_1_)
    {
        List<RecipeList> list = this.field_193964_s.func_202891_a(this.field_191913_x.func_201503_d());
        list.forEach((p_193944_1_) ->
        {
            p_193944_1_.func_194210_a(this.field_193965_u, this.field_201522_g.func_201770_g(), this.field_201522_g.func_201772_h(), this.field_193964_s);
        });
        List<RecipeList> list1 = Lists.newArrayList(list);
        list1.removeIf((p_193952_0_) ->
        {
            return !p_193952_0_.func_194209_a();
        });
        list1.removeIf((p_193953_0_) ->
        {
            return !p_193953_0_.func_194212_c();
        });
        String s = this.field_193962_q.func_146179_b();

        if (!s.isEmpty())
        {
            ObjectSet<RecipeList> objectset = new ObjectLinkedOpenHashSet<>(this.field_191888_F.func_193987_a(SearchTreeManager.field_194012_b).func_194038_a(s.toLowerCase(Locale.ROOT)));
            list1.removeIf((p_193947_1_) ->
            {
                return !objectset.contains(p_193947_1_);
            });
        }

        if (this.field_193964_s.func_203432_a(this.field_201522_g))
        {
            list1.removeIf((p_193958_0_) ->
            {
                return !p_193958_0_.func_192708_c();
            });
        }

        this.field_193022_s.func_194192_a(list1, p_193003_1_);
    }

    private void func_193949_f()
    {
        int i = (this.field_191904_o - 147) / 2 - this.field_191903_n - 30;
        int j = (this.field_191905_p - 166) / 2 + 3;
        int k = 27;
        int l = 0;

        for (GuiButtonRecipeTab guibuttonrecipetab : this.field_193018_j)
        {
            RecipeBookCategories recipebookcategories = guibuttonrecipetab.func_201503_d();

            if (recipebookcategories != RecipeBookCategories.SEARCH && recipebookcategories != RecipeBookCategories.FURNACE_SEARCH)
            {
                if (guibuttonrecipetab.func_199500_a(this.field_193964_s))
                {
                    guibuttonrecipetab.func_191752_c(i, j + 27 * l++);
                    guibuttonrecipetab.func_193918_a(this.field_191888_F);
                }
            }
            else
            {
                guibuttonrecipetab.field_146125_m = true;
                guibuttonrecipetab.func_191752_c(i, j + 27 * l++);
            }
        }
    }

    public void func_193957_d()
    {
        if (this.func_191878_b())
        {
            if (this.field_193966_v != this.field_191888_F.field_71439_g.field_71071_by.func_194015_p())
            {
                this.func_193942_g();
                this.field_193966_v = this.field_191888_F.field_71439_g.field_71071_by.func_194015_p();
            }
        }
    }

    private void func_193942_g()
    {
        this.field_193965_u.func_194119_a();
        this.field_191888_F.field_71439_g.field_71071_by.func_201571_a(this.field_193965_u);
        this.field_201522_g.func_201771_a(this.field_193965_u);
        this.func_193003_g(false);
    }

    public void func_191861_a(int p_191861_1_, int p_191861_2_, float p_191861_3_)
    {
        if (this.func_191878_b())
        {
            RenderHelper.func_74520_c();
            GlStateManager.func_179140_f();
            GlStateManager.func_179094_E();
            GlStateManager.func_179109_b(0.0F, 0.0F, 100.0F);
            this.field_191888_F.func_110434_K().func_110577_a(field_191894_a);
            GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
            int i = (this.field_191904_o - 147) / 2 - this.field_191903_n;
            int j = (this.field_191905_p - 166) / 2;
            this.func_73729_b(i, j, 1, 1, 147, 166);
            this.field_193962_q.func_195608_a(p_191861_1_, p_191861_2_, p_191861_3_);
            RenderHelper.func_74518_a();

            for (GuiButtonRecipeTab guibuttonrecipetab : this.field_193018_j)
            {
                guibuttonrecipetab.func_194828_a(p_191861_1_, p_191861_2_, p_191861_3_);
            }

            this.field_193960_m.func_194828_a(p_191861_1_, p_191861_2_, p_191861_3_);
            this.field_193022_s.func_194191_a(i, j, p_191861_1_, p_191861_2_, p_191861_3_);
            GlStateManager.func_179121_F();
        }
    }

    public void func_191876_c(int p_191876_1_, int p_191876_2_, int p_191876_3_, int p_191876_4_)
    {
        if (this.func_191878_b())
        {
            this.field_193022_s.func_193721_a(p_191876_3_, p_191876_4_);

            if (this.field_193960_m.func_146115_a())
            {
                String s = this.func_205703_f();

                if (this.field_191888_F.field_71462_r != null)
                {
                    this.field_191888_F.field_71462_r.func_146279_a(s, p_191876_3_, p_191876_4_);
                }
            }

            this.func_193015_d(p_191876_1_, p_191876_2_, p_191876_3_, p_191876_4_);
        }
    }

    protected String func_205703_f()
    {
        return I18n.func_135052_a(this.field_193960_m.func_191754_c() ? "gui.recipebook.toggleRecipes.craftable" : "gui.recipebook.toggleRecipes.all");
    }

    private void func_193015_d(int p_193015_1_, int p_193015_2_, int p_193015_3_, int p_193015_4_)
    {
        ItemStack itemstack = null;

        for (int i = 0; i < this.field_191915_z.func_192684_b(); ++i)
        {
            GhostRecipe.GhostIngredient ghostrecipe$ghostingredient = this.field_191915_z.func_192681_a(i);
            int j = ghostrecipe$ghostingredient.func_193713_b() + p_193015_1_;
            int k = ghostrecipe$ghostingredient.func_193712_c() + p_193015_2_;

            if (p_193015_3_ >= j && p_193015_4_ >= k && p_193015_3_ < j + 16 && p_193015_4_ < k + 16)
            {
                itemstack = ghostrecipe$ghostingredient.func_194184_c();
            }
        }

        if (itemstack != null && this.field_191888_F.field_71462_r != null)
        {
            this.field_191888_F.field_71462_r.func_146283_a(this.field_191888_F.field_71462_r.func_191927_a(itemstack), p_193015_3_, p_193015_4_);
        }
    }

    public void func_191864_a(int p_191864_1_, int p_191864_2_, boolean p_191864_3_, float p_191864_4_)
    {
        this.field_191915_z.func_194188_a(this.field_191888_F, p_191864_1_, p_191864_2_, p_191864_3_, p_191864_4_);
    }

    public boolean mouseClicked(double p_mouseClicked_1_, double p_mouseClicked_3_, int p_mouseClicked_5_)
    {
        if (this.func_191878_b() && !this.field_191888_F.field_71439_g.func_175149_v())
        {
            if (this.field_193022_s.func_198955_a(p_mouseClicked_1_, p_mouseClicked_3_, p_mouseClicked_5_, (this.field_191904_o - 147) / 2 - this.field_191903_n, (this.field_191905_p - 166) / 2, 147, 166))
            {
                IRecipe irecipe = this.field_193022_s.func_194193_a();
                RecipeList recipelist = this.field_193022_s.func_194199_b();

                if (irecipe != null && recipelist != null)
                {
                    if (!recipelist.func_194213_a(irecipe) && this.field_191915_z.func_192686_c() == irecipe)
                    {
                        return false;
                    }

                    this.field_191915_z.func_192682_a();
                    this.field_191888_F.field_71442_b.func_203413_a(this.field_191888_F.field_71439_g.field_71070_bA.field_75152_c, irecipe, GuiScreen.func_146272_n());

                    if (!this.func_191880_f())
                    {
                        this.func_193006_a(false);
                    }
                }

                return true;
            }
            else if (this.field_193962_q.mouseClicked(p_mouseClicked_1_, p_mouseClicked_3_, p_mouseClicked_5_))
            {
                return true;
            }
            else if (this.field_193960_m.mouseClicked(p_mouseClicked_1_, p_mouseClicked_3_, p_mouseClicked_5_))
            {
                boolean flag = this.func_201521_f();
                this.field_193960_m.func_191753_b(flag);
                this.func_193956_j();
                this.func_193003_g(false);
                return true;
            }
            else
            {
                for (GuiButtonRecipeTab guibuttonrecipetab : this.field_193018_j)
                {
                    if (guibuttonrecipetab.mouseClicked(p_mouseClicked_1_, p_mouseClicked_3_, p_mouseClicked_5_))
                    {
                        if (this.field_191913_x != guibuttonrecipetab)
                        {
                            this.field_191913_x.func_191753_b(false);
                            this.field_191913_x = guibuttonrecipetab;
                            this.field_191913_x.func_191753_b(true);
                            this.func_193003_g(true);
                        }

                        return true;
                    }
                }

                return false;
            }
        }
        else
        {
            return false;
        }
    }

    protected boolean func_201521_f()
    {
        boolean flag = !this.field_193964_s.func_192815_c();
        this.field_193964_s.func_192810_b(flag);
        return flag;
    }

    public boolean func_195604_a(double p_195604_1_, double p_195604_3_, int p_195604_5_, int p_195604_6_, int p_195604_7_, int p_195604_8_, int p_195604_9_)
    {
        if (!this.func_191878_b())
        {
            return true;
        }
        else
        {
            boolean flag = p_195604_1_ < (double)p_195604_5_ || p_195604_3_ < (double)p_195604_6_ || p_195604_1_ >= (double)(p_195604_5_ + p_195604_7_) || p_195604_3_ >= (double)(p_195604_6_ + p_195604_8_);
            boolean flag1 = (double)(p_195604_5_ - 147) < p_195604_1_ && p_195604_1_ < (double)p_195604_5_ && (double)p_195604_6_ < p_195604_3_ && p_195604_3_ < (double)(p_195604_6_ + p_195604_8_);
            return flag && !flag1 && !this.field_191913_x.func_146115_a();
        }
    }

    public boolean keyPressed(int p_keyPressed_1_, int p_keyPressed_2_, int p_keyPressed_3_)
    {
        this.field_199738_u = false;

        if (this.func_191878_b() && !this.field_191888_F.field_71439_g.func_175149_v())
        {
            if (p_keyPressed_1_ == 256 && !this.func_191880_f())
            {
                this.func_193006_a(false);
                return true;
            }
            else if (this.field_193962_q.keyPressed(p_keyPressed_1_, p_keyPressed_2_, p_keyPressed_3_))
            {
                this.func_195603_h();
                return true;
            }
            else if (this.field_191888_F.field_71474_y.field_74310_D.func_197976_a(p_keyPressed_1_, p_keyPressed_2_) && !this.field_193962_q.func_146206_l())
            {
                this.field_199738_u = true;
                this.field_193962_q.func_146195_b(true);
                return true;
            }
            else
            {
                return false;
            }
        }
        else
        {
            return false;
        }
    }

    public boolean keyReleased(int p_keyReleased_1_, int p_keyReleased_2_, int p_keyReleased_3_)
    {
        this.field_199738_u = false;
        return IGuiEventListener.super.keyReleased(p_keyReleased_1_, p_keyReleased_2_, p_keyReleased_3_);
    }

    public boolean charTyped(char p_charTyped_1_, int p_charTyped_2_)
    {
        if (this.field_199738_u)
        {
            return false;
        }
        else if (this.func_191878_b() && !this.field_191888_F.field_71439_g.func_175149_v())
        {
            if (this.field_193962_q.charTyped(p_charTyped_1_, p_charTyped_2_))
            {
                this.func_195603_h();
                return true;
            }
            else
            {
                return IGuiEventListener.super.charTyped(p_charTyped_1_, p_charTyped_2_);
            }
        }
        else
        {
            return false;
        }
    }

    private void func_195603_h()
    {
        String s = this.field_193962_q.func_146179_b().toLowerCase(Locale.ROOT);
        this.func_193716_a(s);

        if (!s.equals(this.field_193963_r))
        {
            this.func_193003_g(false);
            this.field_193963_r = s;
        }
    }

    private void func_193716_a(String p_193716_1_)
    {
        if ("excitedze".equals(p_193716_1_))
        {
            LanguageManager languagemanager = this.field_191888_F.func_135016_M();
            Language language = languagemanager.func_191960_a("en_pt");

            if (languagemanager.func_135041_c().compareTo(language) == 0)
            {
                return;
            }

            languagemanager.func_135045_a(language);
            this.field_191888_F.field_71474_y.field_74363_ab = language.func_135034_a();
            this.field_191888_F.func_110436_a();
            this.field_191888_F.field_71466_p.func_78275_b(languagemanager.func_135044_b());
            this.field_191888_F.field_71474_y.func_74303_b();
        }
    }

    private boolean func_191880_f()
    {
        return this.field_191903_n == 86;
    }

    public void func_193948_e()
    {
        this.func_193949_f();

        if (this.func_191878_b())
        {
            this.func_193003_g(false);
        }
    }

    public void func_193001_a(List<IRecipe> p_193001_1_)
    {
        for (IRecipe irecipe : p_193001_1_)
        {
            this.field_191888_F.field_71439_g.func_193103_a(irecipe);
        }
    }

    public void func_193951_a(IRecipe p_193951_1_, List<Slot> p_193951_2_)
    {
        ItemStack itemstack = p_193951_1_.func_77571_b();
        this.field_191915_z.func_192685_a(p_193951_1_);
        this.field_191915_z.func_194187_a(Ingredient.func_193369_a(itemstack), (p_193951_2_.get(0)).field_75223_e, (p_193951_2_.get(0)).field_75221_f);
        this.func_201501_a(this.field_201522_g.func_201770_g(), this.field_201522_g.func_201772_h(), this.field_201522_g.func_201767_f(), p_193951_1_, p_193951_1_.func_192400_c().iterator(), 0);
    }

    public void func_201500_a(Iterator<Ingredient> p_201500_1_, int p_201500_2_, int p_201500_3_, int p_201500_4_, int p_201500_5_)
    {
        Ingredient ingredient = p_201500_1_.next();

        if (!ingredient.func_203189_d())
        {
            Slot slot = this.field_201522_g.field_75151_b.get(p_201500_2_);
            this.field_191915_z.func_194187_a(ingredient, slot.field_75223_e, slot.field_75221_f);
        }
    }

    protected void func_193956_j()
    {
        if (this.field_191888_F.func_147114_u() != null)
        {
            this.field_191888_F.func_147114_u().func_147297_a(new CPacketRecipeInfo(this.field_193964_s.func_192812_b(), this.field_193964_s.func_192815_c(), this.field_193964_s.func_202883_c(), this.field_193964_s.func_202884_d()));
        }
    }
}
