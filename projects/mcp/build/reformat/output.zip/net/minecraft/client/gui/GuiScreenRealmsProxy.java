package net.minecraft.client.gui;

import com.google.common.collect.Lists;
import java.util.HashSet;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.item.ItemStack;
import net.minecraft.realms.RealmsButton;
import net.minecraft.realms.RealmsGuiEventListener;
import net.minecraft.realms.RealmsScreen;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@OnlyIn(Dist.CLIENT)
public class GuiScreenRealmsProxy extends GuiScreen
{
    private final RealmsScreen field_154330_a;
    private static final Logger field_212333_f = LogManager.getLogger();

    public GuiScreenRealmsProxy(RealmsScreen p_i1087_1_)
    {
        this.field_154330_a = p_i1087_1_;
    }

    public RealmsScreen func_154321_a()
    {
        return this.field_154330_a;
    }

    public void func_146280_a(Minecraft p_146280_1_, int p_146280_2_, int p_146280_3_)
    {
        this.field_154330_a.init(p_146280_1_, p_146280_2_, p_146280_3_);
        super.func_146280_a(p_146280_1_, p_146280_2_, p_146280_3_);
    }

    protected void func_73866_w_()
    {
        this.field_154330_a.init();
        super.func_73866_w_();
    }

    public void func_154325_a(String p_154325_1_, int p_154325_2_, int p_154325_3_, int p_154325_4_)
    {
        super.func_73732_a(this.field_146289_q, p_154325_1_, p_154325_2_, p_154325_3_, p_154325_4_);
    }

    public void func_207734_a(String p_207734_1_, int p_207734_2_, int p_207734_3_, int p_207734_4_, boolean p_207734_5_)
    {
        if (p_207734_5_)
        {
            super.func_73731_b(this.field_146289_q, p_207734_1_, p_207734_2_, p_207734_3_, p_207734_4_);
        }
        else
        {
            this.field_146289_q.func_211126_b(p_207734_1_, (float)p_207734_2_, (float)p_207734_3_, p_207734_4_);
        }
    }

    public void func_73729_b(int p_73729_1_, int p_73729_2_, int p_73729_3_, int p_73729_4_, int p_73729_5_, int p_73729_6_)
    {
        this.field_154330_a.blit(p_73729_1_, p_73729_2_, p_73729_3_, p_73729_4_, p_73729_5_, p_73729_6_);
        super.func_73729_b(p_73729_1_, p_73729_2_, p_73729_3_, p_73729_4_, p_73729_5_, p_73729_6_);
    }

    public void func_73733_a(int p_73733_1_, int p_73733_2_, int p_73733_3_, int p_73733_4_, int p_73733_5_, int p_73733_6_)
    {
        super.func_73733_a(p_73733_1_, p_73733_2_, p_73733_3_, p_73733_4_, p_73733_5_, p_73733_6_);
    }

    public void func_146276_q_()
    {
        super.func_146276_q_();
    }

    public boolean func_73868_f()
    {
        return super.func_73868_f();
    }

    public void func_146270_b(int p_146270_1_)
    {
        super.func_146270_b(p_146270_1_);
    }

    public void func_73863_a(int p_73863_1_, int p_73863_2_, float p_73863_3_)
    {
        this.field_154330_a.render(p_73863_1_, p_73863_2_, p_73863_3_);
    }

    public void func_146285_a(ItemStack p_146285_1_, int p_146285_2_, int p_146285_3_)
    {
        super.func_146285_a(p_146285_1_, p_146285_2_, p_146285_3_);
    }

    public void func_146279_a(String p_146279_1_, int p_146279_2_, int p_146279_3_)
    {
        super.func_146279_a(p_146279_1_, p_146279_2_, p_146279_3_);
    }

    public void func_146283_a(List<String> p_146283_1_, int p_146283_2_, int p_146283_3_)
    {
        super.func_146283_a(p_146283_1_, p_146283_2_, p_146283_3_);
    }

    public void func_73876_c()
    {
        this.field_154330_a.tick();
        super.func_73876_c();
    }

    public int func_154329_h()
    {
        return this.field_146289_q.field_78288_b;
    }

    public int func_207731_c(String p_207731_1_)
    {
        return this.field_146289_q.func_78256_a(p_207731_1_);
    }

    public void func_207728_b(String p_207728_1_, int p_207728_2_, int p_207728_3_, int p_207728_4_)
    {
        this.field_146289_q.func_175063_a(p_207728_1_, (float)p_207728_2_, (float)p_207728_3_, p_207728_4_);
    }

    public List<String> func_154323_a(String p_154323_1_, int p_154323_2_)
    {
        return this.field_146289_q.func_78271_c(p_154323_1_, p_154323_2_);
    }

    public void func_207735_j()
    {
        this.field_195124_j.clear();
    }

    public void func_207730_a(RealmsGuiEventListener p_207730_1_)
    {
        if (this.func_212332_c(p_207730_1_) || !this.field_195124_j.add(p_207730_1_.getProxy()))
        {
            field_212333_f.error("Tried to add the same widget multiple times: " + p_207730_1_);
        }
    }

    public void func_207733_b(RealmsGuiEventListener p_207733_1_)
    {
        if (!this.func_212332_c(p_207733_1_) || !this.field_195124_j.remove(p_207733_1_.getProxy()))
        {
            field_212333_f.error("Tried to add the same widget multiple times: " + p_207733_1_);
        }
    }

    public boolean func_212332_c(RealmsGuiEventListener p_212332_1_)
    {
        return this.field_195124_j.contains(p_212332_1_.getProxy());
    }

    public void func_154327_a(RealmsButton p_154327_1_)
    {
        this.func_189646_b(p_154327_1_.getProxy());
    }

    public List<RealmsButton> func_154320_j()
    {
        List<RealmsButton> list = Lists.newArrayListWithExpectedSize(this.field_146292_n.size());

        for (GuiButton guibutton : this.field_146292_n)
        {
            list.add(((GuiButtonRealmsProxy)guibutton).func_154317_g());
        }

        return list;
    }

    public void func_207729_m()
    {
        HashSet<IGuiEventListener> hashset = new HashSet<>(this.field_146292_n);
        this.field_195124_j.removeIf(hashset::contains);
        this.field_146292_n.clear();
    }

    public void func_207732_b(RealmsButton p_207732_1_)
    {
        this.field_195124_j.remove(p_207732_1_.getProxy());
        this.field_146292_n.remove(p_207732_1_.getProxy());
    }

    public boolean mouseClicked(double p_mouseClicked_1_, double p_mouseClicked_3_, int p_mouseClicked_5_)
    {
        return this.field_154330_a.mouseClicked(p_mouseClicked_1_, p_mouseClicked_3_, p_mouseClicked_5_) ? true : super.mouseClicked(p_mouseClicked_1_, p_mouseClicked_3_, p_mouseClicked_5_);
    }

    public boolean mouseReleased(double p_mouseReleased_1_, double p_mouseReleased_3_, int p_mouseReleased_5_)
    {
        return this.field_154330_a.mouseReleased(p_mouseReleased_1_, p_mouseReleased_3_, p_mouseReleased_5_);
    }

    public boolean mouseDragged(double p_mouseDragged_1_, double p_mouseDragged_3_, int p_mouseDragged_5_, double p_mouseDragged_6_, double p_mouseDragged_8_)
    {
        return this.field_154330_a.mouseDragged(p_mouseDragged_1_, p_mouseDragged_3_, p_mouseDragged_5_, p_mouseDragged_6_, p_mouseDragged_8_) ? true : super.mouseDragged(p_mouseDragged_1_, p_mouseDragged_3_, p_mouseDragged_5_, p_mouseDragged_6_, p_mouseDragged_8_);
    }

    public boolean keyPressed(int p_keyPressed_1_, int p_keyPressed_2_, int p_keyPressed_3_)
    {
        return this.field_154330_a.keyPressed(p_keyPressed_1_, p_keyPressed_2_, p_keyPressed_3_) ? true : super.keyPressed(p_keyPressed_1_, p_keyPressed_2_, p_keyPressed_3_);
    }

    public boolean charTyped(char p_charTyped_1_, int p_charTyped_2_)
    {
        return this.field_154330_a.charTyped(p_charTyped_1_, p_charTyped_2_) ? true : super.charTyped(p_charTyped_1_, p_charTyped_2_);
    }

    public void confirmResult(boolean p_confirmResult_1_, int p_confirmResult_2_)
    {
        this.field_154330_a.confirmResult(p_confirmResult_1_, p_confirmResult_2_);
    }

    public void func_146281_b()
    {
        this.field_154330_a.removed();
        super.func_146281_b();
    }

    public int func_209208_b(String p_209208_1_, int p_209208_2_, int p_209208_3_, int p_209208_4_, boolean p_209208_5_)
    {
        return p_209208_5_ ? this.field_146289_q.func_175063_a(p_209208_1_, (float)p_209208_2_, (float)p_209208_3_, p_209208_4_) : this.field_146289_q.func_211126_b(p_209208_1_, (float)p_209208_2_, (float)p_209208_3_, p_209208_4_);
    }
}
