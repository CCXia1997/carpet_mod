package net.minecraft.client.gui.fonts.providers;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import it.unimi.dsi.fastutil.chars.CharArraySet;
import it.unimi.dsi.fastutil.chars.CharSet;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import javax.annotation.Nullable;
import net.minecraft.client.gui.fonts.IGlyphInfo;
import net.minecraft.client.renderer.texture.NativeImage;
import net.minecraft.client.renderer.texture.TextureUtil;
import net.minecraft.resources.IResource;
import net.minecraft.resources.IResourceManager;
import net.minecraft.util.JsonUtils;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.lwjgl.stb.STBTTFontinfo;
import org.lwjgl.stb.STBTruetype;
import org.lwjgl.system.MemoryStack;

@OnlyIn(Dist.CLIENT)
public class TrueTypeGlyphProvider implements IGlyphProvider
{
    private static final Logger field_211263_a = LogManager.getLogger();
    private final STBTTFontinfo field_211264_b;
    private final float field_211618_c;
    private final CharSet field_211619_d = new CharArraySet();
    private final float field_211620_e;
    private final float field_211621_f;
    private final float field_211266_d;
    private final float field_211622_h;

    protected TrueTypeGlyphProvider(STBTTFontinfo p_i49765_1_, float p_i49765_2_, float p_i49765_3_, float p_i49765_4_, float p_i49765_5_, String p_i49765_6_)
    {
        this.field_211264_b = p_i49765_1_;
        this.field_211618_c = p_i49765_3_;
        p_i49765_6_.chars().forEach((p_211614_1_) ->
        {
            this.field_211619_d.add((char)(p_211614_1_ & '\uffff'));
        });
        this.field_211620_e = p_i49765_4_ * p_i49765_3_;
        this.field_211621_f = p_i49765_5_ * p_i49765_3_;
        this.field_211266_d = STBTruetype.stbtt_ScaleForPixelHeight(p_i49765_1_, p_i49765_2_ * p_i49765_3_);

        try (MemoryStack memorystack = MemoryStack.stackPush())
        {
            IntBuffer intbuffer = memorystack.mallocInt(1);
            IntBuffer intbuffer1 = memorystack.mallocInt(1);
            IntBuffer intbuffer2 = memorystack.mallocInt(1);
            STBTruetype.stbtt_GetFontVMetrics(p_i49765_1_, intbuffer, intbuffer1, intbuffer2);
            this.field_211622_h = (float)intbuffer.get(0) * this.field_211266_d;
        }
    }

    @Nullable
    public TrueTypeGlyphProvider.GlpyhInfo func_212248_a(char p_212248_1_)
    {
        if (this.field_211619_d.contains(p_212248_1_))
        {
            return null;
        }
        else
        {
            Object lvt_9_1_;

            try (MemoryStack memorystack = MemoryStack.stackPush())
            {
                IntBuffer intbuffer = memorystack.mallocInt(1);
                IntBuffer intbuffer1 = memorystack.mallocInt(1);
                IntBuffer intbuffer2 = memorystack.mallocInt(1);
                IntBuffer intbuffer3 = memorystack.mallocInt(1);
                int i = STBTruetype.stbtt_FindGlyphIndex(this.field_211264_b, p_212248_1_);

                if (i != 0)
                {
                    STBTruetype.stbtt_GetGlyphBitmapBoxSubpixel(this.field_211264_b, i, this.field_211266_d, this.field_211266_d, this.field_211620_e, this.field_211621_f, intbuffer, intbuffer1, intbuffer2, intbuffer3);
                    int k = intbuffer2.get(0) - intbuffer.get(0);
                    int j = intbuffer3.get(0) - intbuffer1.get(0);

                    if (k != 0 && j != 0)
                    {
                        IntBuffer intbuffer5 = memorystack.mallocInt(1);
                        IntBuffer intbuffer4 = memorystack.mallocInt(1);
                        STBTruetype.stbtt_GetGlyphHMetrics(this.field_211264_b, i, intbuffer5, intbuffer4);
                        TrueTypeGlyphProvider.GlpyhInfo truetypeglyphprovider$glpyhinfo = new TrueTypeGlyphProvider.GlpyhInfo(intbuffer.get(0), intbuffer2.get(0), -intbuffer1.get(0), -intbuffer3.get(0), (float)intbuffer5.get(0) * this.field_211266_d, (float)intbuffer4.get(0) * this.field_211266_d, i);
                        return truetypeglyphprovider$glpyhinfo;
                    }

                    Object lvt_11_1_ = null;
                    return (TrueTypeGlyphProvider.GlpyhInfo)lvt_11_1_;
                }

                lvt_9_1_ = null;
            }

            return (TrueTypeGlyphProvider.GlpyhInfo)lvt_9_1_;
        }
    }

    @OnlyIn(Dist.CLIENT)
    public static class Factory implements IGlyphProviderFactory
        {
            private final ResourceLocation field_211249_a;
            private final float field_211250_b;
            private final float field_211625_c;
            private final float field_211626_d;
            private final float field_211627_e;
            private final String field_211628_f;

            public Factory(ResourceLocation p_i49753_1_, float p_i49753_2_, float p_i49753_3_, float p_i49753_4_, float p_i49753_5_, String p_i49753_6_)
            {
                this.field_211249_a = p_i49753_1_;
                this.field_211250_b = p_i49753_2_;
                this.field_211625_c = p_i49753_3_;
                this.field_211626_d = p_i49753_4_;
                this.field_211627_e = p_i49753_5_;
                this.field_211628_f = p_i49753_6_;
            }

            public static IGlyphProviderFactory func_211624_a(JsonObject p_211624_0_)
            {
                float f = 0.0F;
                float f1 = 0.0F;

                if (p_211624_0_.has("shift"))
                {
                    JsonArray jsonarray = p_211624_0_.getAsJsonArray("shift");

                    if (jsonarray.size() != 2)
                    {
                        throw new JsonParseException("Expected 2 elements in 'shift', found " + jsonarray.size());
                    }

                    f = JsonUtils.func_151220_d(jsonarray.get(0), "shift[0]");
                    f1 = JsonUtils.func_151220_d(jsonarray.get(1), "shift[1]");
                }

                StringBuilder stringbuilder = new StringBuilder();

                if (p_211624_0_.has("skip"))
                {
                    JsonElement jsonelement = p_211624_0_.get("skip");

                    if (jsonelement.isJsonArray())
                    {
                        JsonArray jsonarray1 = JsonUtils.func_151207_m(jsonelement, "skip");

                        for (int i = 0; i < jsonarray1.size(); ++i)
                        {
                            stringbuilder.append(JsonUtils.func_151206_a(jsonarray1.get(i), "skip[" + i + "]"));
                        }
                    }
                    else
                    {
                        stringbuilder.append(JsonUtils.func_151206_a(jsonelement, "skip"));
                    }
                }

                return new TrueTypeGlyphProvider.Factory(new ResourceLocation(JsonUtils.func_151200_h(p_211624_0_, "file")), JsonUtils.func_151221_a(p_211624_0_, "size", 11.0F), JsonUtils.func_151221_a(p_211624_0_, "oversample", 1.0F), f, f1, stringbuilder.toString());
            }

            @Nullable
            public IGlyphProvider func_211246_a(IResourceManager p_211246_1_)
            {
                try (IResource iresource = p_211246_1_.func_199002_a(new ResourceLocation(this.field_211249_a.func_110624_b(), (new StringBuilder()).append("font/").append(this.field_211249_a.func_110623_a()).toString())))
                {
                    TrueTypeGlyphProvider.field_211263_a.info("Loading font");
                    ByteBuffer bytebuffer = TextureUtil.func_195724_a(iresource.func_199027_b());
                    bytebuffer.flip();
                    STBTTFontinfo stbttfontinfo = STBTTFontinfo.create();
                    TrueTypeGlyphProvider.field_211263_a.info("Reading font");

                    if (!STBTruetype.stbtt_InitFont(stbttfontinfo, bytebuffer))
                    {
                        throw new IOException("Invalid ttf");
                    }
                    else
                    {
                        TrueTypeGlyphProvider truetypeglyphprovider = new TrueTypeGlyphProvider(stbttfontinfo, this.field_211250_b, this.field_211625_c, this.field_211626_d, this.field_211627_e, this.field_211628_f);
                        return truetypeglyphprovider;
                    }
                }
                catch (IOException ioexception)
                {
                    TrueTypeGlyphProvider.field_211263_a.error("Couldn't load truetype font {}", this.field_211249_a, ioexception);
                    return null;
                }
            }
        }

    @OnlyIn(Dist.CLIENT)
    class GlpyhInfo implements IGlyphInfo
    {
        private final int field_211216_b;
        private final int field_211217_c;
        private final float field_212464_d;
        private final float field_212465_e;
        private final float field_211598_i;
        private final int field_211599_j;

        private GlpyhInfo(int p_i49751_2_, int p_i49751_3_, int p_i49751_4_, int p_i49751_5_, float p_i49751_6_, float p_i49751_7_, int p_i49751_8_)
        {
            this.field_211216_b = p_i49751_3_ - p_i49751_2_;
            this.field_211217_c = p_i49751_4_ - p_i49751_5_;
            this.field_211598_i = p_i49751_6_ / TrueTypeGlyphProvider.this.field_211618_c;
            this.field_212464_d = (p_i49751_7_ + (float)p_i49751_2_ + TrueTypeGlyphProvider.this.field_211620_e) / TrueTypeGlyphProvider.this.field_211618_c;
            this.field_212465_e = (TrueTypeGlyphProvider.this.field_211622_h - (float)p_i49751_4_ + TrueTypeGlyphProvider.this.field_211621_f) / TrueTypeGlyphProvider.this.field_211618_c;
            this.field_211599_j = p_i49751_8_;
        }

        public int func_211202_a()
        {
            return this.field_211216_b;
        }

        public int func_211203_b()
        {
            return this.field_211217_c;
        }

        public float func_211578_g()
        {
            return TrueTypeGlyphProvider.this.field_211618_c;
        }

        public float getAdvance()
        {
            return this.field_211598_i;
        }

        public float getBearingX()
        {
            return this.field_212464_d;
        }

        public float getBearingY()
        {
            return this.field_212465_e;
        }

        public void func_211573_a(int p_211573_1_, int p_211573_2_)
        {
            try (NativeImage nativeimage = new NativeImage(NativeImage.PixelFormat.LUMINANCE, this.field_211216_b, this.field_211217_c, false))
            {
                nativeimage.func_211676_a(TrueTypeGlyphProvider.this.field_211264_b, this.field_211599_j, this.field_211216_b, this.field_211217_c, TrueTypeGlyphProvider.this.field_211266_d, TrueTypeGlyphProvider.this.field_211266_d, TrueTypeGlyphProvider.this.field_211620_e, TrueTypeGlyphProvider.this.field_211621_f, 0, 0);
                nativeimage.func_195706_a(0, p_211573_1_, p_211573_2_, 0, 0, this.field_211216_b, this.field_211217_c, false);
            }
        }

        public boolean func_211579_f()
        {
            return false;
        }
    }
}
