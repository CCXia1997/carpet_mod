package net.minecraft.client.network;

import net.minecraft.util.Util;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class LanServerInfo
{
    private final String field_77492_a;
    private final String field_77490_b;
    private long field_77491_c;

    public LanServerInfo(String p_i47130_1_, String p_i47130_2_)
    {
        this.field_77492_a = p_i47130_1_;
        this.field_77490_b = p_i47130_2_;
        this.field_77491_c = Util.func_211177_b();
    }

    public String func_77487_a()
    {
        return this.field_77492_a;
    }

    public String func_77488_b()
    {
        return this.field_77490_b;
    }

    public void func_77489_c()
    {
        this.field_77491_c = Util.func_211177_b();
    }
}
