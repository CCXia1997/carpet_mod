package net.minecraft.client.gui;

import com.google.common.collect.Lists;
import com.ibm.icu.text.ArabicShaping;
import com.ibm.icu.text.ArabicShapingException;
import com.ibm.icu.text.Bidi;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import net.minecraft.client.gui.fonts.Font;
import net.minecraft.client.gui.fonts.IGlyph;
import net.minecraft.client.gui.fonts.TexturedGlyph;
import net.minecraft.client.gui.fonts.providers.IGlyphProvider;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.text.TextFormatting;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@OnlyIn(Dist.CLIENT)
public class FontRenderer implements AutoCloseable
{
    private static final Logger field_195437_c = LogManager.getLogger();
    public int field_78288_b = 9;
    public Random field_78289_c = new Random();
    private final TextureManager field_78298_i;
    private final Font field_211127_e;
    private boolean field_78294_m;

    public FontRenderer(TextureManager p_i49744_1_, Font p_i49744_2_)
    {
        this.field_78298_i = p_i49744_1_;
        this.field_211127_e = p_i49744_2_;
    }

    public void func_211568_a(List<IGlyphProvider> p_211568_1_)
    {
        this.field_211127_e.func_211570_a(p_211568_1_);
    }

    public void close()
    {
        this.field_211127_e.close();
    }

    public int func_175063_a(String p_175063_1_, float p_175063_2_, float p_175063_3_, int p_175063_4_)
    {
        GlStateManager.func_179141_d();
        return this.func_180455_b(p_175063_1_, p_175063_2_, p_175063_3_, p_175063_4_, true);
    }

    public int func_211126_b(String p_211126_1_, float p_211126_2_, float p_211126_3_, int p_211126_4_)
    {
        GlStateManager.func_179141_d();
        return this.func_180455_b(p_211126_1_, p_211126_2_, p_211126_3_, p_211126_4_, false);
    }

    private String func_147647_b(String p_147647_1_)
    {
        try
        {
            Bidi bidi = new Bidi((new ArabicShaping(8)).shape(p_147647_1_), 127);
            bidi.setReorderingMode(0);
            return bidi.writeReordered(2);
        }
        catch (ArabicShapingException var3)
        {
            return p_147647_1_;
        }
    }

    private int func_180455_b(String p_180455_1_, float p_180455_2_, float p_180455_3_, int p_180455_4_, boolean p_180455_5_)
    {
        if (p_180455_1_ == null)
        {
            return 0;
        }
        else
        {
            if (this.field_78294_m)
            {
                p_180455_1_ = this.func_147647_b(p_180455_1_);
            }

            if ((p_180455_4_ & -67108864) == 0)
            {
                p_180455_4_ |= -16777216;
            }

            if (p_180455_5_)
            {
                this.func_211843_b(p_180455_1_, p_180455_2_, p_180455_3_, p_180455_4_, true);
            }

            p_180455_2_ = this.func_211843_b(p_180455_1_, p_180455_2_, p_180455_3_, p_180455_4_, false);
            return (int)p_180455_2_ + (p_180455_5_ ? 1 : 0);
        }
    }

    private float func_211843_b(String p_211843_1_, float p_211843_2_, float p_211843_3_, int p_211843_4_, boolean p_211843_5_)
    {
        float f = p_211843_5_ ? 0.25F : 1.0F;
        float f1 = (float)(p_211843_4_ >> 16 & 255) / 255.0F * f;
        float f2 = (float)(p_211843_4_ >> 8 & 255) / 255.0F * f;
        float f3 = (float)(p_211843_4_ & 255) / 255.0F * f;
        float f4 = f1;
        float f5 = f2;
        float f6 = f3;
        float f7 = (float)(p_211843_4_ >> 24 & 255) / 255.0F;
        Tessellator tessellator = Tessellator.func_178181_a();
        BufferBuilder bufferbuilder = tessellator.func_178180_c();
        ResourceLocation resourcelocation = null;
        bufferbuilder.func_181668_a(7, DefaultVertexFormats.field_181709_i);
        boolean flag = false;
        boolean flag1 = false;
        boolean flag2 = false;
        boolean flag3 = false;
        boolean flag4 = false;
        List<FontRenderer.Entry> list = Lists.newArrayList();

        for (int i = 0; i < p_211843_1_.length(); ++i)
        {
            char c0 = p_211843_1_.charAt(i);

            if (c0 == 167 && i + 1 < p_211843_1_.length())
            {
                TextFormatting textformatting = TextFormatting.func_211165_a(p_211843_1_.charAt(i + 1));

                if (textformatting != null)
                {
                    if (textformatting.func_211166_f())
                    {
                        flag = false;
                        flag1 = false;
                        flag4 = false;
                        flag3 = false;
                        flag2 = false;
                        f4 = f1;
                        f5 = f2;
                        f6 = f3;
                    }

                    if (textformatting.func_211163_e() != null)
                    {
                        int j = textformatting.func_211163_e();
                        f4 = (float)(j >> 16 & 255) / 255.0F * f;
                        f5 = (float)(j >> 8 & 255) / 255.0F * f;
                        f6 = (float)(j & 255) / 255.0F * f;
                    }
                    else if (textformatting == TextFormatting.OBFUSCATED)
                    {
                        flag = true;
                    }
                    else if (textformatting == TextFormatting.BOLD)
                    {
                        flag1 = true;
                    }
                    else if (textformatting == TextFormatting.STRIKETHROUGH)
                    {
                        flag4 = true;
                    }
                    else if (textformatting == TextFormatting.UNDERLINE)
                    {
                        flag3 = true;
                    }
                    else if (textformatting == TextFormatting.ITALIC)
                    {
                        flag2 = true;
                    }
                }

                ++i;
            }
            else
            {
                IGlyph iglyph = this.field_211127_e.func_211184_b(c0);
                TexturedGlyph texturedglyph = flag && c0 != ' ' ? this.field_211127_e.func_211188_a(iglyph) : this.field_211127_e.func_211187_a(c0);
                ResourceLocation resourcelocation1 = texturedglyph.func_211233_b();

                if (resourcelocation1 != null)
                {
                    if (resourcelocation != resourcelocation1)
                    {
                        tessellator.func_78381_a();
                        this.field_78298_i.func_110577_a(resourcelocation1);
                        bufferbuilder.func_181668_a(7, DefaultVertexFormats.field_181709_i);
                        resourcelocation = resourcelocation1;
                    }

                    float f8 = flag1 ? iglyph.getBoldOffset() : 0.0F;
                    float f9 = p_211843_5_ ? iglyph.getShadowOffset() : 0.0F;
                    this.func_212452_a(texturedglyph, flag1, flag2, f8, p_211843_2_ + f9, p_211843_3_ + f9, bufferbuilder, f4, f5, f6, f7);
                }

                float f10 = iglyph.getAdvance(flag1);
                float f11 = p_211843_5_ ? 1.0F : 0.0F;

                if (flag4)
                {
                    list.add(new FontRenderer.Entry(p_211843_2_ + f11 - 1.0F, p_211843_3_ + f11 + (float)this.field_78288_b / 2.0F, p_211843_2_ + f11 + f10, p_211843_3_ + f11 + (float)this.field_78288_b / 2.0F - 1.0F, f4, f5, f6, f7));
                }

                if (flag3)
                {
                    list.add(new FontRenderer.Entry(p_211843_2_ + f11 - 1.0F, p_211843_3_ + f11 + (float)this.field_78288_b, p_211843_2_ + f11 + f10, p_211843_3_ + f11 + (float)this.field_78288_b - 1.0F, f4, f5, f6, f7));
                }

                p_211843_2_ += f10;
            }
        }

        tessellator.func_78381_a();

        if (!list.isEmpty())
        {
            GlStateManager.func_179090_x();
            bufferbuilder.func_181668_a(7, DefaultVertexFormats.field_181706_f);

            for (FontRenderer.Entry fontrenderer$entry : list)
            {
                fontrenderer$entry.func_211168_a(bufferbuilder);
            }

            tessellator.func_78381_a();
            GlStateManager.func_179098_w();
        }

        return p_211843_2_;
    }

    private void func_212452_a(TexturedGlyph p_212452_1_, boolean p_212452_2_, boolean p_212452_3_, float p_212452_4_, float p_212452_5_, float p_212452_6_, BufferBuilder p_212452_7_, float p_212452_8_, float p_212452_9_, float p_212452_10_, float p_212452_11_)
    {
        p_212452_1_.func_211234_a(this.field_78298_i, p_212452_3_, p_212452_5_, p_212452_6_, p_212452_7_, p_212452_8_, p_212452_9_, p_212452_10_, p_212452_11_);

        if (p_212452_2_)
        {
            p_212452_1_.func_211234_a(this.field_78298_i, p_212452_3_, p_212452_5_ + p_212452_4_, p_212452_6_, p_212452_7_, p_212452_8_, p_212452_9_, p_212452_10_, p_212452_11_);
        }
    }

    public int func_78256_a(String p_78256_1_)
    {
        if (p_78256_1_ == null)
        {
            return 0;
        }
        else
        {
            float f = 0.0F;
            boolean flag = false;

            for (int i = 0; i < p_78256_1_.length(); ++i)
            {
                char c0 = p_78256_1_.charAt(i);

                if (c0 == 167 && i < p_78256_1_.length() - 1)
                {
                    ++i;
                    TextFormatting textformatting = TextFormatting.func_211165_a(p_78256_1_.charAt(i));

                    if (textformatting == TextFormatting.BOLD)
                    {
                        flag = true;
                    }
                    else if (textformatting != null && textformatting.func_211166_f())
                    {
                        flag = false;
                    }
                }
                else
                {
                    f += this.field_211127_e.func_211184_b(c0).getAdvance(flag);
                }
            }

            return MathHelper.func_76123_f(f);
        }
    }

    private float func_211125_a(char p_211125_1_)
    {
        return p_211125_1_ == 167 ? 0.0F : (float)MathHelper.func_76123_f(this.field_211127_e.func_211184_b(p_211125_1_).getAdvance(false));
    }

    public String func_78269_a(String p_78269_1_, int p_78269_2_)
    {
        return this.func_78262_a(p_78269_1_, p_78269_2_, false);
    }

    public String func_78262_a(String p_78262_1_, int p_78262_2_, boolean p_78262_3_)
    {
        StringBuilder stringbuilder = new StringBuilder();
        float f = 0.0F;
        int i = p_78262_3_ ? p_78262_1_.length() - 1 : 0;
        int j = p_78262_3_ ? -1 : 1;
        boolean flag = false;
        boolean flag1 = false;

        for (int k = i; k >= 0 && k < p_78262_1_.length() && f < (float)p_78262_2_; k += j)
        {
            char c0 = p_78262_1_.charAt(k);

            if (flag)
            {
                flag = false;
                TextFormatting textformatting = TextFormatting.func_211165_a(c0);

                if (textformatting == TextFormatting.BOLD)
                {
                    flag1 = true;
                }
                else if (textformatting != null && textformatting.func_211166_f())
                {
                    flag1 = false;
                }
            }
            else if (c0 == 167)
            {
                flag = true;
            }
            else
            {
                f += this.func_211125_a(c0);

                if (flag1)
                {
                    ++f;
                }
            }

            if (f > (float)p_78262_2_)
            {
                break;
            }

            if (p_78262_3_)
            {
                stringbuilder.insert(0, c0);
            }
            else
            {
                stringbuilder.append(c0);
            }
        }

        return stringbuilder.toString();
    }

    private String func_78273_d(String p_78273_1_)
    {
        while (p_78273_1_ != null && p_78273_1_.endsWith("\n"))
        {
            p_78273_1_ = p_78273_1_.substring(0, p_78273_1_.length() - 1);
        }

        return p_78273_1_;
    }

    public void func_78279_b(String p_78279_1_, int p_78279_2_, int p_78279_3_, int p_78279_4_, int p_78279_5_)
    {
        p_78279_1_ = this.func_78273_d(p_78279_1_);
        this.func_211124_b(p_78279_1_, p_78279_2_, p_78279_3_, p_78279_4_, p_78279_5_);
    }

    private void func_211124_b(String p_211124_1_, int p_211124_2_, int p_211124_3_, int p_211124_4_, int p_211124_5_)
    {
        for (String s : this.func_78271_c(p_211124_1_, p_211124_4_))
        {
            float f = (float)p_211124_2_;

            if (this.field_78294_m)
            {
                int i = this.func_78256_a(this.func_147647_b(s));
                f += (float)(p_211124_4_ - i);
            }

            this.func_180455_b(s, f, (float)p_211124_3_, p_211124_5_, false);
            p_211124_3_ += this.field_78288_b;
        }
    }

    public int func_78267_b(String p_78267_1_, int p_78267_2_)
    {
        return this.field_78288_b * this.func_78271_c(p_78267_1_, p_78267_2_).size();
    }

    public void func_78275_b(boolean p_78275_1_)
    {
        this.field_78294_m = p_78275_1_;
    }

    public List<String> func_78271_c(String p_78271_1_, int p_78271_2_)
    {
        return Arrays.asList(this.func_78280_d(p_78271_1_, p_78271_2_).split("\n"));
    }

    public String func_78280_d(String p_78280_1_, int p_78280_2_)
    {
        String s;
        String s1;

        for (s = ""; !p_78280_1_.isEmpty(); s = s + s1 + "\n")
        {
            int i = this.func_78259_e(p_78280_1_, p_78280_2_);

            if (p_78280_1_.length() <= i)
            {
                return s + p_78280_1_;
            }

            s1 = p_78280_1_.substring(0, i);
            char c0 = p_78280_1_.charAt(i);
            boolean flag = c0 == ' ' || c0 == '\n';
            p_78280_1_ = TextFormatting.func_211164_a(s1) + p_78280_1_.substring(i + (flag ? 1 : 0));
        }

        return s;
    }

    private int func_78259_e(String p_78259_1_, int p_78259_2_)
    {
        int i = Math.max(1, p_78259_2_);
        int j = p_78259_1_.length();
        float f = 0.0F;
        int k = 0;
        int l = -1;
        boolean flag = false;

        for (boolean flag1 = true; k < j; ++k)
        {
            char c0 = p_78259_1_.charAt(k);

            switch (c0)
            {
                case '\n':
                    --k;
                    break;
                case ' ':
                    l = k;
                default:

                    if (f != 0.0F)
                    {
                        flag1 = false;
                    }

                    f += this.func_211125_a(c0);

                    if (flag)
                    {
                        ++f;
                    }

                    break;
                case '\u00a7':

                    if (k < j - 1)
                    {
                        ++k;
                        TextFormatting textformatting = TextFormatting.func_211165_a(p_78259_1_.charAt(k));

                        if (textformatting == TextFormatting.BOLD)
                        {
                            flag = true;
                        }
                        else if (textformatting != null && textformatting.func_211166_f())
                        {
                            flag = false;
                        }
                    }
            }

            if (c0 == '\n')
            {
                ++k;
                l = k;
                break;
            }

            if (f > (float)i)
            {
                if (flag1)
                {
                    ++k;
                }

                break;
            }
        }

        return k != j && l != -1 && l < k ? l : k;
    }

    public boolean func_78260_a()
    {
        return this.field_78294_m;
    }

    @OnlyIn(Dist.CLIENT)
    static class Entry
        {
            protected final float field_211169_a;
            protected final float field_211170_b;
            protected final float field_211171_c;
            protected final float field_211172_d;
            protected final float field_211173_e;
            protected final float field_211174_f;
            protected final float field_211175_g;
            protected final float field_211176_h;

            private Entry(float p_i49707_1_, float p_i49707_2_, float p_i49707_3_, float p_i49707_4_, float p_i49707_5_, float p_i49707_6_, float p_i49707_7_, float p_i49707_8_)
            {
                this.field_211169_a = p_i49707_1_;
                this.field_211170_b = p_i49707_2_;
                this.field_211171_c = p_i49707_3_;
                this.field_211172_d = p_i49707_4_;
                this.field_211173_e = p_i49707_5_;
                this.field_211174_f = p_i49707_6_;
                this.field_211175_g = p_i49707_7_;
                this.field_211176_h = p_i49707_8_;
            }

            public void func_211168_a(BufferBuilder p_211168_1_)
            {
                p_211168_1_.func_181662_b((double)this.field_211169_a, (double)this.field_211170_b, 0.0D).func_181666_a(this.field_211173_e, this.field_211174_f, this.field_211175_g, this.field_211176_h).func_181675_d();
                p_211168_1_.func_181662_b((double)this.field_211171_c, (double)this.field_211170_b, 0.0D).func_181666_a(this.field_211173_e, this.field_211174_f, this.field_211175_g, this.field_211176_h).func_181675_d();
                p_211168_1_.func_181662_b((double)this.field_211171_c, (double)this.field_211172_d, 0.0D).func_181666_a(this.field_211173_e, this.field_211174_f, this.field_211175_g, this.field_211176_h).func_181675_d();
                p_211168_1_.func_181662_b((double)this.field_211169_a, (double)this.field_211172_d, 0.0D).func_181666_a(this.field_211173_e, this.field_211174_f, this.field_211175_g, this.field_211176_h).func_181675_d();
            }
        }
}
