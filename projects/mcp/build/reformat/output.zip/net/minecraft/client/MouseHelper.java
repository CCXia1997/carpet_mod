package net.minecraft.client;

import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.IGuiEventListener;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.client.util.InputMappings;
import net.minecraft.client.util.MouseSmoother;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.lwjgl.glfw.GLFW;

@OnlyIn(Dist.CLIENT)
public class MouseHelper
{
    private final Minecraft field_198036_a;
    private boolean field_198037_b;
    private boolean field_198038_c;
    private boolean field_198039_d;
    private double field_198040_e;
    private double field_198041_f;
    private int field_212148_g;
    private int field_198042_g = -1;
    private boolean field_198043_h = true;
    private int field_198044_i;
    private double field_198045_j;
    private final MouseSmoother field_198046_k = new MouseSmoother();
    private final MouseSmoother field_198047_l = new MouseSmoother();
    private double field_198048_m;
    private double field_198049_n;
    private double field_200542_o;
    private double field_198050_o = Double.MIN_VALUE;
    private boolean field_198051_p;

    public MouseHelper(Minecraft p_i47672_1_)
    {
        this.field_198036_a = p_i47672_1_;
    }

    private void func_198023_a(long p_198023_1_, int p_198023_3_, int p_198023_4_, int p_198023_5_)
    {
        if (p_198023_1_ == this.field_198036_a.field_195558_d.func_198092_i())
        {
            boolean flag = p_198023_4_ == 1;

            if (Minecraft.field_142025_a && p_198023_3_ == 0)
            {
                if (flag)
                {
                    if ((p_198023_5_ & 2) == 2)
                    {
                        p_198023_3_ = 1;
                        ++this.field_212148_g;
                    }
                }
                else if (this.field_212148_g > 0)
                {
                    p_198023_3_ = 1;
                    --this.field_212148_g;
                }
            }

            if (flag)
            {
                if (this.field_198036_a.field_71474_y.field_85185_A && this.field_198044_i++ > 0)
                {
                    return;
                }

                this.field_198042_g = p_198023_3_;
                this.field_198045_j = GLFW.glfwGetTime();
            }
            else if (this.field_198042_g != -1)
            {
                if (this.field_198036_a.field_71474_y.field_85185_A && --this.field_198044_i > 0)
                {
                    return;
                }

                this.field_198042_g = -1;
            }

            boolean[] aboolean = new boolean[] {false};

            if (this.field_198036_a.field_71462_r == null)
            {
                if (!this.field_198051_p && flag)
                {
                    this.func_198034_i();
                }
            }
            else
            {
                double d0 = this.field_198040_e * (double)this.field_198036_a.field_195558_d.func_198107_o() / (double)this.field_198036_a.field_195558_d.func_198105_m();
                double d1 = this.field_198041_f * (double)this.field_198036_a.field_195558_d.func_198087_p() / (double)this.field_198036_a.field_195558_d.func_198083_n();
                final int pFinal =  p_198023_3_;

                if (flag)
                {
                    GuiScreen.func_195121_a(() ->
                    {
                        aboolean[0] = this.field_198036_a.field_71462_r.mouseClicked(d0, d1, pFinal);
                    }, "mouseClicked event handler", this.field_198036_a.field_71462_r.getClass().getCanonicalName());
                }
                else
                {
                    GuiScreen.func_195121_a(() ->
                    {
                        aboolean[0] = this.field_198036_a.field_71462_r.mouseReleased(d0, d1, pFinal);
                    }, "mouseReleased event handler", this.field_198036_a.field_71462_r.getClass().getCanonicalName());
                }
            }

            if (!aboolean[0] && (this.field_198036_a.field_71462_r == null || this.field_198036_a.field_71462_r.field_146291_p))
            {
                if (p_198023_3_ == 0)
                {
                    this.field_198037_b = flag;
                }
                else if (p_198023_3_ == 2)
                {
                    this.field_198038_c = flag;
                }
                else if (p_198023_3_ == 1)
                {
                    this.field_198039_d = flag;
                }

                KeyBinding.func_197980_a(InputMappings.Type.MOUSE.func_197944_a(p_198023_3_), flag);

                if (flag)
                {
                    if (this.field_198036_a.field_71439_g.func_175149_v() && p_198023_3_ == 2)
                    {
                        this.field_198036_a.field_71456_v.func_175187_g().func_175261_b();
                    }
                    else
                    {
                        KeyBinding.func_197981_a(InputMappings.Type.MOUSE.func_197944_a(p_198023_3_));
                    }
                }
            }
        }
    }

    private void func_198020_a(long p_198020_1_, double p_198020_3_, double p_198020_5_)
    {
        if (p_198020_1_ == Minecraft.func_71410_x().field_195558_d.func_198092_i())
        {
            double d0 = p_198020_5_ * this.field_198036_a.field_71474_y.field_208033_V;

            if (this.field_198036_a.field_71462_r != null)
            {
                this.field_198036_a.field_71462_r.mouseScrolled(d0);
            }
            else if (this.field_198036_a.field_71439_g != null)
            {
                if (this.field_200542_o != 0.0D && Math.signum(d0) != Math.signum(this.field_200542_o))
                {
                    this.field_200542_o = 0.0D;
                }

                this.field_200542_o += d0;
                double d1 = (double)((int)this.field_200542_o);

                if (d1 == 0.0D)
                {
                    return;
                }

                this.field_200542_o -= d1;

                if (this.field_198036_a.field_71439_g.func_175149_v())
                {
                    if (this.field_198036_a.field_71456_v.func_175187_g().func_175262_a())
                    {
                        this.field_198036_a.field_71456_v.func_175187_g().func_195621_a(-d1);
                    }
                    else
                    {
                        double d2 = MathHelper.func_151237_a((double)this.field_198036_a.field_71439_g.field_71075_bZ.func_75093_a() + d1 * (double)0.005F, 0.0D, (double)0.2F);
                        this.field_198036_a.field_71439_g.field_71075_bZ.func_195931_a(d2);
                    }
                }
                else
                {
                    this.field_198036_a.field_71439_g.field_71071_by.func_195409_a(d1);
                }
            }
        }
    }

    public void func_198029_a(long p_198029_1_)
    {
        GLFW.glfwSetCursorPosCallback(p_198029_1_, this::func_198022_b);
        GLFW.glfwSetMouseButtonCallback(p_198029_1_, this::func_198023_a);
        GLFW.glfwSetScrollCallback(p_198029_1_, this::func_198020_a);
    }

    private void func_198022_b(long p_198022_1_, double p_198022_3_, double p_198022_5_)
    {
        if (p_198022_1_ == Minecraft.func_71410_x().field_195558_d.func_198092_i())
        {
            if (this.field_198043_h)
            {
                this.field_198040_e = p_198022_3_;
                this.field_198041_f = p_198022_5_;
                this.field_198043_h = false;
            }

            IGuiEventListener iguieventlistener = this.field_198036_a.field_71462_r;

            if (this.field_198042_g != -1 && this.field_198045_j > 0.0D && iguieventlistener != null)
            {
                double d0 = p_198022_3_ * (double)this.field_198036_a.field_195558_d.func_198107_o() / (double)this.field_198036_a.field_195558_d.func_198105_m();
                double d1 = p_198022_5_ * (double)this.field_198036_a.field_195558_d.func_198087_p() / (double)this.field_198036_a.field_195558_d.func_198083_n();
                double d2 = (p_198022_3_ - this.field_198040_e) * (double)this.field_198036_a.field_195558_d.func_198107_o() / (double)this.field_198036_a.field_195558_d.func_198105_m();
                double d3 = (p_198022_5_ - this.field_198041_f) * (double)this.field_198036_a.field_195558_d.func_198087_p() / (double)this.field_198036_a.field_195558_d.func_198083_n();
                GuiScreen.func_195121_a(() ->
                {
                    iguieventlistener.mouseDragged(d0, d1, this.field_198042_g, d2, d3);
                }, "mouseDragged event handler", iguieventlistener.getClass().getCanonicalName());
            }

            this.field_198036_a.field_71424_I.func_76320_a("mouse");

            if (this.func_198035_h() && this.field_198036_a.func_195544_aj())
            {
                this.field_198048_m += p_198022_3_ - this.field_198040_e;
                this.field_198049_n += p_198022_5_ - this.field_198041_f;
            }

            this.func_198028_a();
            this.field_198040_e = p_198022_3_;
            this.field_198041_f = p_198022_5_;
            this.field_198036_a.field_71424_I.func_76319_b();
        }
    }

    public void func_198028_a()
    {
        double d0 = GLFW.glfwGetTime();
        double d1 = d0 - this.field_198050_o;
        this.field_198050_o = d0;

        if (this.func_198035_h() && this.field_198036_a.func_195544_aj())
        {
            double d4 = this.field_198036_a.field_71474_y.field_74341_c * (double)0.6F + (double)0.2F;
            double d5 = d4 * d4 * d4 * 8.0D;
            double d2;
            double d3;

            if (this.field_198036_a.field_71474_y.field_74326_T)
            {
                double d6 = this.field_198046_k.func_199102_a(this.field_198048_m * d5, d1 * d5);
                double d7 = this.field_198047_l.func_199102_a(this.field_198049_n * d5, d1 * d5);
                d2 = d6;
                d3 = d7;
            }
            else
            {
                this.field_198046_k.func_199101_a();
                this.field_198047_l.func_199101_a();
                d2 = this.field_198048_m * d5;
                d3 = this.field_198049_n * d5;
            }

            this.field_198048_m = 0.0D;
            this.field_198049_n = 0.0D;
            int i = 1;

            if (this.field_198036_a.field_71474_y.field_74338_d)
            {
                i = -1;
            }

            this.field_198036_a.func_193032_ao().func_195872_a(d2, d3);

            if (this.field_198036_a.field_71439_g != null)
            {
                this.field_198036_a.field_71439_g.func_195049_a(d2, d3 * (double)i);
            }
        }
        else
        {
            this.field_198048_m = 0.0D;
            this.field_198049_n = 0.0D;
        }
    }

    public boolean func_198030_b()
    {
        return this.field_198037_b;
    }

    public boolean func_198031_d()
    {
        return this.field_198039_d;
    }

    public double func_198024_e()
    {
        return this.field_198040_e;
    }

    public double func_198026_f()
    {
        return this.field_198041_f;
    }

    public void func_198021_g()
    {
        this.field_198043_h = true;
    }

    public boolean func_198035_h()
    {
        return this.field_198051_p;
    }

    public void func_198034_i()
    {
        if (this.field_198036_a.func_195544_aj())
        {
            if (!this.field_198051_p)
            {
                if (!Minecraft.field_142025_a)
                {
                    KeyBinding.func_186704_a();
                }

                this.field_198051_p = true;
                this.field_198040_e = (double)(this.field_198036_a.field_195558_d.func_198105_m() / 2);
                this.field_198041_f = (double)(this.field_198036_a.field_195558_d.func_198083_n() / 2);
                GLFW.glfwSetCursorPos(this.field_198036_a.field_195558_d.func_198092_i(), this.field_198040_e, this.field_198041_f);
                GLFW.glfwSetInputMode(this.field_198036_a.field_195558_d.func_198092_i(), 208897, 212995);
                this.field_198036_a.func_147108_a((GuiScreen)null);
                this.field_198036_a.field_71429_W = 10000;
            }
        }
    }

    public void func_198032_j()
    {
        if (this.field_198051_p)
        {
            this.field_198051_p = false;
            GLFW.glfwSetInputMode(this.field_198036_a.field_195558_d.func_198092_i(), 208897, 212993);
            this.field_198040_e = (double)(this.field_198036_a.field_195558_d.func_198105_m() / 2);
            this.field_198041_f = (double)(this.field_198036_a.field_195558_d.func_198083_n() / 2);
            GLFW.glfwSetCursorPos(this.field_198036_a.field_195558_d.func_198092_i(), this.field_198040_e, this.field_198041_f);
        }
    }
}
