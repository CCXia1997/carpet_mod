package net.minecraft.client.audio;

import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.init.SoundEvents;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class UnderwaterAmbientSoundHandler implements IAmbientSoundHandler
{
    private final EntityPlayerSP field_204254_a;
    private final SoundHandler field_204255_b;
    private int field_204256_c = 0;

    public UnderwaterAmbientSoundHandler(EntityPlayerSP p_i48885_1_, SoundHandler p_i48885_2_)
    {
        this.field_204254_a = p_i48885_1_;
        this.field_204255_b = p_i48885_2_;
    }

    public void func_204253_a()
    {
        --this.field_204256_c;

        if (this.field_204256_c <= 0 && this.field_204254_a.func_204231_K())
        {
            float f = this.field_204254_a.field_70170_p.field_73012_v.nextFloat();

            if (f < 1.0E-4F)
            {
                this.field_204256_c = 0;
                this.field_204255_b.func_147682_a(new UnderwaterAmbientSounds.SubSound(this.field_204254_a, SoundEvents.field_204410_e));
            }
            else if (f < 0.001F)
            {
                this.field_204256_c = 0;
                this.field_204255_b.func_147682_a(new UnderwaterAmbientSounds.SubSound(this.field_204254_a, SoundEvents.field_204325_d));
            }
            else if (f < 0.01F)
            {
                this.field_204256_c = 0;
                this.field_204255_b.func_147682_a(new UnderwaterAmbientSounds.SubSound(this.field_204254_a, SoundEvents.field_204324_c));
            }
        }
    }
}
