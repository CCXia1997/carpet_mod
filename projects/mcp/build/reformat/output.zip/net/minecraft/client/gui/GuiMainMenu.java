package net.minecraft.client.gui;

import com.google.common.collect.Lists;
import com.google.common.util.concurrent.Runnables;
import java.io.BufferedReader;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Random;
import net.minecraft.client.GameSettings;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.RenderSkybox;
import net.minecraft.client.renderer.RenderSkyboxCube;
import net.minecraft.client.resources.I18n;
import net.minecraft.realms.RealmsBridge;
import net.minecraft.resources.IResource;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.StringUtils;
import net.minecraft.util.Util;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.world.WorldServerDemo;
import net.minecraft.world.storage.ISaveFormat;
import net.minecraft.world.storage.WorldInfo;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.apache.commons.io.IOUtils;
import org.lwjgl.opengl.GL;

@OnlyIn(Dist.CLIENT)
public class GuiMainMenu extends GuiScreen
{
    private static final Random field_175374_h = new Random();
    private final float field_73974_b;
    private String field_73975_c;
    private GuiButton field_195209_i;
    private GuiButton field_73973_d;
    private final Object field_104025_t = new Object();
    public static final String field_96138_a = "Please click " + TextFormatting.UNDERLINE + "here" + TextFormatting.RESET + " for more information.";
    private int field_92024_r;
    private int field_92023_s;
    private int field_92022_t;
    private int field_92021_u;
    private int field_92020_v;
    private int field_92019_w;
    private String field_92025_p;
    private String field_146972_A = field_96138_a;
    private String field_104024_v;
    private static final ResourceLocation field_110353_x = new ResourceLocation("texts/splashes.txt");
    private static final ResourceLocation field_110352_y = new ResourceLocation("textures/gui/title/minecraft.png");
    private static final ResourceLocation field_194400_H = new ResourceLocation("textures/gui/title/edition.png");
    private boolean field_183502_L;
    private GuiScreen field_183503_M;
    private int field_193978_M;
    private int field_193979_N;
    private final RenderSkybox field_209101_K = new RenderSkybox(new RenderSkyboxCube(new ResourceLocation("textures/gui/title/background/panorama")));

    public GuiMainMenu()
    {
        this.field_73975_c = "missingno";
        IResource iresource = null;

        try
        {
            List<String> list = Lists.newArrayList();
            iresource = Minecraft.func_71410_x().func_195551_G().func_199002_a(field_110353_x);
            BufferedReader bufferedreader = new BufferedReader(new InputStreamReader(iresource.func_199027_b(), StandardCharsets.UTF_8));
            String s;

            while ((s = bufferedreader.readLine()) != null)
            {
                s = s.trim();

                if (!s.isEmpty())
                {
                    list.add(s);
                }
            }

            if (!list.isEmpty())
            {
                while (true)
                {
                    this.field_73975_c = list.get(field_175374_h.nextInt(list.size()));

                    if (this.field_73975_c.hashCode() != 125780783)
                    {
                        break;
                    }
                }
            }
        }
        catch (IOException var8)
        {
            ;
        }
        finally
        {
            IOUtils.closeQuietly((Closeable)iresource);
        }

        this.field_73974_b = field_175374_h.nextFloat();
        this.field_92025_p = "";

        if (!GL.getCapabilities().OpenGL20 && !OpenGlHelper.func_153193_b())
        {
            this.field_92025_p = I18n.func_135052_a("title.oldgl1");
            this.field_146972_A = I18n.func_135052_a("title.oldgl2");
            this.field_104024_v = "https://help.mojang.com/customer/portal/articles/325948?ref=game";
        }
    }

    private boolean func_183501_a()
    {
        return Minecraft.func_71410_x().field_71474_y.func_74308_b(GameSettings.Options.REALMS_NOTIFICATIONS) && this.field_183503_M != null;
    }

    public void func_73876_c()
    {
        if (this.func_183501_a())
        {
            this.field_183503_M.func_73876_c();
        }
    }

    public boolean func_73868_f()
    {
        return false;
    }

    public boolean func_195120_Y_()
    {
        return false;
    }

    protected void func_73866_w_()
    {
        this.field_193978_M = this.field_146289_q.func_78256_a("Copyright Mojang AB. Do not distribute!");
        this.field_193979_N = this.field_146294_l - this.field_193978_M - 2;
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date());

        if (calendar.get(2) + 1 == 12 && calendar.get(5) == 24)
        {
            this.field_73975_c = "Merry X-mas!";
        }
        else if (calendar.get(2) + 1 == 1 && calendar.get(5) == 1)
        {
            this.field_73975_c = "Happy new year!";
        }
        else if (calendar.get(2) + 1 == 10 && calendar.get(5) == 31)
        {
            this.field_73975_c = "OOoooOOOoooo! Spooky!";
        }

        int i = 24;
        int j = this.field_146295_m / 4 + 48;

        if (this.field_146297_k.func_71355_q())
        {
            this.func_73972_b(j, 24);
        }
        else
        {
            this.func_73969_a(j, 24);
        }

        this.field_195209_i = this.func_189646_b(new GuiButton(0, this.field_146294_l / 2 - 100, j + 72 + 12, 98, 20, I18n.func_135052_a("menu.options"))
        {
            public void func_194829_a(double p_194829_1_, double p_194829_3_)
            {
                GuiMainMenu.this.field_146297_k.func_147108_a(new GuiOptions(GuiMainMenu.this, GuiMainMenu.this.field_146297_k.field_71474_y));
            }
        });
        this.func_189646_b(new GuiButton(4, this.field_146294_l / 2 + 2, j + 72 + 12, 98, 20, I18n.func_135052_a("menu.quit"))
        {
            public void func_194829_a(double p_194829_1_, double p_194829_3_)
            {
                GuiMainMenu.this.field_146297_k.func_71400_g();
            }
        });
        this.func_189646_b(new GuiButtonLanguage(5, this.field_146294_l / 2 - 124, j + 72 + 12)
        {
            public void func_194829_a(double p_194829_1_, double p_194829_3_)
            {
                GuiMainMenu.this.field_146297_k.func_147108_a(new GuiLanguage(GuiMainMenu.this, GuiMainMenu.this.field_146297_k.field_71474_y, GuiMainMenu.this.field_146297_k.func_135016_M()));
            }
        });

        synchronized (this.field_104025_t)
        {
            this.field_92023_s = this.field_146289_q.func_78256_a(this.field_92025_p);
            this.field_92024_r = this.field_146289_q.func_78256_a(this.field_146972_A);
            int k = Math.max(this.field_92023_s, this.field_92024_r);
            this.field_92022_t = (this.field_146294_l - k) / 2;
            this.field_92021_u = j - 24;
            this.field_92020_v = this.field_92022_t + k;
            this.field_92019_w = this.field_92021_u + 24;
        }

        this.field_146297_k.func_181537_a(false);

        if (Minecraft.func_71410_x().field_71474_y.func_74308_b(GameSettings.Options.REALMS_NOTIFICATIONS) && !this.field_183502_L)
        {
            RealmsBridge realmsbridge = new RealmsBridge();
            this.field_183503_M = realmsbridge.getNotificationScreen(this);
            this.field_183502_L = true;
        }

        if (this.func_183501_a())
        {
            this.field_183503_M.func_146280_a(this.field_146297_k, this.field_146294_l, this.field_146295_m);
        }
    }

    private void func_73969_a(int p_73969_1_, int p_73969_2_)
    {
        this.func_189646_b(new GuiButton(1, this.field_146294_l / 2 - 100, p_73969_1_, I18n.func_135052_a("menu.singleplayer"))
        {
            public void func_194829_a(double p_194829_1_, double p_194829_3_)
            {
                GuiMainMenu.this.field_146297_k.func_147108_a(new GuiWorldSelection(GuiMainMenu.this));
            }
        });
        this.func_189646_b(new GuiButton(2, this.field_146294_l / 2 - 100, p_73969_1_ + p_73969_2_ * 1, I18n.func_135052_a("menu.multiplayer"))
        {
            public void func_194829_a(double p_194829_1_, double p_194829_3_)
            {
                GuiMainMenu.this.field_146297_k.func_147108_a(new GuiMultiplayer(GuiMainMenu.this));
            }
        });
        this.func_189646_b(new GuiButton(14, this.field_146294_l / 2 - 100, p_73969_1_ + p_73969_2_ * 2, I18n.func_135052_a("menu.online"))
        {
            public void func_194829_a(double p_194829_1_, double p_194829_3_)
            {
                GuiMainMenu.this.func_140005_i();
            }
        });
    }

    private void func_73972_b(int p_73972_1_, int p_73972_2_)
    {
        this.func_189646_b(new GuiButton(11, this.field_146294_l / 2 - 100, p_73972_1_, I18n.func_135052_a("menu.playdemo"))
        {
            public void func_194829_a(double p_194829_1_, double p_194829_3_)
            {
                GuiMainMenu.this.field_146297_k.func_71371_a("Demo_World", "Demo_World", WorldServerDemo.field_73071_a);
            }
        });
        this.field_73973_d = this.func_189646_b(new GuiButton(12, this.field_146294_l / 2 - 100, p_73972_1_ + p_73972_2_ * 1, I18n.func_135052_a("menu.resetdemo"))
        {
            public void func_194829_a(double p_194829_1_, double p_194829_3_)
            {
                ISaveFormat isaveformat1 = GuiMainMenu.this.field_146297_k.func_71359_d();
                WorldInfo worldinfo1 = isaveformat1.func_75803_c("Demo_World");

                if (worldinfo1 != null)
                {
                    GuiMainMenu.this.field_146297_k.func_147108_a(new GuiYesNo(GuiMainMenu.this, I18n.func_135052_a("selectWorld.deleteQuestion"), I18n.func_135052_a("selectWorld.deleteWarning", worldinfo1.func_76065_j()), I18n.func_135052_a("selectWorld.deleteButton"), I18n.func_135052_a("gui.cancel"), 12));
                }
            }
        });
        ISaveFormat isaveformat = this.field_146297_k.func_71359_d();
        WorldInfo worldinfo = isaveformat.func_75803_c("Demo_World");

        if (worldinfo == null)
        {
            this.field_73973_d.field_146124_l = false;
        }
    }

    private void func_140005_i()
    {
        RealmsBridge realmsbridge = new RealmsBridge();
        realmsbridge.switchToRealms(this);
    }

    public void confirmResult(boolean p_confirmResult_1_, int p_confirmResult_2_)
    {
        if (p_confirmResult_1_ && p_confirmResult_2_ == 12)
        {
            ISaveFormat isaveformat = this.field_146297_k.func_71359_d();
            isaveformat.func_75800_d();
            isaveformat.func_75802_e("Demo_World");
            this.field_146297_k.func_147108_a(this);
        }
        else if (p_confirmResult_2_ == 12)
        {
            this.field_146297_k.func_147108_a(this);
        }
        else if (p_confirmResult_2_ == 13)
        {
            if (p_confirmResult_1_)
            {
                Util.func_110647_a().func_195640_a(this.field_104024_v);
            }

            this.field_146297_k.func_147108_a(this);
        }
    }

    public void func_73863_a(int p_73863_1_, int p_73863_2_, float p_73863_3_)
    {
        this.field_209101_K.func_209144_a(p_73863_3_);
        int i = 274;
        int j = this.field_146294_l / 2 - 137;
        int k = 30;
        this.field_146297_k.func_110434_K().func_110577_a(new ResourceLocation("textures/gui/title/background/panorama_overlay.png"));
        func_152125_a(0, 0, 0.0F, 0.0F, 16, 128, this.field_146294_l, this.field_146295_m, 16.0F, 128.0F);
        this.field_146297_k.func_110434_K().func_110577_a(field_110352_y);
        GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);

        if ((double)this.field_73974_b < 1.0E-4D)
        {
            this.func_73729_b(j + 0, 30, 0, 0, 99, 44);
            this.func_73729_b(j + 99, 30, 129, 0, 27, 44);
            this.func_73729_b(j + 99 + 26, 30, 126, 0, 3, 44);
            this.func_73729_b(j + 99 + 26 + 3, 30, 99, 0, 26, 44);
            this.func_73729_b(j + 155, 30, 0, 45, 155, 44);
        }
        else
        {
            this.func_73729_b(j + 0, 30, 0, 0, 155, 44);
            this.func_73729_b(j + 155, 30, 0, 45, 155, 44);
        }

        this.field_146297_k.func_110434_K().func_110577_a(field_194400_H);
        func_146110_a(j + 88, 67, 0.0F, 0.0F, 98, 14, 128.0F, 16.0F);
        GlStateManager.func_179094_E();
        GlStateManager.func_179109_b((float)(this.field_146294_l / 2 + 90), 70.0F, 0.0F);
        GlStateManager.func_179114_b(-20.0F, 0.0F, 0.0F, 1.0F);
        float f = 1.8F - MathHelper.func_76135_e(MathHelper.func_76126_a((float)(Util.func_211177_b() % 1000L) / 1000.0F * ((float)Math.PI * 2F)) * 0.1F);
        f = f * 100.0F / (float)(this.field_146289_q.func_78256_a(this.field_73975_c) + 32);
        GlStateManager.func_179152_a(f, f, f);
        this.func_73732_a(this.field_146289_q, this.field_73975_c, 0, -8, -256);
        GlStateManager.func_179121_F();
        String s = "Minecraft 1.13.2";

        if (this.field_146297_k.func_71355_q())
        {
            s = s + " Demo";
        }
        else
        {
            s = s + ("release".equalsIgnoreCase(this.field_146297_k.func_184123_d()) ? "" : "/" + this.field_146297_k.func_184123_d());
        }

        this.func_73731_b(this.field_146289_q, s, 2, this.field_146295_m - 10, -1);
        this.func_73731_b(this.field_146289_q, "Copyright Mojang AB. Do not distribute!", this.field_193979_N, this.field_146295_m - 10, -1);

        if (p_73863_1_ > this.field_193979_N && p_73863_1_ < this.field_193979_N + this.field_193978_M && p_73863_2_ > this.field_146295_m - 10 && p_73863_2_ < this.field_146295_m)
        {
            func_73734_a(this.field_193979_N, this.field_146295_m - 1, this.field_193979_N + this.field_193978_M, this.field_146295_m, -1);
        }

        if (this.field_92025_p != null && !this.field_92025_p.isEmpty())
        {
            func_73734_a(this.field_92022_t - 2, this.field_92021_u - 2, this.field_92020_v + 2, this.field_92019_w - 1, 1428160512);
            this.func_73731_b(this.field_146289_q, this.field_92025_p, this.field_92022_t, this.field_92021_u, -1);
            this.func_73731_b(this.field_146289_q, this.field_146972_A, (this.field_146294_l - this.field_92024_r) / 2, this.field_92021_u + 12, -1);
        }

        super.func_73863_a(p_73863_1_, p_73863_2_, p_73863_3_);

        if (this.func_183501_a())
        {
            this.field_183503_M.func_73863_a(p_73863_1_, p_73863_2_, p_73863_3_);
        }
    }

    public boolean mouseClicked(double p_mouseClicked_1_, double p_mouseClicked_3_, int p_mouseClicked_5_)
    {
        if (super.mouseClicked(p_mouseClicked_1_, p_mouseClicked_3_, p_mouseClicked_5_))
        {
            return true;
        }
        else
        {
            synchronized (this.field_104025_t)
            {
                if (!this.field_92025_p.isEmpty() && !StringUtils.func_151246_b(this.field_104024_v) && p_mouseClicked_1_ >= (double)this.field_92022_t && p_mouseClicked_1_ <= (double)this.field_92020_v && p_mouseClicked_3_ >= (double)this.field_92021_u && p_mouseClicked_3_ <= (double)this.field_92019_w)
                {
                    GuiConfirmOpenLink guiconfirmopenlink = new GuiConfirmOpenLink(this, this.field_104024_v, 13, true);
                    guiconfirmopenlink.func_146358_g();
                    this.field_146297_k.func_147108_a(guiconfirmopenlink);
                    return true;
                }
            }

            if (this.func_183501_a() && this.field_183503_M.mouseClicked(p_mouseClicked_1_, p_mouseClicked_3_, p_mouseClicked_5_))
            {
                return true;
            }
            else
            {
                if (p_mouseClicked_1_ > (double)this.field_193979_N && p_mouseClicked_1_ < (double)(this.field_193979_N + this.field_193978_M) && p_mouseClicked_3_ > (double)(this.field_146295_m - 10) && p_mouseClicked_3_ < (double)this.field_146295_m)
                {
                    this.field_146297_k.func_147108_a(new GuiWinGame(false, Runnables.doNothing()));
                }

                return false;
            }
        }
    }

    public void func_146281_b()
    {
        if (this.field_183503_M != null)
        {
            this.field_183503_M.func_146281_b();
        }
    }
}
