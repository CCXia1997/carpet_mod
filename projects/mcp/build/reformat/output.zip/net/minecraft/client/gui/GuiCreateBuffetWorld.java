package net.minecraft.client.gui;

import com.google.common.collect.Lists;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import javax.annotation.Nullable;
import net.minecraft.client.resources.I18n;
import net.minecraft.nbt.INBTBase;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.nbt.NBTTagString;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.Util;
import net.minecraft.util.registry.IRegistry;
import net.minecraft.world.biome.provider.BiomeProviderType;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class GuiCreateBuffetWorld extends GuiScreen
{
    private static final List<ResourceLocation> field_205310_a = IRegistry.field_212627_p.func_148742_b().stream().filter((p_205307_0_) ->
    {
        return IRegistry.field_212627_p.func_212608_b(p_205307_0_).func_205481_b();
    }).collect(Collectors.toList());
    private final GuiCreateWorld field_205314_f;
    private final List<ResourceLocation> field_205315_g = Lists.newArrayList();
    private final ResourceLocation[] field_205316_h = new ResourceLocation[IRegistry.field_212624_m.func_148742_b().size()];
    private String field_205317_i;
    private GuiCreateBuffetWorld.BiomeList field_205311_s;
    private int field_205312_t;
    private GuiButton field_205313_u;

    public GuiCreateBuffetWorld(GuiCreateWorld p_i49701_1_, NBTTagCompound p_i49701_2_)
    {
        this.field_205314_f = p_i49701_1_;
        int i = 0;

        for (ResourceLocation resourcelocation : IRegistry.field_212624_m.func_148742_b())
        {
            this.field_205316_h[i] = resourcelocation;
            ++i;
        }

        Arrays.sort(this.field_205316_h, (p_210140_0_, p_210140_1_) ->
        {
            String s = IRegistry.field_212624_m.func_212608_b(p_210140_0_).func_205403_k().getString();
            String s1 = IRegistry.field_212624_m.func_212608_b(p_210140_1_).func_205403_k().getString();
            return s.compareTo(s1);
        });
        this.func_210506_a(p_i49701_2_);
    }

    private void func_210506_a(NBTTagCompound p_210506_1_)
    {
        if (p_210506_1_.func_150297_b("chunk_generator", 10) && p_210506_1_.func_74775_l("chunk_generator").func_150297_b("type", 8))
        {
            ResourceLocation resourcelocation = new ResourceLocation(p_210506_1_.func_74775_l("chunk_generator").func_74779_i("type"));

            for (int i = 0; i < field_205310_a.size(); ++i)
            {
                if (field_205310_a.get(i).equals(resourcelocation))
                {
                    this.field_205312_t = i;
                    break;
                }
            }
        }

        if (p_210506_1_.func_150297_b("biome_source", 10) && p_210506_1_.func_74775_l("biome_source").func_150297_b("biomes", 9))
        {
            NBTTagList nbttaglist = p_210506_1_.func_74775_l("biome_source").func_150295_c("biomes", 8);

            for (int j = 0; j < nbttaglist.size(); ++j)
            {
                this.field_205315_g.add(new ResourceLocation(nbttaglist.func_150307_f(j)));
            }
        }
    }

    private NBTTagCompound func_210507_j()
    {
        NBTTagCompound nbttagcompound = new NBTTagCompound();
        NBTTagCompound nbttagcompound1 = new NBTTagCompound();
        nbttagcompound1.func_74778_a("type", IRegistry.field_212625_n.func_177774_c(BiomeProviderType.field_205461_c).toString());
        NBTTagCompound nbttagcompound2 = new NBTTagCompound();
        NBTTagList nbttaglist = new NBTTagList();

        for (ResourceLocation resourcelocation : this.field_205315_g)
        {
            nbttaglist.add((INBTBase)(new NBTTagString(resourcelocation.toString())));
        }

        nbttagcompound2.func_74782_a("biomes", nbttaglist);
        nbttagcompound1.func_74782_a("options", nbttagcompound2);
        NBTTagCompound nbttagcompound3 = new NBTTagCompound();
        NBTTagCompound nbttagcompound4 = new NBTTagCompound();
        nbttagcompound3.func_74778_a("type", field_205310_a.get(this.field_205312_t).toString());
        nbttagcompound4.func_74778_a("default_block", "minecraft:stone");
        nbttagcompound4.func_74778_a("default_fluid", "minecraft:water");
        nbttagcompound3.func_74782_a("options", nbttagcompound4);
        nbttagcompound.func_74782_a("biome_source", nbttagcompound1);
        nbttagcompound.func_74782_a("chunk_generator", nbttagcompound3);
        return nbttagcompound;
    }

    @Nullable
    public IGuiEventListener getFocused()
    {
        return this.field_205311_s;
    }

    protected void func_73866_w_()
    {
        this.field_146297_k.field_195559_v.func_197967_a(true);
        this.field_205317_i = I18n.func_135052_a("createWorld.customize.buffet.title");
        this.field_205311_s = new GuiCreateBuffetWorld.BiomeList();
        this.field_195124_j.add(this.field_205311_s);
        this.func_189646_b(new GuiButton(2, (this.field_146294_l - 200) / 2, 40, 200, 20, I18n.func_135052_a("createWorld.customize.buffet.generatortype") + " " + I18n.func_135052_a(Util.func_200697_a("generator", field_205310_a.get(this.field_205312_t))))
        {
            public void func_194829_a(double p_194829_1_, double p_194829_3_)
            {
                GuiCreateBuffetWorld.this.field_205312_t++;

                if (GuiCreateBuffetWorld.this.field_205312_t >= GuiCreateBuffetWorld.field_205310_a.size())
                {
                    GuiCreateBuffetWorld.this.field_205312_t = 0;
                }

                this.field_146126_j = I18n.func_135052_a("createWorld.customize.buffet.generatortype") + " " + I18n.func_135052_a(Util.func_200697_a("generator", GuiCreateBuffetWorld.field_205310_a.get(GuiCreateBuffetWorld.this.field_205312_t)));
            }
        });
        this.field_205313_u = this.func_189646_b(new GuiButton(0, this.field_146294_l / 2 - 155, this.field_146295_m - 28, 150, 20, I18n.func_135052_a("gui.done"))
        {
            public void func_194829_a(double p_194829_1_, double p_194829_3_)
            {
                GuiCreateBuffetWorld.this.field_205314_f.field_146334_a = GuiCreateBuffetWorld.this.func_210507_j();
                GuiCreateBuffetWorld.this.field_146297_k.func_147108_a(GuiCreateBuffetWorld.this.field_205314_f);
            }
        });
        this.func_189646_b(new GuiButton(1, this.field_146294_l / 2 + 5, this.field_146295_m - 28, 150, 20, I18n.func_135052_a("gui.cancel"))
        {
            public void func_194829_a(double p_194829_1_, double p_194829_3_)
            {
                GuiCreateBuffetWorld.this.field_146297_k.func_147108_a(GuiCreateBuffetWorld.this.field_205314_f);
            }
        });
        this.func_205306_h();
    }

    public void func_205306_h()
    {
        this.field_205313_u.field_146124_l = !this.field_205315_g.isEmpty();
    }

    public void func_73863_a(int p_73863_1_, int p_73863_2_, float p_73863_3_)
    {
        this.func_146278_c(0);
        this.field_205311_s.func_148128_a(p_73863_1_, p_73863_2_, p_73863_3_);
        this.func_73732_a(this.field_146289_q, this.field_205317_i, this.field_146294_l / 2, 8, 16777215);
        this.func_73732_a(this.field_146289_q, I18n.func_135052_a("createWorld.customize.buffet.generator"), this.field_146294_l / 2, 30, 10526880);
        this.func_73732_a(this.field_146289_q, I18n.func_135052_a("createWorld.customize.buffet.biome"), this.field_146294_l / 2, 68, 10526880);
        super.func_73863_a(p_73863_1_, p_73863_2_, p_73863_3_);
    }

    @OnlyIn(Dist.CLIENT)
    class BiomeList extends GuiSlot
    {
        private BiomeList()
        {
            super(GuiCreateBuffetWorld.this.field_146297_k, GuiCreateBuffetWorld.this.field_146294_l, GuiCreateBuffetWorld.this.field_146295_m, 80, GuiCreateBuffetWorld.this.field_146295_m - 37, 16);
        }

        protected int func_148127_b()
        {
            return GuiCreateBuffetWorld.this.field_205316_h.length;
        }

        protected boolean func_195078_a(int p_195078_1_, int p_195078_2_, double p_195078_3_, double p_195078_5_)
        {
            GuiCreateBuffetWorld.this.field_205315_g.clear();
            GuiCreateBuffetWorld.this.field_205315_g.add(GuiCreateBuffetWorld.this.field_205316_h[p_195078_1_]);
            GuiCreateBuffetWorld.this.func_205306_h();
            return true;
        }

        protected boolean func_148131_a(int p_148131_1_)
        {
            return GuiCreateBuffetWorld.this.field_205315_g.contains(GuiCreateBuffetWorld.this.field_205316_h[p_148131_1_]);
        }

        protected void func_148123_a()
        {
        }

        protected void func_192637_a(int p_192637_1_, int p_192637_2_, int p_192637_3_, int p_192637_4_, int p_192637_5_, int p_192637_6_, float p_192637_7_)
        {
            this.func_73731_b(GuiCreateBuffetWorld.this.field_146289_q, IRegistry.field_212624_m.func_212608_b(GuiCreateBuffetWorld.this.field_205316_h[p_192637_1_]).func_205403_k().getString(), p_192637_2_ + 5, p_192637_3_ + 2, 16777215);
        }
    }
}
