package net.minecraft.client;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.util.Optional;
import java.util.function.BiConsumer;
import javax.annotation.Nullable;
import net.minecraft.client.main.GameConfiguration;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.VideoMode;
import net.minecraft.client.renderer.VirtualScreen;
import net.minecraft.client.renderer.texture.TextureUtil;
import net.minecraft.client.shader.Framebuffer;
import net.minecraft.resources.ResourcePackType;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.Util;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.lwjgl.PointerBuffer;
import org.lwjgl.glfw.Callbacks;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.glfw.GLFWErrorCallback;
import org.lwjgl.glfw.GLFWImage;
import org.lwjgl.glfw.GLFWImage.Buffer;
import org.lwjgl.opengl.GL;
import org.lwjgl.stb.STBImage;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.system.MemoryUtil;

@OnlyIn(Dist.CLIENT)
public final class MainWindow implements AutoCloseable
{
    private static final Logger field_198114_a = LogManager.getLogger();
    private final GLFWErrorCallback field_198115_b = GLFWErrorCallback.create(this::func_198084_a);
    private final Minecraft field_198116_c;
    private final VirtualScreen field_198117_d;
    private Monitor field_198118_e;
    private final long field_198119_f;
    private int field_198120_g;
    private int field_198121_h;
    private int field_198122_i;
    private int field_198123_j;
    private Optional<VideoMode> field_198124_k;
    private boolean field_198125_l;
    private boolean field_198126_m;
    private int field_198127_n;
    private int field_198128_o;
    private int field_198129_p;
    private int field_198130_q;
    private int field_198131_r;
    private int field_198132_s;
    private int field_198133_t;
    private int field_198134_u;
    private double field_198135_v;
    private String field_198136_w = "";
    private boolean field_198138_y;
    private double field_198139_z = Double.MIN_VALUE;

    public MainWindow(Minecraft p_i47667_1_, VirtualScreen p_i47667_2_, GameConfiguration.DisplayInformation p_i47667_3_, String p_i47667_4_)
    {
        this.field_198117_d = p_i47667_2_;
        this.func_198093_u();
        this.func_198076_a("Pre startup");
        this.field_198116_c = p_i47667_1_;
        Optional<VideoMode> optional = VideoMode.func_198061_a(p_i47667_4_);

        if (optional.isPresent())
        {
            this.field_198124_k = optional;
        }
        else if (p_i47667_3_.field_199045_c.isPresent() && p_i47667_3_.field_199046_d.isPresent())
        {
            this.field_198124_k = Optional.of(new VideoMode(p_i47667_3_.field_199045_c.get(), p_i47667_3_.field_199046_d.get(), 8, 8, 8, 60));
        }
        else
        {
            this.field_198124_k = Optional.empty();
        }

        this.field_198126_m = this.field_198125_l = p_i47667_3_.field_178763_c;
        this.field_198118_e = p_i47667_2_.func_198054_a(GLFW.glfwGetPrimaryMonitor());
        VideoMode videomode = this.field_198118_e.func_197992_a(this.field_198125_l ? this.field_198124_k : Optional.empty());
        this.field_198122_i = this.field_198129_p = p_i47667_3_.field_178764_a > 0 ? p_i47667_3_.field_178764_a : 1;
        this.field_198123_j = this.field_198130_q = p_i47667_3_.field_178762_b > 0 ? p_i47667_3_.field_178762_b : 1;
        this.field_198120_g = this.field_198127_n = this.field_198118_e.func_197989_c() + videomode.func_198064_a() / 2 - this.field_198129_p / 2;
        this.field_198121_h = this.field_198128_o = this.field_198118_e.func_197990_d() + videomode.func_198065_b() / 2 - this.field_198130_q / 2;
        GLFW.glfwDefaultWindowHints();
        this.field_198119_f = GLFW.glfwCreateWindow(this.field_198129_p, this.field_198130_q, "Minecraft 1.13.2", this.field_198125_l ? this.field_198118_e.func_197995_f() : 0L, 0L);
        p_i47667_1_.field_195555_I = true;
        this.func_198085_v();
        GLFW.glfwMakeContextCurrent(this.field_198119_f);
        GL.createCapabilities();
        this.func_198108_y();
        this.func_198103_w();
        this.func_198110_t();
        GLFW.glfwSetFramebufferSizeCallback(this.field_198119_f, this::func_198102_b);
        GLFW.glfwSetWindowPosCallback(this.field_198119_f, this::func_198080_a);
        GLFW.glfwSetWindowSizeCallback(this.field_198119_f, this::func_198089_c);
        GLFW.glfwSetWindowFocusCallback(this.field_198119_f, this::func_198095_a);
        p_i47667_1_.field_71417_B = new MouseHelper(p_i47667_1_);
        p_i47667_1_.field_71417_B.func_198029_a(this.field_198119_f);
        p_i47667_1_.field_195559_v = new KeyboardListener(p_i47667_1_);
        p_i47667_1_.field_195559_v.func_197968_a(this.field_198119_f);
    }

    public static void func_211162_a(BiConsumer<Integer, String> p_211162_0_)
    {
        try (MemoryStack memorystack = MemoryStack.stackPush())
        {
            PointerBuffer pointerbuffer = memorystack.mallocPointer(1);
            int i = GLFW.glfwGetError(pointerbuffer);

            if (i != 0)
            {
                long j = pointerbuffer.get();
                String s = j != 0L ? MemoryUtil.memUTF8(j) : "";
                p_211162_0_.accept(i, s);
            }
        }
    }

    public void func_198094_a()
    {
        GlStateManager.func_179086_m(256);
        GlStateManager.func_179128_n(5889);
        GlStateManager.func_179096_D();
        GlStateManager.func_179130_a(0.0D, (double)this.func_198109_k() / this.func_198100_s(), (double)this.func_198091_l() / this.func_198100_s(), 0.0D, 1000.0D, 3000.0D);
        GlStateManager.func_179128_n(5888);
        GlStateManager.func_179096_D();
        GlStateManager.func_179109_b(0.0F, 0.0F, -2000.0F);
    }

    private void func_198110_t()
    {
        try (
                MemoryStack memorystack = MemoryStack.stackPush();
                InputStream inputstream = this.field_198116_c.func_195541_I().func_195746_a().func_195761_a(ResourcePackType.CLIENT_RESOURCES, new ResourceLocation("icons/icon_16x16.png"));
                InputStream inputstream1 = this.field_198116_c.func_195541_I().func_195746_a().func_195761_a(ResourcePackType.CLIENT_RESOURCES, new ResourceLocation("icons/icon_32x32.png"));
            )
        {
            if (inputstream == null)
            {
                throw new FileNotFoundException("icons/icon_16x16.png");
            }

            if (inputstream1 == null)
            {
                throw new FileNotFoundException("icons/icon_32x32.png");
            }

            IntBuffer intbuffer = memorystack.mallocInt(1);
            IntBuffer intbuffer1 = memorystack.mallocInt(1);
            IntBuffer intbuffer2 = memorystack.mallocInt(1);
            Buffer buffer = GLFWImage.mallocStack(2, memorystack);
            ByteBuffer bytebuffer = this.func_198111_a(inputstream, intbuffer, intbuffer1, intbuffer2);

            if (bytebuffer == null)
            {
                throw new IllegalStateException("Could not load icon: " + STBImage.stbi_failure_reason());
            }

            buffer.position(0);
            buffer.width(intbuffer.get(0));
            buffer.height(intbuffer1.get(0));
            buffer.pixels(bytebuffer);
            ByteBuffer bytebuffer1 = this.func_198111_a(inputstream1, intbuffer, intbuffer1, intbuffer2);

            if (bytebuffer1 == null)
            {
                throw new IllegalStateException("Could not load icon: " + STBImage.stbi_failure_reason());
            }

            buffer.position(1);
            buffer.width(intbuffer.get(0));
            buffer.height(intbuffer1.get(0));
            buffer.pixels(bytebuffer1);
            buffer.position(0);
            GLFW.glfwSetWindowIcon(this.field_198119_f, buffer);
            STBImage.stbi_image_free(bytebuffer);
            STBImage.stbi_image_free(bytebuffer1);
        }
        catch (IOException ioexception)
        {
            field_198114_a.error("Couldn't set icon", (Throwable)ioexception);
        }
    }

    @Nullable
    private ByteBuffer func_198111_a(InputStream p_198111_1_, IntBuffer p_198111_2_, IntBuffer p_198111_3_, IntBuffer p_198111_4_) throws IOException
    {
        ByteBuffer bytebuffer = null;
        ByteBuffer bytebuffer1;

        try
        {
            bytebuffer = TextureUtil.func_195724_a(p_198111_1_);
            bytebuffer.rewind();
            bytebuffer1 = STBImage.stbi_load_from_memory(bytebuffer, p_198111_2_, p_198111_3_, p_198111_4_, 0);
        }
        finally
        {
            if (bytebuffer != null)
            {
                MemoryUtil.memFree(bytebuffer);
            }
        }

        return bytebuffer1;
    }

    void func_198076_a(String p_198076_1_)
    {
        this.field_198136_w = p_198076_1_;
    }

    private void func_198093_u()
    {
        GLFW.glfwSetErrorCallback(MainWindow::func_208034_b);
    }

    private static void func_208034_b(int p_208034_0_, long p_208034_1_)
    {
        throw new IllegalStateException("GLFW error " + p_208034_0_ + ": " + MemoryUtil.memUTF8(p_208034_1_));
    }

    void func_198084_a(int p_198084_1_, long p_198084_2_)
    {
        String s = MemoryUtil.memUTF8(p_198084_2_);
        field_198114_a.error("########## GL ERROR ##########");
        field_198114_a.error("@ {}", (Object)this.field_198136_w);
        field_198114_a.error("{}: {}", p_198084_1_, s);
    }

    void func_198112_b()
    {
        GLFW.glfwSetErrorCallback(this.field_198115_b).free();
    }

    public void func_209548_c()
    {
        GLFW.glfwSwapInterval(this.field_198116_c.field_71474_y.field_74352_v ? 1 : 0);
    }

    public void close()
    {
        Util.field_211180_a = System::nanoTime;
        Callbacks.glfwFreeCallbacks(this.field_198119_f);
        this.field_198115_b.close();
        GLFW.glfwDestroyWindow(this.field_198119_f);
        GLFW.glfwTerminate();
    }

    private void func_198085_v()
    {
        this.field_198118_e = this.field_198117_d.func_198055_a(this);
    }

    private void func_198080_a(long p_198080_1_, int p_198080_3_, int p_198080_4_)
    {
        this.field_198127_n = p_198080_3_;
        this.field_198128_o = p_198080_4_;
        this.func_198085_v();
    }

    private void func_198102_b(long p_198102_1_, int p_198102_3_, int p_198102_4_)
    {
        if (p_198102_1_ == this.field_198119_f)
        {
            int i = this.func_198109_k();
            int j = this.func_198091_l();

            if (p_198102_3_ != 0 && p_198102_4_ != 0)
            {
                this.field_198131_r = p_198102_3_;
                this.field_198132_s = p_198102_4_;

                if (this.func_198109_k() != i || this.func_198091_l() != j)
                {
                    this.func_198098_h();
                }
            }
        }
    }

    private void func_198103_w()
    {
        int[] aint = new int[1];
        int[] aint1 = new int[1];
        GLFW.glfwGetFramebufferSize(this.field_198119_f, aint, aint1);
        this.field_198131_r = aint[0];
        this.field_198132_s = aint1[0];
    }

    private void func_198089_c(long p_198089_1_, int p_198089_3_, int p_198089_4_)
    {
        this.field_198129_p = p_198089_3_;
        this.field_198130_q = p_198089_4_;
        this.func_198085_v();
    }

    private void func_198095_a(long p_198095_1_, boolean p_198095_3_)
    {
        if (p_198095_1_ == this.field_198119_f)
        {
            this.field_198116_c.field_195555_I = p_198095_3_;
        }
    }

    private int func_198082_x()
    {
        return this.field_198116_c.field_71441_e == null && this.field_198116_c.field_71462_r != null ? 60 : this.field_198116_c.field_71474_y.field_74350_i;
    }

    public boolean func_198096_c()
    {
        return (double)this.func_198082_x() < GameSettings.Options.FRAMERATE_LIMIT.func_198009_f();
    }

    public void func_198086_a(boolean p_198086_1_)
    {
        this.field_198116_c.field_71424_I.func_76320_a("display_update");
        GLFW.glfwSwapBuffers(this.field_198119_f);
        GLFW.glfwPollEvents();

        if (this.field_198125_l != this.field_198126_m)
        {
            this.field_198126_m = this.field_198125_l;
            this.func_198081_z();
        }

        this.field_198116_c.field_71424_I.func_76319_b();

        if (p_198086_1_ && this.func_198096_c())
        {
            this.field_198116_c.field_71424_I.func_76320_a("fpslimit_wait");
            double d0 = this.field_198139_z + 1.0D / (double)this.func_198082_x();
            double d1;

            for (d1 = GLFW.glfwGetTime(); d1 < d0; d1 = GLFW.glfwGetTime())
            {
                GLFW.glfwWaitEventsTimeout(d0 - d1);
            }

            this.field_198139_z = d1;
            this.field_198116_c.field_71424_I.func_76319_b();
        }
    }

    public Optional<VideoMode> func_198106_d()
    {
        return this.field_198124_k;
    }

    public int func_198090_e()
    {
        return this.field_198124_k.isPresent() ? this.field_198118_e.func_197993_b(this.field_198124_k) + 1 : 0;
    }

    public String func_198088_a(int p_198088_1_)
    {
        if (this.field_198118_e.func_197994_e() <= p_198088_1_)
        {
            p_198088_1_ = this.field_198118_e.func_197994_e() - 1;
        }

        return this.field_198118_e.func_197991_a(p_198088_1_).toString();
    }

    public void func_198104_b(int p_198104_1_)
    {
        Optional<VideoMode> optional = this.field_198124_k;

        if (p_198104_1_ == 0)
        {
            this.field_198124_k = Optional.empty();
        }
        else
        {
            this.field_198124_k = Optional.of(this.field_198118_e.func_197991_a(p_198104_1_ - 1));
        }

        if (!this.field_198124_k.equals(optional))
        {
            this.field_198138_y = true;
        }
    }

    public void func_198097_f()
    {
        if (this.field_198125_l && this.field_198138_y)
        {
            this.field_198138_y = false;
            this.func_198108_y();
            this.func_198098_h();
        }
    }

    private void func_198108_y()
    {
        boolean flag = GLFW.glfwGetWindowMonitor(this.field_198119_f) != 0L;

        if (this.field_198125_l)
        {
            VideoMode videomode = this.field_198118_e.func_197992_a(this.field_198124_k);

            if (!flag)
            {
                this.field_198120_g = this.field_198127_n;
                this.field_198121_h = this.field_198128_o;
                this.field_198122_i = this.field_198129_p;
                this.field_198123_j = this.field_198130_q;
            }

            this.field_198127_n = 0;
            this.field_198128_o = 0;
            this.field_198129_p = videomode.func_198064_a();
            this.field_198130_q = videomode.func_198065_b();
            GLFW.glfwSetWindowMonitor(this.field_198119_f, this.field_198118_e.func_197995_f(), this.field_198127_n, this.field_198128_o, this.field_198129_p, this.field_198130_q, videomode.func_198067_f());
        }
        else
        {
            VideoMode videomode1 = this.field_198118_e.func_197987_b();
            this.field_198127_n = this.field_198120_g;
            this.field_198128_o = this.field_198121_h;
            this.field_198129_p = this.field_198122_i;
            this.field_198130_q = this.field_198123_j;
            GLFW.glfwSetWindowMonitor(this.field_198119_f, 0L, this.field_198127_n, this.field_198128_o, this.field_198129_p, this.field_198130_q, -1);
        }
    }

    public void func_198077_g()
    {
        this.field_198125_l = !this.field_198125_l;
        this.field_198116_c.field_71474_y.field_74353_u = this.field_198125_l;
    }

    private void func_198081_z()
    {
        try
        {
            this.func_198108_y();
            this.func_198098_h();
            this.func_209548_c();
            this.func_198086_a(false);
        }
        catch (Exception exception)
        {
            field_198114_a.error("Couldn't toggle fullscreen", (Throwable)exception);
        }
    }

    public void func_198098_h()
    {
        this.field_198135_v = (double)this.func_198078_c(this.field_198116_c.field_71474_y.field_74335_Z);
        this.field_198133_t = MathHelper.func_76143_f((double)this.field_198131_r / this.field_198135_v);
        this.field_198134_u = MathHelper.func_76143_f((double)this.field_198132_s / this.field_198135_v);

        if (this.field_198116_c.field_71462_r != null)
        {
            this.field_198116_c.field_71462_r.func_175273_b(this.field_198116_c, this.field_198133_t, this.field_198134_u);
        }

        Framebuffer framebuffer = this.field_198116_c.func_147110_a();

        if (framebuffer != null)
        {
            framebuffer.func_147613_a(this.field_198131_r, this.field_198132_s);
        }

        if (this.field_198116_c.field_71460_t != null)
        {
            this.field_198116_c.field_71460_t.func_147704_a(this.field_198131_r, this.field_198132_s);
        }

        if (this.field_198116_c.field_71417_B != null)
        {
            this.field_198116_c.field_71417_B.func_198021_g();
        }
    }

    public int func_198078_c(int p_198078_1_)
    {
        int i;

        for (i = 1; i != p_198078_1_ && i < this.field_198131_r && i < this.field_198132_s && this.field_198131_r / (i + 1) >= 320 && this.field_198132_s / (i + 1) >= 240; ++i)
        {
            ;
        }

        if (this.field_198116_c.func_211821_e() && i % 2 != 0)
        {
            ++i;
        }

        return i;
    }

    public long func_198092_i()
    {
        return this.field_198119_f;
    }

    public boolean func_198113_j()
    {
        return this.field_198125_l;
    }

    public int func_198109_k()
    {
        return this.field_198131_r;
    }

    public int func_198091_l()
    {
        return this.field_198132_s;
    }

    public int func_198105_m()
    {
        return this.field_198129_p;
    }

    public int func_198083_n()
    {
        return this.field_198130_q;
    }

    public int func_198107_o()
    {
        return this.field_198133_t;
    }

    public int func_198087_p()
    {
        return this.field_198134_u;
    }

    public int func_198099_q()
    {
        return this.field_198127_n;
    }

    public int func_198079_r()
    {
        return this.field_198128_o;
    }

    public double func_198100_s()
    {
        return this.field_198135_v;
    }
}
