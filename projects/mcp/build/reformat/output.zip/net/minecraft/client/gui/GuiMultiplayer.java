package net.minecraft.client.gui;

import com.google.common.base.Splitter;
import com.google.common.collect.Lists;
import java.util.List;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.multiplayer.ServerList;
import net.minecraft.client.network.LanServerDetector;
import net.minecraft.client.network.LanServerInfo;
import net.minecraft.client.network.ServerPinger;
import net.minecraft.client.resources.I18n;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@OnlyIn(Dist.CLIENT)
public class GuiMultiplayer extends GuiScreen
{
    private static final Logger field_146802_a = LogManager.getLogger();
    private final ServerPinger field_146797_f = new ServerPinger();
    private final GuiScreen field_146798_g;
    private ServerSelectionList field_146803_h;
    private ServerList field_146804_i;
    private GuiButton field_146810_r;
    private GuiButton field_146809_s;
    private GuiButton field_146808_t;
    private boolean field_146807_u;
    private boolean field_146806_v;
    private boolean field_146805_w;
    private boolean field_146813_x;
    private String field_146812_y;
    private ServerData field_146811_z;
    private LanServerDetector.LanServerList field_146799_A;
    private LanServerDetector.ThreadLanServerFind field_146800_B;
    private boolean field_146801_C;

    public GuiMultiplayer(GuiScreen p_i1040_1_)
    {
        this.field_146798_g = p_i1040_1_;
    }

    public IGuiEventListener getFocused()
    {
        return this.field_146803_h;
    }

    protected void func_73866_w_()
    {
        super.func_73866_w_();
        this.field_146297_k.field_195559_v.func_197967_a(true);

        if (this.field_146801_C)
        {
            this.field_146803_h.func_148122_a(this.field_146294_l, this.field_146295_m, 32, this.field_146295_m - 64);
        }
        else
        {
            this.field_146801_C = true;
            this.field_146804_i = new ServerList(this.field_146297_k);
            this.field_146804_i.func_78853_a();
            this.field_146799_A = new LanServerDetector.LanServerList();

            try
            {
                this.field_146800_B = new LanServerDetector.ThreadLanServerFind(this.field_146799_A);
                this.field_146800_B.start();
            }
            catch (Exception exception)
            {
                field_146802_a.warn("Unable to start LAN server detection: {}", (Object)exception.getMessage());
            }

            this.field_146803_h = new ServerSelectionList(this, this.field_146297_k, this.field_146294_l, this.field_146295_m, 32, this.field_146295_m - 64, 36);
            this.field_146803_h.func_148195_a(this.field_146804_i);
        }

        this.func_146794_g();
    }

    public void func_146794_g()
    {
        this.field_146810_r = this.func_189646_b(new GuiButton(7, this.field_146294_l / 2 - 154, this.field_146295_m - 28, 70, 20, I18n.func_135052_a("selectServer.edit"))
        {
            public void func_194829_a(double p_194829_1_, double p_194829_3_)
            {
                GuiListExtended.IGuiListEntry<?> iguilistentry = GuiMultiplayer.this.field_146803_h.func_148193_k() < 0 ? null : GuiMultiplayer.this.field_146803_h.func_195074_b().get(GuiMultiplayer.this.field_146803_h.func_148193_k());
                GuiMultiplayer.this.field_146805_w = true;

                if (iguilistentry instanceof ServerListEntryNormal)
                {
                    ServerData serverdata = ((ServerListEntryNormal)iguilistentry).func_148296_a();
                    GuiMultiplayer.this.field_146811_z = new ServerData(serverdata.field_78847_a, serverdata.field_78845_b, false);
                    GuiMultiplayer.this.field_146811_z.func_152583_a(serverdata);
                    GuiMultiplayer.this.field_146297_k.func_147108_a(new GuiScreenAddServer(GuiMultiplayer.this, GuiMultiplayer.this.field_146811_z));
                }
            }
        });
        this.field_146808_t = this.func_189646_b(new GuiButton(2, this.field_146294_l / 2 - 74, this.field_146295_m - 28, 70, 20, I18n.func_135052_a("selectServer.delete"))
        {
            public void func_194829_a(double p_194829_1_, double p_194829_3_)
            {
                GuiListExtended.IGuiListEntry<?> iguilistentry = GuiMultiplayer.this.field_146803_h.func_148193_k() < 0 ? null : GuiMultiplayer.this.field_146803_h.func_195074_b().get(GuiMultiplayer.this.field_146803_h.func_148193_k());

                if (iguilistentry instanceof ServerListEntryNormal)
                {
                    String s = ((ServerListEntryNormal)iguilistentry).func_148296_a().field_78847_a;

                    if (s != null)
                    {
                        GuiMultiplayer.this.field_146807_u = true;
                        String s1 = I18n.func_135052_a("selectServer.deleteQuestion");
                        String s2 = I18n.func_135052_a("selectServer.deleteWarning", s);
                        String s3 = I18n.func_135052_a("selectServer.deleteButton");
                        String s4 = I18n.func_135052_a("gui.cancel");
                        GuiYesNo guiyesno = new GuiYesNo(GuiMultiplayer.this, s1, s2, s3, s4, GuiMultiplayer.this.field_146803_h.func_148193_k());
                        GuiMultiplayer.this.field_146297_k.func_147108_a(guiyesno);
                    }
                }
            }
        });
        this.field_146809_s = this.func_189646_b(new GuiButton(1, this.field_146294_l / 2 - 154, this.field_146295_m - 52, 100, 20, I18n.func_135052_a("selectServer.select"))
        {
            public void func_194829_a(double p_194829_1_, double p_194829_3_)
            {
                GuiMultiplayer.this.func_146796_h();
            }
        });
        this.func_189646_b(new GuiButton(4, this.field_146294_l / 2 - 50, this.field_146295_m - 52, 100, 20, I18n.func_135052_a("selectServer.direct"))
        {
            public void func_194829_a(double p_194829_1_, double p_194829_3_)
            {
                GuiMultiplayer.this.field_146813_x = true;
                GuiMultiplayer.this.field_146811_z = new ServerData(I18n.func_135052_a("selectServer.defaultName"), "", false);
                GuiMultiplayer.this.field_146297_k.func_147108_a(new GuiScreenServerList(GuiMultiplayer.this, GuiMultiplayer.this.field_146811_z));
            }
        });
        this.func_189646_b(new GuiButton(3, this.field_146294_l / 2 + 4 + 50, this.field_146295_m - 52, 100, 20, I18n.func_135052_a("selectServer.add"))
        {
            public void func_194829_a(double p_194829_1_, double p_194829_3_)
            {
                GuiMultiplayer.this.field_146806_v = true;
                GuiMultiplayer.this.field_146811_z = new ServerData(I18n.func_135052_a("selectServer.defaultName"), "", false);
                GuiMultiplayer.this.field_146297_k.func_147108_a(new GuiScreenAddServer(GuiMultiplayer.this, GuiMultiplayer.this.field_146811_z));
            }
        });
        this.func_189646_b(new GuiButton(8, this.field_146294_l / 2 + 4, this.field_146295_m - 28, 70, 20, I18n.func_135052_a("selectServer.refresh"))
        {
            public void func_194829_a(double p_194829_1_, double p_194829_3_)
            {
                GuiMultiplayer.this.func_146792_q();
            }
        });
        this.func_189646_b(new GuiButton(0, this.field_146294_l / 2 + 4 + 76, this.field_146295_m - 28, 75, 20, I18n.func_135052_a("gui.cancel"))
        {
            public void func_194829_a(double p_194829_1_, double p_194829_3_)
            {
                GuiMultiplayer.this.field_146297_k.func_147108_a(GuiMultiplayer.this.field_146798_g);
            }
        });
        this.field_195124_j.add(this.field_146803_h);
        this.func_146790_a(this.field_146803_h.func_148193_k());
    }

    public void func_73876_c()
    {
        super.func_73876_c();

        if (this.field_146799_A.func_77553_a())
        {
            List<LanServerInfo> list = this.field_146799_A.func_77554_c();
            this.field_146799_A.func_77552_b();
            this.field_146803_h.func_148194_a(list);
        }

        this.field_146797_f.func_147223_a();
    }

    public void func_146281_b()
    {
        this.field_146297_k.field_195559_v.func_197967_a(false);

        if (this.field_146800_B != null)
        {
            this.field_146800_B.interrupt();
            this.field_146800_B = null;
        }

        this.field_146797_f.func_147226_b();
    }

    private void func_146792_q()
    {
        this.field_146297_k.func_147108_a(new GuiMultiplayer(this.field_146798_g));
    }

    public void confirmResult(boolean p_confirmResult_1_, int p_confirmResult_2_)
    {
        GuiListExtended.IGuiListEntry<?> iguilistentry = this.field_146803_h.func_148193_k() < 0 ? null : this.field_146803_h.func_195074_b().get(this.field_146803_h.func_148193_k());

        if (this.field_146807_u)
        {
            this.field_146807_u = false;

            if (p_confirmResult_1_ && iguilistentry instanceof ServerListEntryNormal)
            {
                this.field_146804_i.func_78851_b(this.field_146803_h.func_148193_k());
                this.field_146804_i.func_78855_b();
                this.field_146803_h.func_148192_c(-1);
                this.field_146803_h.func_148195_a(this.field_146804_i);
            }

            this.field_146297_k.func_147108_a(this);
        }
        else if (this.field_146813_x)
        {
            this.field_146813_x = false;

            if (p_confirmResult_1_)
            {
                this.func_146791_a(this.field_146811_z);
            }
            else
            {
                this.field_146297_k.func_147108_a(this);
            }
        }
        else if (this.field_146806_v)
        {
            this.field_146806_v = false;

            if (p_confirmResult_1_)
            {
                this.field_146804_i.func_78849_a(this.field_146811_z);
                this.field_146804_i.func_78855_b();
                this.field_146803_h.func_148192_c(-1);
                this.field_146803_h.func_148195_a(this.field_146804_i);
            }

            this.field_146297_k.func_147108_a(this);
        }
        else if (this.field_146805_w)
        {
            this.field_146805_w = false;

            if (p_confirmResult_1_ && iguilistentry instanceof ServerListEntryNormal)
            {
                ServerData serverdata = ((ServerListEntryNormal)iguilistentry).func_148296_a();
                serverdata.field_78847_a = this.field_146811_z.field_78847_a;
                serverdata.field_78845_b = this.field_146811_z.field_78845_b;
                serverdata.func_152583_a(this.field_146811_z);
                this.field_146804_i.func_78855_b();
                this.field_146803_h.func_148195_a(this.field_146804_i);
            }

            this.field_146297_k.func_147108_a(this);
        }
    }

    public boolean keyPressed(int p_keyPressed_1_, int p_keyPressed_2_, int p_keyPressed_3_)
    {
        int i = this.field_146803_h.func_148193_k();
        GuiListExtended.IGuiListEntry<?> iguilistentry = i < 0 ? null : this.field_146803_h.func_195074_b().get(i);

        if (p_keyPressed_1_ == 294)
        {
            this.func_146792_q();
            return true;
        }
        else
        {
            if (i >= 0)
            {
                if (p_keyPressed_1_ == 265)
                {
                    if (func_146272_n())
                    {
                        if (i > 0 && iguilistentry instanceof ServerListEntryNormal)
                        {
                            this.field_146804_i.func_78857_a(i, i - 1);
                            this.func_146790_a(this.field_146803_h.func_148193_k() - 1);
                            this.field_146803_h.func_148145_f(-this.field_146803_h.func_148146_j());
                            this.field_146803_h.func_148195_a(this.field_146804_i);
                        }
                    }
                    else if (i > 0)
                    {
                        this.func_146790_a(this.field_146803_h.func_148193_k() - 1);
                        this.field_146803_h.func_148145_f(-this.field_146803_h.func_148146_j());

                        if (this.field_146803_h.func_195074_b().get(this.field_146803_h.func_148193_k()) instanceof ServerListEntryLanScan)
                        {
                            if (this.field_146803_h.func_148193_k() > 0)
                            {
                                this.func_146790_a(this.field_146803_h.func_195074_b().size() - 1);
                                this.field_146803_h.func_148145_f(-this.field_146803_h.func_148146_j());
                            }
                            else
                            {
                                this.func_146790_a(-1);
                            }
                        }
                    }
                    else
                    {
                        this.func_146790_a(-1);
                    }

                    return true;
                }

                if (p_keyPressed_1_ == 264)
                {
                    if (func_146272_n())
                    {
                        if (i < this.field_146804_i.func_78856_c() - 1)
                        {
                            this.field_146804_i.func_78857_a(i, i + 1);
                            this.func_146790_a(i + 1);
                            this.field_146803_h.func_148145_f(this.field_146803_h.func_148146_j());
                            this.field_146803_h.func_148195_a(this.field_146804_i);
                        }
                    }
                    else if (i < this.field_146803_h.func_195074_b().size())
                    {
                        this.func_146790_a(this.field_146803_h.func_148193_k() + 1);
                        this.field_146803_h.func_148145_f(this.field_146803_h.func_148146_j());

                        if (this.field_146803_h.func_195074_b().get(this.field_146803_h.func_148193_k()) instanceof ServerListEntryLanScan)
                        {
                            if (this.field_146803_h.func_148193_k() < this.field_146803_h.func_195074_b().size() - 1)
                            {
                                this.func_146790_a(this.field_146803_h.func_195074_b().size() + 1);
                                this.field_146803_h.func_148145_f(this.field_146803_h.func_148146_j());
                            }
                            else
                            {
                                this.func_146790_a(-1);
                            }
                        }
                    }
                    else
                    {
                        this.func_146790_a(-1);
                    }

                    return true;
                }

                if (p_keyPressed_1_ == 257 || p_keyPressed_1_ == 335)
                {
                    this.func_146796_h();
                    return true;
                }
            }

            return super.keyPressed(p_keyPressed_1_, p_keyPressed_2_, p_keyPressed_3_);
        }
    }

    public void func_73863_a(int p_73863_1_, int p_73863_2_, float p_73863_3_)
    {
        this.field_146812_y = null;
        this.func_146276_q_();
        this.field_146803_h.func_148128_a(p_73863_1_, p_73863_2_, p_73863_3_);
        this.func_73732_a(this.field_146289_q, I18n.func_135052_a("multiplayer.title"), this.field_146294_l / 2, 20, 16777215);
        super.func_73863_a(p_73863_1_, p_73863_2_, p_73863_3_);

        if (this.field_146812_y != null)
        {
            this.func_146283_a(Lists.newArrayList(Splitter.on("\n").split(this.field_146812_y)), p_73863_1_, p_73863_2_);
        }
    }

    public void func_146796_h()
    {
        GuiListExtended.IGuiListEntry<?> iguilistentry = this.field_146803_h.func_148193_k() < 0 ? null : this.field_146803_h.func_195074_b().get(this.field_146803_h.func_148193_k());

        if (iguilistentry instanceof ServerListEntryNormal)
        {
            this.func_146791_a(((ServerListEntryNormal)iguilistentry).func_148296_a());
        }
        else if (iguilistentry instanceof ServerListEntryLanDetected)
        {
            LanServerInfo lanserverinfo = ((ServerListEntryLanDetected)iguilistentry).func_189995_a();
            this.func_146791_a(new ServerData(lanserverinfo.func_77487_a(), lanserverinfo.func_77488_b(), true));
        }
    }

    private void func_146791_a(ServerData p_146791_1_)
    {
        this.field_146297_k.func_147108_a(new GuiConnecting(this, this.field_146297_k, p_146791_1_));
    }

    public void func_146790_a(int p_146790_1_)
    {
        this.field_146803_h.func_148192_c(p_146790_1_);
        GuiListExtended.IGuiListEntry<?> iguilistentry = p_146790_1_ < 0 ? null : this.field_146803_h.func_195074_b().get(p_146790_1_);
        this.field_146809_s.field_146124_l = false;
        this.field_146810_r.field_146124_l = false;
        this.field_146808_t.field_146124_l = false;

        if (iguilistentry != null && !(iguilistentry instanceof ServerListEntryLanScan))
        {
            this.field_146809_s.field_146124_l = true;

            if (iguilistentry instanceof ServerListEntryNormal)
            {
                this.field_146810_r.field_146124_l = true;
                this.field_146808_t.field_146124_l = true;
            }
        }
    }

    public ServerPinger func_146789_i()
    {
        return this.field_146797_f;
    }

    public void func_146793_a(String p_146793_1_)
    {
        this.field_146812_y = p_146793_1_;
    }

    public ServerList func_146795_p()
    {
        return this.field_146804_i;
    }

    public boolean func_175392_a(ServerListEntryNormal p_175392_1_, int p_175392_2_)
    {
        return p_175392_2_ > 0;
    }

    public boolean func_175394_b(ServerListEntryNormal p_175394_1_, int p_175394_2_)
    {
        return p_175394_2_ < this.field_146804_i.func_78856_c() - 1;
    }

    public void func_175391_a(ServerListEntryNormal p_175391_1_, int p_175391_2_, boolean p_175391_3_)
    {
        int i = p_175391_3_ ? 0 : p_175391_2_ - 1;
        this.field_146804_i.func_78857_a(p_175391_2_, i);

        if (this.field_146803_h.func_148193_k() == p_175391_2_)
        {
            this.func_146790_a(i);
        }

        this.field_146803_h.func_148195_a(this.field_146804_i);
    }

    public void func_175393_b(ServerListEntryNormal p_175393_1_, int p_175393_2_, boolean p_175393_3_)
    {
        int i = p_175393_3_ ? this.field_146804_i.func_78856_c() - 1 : p_175393_2_ + 1;
        this.field_146804_i.func_78857_a(p_175393_2_, i);

        if (this.field_146803_h.func_148193_k() == p_175393_2_)
        {
            this.func_146790_a(i);
        }

        this.field_146803_h.func_148195_a(this.field_146804_i);
    }
}
