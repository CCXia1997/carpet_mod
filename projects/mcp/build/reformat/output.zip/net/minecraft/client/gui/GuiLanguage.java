package net.minecraft.client.gui;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import java.util.Map;
import net.minecraft.client.GameSettings;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.resources.Language;
import net.minecraft.client.resources.LanguageManager;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class GuiLanguage extends GuiScreen
{
    protected GuiScreen field_146453_a;
    private GuiLanguage.List field_146450_f;
    private final GameSettings field_146451_g;
    private final LanguageManager field_146454_h;
    private GuiOptionButton field_211832_i;
    private GuiOptionButton field_146452_r;

    public GuiLanguage(GuiScreen p_i1043_1_, GameSettings p_i1043_2_, LanguageManager p_i1043_3_)
    {
        this.field_146453_a = p_i1043_1_;
        this.field_146451_g = p_i1043_2_;
        this.field_146454_h = p_i1043_3_;
    }

    public IGuiEventListener getFocused()
    {
        return this.field_146450_f;
    }

    protected void func_73866_w_()
    {
        this.field_146450_f = new GuiLanguage.List(this.field_146297_k);
        this.field_195124_j.add(this.field_146450_f);
        this.field_211832_i = this.func_189646_b(new GuiOptionButton(100, this.field_146294_l / 2 - 155, this.field_146295_m - 38, GameSettings.Options.FORCE_UNICODE_FONT, this.field_146451_g.func_74297_c(GameSettings.Options.FORCE_UNICODE_FONT))
        {
            public void func_194829_a(double p_194829_1_, double p_194829_3_)
            {
                GuiLanguage.this.field_146451_g.func_74306_a(this.func_146136_c(), 1);
                this.field_146126_j = GuiLanguage.this.field_146451_g.func_74297_c(GameSettings.Options.FORCE_UNICODE_FONT);
                GuiLanguage.this.func_195181_h();
            }
        });
        this.field_146452_r = this.func_189646_b(new GuiOptionButton(6, this.field_146294_l / 2 - 155 + 160, this.field_146295_m - 38, I18n.func_135052_a("gui.done"))
        {
            public void func_194829_a(double p_194829_1_, double p_194829_3_)
            {
                GuiLanguage.this.field_146297_k.func_147108_a(GuiLanguage.this.field_146453_a);
            }
        });
        super.func_73866_w_();
    }

    private void func_195181_h()
    {
        this.field_146297_k.field_195558_d.func_198098_h();
    }

    public void func_73863_a(int p_73863_1_, int p_73863_2_, float p_73863_3_)
    {
        this.field_146450_f.func_148128_a(p_73863_1_, p_73863_2_, p_73863_3_);
        this.func_73732_a(this.field_146289_q, I18n.func_135052_a("options.language"), this.field_146294_l / 2, 16, 16777215);
        this.func_73732_a(this.field_146289_q, "(" + I18n.func_135052_a("options.languageWarning") + ")", this.field_146294_l / 2, this.field_146295_m - 56, 8421504);
        super.func_73863_a(p_73863_1_, p_73863_2_, p_73863_3_);
    }

    @OnlyIn(Dist.CLIENT)
    class List extends GuiSlot
    {
        private final java.util.List<String> field_148176_l = Lists.newArrayList();
        private final Map<String, Language> field_148177_m = Maps.newHashMap();

        public List(Minecraft p_i45519_2_)
        {
            super(p_i45519_2_, GuiLanguage.this.field_146294_l, GuiLanguage.this.field_146295_m, 32, GuiLanguage.this.field_146295_m - 65 + 4, 18);

            for (Language language : GuiLanguage.this.field_146454_h.func_135040_d())
            {
                this.field_148177_m.put(language.func_135034_a(), language);
                this.field_148176_l.add(language.func_135034_a());
            }
        }

        protected int func_148127_b()
        {
            return this.field_148176_l.size();
        }

        protected boolean func_195078_a(int p_195078_1_, int p_195078_2_, double p_195078_3_, double p_195078_5_)
        {
            Language language = this.field_148177_m.get(this.field_148176_l.get(p_195078_1_));
            GuiLanguage.this.field_146454_h.func_135045_a(language);
            GuiLanguage.this.field_146451_g.field_74363_ab = language.func_135034_a();
            this.field_148161_k.func_110436_a();
            GuiLanguage.this.field_146289_q.func_78275_b(GuiLanguage.this.field_146454_h.func_135044_b());
            GuiLanguage.this.field_146452_r.field_146126_j = I18n.func_135052_a("gui.done");
            GuiLanguage.this.field_211832_i.field_146126_j = GuiLanguage.this.field_146451_g.func_74297_c(GameSettings.Options.FORCE_UNICODE_FONT);
            GuiLanguage.this.field_146451_g.func_74303_b();
            GuiLanguage.this.func_195181_h();
            return true;
        }

        protected boolean func_148131_a(int p_148131_1_)
        {
            return this.field_148176_l.get(p_148131_1_).equals(GuiLanguage.this.field_146454_h.func_135041_c().func_135034_a());
        }

        protected int func_148138_e()
        {
            return this.func_148127_b() * 18;
        }

        protected void func_148123_a()
        {
            GuiLanguage.this.func_146276_q_();
        }

        protected void func_192637_a(int p_192637_1_, int p_192637_2_, int p_192637_3_, int p_192637_4_, int p_192637_5_, int p_192637_6_, float p_192637_7_)
        {
            GuiLanguage.this.field_146289_q.func_78275_b(true);
            this.func_73732_a(GuiLanguage.this.field_146289_q, this.field_148177_m.get(this.field_148176_l.get(p_192637_1_)).toString(), this.field_148155_a / 2, p_192637_3_ + 1, 16777215);
            GuiLanguage.this.field_146289_q.func_78275_b(GuiLanguage.this.field_146454_h.func_135041_c().func_135035_b());
        }
    }
}
