package net.minecraft.client.gui.recipebook;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public interface IRecipeShownListener
{
    void func_192043_J_();

    GuiRecipeBook func_194310_f();
}
