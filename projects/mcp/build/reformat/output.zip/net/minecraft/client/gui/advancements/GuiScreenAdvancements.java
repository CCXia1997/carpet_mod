package net.minecraft.client.gui.advancements;

import com.google.common.collect.Maps;
import java.util.Map;
import javax.annotation.Nullable;
import net.minecraft.advancements.Advancement;
import net.minecraft.advancements.AdvancementProgress;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.multiplayer.ClientAdvancementManager;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.resources.I18n;
import net.minecraft.network.play.client.CPacketSeenAdvancements;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class GuiScreenAdvancements extends GuiScreen implements ClientAdvancementManager.IListener
{
    private static final ResourceLocation field_191943_f = new ResourceLocation("textures/gui/advancements/window.png");
    private static final ResourceLocation field_191945_g = new ResourceLocation("textures/gui/advancements/tabs.png");
    private final ClientAdvancementManager field_191946_h;
    private final Map<Advancement, GuiAdvancementTab> field_191947_i = Maps.newLinkedHashMap();
    private GuiAdvancementTab field_191940_s;
    private boolean field_191944_v;

    public GuiScreenAdvancements(ClientAdvancementManager p_i47383_1_)
    {
        this.field_191946_h = p_i47383_1_;
    }

    protected void func_73866_w_()
    {
        this.field_191947_i.clear();
        this.field_191940_s = null;
        this.field_191946_h.func_192798_a(this);

        if (this.field_191940_s == null && !this.field_191947_i.isEmpty())
        {
            this.field_191946_h.func_194230_a(this.field_191947_i.values().iterator().next().func_193935_c(), true);
        }
        else
        {
            this.field_191946_h.func_194230_a(this.field_191940_s == null ? null : this.field_191940_s.func_193935_c(), true);
        }
    }

    public void func_146281_b()
    {
        this.field_191946_h.func_192798_a((ClientAdvancementManager.IListener)null);
        NetHandlerPlayClient nethandlerplayclient = this.field_146297_k.func_147114_u();

        if (nethandlerplayclient != null)
        {
            nethandlerplayclient.func_147297_a(CPacketSeenAdvancements.func_194164_a());
        }
    }

    public boolean mouseClicked(double p_mouseClicked_1_, double p_mouseClicked_3_, int p_mouseClicked_5_)
    {
        if (p_mouseClicked_5_ == 0)
        {
            int i = (this.field_146294_l - 252) / 2;
            int j = (this.field_146295_m - 140) / 2;

            for (GuiAdvancementTab guiadvancementtab : this.field_191947_i.values())
            {
                if (guiadvancementtab.func_195627_a(i, j, p_mouseClicked_1_, p_mouseClicked_3_))
                {
                    this.field_191946_h.func_194230_a(guiadvancementtab.func_193935_c(), true);
                    break;
                }
            }
        }

        return super.mouseClicked(p_mouseClicked_1_, p_mouseClicked_3_, p_mouseClicked_5_);
    }

    public boolean keyPressed(int p_keyPressed_1_, int p_keyPressed_2_, int p_keyPressed_3_)
    {
        if (this.field_146297_k.field_71474_y.field_194146_ao.func_197976_a(p_keyPressed_1_, p_keyPressed_2_))
        {
            this.field_146297_k.func_147108_a((GuiScreen)null);
            this.field_146297_k.field_71417_B.func_198034_i();
            return true;
        }
        else
        {
            return super.keyPressed(p_keyPressed_1_, p_keyPressed_2_, p_keyPressed_3_);
        }
    }

    public void func_73863_a(int p_73863_1_, int p_73863_2_, float p_73863_3_)
    {
        int i = (this.field_146294_l - 252) / 2;
        int j = (this.field_146295_m - 140) / 2;
        this.func_146276_q_();
        this.func_191936_c(p_73863_1_, p_73863_2_, i, j);
        this.func_191934_b(i, j);
        this.func_191937_d(p_73863_1_, p_73863_2_, i, j);
    }

    public boolean mouseDragged(double p_mouseDragged_1_, double p_mouseDragged_3_, int p_mouseDragged_5_, double p_mouseDragged_6_, double p_mouseDragged_8_)
    {
        if (p_mouseDragged_5_ != 0)
        {
            this.field_191944_v = false;
            return false;
        }
        else
        {
            if (!this.field_191944_v)
            {
                this.field_191944_v = true;
            }
            else if (this.field_191940_s != null)
            {
                this.field_191940_s.func_195626_a(p_mouseDragged_6_, p_mouseDragged_8_);
            }

            return true;
        }
    }

    private void func_191936_c(int p_191936_1_, int p_191936_2_, int p_191936_3_, int p_191936_4_)
    {
        GuiAdvancementTab guiadvancementtab = this.field_191940_s;

        if (guiadvancementtab == null)
        {
            func_73734_a(p_191936_3_ + 9, p_191936_4_ + 18, p_191936_3_ + 9 + 234, p_191936_4_ + 18 + 113, -16777216);
            String s = I18n.func_135052_a("advancements.empty");
            int i = this.field_146289_q.func_78256_a(s);
            this.field_146289_q.func_211126_b(s, (float)(p_191936_3_ + 9 + 117 - i / 2), (float)(p_191936_4_ + 18 + 56 - this.field_146289_q.field_78288_b / 2), -1);
            this.field_146289_q.func_211126_b(":(", (float)(p_191936_3_ + 9 + 117 - this.field_146289_q.func_78256_a(":(") / 2), (float)(p_191936_4_ + 18 + 113 - this.field_146289_q.field_78288_b), -1);
        }
        else
        {
            GlStateManager.func_179094_E();
            GlStateManager.func_179109_b((float)(p_191936_3_ + 9), (float)(p_191936_4_ + 18), -400.0F);
            GlStateManager.func_179126_j();
            guiadvancementtab.func_191799_a();
            GlStateManager.func_179121_F();
            GlStateManager.func_179143_c(515);
            GlStateManager.func_179097_i();
        }
    }

    public void func_191934_b(int p_191934_1_, int p_191934_2_)
    {
        GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
        GlStateManager.func_179147_l();
        RenderHelper.func_74518_a();
        this.field_146297_k.func_110434_K().func_110577_a(field_191943_f);
        this.func_73729_b(p_191934_1_, p_191934_2_, 0, 0, 252, 140);

        if (this.field_191947_i.size() > 1)
        {
            this.field_146297_k.func_110434_K().func_110577_a(field_191945_g);

            for (GuiAdvancementTab guiadvancementtab : this.field_191947_i.values())
            {
                guiadvancementtab.func_191798_a(p_191934_1_, p_191934_2_, guiadvancementtab == this.field_191940_s);
            }

            GlStateManager.func_179091_B();
            GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
            RenderHelper.func_74520_c();

            for (GuiAdvancementTab guiadvancementtab1 : this.field_191947_i.values())
            {
                guiadvancementtab1.func_191796_a(p_191934_1_, p_191934_2_, this.field_146296_j);
            }

            GlStateManager.func_179084_k();
        }

        this.field_146289_q.func_211126_b(I18n.func_135052_a("gui.advancements"), (float)(p_191934_1_ + 8), (float)(p_191934_2_ + 6), 4210752);
    }

    private void func_191937_d(int p_191937_1_, int p_191937_2_, int p_191937_3_, int p_191937_4_)
    {
        GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);

        if (this.field_191940_s != null)
        {
            GlStateManager.func_179094_E();
            GlStateManager.func_179126_j();
            GlStateManager.func_179109_b((float)(p_191937_3_ + 9), (float)(p_191937_4_ + 18), 400.0F);
            this.field_191940_s.func_192991_a(p_191937_1_ - p_191937_3_ - 9, p_191937_2_ - p_191937_4_ - 18, p_191937_3_, p_191937_4_);
            GlStateManager.func_179097_i();
            GlStateManager.func_179121_F();
        }

        if (this.field_191947_i.size() > 1)
        {
            for (GuiAdvancementTab guiadvancementtab : this.field_191947_i.values())
            {
                if (guiadvancementtab.func_195627_a(p_191937_3_, p_191937_4_, (double)p_191937_1_, (double)p_191937_2_))
                {
                    this.func_146279_a(guiadvancementtab.func_191795_d(), p_191937_1_, p_191937_2_);
                }
            }
        }
    }

    public void func_191931_a(Advancement p_191931_1_)
    {
        GuiAdvancementTab guiadvancementtab = GuiAdvancementTab.func_193936_a(this.field_146297_k, this, this.field_191947_i.size(), p_191931_1_);

        if (guiadvancementtab != null)
        {
            this.field_191947_i.put(p_191931_1_, guiadvancementtab);
        }
    }

    public void func_191928_b(Advancement p_191928_1_)
    {
    }

    public void func_191932_c(Advancement p_191932_1_)
    {
        GuiAdvancementTab guiadvancementtab = this.func_191935_f(p_191932_1_);

        if (guiadvancementtab != null)
        {
            guiadvancementtab.func_191800_a(p_191932_1_);
        }
    }

    public void func_191929_d(Advancement p_191929_1_)
    {
    }

    public void func_191933_a(Advancement p_191933_1_, AdvancementProgress p_191933_2_)
    {
        GuiAdvancement guiadvancement = this.func_191938_e(p_191933_1_);

        if (guiadvancement != null)
        {
            guiadvancement.func_191824_a(p_191933_2_);
        }
    }

    public void func_193982_e(@Nullable Advancement p_193982_1_)
    {
        this.field_191940_s = this.field_191947_i.get(p_193982_1_);
    }

    public void func_191930_a()
    {
        this.field_191947_i.clear();
        this.field_191940_s = null;
    }

    @Nullable
    public GuiAdvancement func_191938_e(Advancement p_191938_1_)
    {
        GuiAdvancementTab guiadvancementtab = this.func_191935_f(p_191938_1_);
        return guiadvancementtab == null ? null : guiadvancementtab.func_191794_b(p_191938_1_);
    }

    @Nullable
    private GuiAdvancementTab func_191935_f(Advancement p_191935_1_)
    {
        while (p_191935_1_.func_192070_b() != null)
        {
            p_191935_1_ = p_191935_1_.func_192070_b();
        }

        return this.field_191947_i.get(p_191935_1_);
    }
}
