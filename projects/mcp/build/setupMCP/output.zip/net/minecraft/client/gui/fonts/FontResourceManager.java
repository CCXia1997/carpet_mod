package net.minecraft.client.gui.fonts;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;
import javax.annotation.Nullable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.fonts.providers.DefaultGlyphProvider;
import net.minecraft.client.gui.fonts.providers.GlyphProviderTypes;
import net.minecraft.client.gui.fonts.providers.IGlyphProvider;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.resources.IResource;
import net.minecraft.resources.IResourceManager;
import net.minecraft.resources.IResourceManagerReloadListener;
import net.minecraft.util.JsonUtils;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.apache.commons.io.IOUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@OnlyIn(Dist.CLIENT)
public class FontResourceManager implements IResourceManagerReloadListener {
   private static final Logger field_211509_a = LogManager.getLogger();
   private final Map<ResourceLocation, FontRenderer> field_211510_b = Maps.newHashMap();
   private final TextureManager field_211511_c;
   private boolean field_211826_d;

   public FontResourceManager(TextureManager p_i49787_1_, boolean p_i49787_2_) {
      this.field_211511_c = p_i49787_1_;
      this.field_211826_d = p_i49787_2_;
   }

   public void func_195410_a(IResourceManager p_195410_1_) {
      Gson gson = (new GsonBuilder()).setPrettyPrinting().disableHtmlEscaping().create();
      Map<ResourceLocation, List<IGlyphProvider>> map = Maps.newHashMap();

      for(ResourceLocation resourcelocation : p_195410_1_.func_199003_a("font", (p_211506_0_) -> {
         return p_211506_0_.endsWith(".json");
      })) {
         String s = resourcelocation.func_110623_a();
         ResourceLocation resourcelocation1 = new ResourceLocation(resourcelocation.func_110624_b(), s.substring("font/".length(), s.length() - ".json".length()));
         List<IGlyphProvider> list = map.computeIfAbsent(resourcelocation1, (p_211507_0_) -> {
            return Lists.newArrayList(new DefaultGlyphProvider());
         });

         try {
            for(IResource iresource : p_195410_1_.func_199004_b(resourcelocation)) {
               try (InputStream inputstream = iresource.func_199027_b()) {
                  JsonArray jsonarray = JsonUtils.func_151214_t(JsonUtils.func_188178_a(gson, IOUtils.toString(inputstream, StandardCharsets.UTF_8), JsonObject.class), "providers");

                  for(int i = jsonarray.size() - 1; i >= 0; --i) {
                     JsonObject jsonobject = JsonUtils.func_151210_l(jsonarray.get(i), "providers[" + i + "]");

                     try {
                        GlyphProviderTypes glyphprovidertypes = GlyphProviderTypes.func_211638_a(JsonUtils.func_151200_h(jsonobject, "type"));
                        if (!this.field_211826_d || glyphprovidertypes == GlyphProviderTypes.LEGACY_UNICODE || !resourcelocation1.equals(Minecraft.field_211502_b)) {
                           IGlyphProvider iglyphprovider = glyphprovidertypes.func_211637_a(jsonobject).func_211246_a(p_195410_1_);
                           if (iglyphprovider != null) {
                              list.add(iglyphprovider);
                           }
                        }
                     } catch (RuntimeException runtimeexception) {
                        field_211509_a.warn("Unable to read definition '{}' in fonts.json in resourcepack: '{}': {}", resourcelocation1, iresource.func_199026_d(), runtimeexception.getMessage());
                     }
                  }
               } catch (RuntimeException runtimeexception1) {
                  field_211509_a.warn("Unable to load font '{}' in fonts.json in resourcepack: '{}': {}", resourcelocation1, iresource.func_199026_d(), runtimeexception1.getMessage());
               }
            }
         } catch (IOException ioexception) {
            field_211509_a.warn("Unable to load font '{}' in fonts.json: {}", resourcelocation1, ioexception.getMessage());
         }
      }

      Stream.concat(this.field_211510_b.keySet().stream(), map.keySet().stream()).distinct().forEach((p_211508_2_) -> {
         List<IGlyphProvider> list1 = map.getOrDefault(p_211508_2_, Collections.emptyList());
         Collections.reverse(list1);
         this.field_211510_b.computeIfAbsent(p_211508_2_, (p_211505_1_) -> {
            return new FontRenderer(this.field_211511_c, new Font(this.field_211511_c, p_211505_1_));
         }).func_211568_a(list1);
      });
   }

   @Nullable
   public FontRenderer func_211504_a(ResourceLocation p_211504_1_) {
      return this.field_211510_b.computeIfAbsent(p_211504_1_, (p_212318_1_) -> {
         FontRenderer fontrenderer = new FontRenderer(this.field_211511_c, new Font(this.field_211511_c, p_212318_1_));
         fontrenderer.func_211568_a(Lists.newArrayList(new DefaultGlyphProvider()));
         return fontrenderer;
      });
   }

   public void func_211825_a(boolean p_211825_1_) {
      if (p_211825_1_ != this.field_211826_d) {
         this.field_211826_d = p_211825_1_;
         this.func_195410_a(Minecraft.func_71410_x().func_195551_G());
      }
   }
}
