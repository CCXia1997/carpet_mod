package net.minecraft.client.gui;

import com.google.common.collect.Lists;
import java.util.AbstractList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Util;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public abstract class GuiListExtended<E extends GuiListExtended.IGuiListEntry<E>> extends GuiSlot {
   private final List<E> field_195087_v = new GuiListExtended.UpdatingList();

   public GuiListExtended(Minecraft p_i45010_1_, int p_i45010_2_, int p_i45010_3_, int p_i45010_4_, int p_i45010_5_, int p_i45010_6_) {
      super(p_i45010_1_, p_i45010_2_, p_i45010_3_, p_i45010_4_, p_i45010_5_, p_i45010_6_);
   }

   protected boolean func_195078_a(int p_195078_1_, int p_195078_2_, double p_195078_3_, double p_195078_5_) {
      return this.func_148180_b(p_195078_1_).mouseClicked(p_195078_3_, p_195078_5_, p_195078_2_);
   }

   protected boolean func_148131_a(int p_148131_1_) {
      return false;
   }

   protected void func_148123_a() {
   }

   protected void func_192637_a(int p_192637_1_, int p_192637_2_, int p_192637_3_, int p_192637_4_, int p_192637_5_, int p_192637_6_, float p_192637_7_) {
      this.func_148180_b(p_192637_1_).func_194999_a(this.func_148139_c(), p_192637_4_, p_192637_5_, p_192637_6_, this.func_195079_b((double)p_192637_5_, (double)p_192637_6_) && this.func_195083_a((double)p_192637_5_, (double)p_192637_6_) == p_192637_1_, p_192637_7_);
   }

   protected void func_192639_a(int p_192639_1_, int p_192639_2_, int p_192639_3_, float p_192639_4_) {
      this.func_148180_b(p_192639_1_).func_195000_a(p_192639_4_);
   }

   public final List<E> func_195074_b() {
      return this.field_195087_v;
   }

   protected final void func_195086_c() {
      this.field_195087_v.clear();
   }

   private E func_148180_b(int p_148180_1_) {
      return (E)(this.func_195074_b().get(p_148180_1_));
   }

   protected final void func_195085_a(E p_195085_1_) {
      this.field_195087_v.add(p_195085_1_);
   }

   public void func_195080_b(int p_195080_1_) {
      this.field_148168_r = p_195080_1_;
      this.field_148167_s = Util.func_211177_b();
   }

   protected final int func_148127_b() {
      return this.func_195074_b().size();
   }

   @OnlyIn(Dist.CLIENT)
   public abstract static class IGuiListEntry<E extends GuiListExtended.IGuiListEntry<E>> implements IGuiEventListener {
      protected GuiListExtended<E> field_195004_a;
      protected int field_195005_b;

      protected GuiListExtended<E> func_194998_a() {
         return this.field_195004_a;
      }

      protected int func_195003_b() {
         return this.field_195005_b;
      }

      protected int func_195001_c() {
         return this.field_195004_a.field_148153_b + 4 - this.field_195004_a.func_148148_g() + this.field_195005_b * this.field_195004_a.field_148149_f + this.field_195004_a.field_148160_j;
      }

      protected int func_195002_d() {
         return this.field_195004_a.field_148152_e + this.field_195004_a.field_148155_a / 2 - this.field_195004_a.func_148139_c() / 2 + 2;
      }

      protected void func_195000_a(float p_195000_1_) {
      }

      public abstract void func_194999_a(int p_194999_1_, int p_194999_2_, int p_194999_3_, int p_194999_4_, boolean p_194999_5_, float p_194999_6_);
   }

   @OnlyIn(Dist.CLIENT)
   class UpdatingList extends AbstractList<E> {
      private final List<E> field_198174_b = Lists.newArrayList();

      private UpdatingList() {
      }

      public E get(int p_get_1_) {
         return (E)(this.field_198174_b.get(p_get_1_));
      }

      public int size() {
         return this.field_198174_b.size();
      }

      public E set(int p_set_1_, E p_set_2_) {
         E e = this.field_198174_b.set(p_set_1_, p_set_2_);
         p_set_2_.field_195004_a = GuiListExtended.this;
         p_set_2_.field_195005_b = p_set_1_;
         return e;
      }

      public void add(int p_add_1_, E p_add_2_) {
         this.field_198174_b.add(p_add_1_, p_add_2_);
         p_add_2_.field_195004_a = GuiListExtended.this;
         p_add_2_.field_195005_b = p_add_1_;

         for(int i = p_add_1_ + 1; i < this.size(); this.get(i).field_195005_b = i++) {
            ;
         }

      }

      public E remove(int p_remove_1_) {
         E e = this.field_198174_b.remove(p_remove_1_);

         for(int i = p_remove_1_; i < this.size(); this.get(i).field_195005_b = i++) {
            ;
         }

         return e;
      }
   }
}
