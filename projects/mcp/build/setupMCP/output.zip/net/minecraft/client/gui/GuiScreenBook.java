package net.minecraft.client.gui;

import com.google.common.collect.Lists;
import com.google.gson.JsonParseException;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.resources.I18n;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemWrittenBook;
import net.minecraft.nbt.INBTBase;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.nbt.NBTTagString;
import net.minecraft.network.play.client.CPacketEditBook;
import net.minecraft.util.EnumHand;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SharedConstants;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.util.text.event.ClickEvent;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@OnlyIn(Dist.CLIENT)
public class GuiScreenBook extends GuiScreen {
   private static final Logger field_146473_a = LogManager.getLogger();
   private static final ResourceLocation field_146466_f = new ResourceLocation("textures/gui/book.png");
   private final EntityPlayer field_146468_g;
   private final ItemStack field_146474_h;
   private final boolean field_146475_i;
   private boolean field_146481_r;
   private boolean field_146480_s;
   private int field_146479_t;
   private final int field_146478_u = 192;
   private final int field_146477_v = 192;
   private int field_146476_w = 1;
   private int field_146484_x;
   private NBTTagList field_146483_y;
   private String field_146482_z = "";
   private List<ITextComponent> field_175386_A;
   private int field_175387_B = -1;
   private GuiScreenBook.NextPageButton field_146470_A;
   private GuiScreenBook.NextPageButton field_146471_B;
   private GuiButton field_146472_C;
   private GuiButton field_146465_D;
   private GuiButton field_146467_E;
   private GuiButton field_146469_F;
   private final EnumHand field_212343_J;

   public GuiScreenBook(EntityPlayer p_i49849_1_, ItemStack p_i49849_2_, boolean p_i49849_3_, EnumHand p_i49849_4_) {
      this.field_146468_g = p_i49849_1_;
      this.field_146474_h = p_i49849_2_;
      this.field_146475_i = p_i49849_3_;
      this.field_212343_J = p_i49849_4_;
      if (p_i49849_2_.func_77942_o()) {
         NBTTagCompound nbttagcompound = p_i49849_2_.func_77978_p();
         this.field_146483_y = nbttagcompound.func_150295_c("pages", 8).func_74737_b();
         this.field_146476_w = this.field_146483_y.size();
         if (this.field_146476_w < 1) {
            this.field_146483_y.add((INBTBase)(new NBTTagString("")));
            this.field_146476_w = 1;
         }
      }

      if (this.field_146483_y == null && p_i49849_3_) {
         this.field_146483_y = new NBTTagList();
         this.field_146483_y.add((INBTBase)(new NBTTagString("")));
         this.field_146476_w = 1;
      }

   }

   public void func_73876_c() {
      super.func_73876_c();
      ++this.field_146479_t;
   }

   protected void func_73866_w_() {
      this.field_146297_k.field_195559_v.func_197967_a(true);
      if (this.field_146475_i) {
         this.field_146465_D = this.func_189646_b(new GuiButton(3, this.field_146294_l / 2 - 100, 196, 98, 20, I18n.func_135052_a("book.signButton")) {
            public void func_194829_a(double p_194829_1_, double p_194829_3_) {
               GuiScreenBook.this.field_146480_s = true;
               GuiScreenBook.this.func_146464_h();
            }
         });
         this.field_146472_C = this.func_189646_b(new GuiButton(0, this.field_146294_l / 2 + 2, 196, 98, 20, I18n.func_135052_a("gui.done")) {
            public void func_194829_a(double p_194829_1_, double p_194829_3_) {
               GuiScreenBook.this.field_146297_k.func_147108_a((GuiScreen)null);
               GuiScreenBook.this.func_146462_a(false);
            }
         });
         this.field_146467_E = this.func_189646_b(new GuiButton(5, this.field_146294_l / 2 - 100, 196, 98, 20, I18n.func_135052_a("book.finalizeButton")) {
            public void func_194829_a(double p_194829_1_, double p_194829_3_) {
               if (GuiScreenBook.this.field_146480_s) {
                  GuiScreenBook.this.func_146462_a(true);
                  GuiScreenBook.this.field_146297_k.func_147108_a((GuiScreen)null);
               }

            }
         });
         this.field_146469_F = this.func_189646_b(new GuiButton(4, this.field_146294_l / 2 + 2, 196, 98, 20, I18n.func_135052_a("gui.cancel")) {
            public void func_194829_a(double p_194829_1_, double p_194829_3_) {
               if (GuiScreenBook.this.field_146480_s) {
                  GuiScreenBook.this.field_146480_s = false;
               }

               GuiScreenBook.this.func_146464_h();
            }
         });
      } else {
         this.field_146472_C = this.func_189646_b(new GuiButton(0, this.field_146294_l / 2 - 100, 196, 200, 20, I18n.func_135052_a("gui.done")) {
            public void func_194829_a(double p_194829_1_, double p_194829_3_) {
               GuiScreenBook.this.field_146297_k.func_147108_a((GuiScreen)null);
               GuiScreenBook.this.func_146462_a(false);
            }
         });
      }

      int i = (this.field_146294_l - 192) / 2;
      int j = 2;
      this.field_146470_A = this.func_189646_b(new GuiScreenBook.NextPageButton(1, i + 120, 156, true) {
         public void func_194829_a(double p_194829_1_, double p_194829_3_) {
            if (GuiScreenBook.this.field_146484_x < GuiScreenBook.this.field_146476_w - 1) {
               GuiScreenBook.this.field_146484_x++;
            } else if (GuiScreenBook.this.field_146475_i) {
               GuiScreenBook.this.func_146461_i();
               if (GuiScreenBook.this.field_146484_x < GuiScreenBook.this.field_146476_w - 1) {
                  GuiScreenBook.this.field_146484_x++;
               }
            }

            GuiScreenBook.this.func_146464_h();
         }
      });
      this.field_146471_B = this.func_189646_b(new GuiScreenBook.NextPageButton(2, i + 38, 156, false) {
         public void func_194829_a(double p_194829_1_, double p_194829_3_) {
            if (GuiScreenBook.this.field_146484_x > 0) {
               GuiScreenBook.this.field_146484_x--;
            }

            GuiScreenBook.this.func_146464_h();
         }
      });
      this.func_146464_h();
   }

   public void func_146281_b() {
      this.field_146297_k.field_195559_v.func_197967_a(false);
   }

   private void func_146464_h() {
      this.field_146470_A.field_146125_m = !this.field_146480_s && (this.field_146484_x < this.field_146476_w - 1 || this.field_146475_i);
      this.field_146471_B.field_146125_m = !this.field_146480_s && this.field_146484_x > 0;
      this.field_146472_C.field_146125_m = !this.field_146475_i || !this.field_146480_s;
      if (this.field_146475_i) {
         this.field_146465_D.field_146125_m = !this.field_146480_s;
         this.field_146469_F.field_146125_m = this.field_146480_s;
         this.field_146467_E.field_146125_m = this.field_146480_s;
         this.field_146467_E.field_146124_l = !this.field_146482_z.trim().isEmpty();
      }

   }

   private void func_146462_a(boolean p_146462_1_) {
      if (this.field_146475_i && this.field_146481_r) {
         if (this.field_146483_y != null) {
            while(this.field_146483_y.size() > 1) {
               String s = this.field_146483_y.func_150307_f(this.field_146483_y.size() - 1);
               if (!s.isEmpty()) {
                  break;
               }

               this.field_146483_y.remove(this.field_146483_y.size() - 1);
            }

            this.field_146474_h.func_77983_a("pages", this.field_146483_y);
            if (p_146462_1_) {
               this.field_146474_h.func_77983_a("author", new NBTTagString(this.field_146468_g.func_146103_bH().getName()));
               this.field_146474_h.func_77983_a("title", new NBTTagString(this.field_146482_z.trim()));
            }

            this.field_146297_k.func_147114_u().func_147297_a(new CPacketEditBook(this.field_146474_h, p_146462_1_, this.field_212343_J));
         }

      }
   }

   private void func_146461_i() {
      if (this.field_146483_y != null && this.field_146483_y.size() < 50) {
         this.field_146483_y.add((INBTBase)(new NBTTagString("")));
         ++this.field_146476_w;
         this.field_146481_r = true;
      }
   }

   public boolean keyPressed(int p_keyPressed_1_, int p_keyPressed_2_, int p_keyPressed_3_) {
      if (super.keyPressed(p_keyPressed_1_, p_keyPressed_2_, p_keyPressed_3_)) {
         return true;
      } else if (this.field_146475_i) {
         return this.field_146480_s ? this.func_195267_b(p_keyPressed_1_, p_keyPressed_2_, p_keyPressed_3_) : this.func_195259_a(p_keyPressed_1_, p_keyPressed_2_, p_keyPressed_3_);
      } else {
         return false;
      }
   }

   public boolean charTyped(char p_charTyped_1_, int p_charTyped_2_) {
      if (super.charTyped(p_charTyped_1_, p_charTyped_2_)) {
         return true;
      } else if (this.field_146475_i) {
         if (this.field_146480_s) {
            if (this.field_146482_z.length() < 16 && SharedConstants.func_71566_a(p_charTyped_1_)) {
               this.field_146482_z = this.field_146482_z + Character.toString(p_charTyped_1_);
               this.func_146464_h();
               this.field_146481_r = true;
               return true;
            } else {
               return false;
            }
         } else if (SharedConstants.func_71566_a(p_charTyped_1_)) {
            this.func_146459_b(Character.toString(p_charTyped_1_));
            return true;
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private boolean func_195259_a(int p_195259_1_, int p_195259_2_, int p_195259_3_) {
      if (GuiScreen.func_175279_e(p_195259_1_)) {
         this.func_146459_b(this.field_146297_k.field_195559_v.func_197965_a());
         return true;
      } else {
         switch(p_195259_1_) {
         case 257:
         case 335:
            this.func_146459_b("\n");
            return true;
         case 259:
            String s = this.func_146456_p();
            if (!s.isEmpty()) {
               this.func_146457_a(s.substring(0, s.length() - 1));
            }

            return true;
         default:
            return false;
         }
      }
   }

   private boolean func_195267_b(int p_195267_1_, int p_195267_2_, int p_195267_3_) {
      switch(p_195267_1_) {
      case 257:
      case 335:
         if (!this.field_146482_z.isEmpty()) {
            this.func_146462_a(true);
            this.field_146297_k.func_147108_a((GuiScreen)null);
         }

         return true;
      case 259:
         if (!this.field_146482_z.isEmpty()) {
            this.field_146482_z = this.field_146482_z.substring(0, this.field_146482_z.length() - 1);
            this.func_146464_h();
         }

         return true;
      default:
         return false;
      }
   }

   private String func_146456_p() {
      return this.field_146483_y != null && this.field_146484_x >= 0 && this.field_146484_x < this.field_146483_y.size() ? this.field_146483_y.func_150307_f(this.field_146484_x) : "";
   }

   private void func_146457_a(String p_146457_1_) {
      if (this.field_146483_y != null && this.field_146484_x >= 0 && this.field_146484_x < this.field_146483_y.size()) {
         this.field_146483_y.set(this.field_146484_x, (INBTBase)(new NBTTagString(p_146457_1_)));
         this.field_146481_r = true;
      }

   }

   private void func_146459_b(String p_146459_1_) {
      String s = this.func_146456_p();
      String s1 = s + p_146459_1_;
      int i = this.field_146289_q.func_78267_b(s1 + "" + TextFormatting.BLACK + "_", 118);
      if (i <= 128 && s1.length() < 256) {
         this.func_146457_a(s1);
      }

   }

   public void func_73863_a(int p_73863_1_, int p_73863_2_, float p_73863_3_) {
      GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
      this.field_146297_k.func_110434_K().func_110577_a(field_146466_f);
      int i = (this.field_146294_l - 192) / 2;
      int j = 2;
      this.func_73729_b(i, 2, 0, 0, 192, 192);
      if (this.field_146480_s) {
         String s = this.field_146482_z;
         if (this.field_146475_i) {
            if (this.field_146479_t / 6 % 2 == 0) {
               s = s + "" + TextFormatting.BLACK + "_";
            } else {
               s = s + "" + TextFormatting.GRAY + "_";
            }
         }

         String s1 = I18n.func_135052_a("book.editTitle");
         int k = this.field_146289_q.func_78256_a(s1);
         this.field_146289_q.func_211126_b(s1, (float)(i + 36 + (116 - k) / 2), 34.0F, 0);
         int l = this.field_146289_q.func_78256_a(s);
         this.field_146289_q.func_211126_b(s, (float)(i + 36 + (116 - l) / 2), 50.0F, 0);
         String s2 = I18n.func_135052_a("book.byAuthor", this.field_146468_g.func_200200_C_().getString());
         int i1 = this.field_146289_q.func_78256_a(s2);
         this.field_146289_q.func_211126_b(TextFormatting.DARK_GRAY + s2, (float)(i + 36 + (116 - i1) / 2), 60.0F, 0);
         String s3 = I18n.func_135052_a("book.finalizeWarning");
         this.field_146289_q.func_78279_b(s3, i + 36, 82, 116, 0);
      } else {
         String s4 = I18n.func_135052_a("book.pageIndicator", this.field_146484_x + 1, this.field_146476_w);
         String s5 = "";
         if (this.field_146483_y != null && this.field_146484_x >= 0 && this.field_146484_x < this.field_146483_y.size()) {
            s5 = this.field_146483_y.func_150307_f(this.field_146484_x);
         }

         if (this.field_146475_i) {
            if (this.field_146289_q.func_78260_a()) {
               s5 = s5 + "_";
            } else if (this.field_146479_t / 6 % 2 == 0) {
               s5 = s5 + "" + TextFormatting.BLACK + "_";
            } else {
               s5 = s5 + "" + TextFormatting.GRAY + "_";
            }
         } else if (this.field_175387_B != this.field_146484_x) {
            if (ItemWrittenBook.func_77828_a(this.field_146474_h.func_77978_p())) {
               try {
                  ITextComponent itextcomponent = ITextComponent.Serializer.func_150699_a(s5);
                  this.field_175386_A = itextcomponent != null ? GuiUtilRenderComponents.func_178908_a(itextcomponent, 116, this.field_146289_q, true, true) : null;
               } catch (JsonParseException var13) {
                  this.field_175386_A = null;
               }
            } else {
               this.field_175386_A = Lists.newArrayList((new TextComponentTranslation("book.invalid.tag")).func_211708_a(TextFormatting.DARK_RED));
            }

            this.field_175387_B = this.field_146484_x;
         }

         int j1 = this.field_146289_q.func_78256_a(s4);
         this.field_146289_q.func_211126_b(s4, (float)(i - j1 + 192 - 44), 18.0F, 0);
         if (this.field_175386_A == null) {
            this.field_146289_q.func_78279_b(s5, i + 36, 34, 116, 0);
         } else {
            int k1 = Math.min(128 / this.field_146289_q.field_78288_b, this.field_175386_A.size());

            for(int l1 = 0; l1 < k1; ++l1) {
               ITextComponent itextcomponent2 = this.field_175386_A.get(l1);
               this.field_146289_q.func_211126_b(itextcomponent2.func_150254_d(), (float)(i + 36), (float)(34 + l1 * this.field_146289_q.field_78288_b), 0);
            }

            ITextComponent itextcomponent1 = this.func_195260_a((double)p_73863_1_, (double)p_73863_2_);
            if (itextcomponent1 != null) {
               this.func_175272_a(itextcomponent1, p_73863_1_, p_73863_2_);
            }
         }
      }

      super.func_73863_a(p_73863_1_, p_73863_2_, p_73863_3_);
   }

   public boolean mouseClicked(double p_mouseClicked_1_, double p_mouseClicked_3_, int p_mouseClicked_5_) {
      if (p_mouseClicked_5_ == 0) {
         ITextComponent itextcomponent = this.func_195260_a(p_mouseClicked_1_, p_mouseClicked_3_);
         if (itextcomponent != null && this.func_175276_a(itextcomponent)) {
            return true;
         }
      }

      return super.mouseClicked(p_mouseClicked_1_, p_mouseClicked_3_, p_mouseClicked_5_);
   }

   public boolean func_175276_a(ITextComponent p_175276_1_) {
      ClickEvent clickevent = p_175276_1_.func_150256_b().func_150235_h();
      if (clickevent == null) {
         return false;
      } else if (clickevent.func_150669_a() == ClickEvent.Action.CHANGE_PAGE) {
         String s = clickevent.func_150668_b();

         try {
            int i = Integer.parseInt(s) - 1;
            if (i >= 0 && i < this.field_146476_w && i != this.field_146484_x) {
               this.field_146484_x = i;
               this.func_146464_h();
               return true;
            }
         } catch (Throwable var5) {
            ;
         }

         return false;
      } else {
         boolean flag = super.func_175276_a(p_175276_1_);
         if (flag && clickevent.func_150669_a() == ClickEvent.Action.RUN_COMMAND) {
            this.field_146297_k.func_147108_a((GuiScreen)null);
         }

         return flag;
      }
   }

   @Nullable
   public ITextComponent func_195260_a(double p_195260_1_, double p_195260_3_) {
      if (this.field_175386_A == null) {
         return null;
      } else {
         int i = MathHelper.func_76128_c(p_195260_1_ - (double)((this.field_146294_l - 192) / 2) - 36.0D);
         int j = MathHelper.func_76128_c(p_195260_3_ - 2.0D - 16.0D - 16.0D);
         if (i >= 0 && j >= 0) {
            int k = Math.min(128 / this.field_146289_q.field_78288_b, this.field_175386_A.size());
            if (i <= 116 && j < this.field_146297_k.field_71466_p.field_78288_b * k + k) {
               int l = j / this.field_146297_k.field_71466_p.field_78288_b;
               if (l >= 0 && l < this.field_175386_A.size()) {
                  ITextComponent itextcomponent = this.field_175386_A.get(l);
                  int i1 = 0;

                  for(ITextComponent itextcomponent1 : itextcomponent) {
                     if (itextcomponent1 instanceof TextComponentString) {
                        i1 += this.field_146297_k.field_71466_p.func_78256_a(itextcomponent1.func_150254_d());
                        if (i1 > i) {
                           return itextcomponent1;
                        }
                     }
                  }
               }

               return null;
            } else {
               return null;
            }
         } else {
            return null;
         }
      }
   }

   @OnlyIn(Dist.CLIENT)
   abstract static class NextPageButton extends GuiButton {
      private final boolean field_146151_o;

      public NextPageButton(int p_i46316_1_, int p_i46316_2_, int p_i46316_3_, boolean p_i46316_4_) {
         super(p_i46316_1_, p_i46316_2_, p_i46316_3_, 23, 13, "");
         this.field_146151_o = p_i46316_4_;
      }

      public void func_194828_a(int p_194828_1_, int p_194828_2_, float p_194828_3_) {
         if (this.field_146125_m) {
            boolean flag = p_194828_1_ >= this.field_146128_h && p_194828_2_ >= this.field_146129_i && p_194828_1_ < this.field_146128_h + this.field_146120_f && p_194828_2_ < this.field_146129_i + this.field_146121_g;
            GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
            Minecraft.func_71410_x().func_110434_K().func_110577_a(GuiScreenBook.field_146466_f);
            int i = 0;
            int j = 192;
            if (flag) {
               i += 23;
            }

            if (!this.field_146151_o) {
               j += 13;
            }

            this.func_73729_b(this.field_146128_h, this.field_146129_i, i, j, 23, 13);
         }
      }
   }
}
