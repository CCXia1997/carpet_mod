package net.minecraft.client.gui.fonts;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import it.unimi.dsi.fastutil.chars.Char2ObjectMap;
import it.unimi.dsi.fastutil.chars.Char2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.chars.CharArrayList;
import it.unimi.dsi.fastutil.chars.CharList;
import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import java.util.List;
import java.util.Random;
import java.util.Set;
import net.minecraft.client.gui.fonts.providers.IGlyphProvider;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@OnlyIn(Dist.CLIENT)
public class Font implements AutoCloseable {
   private static final Logger field_211189_a = LogManager.getLogger();
   private static final EmptyGlyph field_212460_b = new EmptyGlyph();
   private static final IGlyph field_212461_c = () -> {
      return 4.0F;
   };
   private static final Random field_212462_d = new Random();
   private final TextureManager field_211191_c;
   private final ResourceLocation field_211192_d;
   private TexturedGlyph field_211572_d;
   private final List<IGlyphProvider> field_211194_f = Lists.newArrayList();
   private final Char2ObjectMap<TexturedGlyph> field_212463_j = new Char2ObjectOpenHashMap<>();
   private final Char2ObjectMap<IGlyph> field_211195_g = new Char2ObjectOpenHashMap<>();
   private final Int2ObjectMap<CharList> field_211196_h = new Int2ObjectOpenHashMap<>();
   private final List<FontTexture> field_211197_i = Lists.newArrayList();

   public Font(TextureManager p_i49771_1_, ResourceLocation p_i49771_2_) {
      this.field_211191_c = p_i49771_1_;
      this.field_211192_d = p_i49771_2_;
   }

   public void func_211570_a(List<IGlyphProvider> p_211570_1_) {
      for(IGlyphProvider iglyphprovider : this.field_211194_f) {
         iglyphprovider.close();
      }

      this.field_211194_f.clear();
      this.func_211571_a();
      this.field_211197_i.clear();
      this.field_212463_j.clear();
      this.field_211195_g.clear();
      this.field_211196_h.clear();
      this.field_211572_d = this.func_211185_a(DefaultGlyph.INSTANCE);
      Set<IGlyphProvider> set = Sets.newHashSet();

      for(char c0 = 0; c0 < '\uffff'; ++c0) {
         for(IGlyphProvider iglyphprovider1 : p_211570_1_) {
            IGlyph iglyph = (IGlyph)(c0 == ' ' ? field_212461_c : iglyphprovider1.func_212248_a(c0));
            if (iglyph != null) {
               set.add(iglyphprovider1);
               if (iglyph != DefaultGlyph.INSTANCE) {
                  this.field_211196_h.computeIfAbsent(MathHelper.func_76123_f(iglyph.getAdvance(false)), (p_212456_0_) -> {
                     return new CharArrayList();
                  }).add(c0);
               }
               break;
            }
         }
      }

      p_211570_1_.stream().filter(set::contains).forEach(this.field_211194_f::add);
   }

   public void close() {
      this.func_211571_a();
   }

   public void func_211571_a() {
      for(FontTexture fonttexture : this.field_211197_i) {
         fonttexture.close();
      }

   }

   public IGlyph func_211184_b(char p_211184_1_) {
      return this.field_211195_g.computeIfAbsent(p_211184_1_, (p_212457_1_) -> {
         return (IGlyph)(p_212457_1_ == 32 ? field_212461_c : this.func_212455_c((char)p_212457_1_));
      });
   }

   private IGlyphInfo func_212455_c(char p_212455_1_) {
      for(IGlyphProvider iglyphprovider : this.field_211194_f) {
         IGlyphInfo iglyphinfo = iglyphprovider.func_212248_a(p_212455_1_);
         if (iglyphinfo != null) {
            return iglyphinfo;
         }
      }

      return DefaultGlyph.INSTANCE;
   }

   public TexturedGlyph func_211187_a(char p_211187_1_) {
      return this.field_212463_j.computeIfAbsent(p_211187_1_, (p_212458_1_) -> {
         return (TexturedGlyph)(p_212458_1_ == 32 ? field_212460_b : this.func_211185_a(this.func_212455_c((char)p_212458_1_)));
      });
   }

   private TexturedGlyph func_211185_a(IGlyphInfo p_211185_1_) {
      for(FontTexture fonttexture : this.field_211197_i) {
         TexturedGlyph texturedglyph = fonttexture.func_211131_a(p_211185_1_);
         if (texturedglyph != null) {
            return texturedglyph;
         }
      }

      FontTexture fonttexture1 = new FontTexture(new ResourceLocation(this.field_211192_d.func_110624_b(), this.field_211192_d.func_110623_a() + "/" + this.field_211197_i.size()), p_211185_1_.func_211579_f());
      this.field_211197_i.add(fonttexture1);
      this.field_211191_c.func_110579_a(fonttexture1.func_211132_a(), fonttexture1);
      TexturedGlyph texturedglyph1 = fonttexture1.func_211131_a(p_211185_1_);
      return texturedglyph1 == null ? this.field_211572_d : texturedglyph1;
   }

   public TexturedGlyph func_211188_a(IGlyph p_211188_1_) {
      CharList charlist = this.field_211196_h.get(MathHelper.func_76123_f(p_211188_1_.getAdvance(false)));
      return charlist != null && !charlist.isEmpty() ? this.func_211187_a(charlist.get(field_212462_d.nextInt(charlist.size()))) : this.field_211572_d;
   }
}
