package net.minecraft.client.gui;

import javax.annotation.Nullable;
import net.minecraft.client.GameSettings;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.resources.I18n;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class GuiVideoSettings extends GuiScreen {
   private final GuiScreen field_146498_f;
   protected String field_146500_a = "Video Settings";
   private final GameSettings field_146499_g;
   private GuiOptionsRowList field_146501_h;
   private static final GameSettings.Options[] field_146502_i = new GameSettings.Options[]{GameSettings.Options.GRAPHICS, GameSettings.Options.RENDER_DISTANCE, GameSettings.Options.AMBIENT_OCCLUSION, GameSettings.Options.FRAMERATE_LIMIT, GameSettings.Options.ENABLE_VSYNC, GameSettings.Options.VIEW_BOBBING, GameSettings.Options.GUI_SCALE, GameSettings.Options.ATTACK_INDICATOR, GameSettings.Options.GAMMA, GameSettings.Options.RENDER_CLOUDS, GameSettings.Options.USE_FULLSCREEN, GameSettings.Options.PARTICLES, GameSettings.Options.MIPMAP_LEVELS, GameSettings.Options.USE_VBO, GameSettings.Options.ENTITY_SHADOWS, GameSettings.Options.BIOME_BLEND_RADIUS};

   public GuiVideoSettings(GuiScreen p_i1062_1_, GameSettings p_i1062_2_) {
      this.field_146498_f = p_i1062_1_;
      this.field_146499_g = p_i1062_2_;
   }

   @Nullable
   public IGuiEventListener getFocused() {
      return this.field_146501_h;
   }

   protected void func_73866_w_() {
      this.field_146500_a = I18n.func_135052_a("options.videoTitle");
      this.func_189646_b(new GuiButton(200, this.field_146294_l / 2 - 100, this.field_146295_m - 27, I18n.func_135052_a("gui.done")) {
         public void func_194829_a(double p_194829_1_, double p_194829_3_) {
            GuiVideoSettings.this.field_146297_k.field_71474_y.func_74303_b();
            GuiVideoSettings.this.field_146297_k.field_195558_d.func_198097_f();
            GuiVideoSettings.this.field_146297_k.func_147108_a(GuiVideoSettings.this.field_146498_f);
         }
      });
      if (OpenGlHelper.field_176083_O) {
         this.field_146501_h = new GuiOptionsRowList(this.field_146297_k, this.field_146294_l, this.field_146295_m, 32, this.field_146295_m - 32, 25, field_146502_i);
      } else {
         GameSettings.Options[] agamesettings$options = new GameSettings.Options[field_146502_i.length - 1];
         int i = 0;

         for(GameSettings.Options gamesettings$options : field_146502_i) {
            if (gamesettings$options == GameSettings.Options.USE_VBO) {
               break;
            }

            agamesettings$options[i] = gamesettings$options;
            ++i;
         }

         this.field_146501_h = new GuiOptionsRowList(this.field_146297_k, this.field_146294_l, this.field_146295_m, 32, this.field_146295_m - 32, 25, agamesettings$options);
      }

      this.field_195124_j.add(this.field_146501_h);
   }

   public void func_195122_V_() {
      this.field_146297_k.field_71474_y.func_74303_b();
      super.func_195122_V_();
   }

   public boolean mouseClicked(double p_mouseClicked_1_, double p_mouseClicked_3_, int p_mouseClicked_5_) {
      int i = this.field_146499_g.field_74335_Z;
      if (super.mouseClicked(p_mouseClicked_1_, p_mouseClicked_3_, p_mouseClicked_5_)) {
         if (this.field_146499_g.field_74335_Z != i) {
            this.field_146297_k.field_195558_d.func_198098_h();
         }

         return true;
      } else {
         return false;
      }
   }

   public boolean mouseReleased(double p_mouseReleased_1_, double p_mouseReleased_3_, int p_mouseReleased_5_) {
      int i = this.field_146499_g.field_74335_Z;
      if (super.mouseReleased(p_mouseReleased_1_, p_mouseReleased_3_, p_mouseReleased_5_)) {
         return true;
      } else if (this.field_146501_h.mouseReleased(p_mouseReleased_1_, p_mouseReleased_3_, p_mouseReleased_5_)) {
         if (this.field_146499_g.field_74335_Z != i) {
            this.field_146297_k.field_195558_d.func_198098_h();
         }

         return true;
      } else {
         return false;
      }
   }

   public void func_73863_a(int p_73863_1_, int p_73863_2_, float p_73863_3_) {
      this.func_146276_q_();
      this.field_146501_h.func_148128_a(p_73863_1_, p_73863_2_, p_73863_3_);
      this.func_73732_a(this.field_146289_q, this.field_146500_a, this.field_146294_l / 2, 5, 16777215);
      super.func_73863_a(p_73863_1_, p_73863_2_, p_73863_3_);
   }
}
