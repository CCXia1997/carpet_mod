package net.minecraft.client.gui;

import com.google.common.collect.Lists;
import java.util.Collections;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.resources.ResourcePackInfoClient;
import net.minecraft.client.resources.ResourcePackListEntryFound;
import net.minecraft.resources.ResourcePackList;
import net.minecraft.util.Util;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class GuiScreenResourcePacks extends GuiScreen {
   private final GuiScreen field_146965_f;
   @Nullable
   private GuiResourcePackAvailable field_146970_i;
   @Nullable
   private GuiResourcePackSelected field_146967_r;
   private boolean field_175289_s;

   public GuiScreenResourcePacks(GuiScreen p_i45050_1_) {
      this.field_146965_f = p_i45050_1_;
   }

   protected void func_73866_w_() {
      this.func_189646_b(new GuiOptionButton(2, this.field_146294_l / 2 - 154, this.field_146295_m - 48, I18n.func_135052_a("resourcePack.openFolder")) {
         public void func_194829_a(double p_194829_1_, double p_194829_3_) {
            Util.func_110647_a().func_195641_a(GuiScreenResourcePacks.this.field_146297_k.func_195549_J());
         }
      });
      this.func_189646_b(new GuiOptionButton(1, this.field_146294_l / 2 + 4, this.field_146295_m - 48, I18n.func_135052_a("gui.done")) {
         public void func_194829_a(double p_194829_1_, double p_194829_3_) {
            if (GuiScreenResourcePacks.this.field_175289_s) {
               List<ResourcePackInfoClient> list1 = Lists.newArrayList();

               for(ResourcePackListEntryFound resourcepacklistentryfound : GuiScreenResourcePacks.this.field_146967_r.func_195074_b()) {
                  list1.add(resourcepacklistentryfound.func_195017_i());
               }

               Collections.reverse(list1);
               GuiScreenResourcePacks.this.field_146297_k.func_195548_H().func_198985_a(list1);
               GuiScreenResourcePacks.this.field_146297_k.field_71474_y.field_151453_l.clear();
               GuiScreenResourcePacks.this.field_146297_k.field_71474_y.field_183018_l.clear();

               for(ResourcePackInfoClient resourcepackinfoclient2 : list1) {
                  if (!resourcepackinfoclient2.func_195798_h()) {
                     GuiScreenResourcePacks.this.field_146297_k.field_71474_y.field_151453_l.add(resourcepackinfoclient2.func_195790_f());
                     if (!resourcepackinfoclient2.func_195791_d().func_198968_a()) {
                        GuiScreenResourcePacks.this.field_146297_k.field_71474_y.field_183018_l.add(resourcepackinfoclient2.func_195790_f());
                     }
                  }
               }

               GuiScreenResourcePacks.this.field_146297_k.field_71474_y.func_74303_b();
               GuiScreenResourcePacks.this.field_146297_k.func_110436_a();
            }

            GuiScreenResourcePacks.this.field_146297_k.func_147108_a(GuiScreenResourcePacks.this.field_146965_f);
         }
      });
      GuiResourcePackAvailable guiresourcepackavailable = this.field_146970_i;
      GuiResourcePackSelected guiresourcepackselected = this.field_146967_r;
      this.field_146970_i = new GuiResourcePackAvailable(this.field_146297_k, 200, this.field_146295_m);
      this.field_146970_i.func_148140_g(this.field_146294_l / 2 - 4 - 200);
      if (guiresourcepackavailable != null) {
         this.field_146970_i.func_195074_b().addAll(guiresourcepackavailable.func_195074_b());
      }

      this.field_195124_j.add(this.field_146970_i);
      this.field_146967_r = new GuiResourcePackSelected(this.field_146297_k, 200, this.field_146295_m);
      this.field_146967_r.func_148140_g(this.field_146294_l / 2 + 4);
      if (guiresourcepackselected != null) {
         this.field_146967_r.func_195074_b().addAll(guiresourcepackselected.func_195074_b());
      }

      this.field_195124_j.add(this.field_146967_r);
      if (!this.field_175289_s) {
         this.field_146970_i.func_195074_b().clear();
         this.field_146967_r.func_195074_b().clear();
         ResourcePackList<ResourcePackInfoClient> resourcepacklist = this.field_146297_k.func_195548_H();
         resourcepacklist.func_198983_a();
         List<ResourcePackInfoClient> list = Lists.newArrayList(resourcepacklist.func_198978_b());
         list.removeAll(resourcepacklist.func_198980_d());

         for(ResourcePackInfoClient resourcepackinfoclient : list) {
            this.field_146970_i.func_195095_a(new ResourcePackListEntryFound(this, resourcepackinfoclient));
         }

         for(ResourcePackInfoClient resourcepackinfoclient1 : Lists.reverse(Lists.newArrayList(resourcepacklist.func_198980_d()))) {
            this.field_146967_r.func_195095_a(new ResourcePackListEntryFound(this, resourcepackinfoclient1));
         }
      }

   }

   public void func_195301_a(ResourcePackListEntryFound p_195301_1_) {
      this.field_146970_i.func_195074_b().remove(p_195301_1_);
      p_195301_1_.func_195020_a(this.field_146967_r);
      this.func_175288_g();
   }

   public void func_195305_b(ResourcePackListEntryFound p_195305_1_) {
      this.field_146967_r.func_195074_b().remove(p_195305_1_);
      this.field_146970_i.func_195095_a(p_195305_1_);
      this.func_175288_g();
   }

   public boolean func_195312_c(ResourcePackListEntryFound p_195312_1_) {
      return this.field_146967_r.func_195074_b().contains(p_195312_1_);
   }

   public void func_73863_a(int p_73863_1_, int p_73863_2_, float p_73863_3_) {
      this.func_146278_c(0);
      this.field_146970_i.func_148128_a(p_73863_1_, p_73863_2_, p_73863_3_);
      this.field_146967_r.func_148128_a(p_73863_1_, p_73863_2_, p_73863_3_);
      this.func_73732_a(this.field_146289_q, I18n.func_135052_a("resourcePack.title"), this.field_146294_l / 2, 16, 16777215);
      this.func_73732_a(this.field_146289_q, I18n.func_135052_a("resourcePack.folderInfo"), this.field_146294_l / 2 - 77, this.field_146295_m - 26, 8421504);
      super.func_73863_a(p_73863_1_, p_73863_2_, p_73863_3_);
   }

   public void func_175288_g() {
      this.field_175289_s = true;
   }
}
