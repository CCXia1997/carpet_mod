package net.minecraft.client.gui;

import com.google.common.hash.Hashing;
import com.google.common.util.concurrent.ThreadFactoryBuilder;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.util.Base64;
import java.util.List;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.ThreadPoolExecutor;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.client.renderer.texture.NativeImage;
import net.minecraft.client.resources.I18n;
import net.minecraft.util.DefaultUncaughtExceptionHandler;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.Util;
import net.minecraft.util.text.TextFormatting;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.apache.commons.lang3.Validate;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.lwjgl.system.MemoryStack;

@OnlyIn(Dist.CLIENT)
public class ServerListEntryNormal extends ServerSelectionList.Entry {
   private static final Logger field_148304_a = LogManager.getLogger();
   private static final ThreadPoolExecutor field_148302_b = new ScheduledThreadPoolExecutor(5, (new ThreadFactoryBuilder()).setNameFormat("Server Pinger #%d").setDaemon(true).setUncaughtExceptionHandler(new DefaultUncaughtExceptionHandler(field_148304_a)).build());
   private static final ResourceLocation field_178015_c = new ResourceLocation("textures/misc/unknown_server.png");
   private static final ResourceLocation field_178014_d = new ResourceLocation("textures/gui/server_selection.png");
   private final GuiMultiplayer field_148303_c;
   private final Minecraft field_148300_d;
   private final ServerData field_148301_e;
   private final ResourceLocation field_148306_i;
   private String field_148299_g;
   private DynamicTexture field_148305_h;
   private long field_148298_f;

   protected ServerListEntryNormal(GuiMultiplayer p_i45048_1_, ServerData p_i45048_2_) {
      this.field_148303_c = p_i45048_1_;
      this.field_148301_e = p_i45048_2_;
      this.field_148300_d = Minecraft.func_71410_x();
      this.field_148306_i = new ResourceLocation("servers/" + Hashing.sha1().hashUnencodedChars(p_i45048_2_.field_78845_b) + "/icon");
      this.field_148305_h = (DynamicTexture)this.field_148300_d.func_110434_K().func_110581_b(this.field_148306_i);
   }

   public void func_194999_a(int p_194999_1_, int p_194999_2_, int p_194999_3_, int p_194999_4_, boolean p_194999_5_, float p_194999_6_) {
      int i = this.func_195001_c();
      int j = this.func_195002_d();
      if (!this.field_148301_e.field_78841_f) {
         this.field_148301_e.field_78841_f = true;
         this.field_148301_e.field_78844_e = -2L;
         this.field_148301_e.field_78843_d = "";
         this.field_148301_e.field_78846_c = "";
         field_148302_b.submit(() -> {
            try {
               this.field_148303_c.func_146789_i().func_147224_a(this.field_148301_e);
            } catch (UnknownHostException var2) {
               this.field_148301_e.field_78844_e = -1L;
               this.field_148301_e.field_78843_d = TextFormatting.DARK_RED + I18n.func_135052_a("multiplayer.status.cannot_resolve");
            } catch (Exception var3) {
               this.field_148301_e.field_78844_e = -1L;
               this.field_148301_e.field_78843_d = TextFormatting.DARK_RED + I18n.func_135052_a("multiplayer.status.cannot_connect");
            }

         });
      }

      boolean flag = this.field_148301_e.field_82821_f > 404;
      boolean flag1 = this.field_148301_e.field_82821_f < 404;
      boolean flag2 = flag || flag1;
      this.field_148300_d.field_71466_p.func_211126_b(this.field_148301_e.field_78847_a, (float)(j + 32 + 3), (float)(i + 1), 16777215);
      List<String> list = this.field_148300_d.field_71466_p.func_78271_c(this.field_148301_e.field_78843_d, p_194999_1_ - 32 - 2);

      for(int k = 0; k < Math.min(list.size(), 2); ++k) {
         this.field_148300_d.field_71466_p.func_211126_b(list.get(k), (float)(j + 32 + 3), (float)(i + 12 + this.field_148300_d.field_71466_p.field_78288_b * k), 8421504);
      }

      String s2 = flag2 ? TextFormatting.DARK_RED + this.field_148301_e.field_82822_g : this.field_148301_e.field_78846_c;
      int l = this.field_148300_d.field_71466_p.func_78256_a(s2);
      this.field_148300_d.field_71466_p.func_211126_b(s2, (float)(j + p_194999_1_ - l - 15 - 2), (float)(i + 1), 8421504);
      int i1 = 0;
      String s = null;
      int j1;
      String s1;
      if (flag2) {
         j1 = 5;
         s1 = I18n.func_135052_a(flag ? "multiplayer.status.client_out_of_date" : "multiplayer.status.server_out_of_date");
         s = this.field_148301_e.field_147412_i;
      } else if (this.field_148301_e.field_78841_f && this.field_148301_e.field_78844_e != -2L) {
         if (this.field_148301_e.field_78844_e < 0L) {
            j1 = 5;
         } else if (this.field_148301_e.field_78844_e < 150L) {
            j1 = 0;
         } else if (this.field_148301_e.field_78844_e < 300L) {
            j1 = 1;
         } else if (this.field_148301_e.field_78844_e < 600L) {
            j1 = 2;
         } else if (this.field_148301_e.field_78844_e < 1000L) {
            j1 = 3;
         } else {
            j1 = 4;
         }

         if (this.field_148301_e.field_78844_e < 0L) {
            s1 = I18n.func_135052_a("multiplayer.status.no_connection");
         } else {
            s1 = this.field_148301_e.field_78844_e + "ms";
            s = this.field_148301_e.field_147412_i;
         }
      } else {
         i1 = 1;
         j1 = (int)(Util.func_211177_b() / 100L + (long)(this.func_195003_b() * 2) & 7L);
         if (j1 > 4) {
            j1 = 8 - j1;
         }

         s1 = I18n.func_135052_a("multiplayer.status.pinging");
      }

      GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
      this.field_148300_d.func_110434_K().func_110577_a(Gui.field_110324_m);
      Gui.func_146110_a(j + p_194999_1_ - 15, i, (float)(i1 * 10), (float)(176 + j1 * 8), 10, 8, 256.0F, 256.0F);
      if (this.field_148301_e.func_147409_e() != null && !this.field_148301_e.func_147409_e().equals(this.field_148299_g)) {
         this.field_148299_g = this.field_148301_e.func_147409_e();
         this.func_148297_b();
         this.field_148303_c.func_146795_p().func_78855_b();
      }

      if (this.field_148305_h != null) {
         this.func_178012_a(j, i, this.field_148306_i);
      } else {
         this.func_178012_a(j, i, field_178015_c);
      }

      int k1 = p_194999_3_ - j;
      int l1 = p_194999_4_ - i;
      if (k1 >= p_194999_1_ - 15 && k1 <= p_194999_1_ - 5 && l1 >= 0 && l1 <= 8) {
         this.field_148303_c.func_146793_a(s1);
      } else if (k1 >= p_194999_1_ - l - 15 - 2 && k1 <= p_194999_1_ - 15 - 2 && l1 >= 0 && l1 <= 8) {
         this.field_148303_c.func_146793_a(s);
      }

      if (this.field_148300_d.field_71474_y.field_85185_A || p_194999_5_) {
         this.field_148300_d.func_110434_K().func_110577_a(field_178014_d);
         Gui.func_73734_a(j, i, j + 32, i + 32, -1601138544);
         GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
         int i2 = p_194999_3_ - j;
         int j2 = p_194999_4_ - i;
         if (this.func_178013_b()) {
            if (i2 < 32 && i2 > 16) {
               Gui.func_146110_a(j, i, 0.0F, 32.0F, 32, 32, 256.0F, 256.0F);
            } else {
               Gui.func_146110_a(j, i, 0.0F, 0.0F, 32, 32, 256.0F, 256.0F);
            }
         }

         if (this.field_148303_c.func_175392_a(this, this.func_195003_b())) {
            if (i2 < 16 && j2 < 16) {
               Gui.func_146110_a(j, i, 96.0F, 32.0F, 32, 32, 256.0F, 256.0F);
            } else {
               Gui.func_146110_a(j, i, 96.0F, 0.0F, 32, 32, 256.0F, 256.0F);
            }
         }

         if (this.field_148303_c.func_175394_b(this, this.func_195003_b())) {
            if (i2 < 16 && j2 > 16) {
               Gui.func_146110_a(j, i, 64.0F, 32.0F, 32, 32, 256.0F, 256.0F);
            } else {
               Gui.func_146110_a(j, i, 64.0F, 0.0F, 32, 32, 256.0F, 256.0F);
            }
         }
      }

   }

   protected void func_178012_a(int p_178012_1_, int p_178012_2_, ResourceLocation p_178012_3_) {
      this.field_148300_d.func_110434_K().func_110577_a(p_178012_3_);
      GlStateManager.func_179147_l();
      Gui.func_146110_a(p_178012_1_, p_178012_2_, 0.0F, 0.0F, 32, 32, 32.0F, 32.0F);
      GlStateManager.func_179084_k();
   }

   private boolean func_178013_b() {
      return true;
   }

   private void func_148297_b() {
      if (this.field_148301_e.func_147409_e() == null) {
         this.field_148300_d.func_110434_K().func_147645_c(this.field_148306_i);
         this.field_148305_h.func_195414_e().close();
         this.field_148305_h = null;
      } else {
         try (MemoryStack memorystack = MemoryStack.stackPush()) {
            ByteBuffer bytebuffer = memorystack.UTF8(this.field_148301_e.func_147409_e(), false);
            ByteBuffer bytebuffer1 = Base64.getDecoder().decode(bytebuffer);
            ByteBuffer bytebuffer2 = memorystack.malloc(bytebuffer1.remaining());
            bytebuffer2.put(bytebuffer1);
            bytebuffer2.rewind();
            NativeImage nativeimage = NativeImage.func_195704_a(bytebuffer2);
            Validate.validState(nativeimage.func_195702_a() == 64, "Must be 64 pixels wide");
            Validate.validState(nativeimage.func_195714_b() == 64, "Must be 64 pixels high");
            if (this.field_148305_h == null) {
               this.field_148305_h = new DynamicTexture(nativeimage);
            } else {
               this.field_148305_h.func_195415_a(nativeimage);
               this.field_148305_h.func_110564_a();
            }

            this.field_148300_d.func_110434_K().func_110579_a(this.field_148306_i, this.field_148305_h);
         } catch (Throwable throwable) {
            field_148304_a.error("Invalid icon for server {} ({})", this.field_148301_e.field_78847_a, this.field_148301_e.field_78845_b, throwable);
            this.field_148301_e.func_147407_a((String)null);
         }
      }

   }

   public boolean mouseClicked(double p_mouseClicked_1_, double p_mouseClicked_3_, int p_mouseClicked_5_) {
      double d0 = p_mouseClicked_1_ - (double)this.func_195002_d();
      double d1 = p_mouseClicked_3_ - (double)this.func_195001_c();
      if (d0 <= 32.0D) {
         if (d0 < 32.0D && d0 > 16.0D && this.func_178013_b()) {
            this.field_148303_c.func_146790_a(this.func_195003_b());
            this.field_148303_c.func_146796_h();
            return true;
         }

         if (d0 < 16.0D && d1 < 16.0D && this.field_148303_c.func_175392_a(this, this.func_195003_b())) {
            this.field_148303_c.func_175391_a(this, this.func_195003_b(), GuiScreen.func_146272_n());
            return true;
         }

         if (d0 < 16.0D && d1 > 16.0D && this.field_148303_c.func_175394_b(this, this.func_195003_b())) {
            this.field_148303_c.func_175393_b(this, this.func_195003_b(), GuiScreen.func_146272_n());
            return true;
         }
      }

      this.field_148303_c.func_146790_a(this.func_195003_b());
      if (Util.func_211177_b() - this.field_148298_f < 250L) {
         this.field_148303_c.func_146796_h();
      }

      this.field_148298_f = Util.func_211177_b();
      return false;
   }

   public ServerData func_148296_a() {
      return this.field_148301_e;
   }
}
