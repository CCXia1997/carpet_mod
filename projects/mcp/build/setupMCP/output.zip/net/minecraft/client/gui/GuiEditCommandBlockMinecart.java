package net.minecraft.client.gui;

import net.minecraft.entity.item.EntityMinecartCommandBlock;
import net.minecraft.network.play.client.CPacketUpdateCommandMinecart;
import net.minecraft.tileentity.CommandBlockBaseLogic;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class GuiEditCommandBlockMinecart extends GuiCommandBlockBase {
   private final CommandBlockBaseLogic field_184093_g;

   public GuiEditCommandBlockMinecart(CommandBlockBaseLogic p_i46595_1_) {
      this.field_184093_g = p_i46595_1_;
   }

   public CommandBlockBaseLogic func_195231_h() {
      return this.field_184093_g;
   }

   int func_195236_i() {
      return 150;
   }

   protected void func_73866_w_() {
      super.func_73866_w_();
      this.field_195238_s = this.func_195231_h().func_175571_m();
      this.func_195233_j();
      this.field_195237_a.func_146180_a(this.func_195231_h().func_145753_i());
   }

   protected void func_195235_a(CommandBlockBaseLogic p_195235_1_) {
      if (p_195235_1_ instanceof EntityMinecartCommandBlock.MinecartCommandLogic) {
         EntityMinecartCommandBlock.MinecartCommandLogic entityminecartcommandblock$minecartcommandlogic = (EntityMinecartCommandBlock.MinecartCommandLogic)p_195235_1_;
         this.field_146297_k.func_147114_u().func_147297_a(new CPacketUpdateCommandMinecart(entityminecartcommandblock$minecartcommandlogic.func_210167_g().func_145782_y(), this.field_195237_a.func_146179_b(), p_195235_1_.func_175571_m()));
      }

   }
}
