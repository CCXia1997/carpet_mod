package net.minecraft.client;

import com.google.common.collect.Lists;
import java.util.List;
import java.util.Optional;
import net.minecraft.client.renderer.VideoMode;
import net.minecraft.client.renderer.VirtualScreen;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.glfw.GLFWVidMode;
import org.lwjgl.glfw.GLFWVidMode.Buffer;

@OnlyIn(Dist.CLIENT)
public final class Monitor {
   private final VirtualScreen field_197996_a;
   private final long field_197997_b;
   private final List<VideoMode> field_197998_c;
   private VideoMode field_197999_d;
   private int field_198000_e;
   private int field_198001_f;

   public Monitor(VirtualScreen p_i47673_1_, long p_i47673_2_) {
      this.field_197996_a = p_i47673_1_;
      this.field_197997_b = p_i47673_2_;
      this.field_197998_c = Lists.newArrayList();
      this.func_197988_a();
   }

   public void func_197988_a() {
      this.field_197998_c.clear();
      Buffer buffer = GLFW.glfwGetVideoModes(this.field_197997_b);

      for(int i = 0; i < buffer.limit(); ++i) {
         buffer.position(i);
         VideoMode videomode = new VideoMode(buffer);
         if (videomode.func_198062_c() >= 8 && videomode.func_198063_d() >= 8 && videomode.func_198068_e() >= 8) {
            this.field_197998_c.add(videomode);
         }
      }

      int[] aint = new int[1];
      int[] aint1 = new int[1];
      GLFW.glfwGetMonitorPos(this.field_197997_b, aint, aint1);
      this.field_198000_e = aint[0];
      this.field_198001_f = aint1[0];
      GLFWVidMode glfwvidmode = GLFW.glfwGetVideoMode(this.field_197997_b);
      this.field_197999_d = new VideoMode(glfwvidmode);
   }

   VideoMode func_197992_a(Optional<VideoMode> p_197992_1_) {
      if (p_197992_1_.isPresent()) {
         VideoMode videomode = p_197992_1_.get();

         for(VideoMode videomode1 : Lists.reverse(this.field_197998_c)) {
            if (videomode1.equals(videomode)) {
               return videomode1;
            }
         }
      }

      return this.func_197987_b();
   }

   int func_197993_b(Optional<VideoMode> p_197993_1_) {
      if (p_197993_1_.isPresent()) {
         VideoMode videomode = p_197993_1_.get();

         for(int i = this.field_197998_c.size() - 1; i >= 0; --i) {
            if (videomode.equals(this.field_197998_c.get(i))) {
               return i;
            }
         }
      }

      return this.field_197998_c.indexOf(this.func_197987_b());
   }

   public VideoMode func_197987_b() {
      return this.field_197999_d;
   }

   public int func_197989_c() {
      return this.field_198000_e;
   }

   public int func_197990_d() {
      return this.field_198001_f;
   }

   public VideoMode func_197991_a(int p_197991_1_) {
      return this.field_197998_c.get(p_197991_1_);
   }

   public int func_197994_e() {
      return this.field_197998_c.size();
   }

   public long func_197995_f() {
      return this.field_197997_b;
   }

   public String toString() {
      return String.format("Monitor[%s %sx%s %s]", this.field_197997_b, this.field_198000_e, this.field_198001_f, this.field_197999_d);
   }
}
