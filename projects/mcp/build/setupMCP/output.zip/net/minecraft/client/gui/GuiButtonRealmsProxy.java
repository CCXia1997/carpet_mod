package net.minecraft.client.gui;

import net.minecraft.client.Minecraft;
import net.minecraft.realms.RealmsButton;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class GuiButtonRealmsProxy extends GuiButton {
   private final RealmsButton field_154318_o;

   public GuiButtonRealmsProxy(RealmsButton p_i46321_1_, int p_i46321_2_, int p_i46321_3_, int p_i46321_4_, String p_i46321_5_) {
      super(p_i46321_2_, p_i46321_3_, p_i46321_4_, p_i46321_5_);
      this.field_154318_o = p_i46321_1_;
   }

   public GuiButtonRealmsProxy(RealmsButton p_i1090_1_, int p_i1090_2_, int p_i1090_3_, int p_i1090_4_, String p_i1090_5_, int p_i1090_6_, int p_i1090_7_) {
      super(p_i1090_2_, p_i1090_3_, p_i1090_4_, p_i1090_6_, p_i1090_7_, p_i1090_5_);
      this.field_154318_o = p_i1090_1_;
   }

   public int func_207707_c() {
      return this.field_146127_k;
   }

   public boolean func_207710_d() {
      return this.field_146124_l;
   }

   public void func_207706_c(boolean p_207706_1_) {
      this.field_146124_l = p_207706_1_;
   }

   public void func_207705_a(String p_207705_1_) {
      super.field_146126_j = p_207705_1_;
   }

   public int func_146117_b() {
      return super.func_146117_b();
   }

   public int func_207708_e() {
      return this.field_146129_i;
   }

   public void func_194829_a(double p_194829_1_, double p_194829_3_) {
      this.field_154318_o.onClick(p_194829_1_, p_194829_3_);
   }

   public void func_194831_b(double p_194831_1_, double p_194831_3_) {
      this.field_154318_o.onRelease(p_194831_1_, p_194831_3_);
   }

   public void func_146119_b(Minecraft p_146119_1_, int p_146119_2_, int p_146119_3_) {
      this.field_154318_o.renderBg(p_146119_2_, p_146119_3_);
   }

   public RealmsButton func_154317_g() {
      return this.field_154318_o;
   }

   public int func_146114_a(boolean p_146114_1_) {
      return this.field_154318_o.getYImage(p_146114_1_);
   }

   public int func_154312_c(boolean p_154312_1_) {
      return super.func_146114_a(p_154312_1_);
   }

   public int func_207709_g() {
      return this.field_146121_g;
   }
}
