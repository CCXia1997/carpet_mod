package net.minecraft.client.gui.inventory;

import net.minecraft.client.gui.GuiButtonImage;
import net.minecraft.client.gui.recipebook.GuiFurnaceRecipeBook;
import net.minecraft.client.gui.recipebook.GuiRecipeBook;
import net.minecraft.client.gui.recipebook.IRecipeShownListener;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.ClickType;
import net.minecraft.inventory.ContainerFurnace;
import net.minecraft.inventory.ContainerRecipeBook;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.Slot;
import net.minecraft.tileentity.TileEntityFurnace;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class GuiFurnace extends GuiContainer implements IRecipeShownListener {
   private static final ResourceLocation field_147087_u = new ResourceLocation("textures/gui/container/furnace.png");
   private static final ResourceLocation field_201558_x = new ResourceLocation("textures/gui/recipe_button.png");
   private final InventoryPlayer field_175383_v;
   private final IInventory field_147086_v;
   public final GuiFurnaceRecipeBook field_201557_v = new GuiFurnaceRecipeBook();
   private boolean field_201556_A;

   public GuiFurnace(InventoryPlayer p_i45501_1_, IInventory p_i45501_2_) {
      super(new ContainerFurnace(p_i45501_1_, p_i45501_2_));
      this.field_175383_v = p_i45501_1_;
      this.field_147086_v = p_i45501_2_;
   }

   public void func_73866_w_() {
      super.func_73866_w_();
      this.field_201556_A = this.field_146294_l < 379;
      this.field_201557_v.func_201520_a(this.field_146294_l, this.field_146295_m, this.field_146297_k, this.field_201556_A, (ContainerRecipeBook)this.field_147002_h);
      this.field_147003_i = this.field_201557_v.func_193011_a(this.field_201556_A, this.field_146294_l, this.field_146999_f);
      this.func_189646_b(new GuiButtonImage(10, this.field_147003_i + 20, this.field_146295_m / 2 - 49, 20, 18, 0, 0, 19, field_201558_x) {
         public void func_194829_a(double p_194829_1_, double p_194829_3_) {
            GuiFurnace.this.field_201557_v.func_201518_a(GuiFurnace.this.field_201556_A);
            GuiFurnace.this.field_201557_v.func_191866_a();
            GuiFurnace.this.field_147003_i = GuiFurnace.this.field_201557_v.func_193011_a(GuiFurnace.this.field_201556_A, GuiFurnace.this.field_146294_l, GuiFurnace.this.field_146999_f);
            this.func_191746_c(GuiFurnace.this.field_147003_i + 20, GuiFurnace.this.field_146295_m / 2 - 49);
         }
      });
   }

   public void func_73876_c() {
      super.func_73876_c();
      this.field_201557_v.func_193957_d();
   }

   public void func_73863_a(int p_73863_1_, int p_73863_2_, float p_73863_3_) {
      this.func_146276_q_();
      if (this.field_201557_v.func_191878_b() && this.field_201556_A) {
         this.func_146976_a(p_73863_3_, p_73863_1_, p_73863_2_);
         this.field_201557_v.func_191861_a(p_73863_1_, p_73863_2_, p_73863_3_);
      } else {
         this.field_201557_v.func_191861_a(p_73863_1_, p_73863_2_, p_73863_3_);
         super.func_73863_a(p_73863_1_, p_73863_2_, p_73863_3_);
         this.field_201557_v.func_191864_a(this.field_147003_i, this.field_147009_r, true, p_73863_3_);
      }

      this.func_191948_b(p_73863_1_, p_73863_2_);
      this.field_201557_v.func_191876_c(this.field_147003_i, this.field_147009_r, p_73863_1_, p_73863_2_);
   }

   protected void func_146979_b(int p_146979_1_, int p_146979_2_) {
      String s = this.field_147086_v.func_145748_c_().func_150254_d();
      this.field_146289_q.func_211126_b(s, (float)(this.field_146999_f / 2 - this.field_146289_q.func_78256_a(s) / 2), 6.0F, 4210752);
      this.field_146289_q.func_211126_b(this.field_175383_v.func_145748_c_().func_150254_d(), 8.0F, (float)(this.field_147000_g - 96 + 2), 4210752);
   }

   protected void func_146976_a(float p_146976_1_, int p_146976_2_, int p_146976_3_) {
      GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
      this.field_146297_k.func_110434_K().func_110577_a(field_147087_u);
      int i = this.field_147003_i;
      int j = this.field_147009_r;
      this.func_73729_b(i, j, 0, 0, this.field_146999_f, this.field_147000_g);
      if (TileEntityFurnace.func_174903_a(this.field_147086_v)) {
         int k = this.func_175382_i(13);
         this.func_73729_b(i + 56, j + 36 + 12 - k, 176, 12 - k, 14, k + 1);
      }

      int l = this.func_175381_h(24);
      this.func_73729_b(i + 79, j + 34, 176, 14, l + 1, 16);
   }

   public boolean mouseClicked(double p_mouseClicked_1_, double p_mouseClicked_3_, int p_mouseClicked_5_) {
      if (this.field_201557_v.mouseClicked(p_mouseClicked_1_, p_mouseClicked_3_, p_mouseClicked_5_)) {
         return true;
      } else {
         return this.field_201556_A && this.field_201557_v.func_191878_b() ? true : super.mouseClicked(p_mouseClicked_1_, p_mouseClicked_3_, p_mouseClicked_5_);
      }
   }

   protected void func_184098_a(Slot p_184098_1_, int p_184098_2_, int p_184098_3_, ClickType p_184098_4_) {
      super.func_184098_a(p_184098_1_, p_184098_2_, p_184098_3_, p_184098_4_);
      this.field_201557_v.func_191874_a(p_184098_1_);
   }

   public boolean keyPressed(int p_keyPressed_1_, int p_keyPressed_2_, int p_keyPressed_3_) {
      return this.field_201557_v.keyPressed(p_keyPressed_1_, p_keyPressed_2_, p_keyPressed_3_) ? false : super.keyPressed(p_keyPressed_1_, p_keyPressed_2_, p_keyPressed_3_);
   }

   protected boolean func_195361_a(double p_195361_1_, double p_195361_3_, int p_195361_5_, int p_195361_6_, int p_195361_7_) {
      boolean flag = p_195361_1_ < (double)p_195361_5_ || p_195361_3_ < (double)p_195361_6_ || p_195361_1_ >= (double)(p_195361_5_ + this.field_146999_f) || p_195361_3_ >= (double)(p_195361_6_ + this.field_147000_g);
      return this.field_201557_v.func_195604_a(p_195361_1_, p_195361_3_, this.field_147003_i, this.field_147009_r, this.field_146999_f, this.field_147000_g, p_195361_7_) && flag;
   }

   public boolean charTyped(char p_charTyped_1_, int p_charTyped_2_) {
      return this.field_201557_v.charTyped(p_charTyped_1_, p_charTyped_2_) ? true : super.charTyped(p_charTyped_1_, p_charTyped_2_);
   }

   public void func_192043_J_() {
      this.field_201557_v.func_193948_e();
   }

   public GuiRecipeBook func_194310_f() {
      return this.field_201557_v;
   }

   public void func_146281_b() {
      this.field_201557_v.func_191871_c();
      super.func_146281_b();
   }

   private int func_175381_h(int p_175381_1_) {
      int i = this.field_147086_v.func_174887_a_(2);
      int j = this.field_147086_v.func_174887_a_(3);
      return j != 0 && i != 0 ? i * p_175381_1_ / j : 0;
   }

   private int func_175382_i(int p_175382_1_) {
      int i = this.field_147086_v.func_174887_a_(1);
      if (i == 0) {
         i = 200;
      }

      return this.field_147086_v.func_174887_a_(0) * p_175382_1_ / i;
   }
}
