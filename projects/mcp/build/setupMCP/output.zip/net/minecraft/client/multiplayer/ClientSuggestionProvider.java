package net.minecraft.client.multiplayer;

import com.google.common.collect.Lists;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CompletableFuture;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.command.ISuggestionProvider;
import net.minecraft.network.play.client.CPacketTabComplete;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class ClientSuggestionProvider implements ISuggestionProvider {
   private final NetHandlerPlayClient field_197016_a;
   private final Minecraft field_210248_b;
   private int field_197017_b = -1;
   private CompletableFuture<Suggestions> field_197018_c;

   public ClientSuggestionProvider(NetHandlerPlayClient p_i49558_1_, Minecraft p_i49558_2_) {
      this.field_197016_a = p_i49558_1_;
      this.field_210248_b = p_i49558_2_;
   }

   public Collection<String> func_197011_j() {
      List<String> list = Lists.newArrayList();

      for(NetworkPlayerInfo networkplayerinfo : this.field_197016_a.func_175106_d()) {
         list.add(networkplayerinfo.func_178845_a().getName());
      }

      return list;
   }

   public Collection<String> func_211270_p() {
      return (Collection<String>)(this.field_210248_b.field_71476_x != null && this.field_210248_b.field_71476_x.field_72313_a == RayTraceResult.Type.ENTITY ? Collections.singleton(this.field_210248_b.field_71476_x.field_72308_g.func_189512_bd()) : Collections.emptyList());
   }

   public Collection<String> func_197012_k() {
      return this.field_197016_a.func_195514_j().func_96441_U().func_96531_f();
   }

   public Collection<ResourceLocation> func_197010_l() {
      return this.field_210248_b.func_147118_V().func_195477_a();
   }

   public Collection<ResourceLocation> func_199612_m() {
      return this.field_197016_a.func_199526_e().func_199511_c();
   }

   public boolean func_197034_c(int p_197034_1_) {
      EntityPlayerSP entityplayersp = this.field_210248_b.field_71439_g;
      return entityplayersp != null ? entityplayersp.func_211513_k(p_197034_1_) : p_197034_1_ == 0;
   }

   public CompletableFuture<Suggestions> func_197009_a(CommandContext<ISuggestionProvider> p_197009_1_, SuggestionsBuilder p_197009_2_) {
      if (this.field_197018_c != null) {
         this.field_197018_c.cancel(false);
      }

      this.field_197018_c = new CompletableFuture<>();
      int i = ++this.field_197017_b;
      this.field_197016_a.func_147297_a(new CPacketTabComplete(i, p_197009_1_.getInput()));
      return this.field_197018_c;
   }

   private static String func_209001_a(double p_209001_0_) {
      return String.format(Locale.ROOT, "%.2f", p_209001_0_);
   }

   private static String func_209002_a(int p_209002_0_) {
      return Integer.toString(p_209002_0_);
   }

   public Collection<ISuggestionProvider.Coordinates> func_199613_a(boolean p_199613_1_) {
      if (this.field_210248_b.field_71476_x != null && this.field_210248_b.field_71476_x.field_72313_a == RayTraceResult.Type.BLOCK) {
         if (p_199613_1_) {
            Vec3d vec3d = this.field_210248_b.field_71476_x.field_72307_f;
            return Collections.singleton(new ISuggestionProvider.Coordinates(func_209001_a(vec3d.field_72450_a), func_209001_a(vec3d.field_72448_b), func_209001_a(vec3d.field_72449_c)));
         } else {
            BlockPos blockpos = this.field_210248_b.field_71476_x.func_178782_a();
            return Collections.singleton(new ISuggestionProvider.Coordinates(func_209002_a(blockpos.func_177958_n()), func_209002_a(blockpos.func_177956_o()), func_209002_a(blockpos.func_177952_p())));
         }
      } else {
         return Collections.singleton(ISuggestionProvider.Coordinates.field_209005_b);
      }
   }

   public void func_197015_a(int p_197015_1_, Suggestions p_197015_2_) {
      if (p_197015_1_ == this.field_197017_b) {
         this.field_197018_c.complete(p_197015_2_);
         this.field_197018_c = null;
         this.field_197017_b = -1;
      }

   }
}
