package net.minecraft.client.gui;

import net.minecraft.client.GameSettings;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class GuiOptionSlider extends GuiButton {
   private double field_146134_p = 1.0D;
   public boolean field_146135_o;
   private final GameSettings.Options field_146133_q;
   private final double field_146132_r;
   private final double field_146131_s;

   public GuiOptionSlider(int p_i45016_1_, int p_i45016_2_, int p_i45016_3_, GameSettings.Options p_i45016_4_) {
      this(p_i45016_1_, p_i45016_2_, p_i45016_3_, p_i45016_4_, 0.0D, 1.0D);
   }

   public GuiOptionSlider(int p_i47662_1_, int p_i47662_2_, int p_i47662_3_, GameSettings.Options p_i47662_4_, double p_i47662_5_, double p_i47662_7_) {
      this(p_i47662_1_, p_i47662_2_, p_i47662_3_, 150, 20, p_i47662_4_, p_i47662_5_, p_i47662_7_);
   }

   public GuiOptionSlider(int p_i47663_1_, int p_i47663_2_, int p_i47663_3_, int p_i47663_4_, int p_i47663_5_, GameSettings.Options p_i47663_6_, double p_i47663_7_, double p_i47663_9_) {
      super(p_i47663_1_, p_i47663_2_, p_i47663_3_, p_i47663_4_, p_i47663_5_, "");
      this.field_146133_q = p_i47663_6_;
      this.field_146132_r = p_i47663_7_;
      this.field_146131_s = p_i47663_9_;
      Minecraft minecraft = Minecraft.func_71410_x();
      this.field_146134_p = p_i47663_6_.func_198008_a(minecraft.field_71474_y.func_198015_a(p_i47663_6_));
      this.field_146126_j = minecraft.field_71474_y.func_74297_c(p_i47663_6_);
   }

   protected int func_146114_a(boolean p_146114_1_) {
      return 0;
   }

   protected void func_146119_b(Minecraft p_146119_1_, int p_146119_2_, int p_146119_3_) {
      if (this.field_146125_m) {
         if (this.field_146135_o) {
            this.field_146134_p = (double)((float)(p_146119_2_ - (this.field_146128_h + 4)) / (float)(this.field_146120_f - 8));
            this.field_146134_p = MathHelper.func_151237_a(this.field_146134_p, 0.0D, 1.0D);
         }

         if (this.field_146135_o || this.field_146133_q == GameSettings.Options.FULLSCREEN_RESOLUTION) {
            double d0 = this.field_146133_q.func_198004_b(this.field_146134_p);
            p_146119_1_.field_71474_y.func_198016_a(this.field_146133_q, d0);
            this.field_146134_p = this.field_146133_q.func_198008_a(d0);
            this.field_146126_j = p_146119_1_.field_71474_y.func_74297_c(this.field_146133_q);
         }

         p_146119_1_.func_110434_K().func_110577_a(field_146122_a);
         GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
         this.func_73729_b(this.field_146128_h + (int)(this.field_146134_p * (double)(this.field_146120_f - 8)), this.field_146129_i, 0, 66, 4, 20);
         this.func_73729_b(this.field_146128_h + (int)(this.field_146134_p * (double)(this.field_146120_f - 8)) + 4, this.field_146129_i, 196, 66, 4, 20);
      }
   }

   public final void func_194829_a(double p_194829_1_, double p_194829_3_) {
      this.field_146134_p = (p_194829_1_ - (double)(this.field_146128_h + 4)) / (double)(this.field_146120_f - 8);
      this.field_146134_p = MathHelper.func_151237_a(this.field_146134_p, 0.0D, 1.0D);
      Minecraft minecraft = Minecraft.func_71410_x();
      minecraft.field_71474_y.func_198016_a(this.field_146133_q, this.field_146133_q.func_198004_b(this.field_146134_p));
      this.field_146126_j = minecraft.field_71474_y.func_74297_c(this.field_146133_q);
      this.field_146135_o = true;
   }

   public void func_194831_b(double p_194831_1_, double p_194831_3_) {
      this.field_146135_o = false;
   }
}
