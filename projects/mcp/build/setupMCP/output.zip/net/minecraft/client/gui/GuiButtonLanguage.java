package net.minecraft.client.gui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public abstract class GuiButtonLanguage extends GuiButton {
   public GuiButtonLanguage(int p_i1041_1_, int p_i1041_2_, int p_i1041_3_) {
      super(p_i1041_1_, p_i1041_2_, p_i1041_3_, 20, 20, "");
   }

   public void func_194828_a(int p_194828_1_, int p_194828_2_, float p_194828_3_) {
      if (this.field_146125_m) {
         Minecraft.func_71410_x().func_110434_K().func_110577_a(GuiButton.field_146122_a);
         GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
         boolean flag = p_194828_1_ >= this.field_146128_h && p_194828_2_ >= this.field_146129_i && p_194828_1_ < this.field_146128_h + this.field_146120_f && p_194828_2_ < this.field_146129_i + this.field_146121_g;
         int i = 106;
         if (flag) {
            i += this.field_146121_g;
         }

         this.func_73729_b(this.field_146128_h, this.field_146129_i, 0, i, this.field_146120_f, this.field_146121_g);
      }
   }
}
