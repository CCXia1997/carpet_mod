package net.minecraft.client.gui;

import javax.annotation.Nullable;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.resources.I18n;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.util.text.event.ClickEvent;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class GuiGameOver extends GuiScreen {
   private int field_146347_a;
   private final ITextComponent field_184871_f;

   public GuiGameOver(@Nullable ITextComponent p_i46598_1_) {
      this.field_184871_f = p_i46598_1_;
   }

   protected void func_73866_w_() {
      this.field_146347_a = 0;
      String s;
      String s1;
      if (this.field_146297_k.field_71441_e.func_72912_H().func_76093_s()) {
         s = I18n.func_135052_a("deathScreen.spectate");
         s1 = I18n.func_135052_a("deathScreen." + (this.field_146297_k.func_71387_A() ? "deleteWorld" : "leaveServer"));
      } else {
         s = I18n.func_135052_a("deathScreen.respawn");
         s1 = I18n.func_135052_a("deathScreen.titleScreen");
      }

      this.func_189646_b(new GuiButton(0, this.field_146294_l / 2 - 100, this.field_146295_m / 4 + 72, s) {
         public void func_194829_a(double p_194829_1_, double p_194829_3_) {
            GuiGameOver.this.field_146297_k.field_71439_g.func_71004_bE();
            GuiGameOver.this.field_146297_k.func_147108_a((GuiScreen)null);
         }
      });
      GuiButton guibutton = this.func_189646_b(new GuiButton(1, this.field_146294_l / 2 - 100, this.field_146295_m / 4 + 96, s1) {
         public void func_194829_a(double p_194829_1_, double p_194829_3_) {
            if (GuiGameOver.this.field_146297_k.field_71441_e.func_72912_H().func_76093_s()) {
               GuiGameOver.this.field_146297_k.func_147108_a(new GuiMainMenu());
            } else {
               GuiYesNo guiyesno = new GuiYesNo(GuiGameOver.this, I18n.func_135052_a("deathScreen.quit.confirm"), "", I18n.func_135052_a("deathScreen.titleScreen"), I18n.func_135052_a("deathScreen.respawn"), 0);
               GuiGameOver.this.field_146297_k.func_147108_a(guiyesno);
               guiyesno.func_146350_a(20);
            }
         }
      });
      if (!this.field_146297_k.field_71441_e.func_72912_H().func_76093_s() && this.field_146297_k.func_110432_I() == null) {
         guibutton.field_146124_l = false;
      }

      for(GuiButton guibutton1 : this.field_146292_n) {
         guibutton1.field_146124_l = false;
      }

   }

   public boolean func_195120_Y_() {
      return false;
   }

   public void confirmResult(boolean p_confirmResult_1_, int p_confirmResult_2_) {
      if (p_confirmResult_2_ == 31102009) {
         super.confirmResult(p_confirmResult_1_, p_confirmResult_2_);
      } else if (p_confirmResult_1_) {
         if (this.field_146297_k.field_71441_e != null) {
            this.field_146297_k.field_71441_e.func_72882_A();
         }

         this.field_146297_k.func_205055_a((WorldClient)null, new GuiDirtMessageScreen(I18n.func_135052_a("menu.savingLevel")));
         this.field_146297_k.func_147108_a(new GuiMainMenu());
      } else {
         this.field_146297_k.field_71439_g.func_71004_bE();
         this.field_146297_k.func_147108_a((GuiScreen)null);
      }

   }

   public void func_73863_a(int p_73863_1_, int p_73863_2_, float p_73863_3_) {
      boolean flag = this.field_146297_k.field_71441_e.func_72912_H().func_76093_s();
      this.func_73733_a(0, 0, this.field_146294_l, this.field_146295_m, 1615855616, -1602211792);
      GlStateManager.func_179094_E();
      GlStateManager.func_179152_a(2.0F, 2.0F, 2.0F);
      this.func_73732_a(this.field_146289_q, I18n.func_135052_a(flag ? "deathScreen.title.hardcore" : "deathScreen.title"), this.field_146294_l / 2 / 2, 30, 16777215);
      GlStateManager.func_179121_F();
      if (this.field_184871_f != null) {
         this.func_73732_a(this.field_146289_q, this.field_184871_f.func_150254_d(), this.field_146294_l / 2, 85, 16777215);
      }

      this.func_73732_a(this.field_146289_q, I18n.func_135052_a("deathScreen.score") + ": " + TextFormatting.YELLOW + this.field_146297_k.field_71439_g.func_71037_bA(), this.field_146294_l / 2, 100, 16777215);
      if (this.field_184871_f != null && p_73863_2_ > 85 && p_73863_2_ < 85 + this.field_146289_q.field_78288_b) {
         ITextComponent itextcomponent = this.func_184870_b(p_73863_1_);
         if (itextcomponent != null && itextcomponent.func_150256_b().func_150210_i() != null) {
            this.func_175272_a(itextcomponent, p_73863_1_, p_73863_2_);
         }
      }

      super.func_73863_a(p_73863_1_, p_73863_2_, p_73863_3_);
   }

   @Nullable
   public ITextComponent func_184870_b(int p_184870_1_) {
      if (this.field_184871_f == null) {
         return null;
      } else {
         int i = this.field_146297_k.field_71466_p.func_78256_a(this.field_184871_f.func_150254_d());
         int j = this.field_146294_l / 2 - i / 2;
         int k = this.field_146294_l / 2 + i / 2;
         int l = j;
         if (p_184870_1_ >= j && p_184870_1_ <= k) {
            for(ITextComponent itextcomponent : this.field_184871_f) {
               l += this.field_146297_k.field_71466_p.func_78256_a(GuiUtilRenderComponents.func_178909_a(itextcomponent.func_150261_e(), false));
               if (l > p_184870_1_) {
                  return itextcomponent;
               }
            }

            return null;
         } else {
            return null;
         }
      }
   }

   public boolean mouseClicked(double p_mouseClicked_1_, double p_mouseClicked_3_, int p_mouseClicked_5_) {
      if (this.field_184871_f != null && p_mouseClicked_3_ > 85.0D && p_mouseClicked_3_ < (double)(85 + this.field_146289_q.field_78288_b)) {
         ITextComponent itextcomponent = this.func_184870_b((int)p_mouseClicked_1_);
         if (itextcomponent != null && itextcomponent.func_150256_b().func_150235_h() != null && itextcomponent.func_150256_b().func_150235_h().func_150669_a() == ClickEvent.Action.OPEN_URL) {
            this.func_175276_a(itextcomponent);
            return false;
         }
      }

      return super.mouseClicked(p_mouseClicked_1_, p_mouseClicked_3_, p_mouseClicked_5_);
   }

   public boolean func_73868_f() {
      return false;
   }

   public void func_73876_c() {
      super.func_73876_c();
      ++this.field_146347_a;
      if (this.field_146347_a == 20) {
         for(GuiButton guibutton : this.field_146292_n) {
            guibutton.field_146124_l = true;
         }
      }

   }
}
