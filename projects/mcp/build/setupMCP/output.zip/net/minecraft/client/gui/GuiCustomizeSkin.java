package net.minecraft.client.gui;

import net.minecraft.client.GameSettings;
import net.minecraft.client.resources.I18n;
import net.minecraft.entity.player.EnumPlayerModelParts;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class GuiCustomizeSkin extends GuiScreen {
   private final GuiScreen field_175361_a;
   private String field_175360_f;

   public GuiCustomizeSkin(GuiScreen p_i45516_1_) {
      this.field_175361_a = p_i45516_1_;
   }

   protected void func_73866_w_() {
      int i = 0;
      this.field_175360_f = I18n.func_135052_a("options.skinCustomisation.title");

      for(EnumPlayerModelParts enumplayermodelparts : EnumPlayerModelParts.values()) {
         this.func_189646_b(new GuiCustomizeSkin.ButtonPart(enumplayermodelparts.func_179328_b(), this.field_146294_l / 2 - 155 + i % 2 * 160, this.field_146295_m / 6 + 24 * (i >> 1), 150, 20, enumplayermodelparts));
         ++i;
      }

      this.func_189646_b(new GuiOptionButton(199, this.field_146294_l / 2 - 155 + i % 2 * 160, this.field_146295_m / 6 + 24 * (i >> 1), GameSettings.Options.MAIN_HAND, this.field_146297_k.field_71474_y.func_74297_c(GameSettings.Options.MAIN_HAND)) {
         public void func_194829_a(double p_194829_1_, double p_194829_3_) {
            GuiCustomizeSkin.this.field_146297_k.field_71474_y.func_74306_a(GameSettings.Options.MAIN_HAND, 1);
            this.field_146126_j = GuiCustomizeSkin.this.field_146297_k.field_71474_y.func_74297_c(GameSettings.Options.MAIN_HAND);
            GuiCustomizeSkin.this.field_146297_k.field_71474_y.func_82879_c();
         }
      });
      ++i;
      if (i % 2 == 1) {
         ++i;
      }

      this.func_189646_b(new GuiButton(200, this.field_146294_l / 2 - 100, this.field_146295_m / 6 + 24 * (i >> 1), I18n.func_135052_a("gui.done")) {
         public void func_194829_a(double p_194829_1_, double p_194829_3_) {
            GuiCustomizeSkin.this.field_146297_k.field_71474_y.func_74303_b();
            GuiCustomizeSkin.this.field_146297_k.func_147108_a(GuiCustomizeSkin.this.field_175361_a);
         }
      });
   }

   public void func_195122_V_() {
      this.field_146297_k.field_71474_y.func_74303_b();
      super.func_195122_V_();
   }

   public void func_73863_a(int p_73863_1_, int p_73863_2_, float p_73863_3_) {
      this.func_146276_q_();
      this.func_73732_a(this.field_146289_q, this.field_175360_f, this.field_146294_l / 2, 20, 16777215);
      super.func_73863_a(p_73863_1_, p_73863_2_, p_73863_3_);
   }

   private String func_175358_a(EnumPlayerModelParts p_175358_1_) {
      String s;
      if (this.field_146297_k.field_71474_y.func_178876_d().contains(p_175358_1_)) {
         s = I18n.func_135052_a("options.on");
      } else {
         s = I18n.func_135052_a("options.off");
      }

      return p_175358_1_.func_179326_d().func_150254_d() + ": " + s;
   }

   @OnlyIn(Dist.CLIENT)
   class ButtonPart extends GuiButton {
      private final EnumPlayerModelParts field_175234_p;

      private ButtonPart(int p_i45514_2_, int p_i45514_3_, int p_i45514_4_, int p_i45514_5_, int p_i45514_6_, EnumPlayerModelParts p_i45514_7_) {
         super(p_i45514_2_, p_i45514_3_, p_i45514_4_, p_i45514_5_, p_i45514_6_, GuiCustomizeSkin.this.func_175358_a(p_i45514_7_));
         this.field_175234_p = p_i45514_7_;
      }

      public void func_194829_a(double p_194829_1_, double p_194829_3_) {
         GuiCustomizeSkin.this.field_146297_k.field_71474_y.func_178877_a(this.field_175234_p);
         this.field_146126_j = GuiCustomizeSkin.this.func_175358_a(this.field_175234_p);
      }
   }
}
