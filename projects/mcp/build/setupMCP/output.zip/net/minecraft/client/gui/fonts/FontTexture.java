package net.minecraft.client.gui.fonts;

import java.io.Closeable;
import javax.annotation.Nullable;
import net.minecraft.client.renderer.texture.AbstractTexture;
import net.minecraft.client.renderer.texture.NativeImage;
import net.minecraft.client.renderer.texture.TextureUtil;
import net.minecraft.resources.IResourceManager;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class FontTexture extends AbstractTexture implements Closeable {
   private final ResourceLocation field_211133_f;
   private final boolean field_211512_g;
   private final FontTexture.Entry field_211135_h;

   public FontTexture(ResourceLocation p_i49770_1_, boolean p_i49770_2_) {
      this.field_211133_f = p_i49770_1_;
      this.field_211512_g = p_i49770_2_;
      this.field_211135_h = new FontTexture.Entry(0, 0, 256, 256);
      TextureUtil.func_211681_a(p_i49770_2_ ? NativeImage.PixelFormatGLCode.RGBA : NativeImage.PixelFormatGLCode.INTENSITY, this.func_110552_b(), 256, 256);
   }

   public void func_195413_a(IResourceManager p_195413_1_) {
   }

   public void close() {
      this.func_147631_c();
   }

   @Nullable
   public TexturedGlyph func_211131_a(IGlyphInfo p_211131_1_) {
      if (p_211131_1_.func_211579_f() != this.field_211512_g) {
         return null;
      } else {
         FontTexture.Entry fonttexture$entry = this.field_211135_h.func_211224_a(p_211131_1_);
         if (fonttexture$entry != null) {
            this.func_195412_h();
            p_211131_1_.func_211573_a(fonttexture$entry.field_211225_a, fonttexture$entry.field_211226_b);
            float f = 256.0F;
            float f1 = 256.0F;
            float f2 = 0.01F;
            return new TexturedGlyph(this.field_211133_f, ((float)fonttexture$entry.field_211225_a + 0.01F) / 256.0F, ((float)fonttexture$entry.field_211225_a - 0.01F + (float)p_211131_1_.func_211202_a()) / 256.0F, ((float)fonttexture$entry.field_211226_b + 0.01F) / 256.0F, ((float)fonttexture$entry.field_211226_b - 0.01F + (float)p_211131_1_.func_211203_b()) / 256.0F, p_211131_1_.func_211198_f(), p_211131_1_.func_211199_g(), p_211131_1_.func_211200_h(), p_211131_1_.func_211204_i());
         } else {
            return null;
         }
      }
   }

   public ResourceLocation func_211132_a() {
      return this.field_211133_f;
   }

   @OnlyIn(Dist.CLIENT)
   static class Entry {
      final int field_211225_a;
      final int field_211226_b;
      final int field_211227_c;
      final int field_211228_d;
      FontTexture.Entry field_211229_e;
      FontTexture.Entry field_211230_f;
      boolean field_211231_g;

      private Entry(int p_i49711_1_, int p_i49711_2_, int p_i49711_3_, int p_i49711_4_) {
         this.field_211225_a = p_i49711_1_;
         this.field_211226_b = p_i49711_2_;
         this.field_211227_c = p_i49711_3_;
         this.field_211228_d = p_i49711_4_;
      }

      @Nullable
      FontTexture.Entry func_211224_a(IGlyphInfo p_211224_1_) {
         if (this.field_211229_e != null && this.field_211230_f != null) {
            FontTexture.Entry fonttexture$entry = this.field_211229_e.func_211224_a(p_211224_1_);
            if (fonttexture$entry == null) {
               fonttexture$entry = this.field_211230_f.func_211224_a(p_211224_1_);
            }

            return fonttexture$entry;
         } else if (this.field_211231_g) {
            return null;
         } else {
            int i = p_211224_1_.func_211202_a();
            int j = p_211224_1_.func_211203_b();
            if (i <= this.field_211227_c && j <= this.field_211228_d) {
               if (i == this.field_211227_c && j == this.field_211228_d) {
                  this.field_211231_g = true;
                  return this;
               } else {
                  int k = this.field_211227_c - i;
                  int l = this.field_211228_d - j;
                  if (k > l) {
                     this.field_211229_e = new FontTexture.Entry(this.field_211225_a, this.field_211226_b, i, this.field_211228_d);
                     this.field_211230_f = new FontTexture.Entry(this.field_211225_a + i + 1, this.field_211226_b, this.field_211227_c - i - 1, this.field_211228_d);
                  } else {
                     this.field_211229_e = new FontTexture.Entry(this.field_211225_a, this.field_211226_b, this.field_211227_c, j);
                     this.field_211230_f = new FontTexture.Entry(this.field_211225_a, this.field_211226_b + j + 1, this.field_211227_c, this.field_211228_d - j - 1);
                  }

                  return this.field_211229_e.func_211224_a(p_211224_1_);
               }
            } else {
               return null;
            }
         }
      }
   }
}
