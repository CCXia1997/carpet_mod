package net.minecraft.client.gui;

import net.minecraft.client.GameSettings;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.resources.I18n;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.Util;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class GuiScreenDemo extends GuiScreen {
   private static final ResourceLocation field_146348_f = new ResourceLocation("textures/gui/demo_background.png");

   protected void func_73866_w_() {
      int i = -16;
      this.func_189646_b(new GuiButton(1, this.field_146294_l / 2 - 116, this.field_146295_m / 2 + 62 + -16, 114, 20, I18n.func_135052_a("demo.help.buy")) {
         public void func_194829_a(double p_194829_1_, double p_194829_3_) {
            this.field_146124_l = false;
            Util.func_110647_a().func_195640_a("http://www.minecraft.net/store?source=demo");
         }
      });
      this.func_189646_b(new GuiButton(2, this.field_146294_l / 2 + 2, this.field_146295_m / 2 + 62 + -16, 114, 20, I18n.func_135052_a("demo.help.later")) {
         public void func_194829_a(double p_194829_1_, double p_194829_3_) {
            GuiScreenDemo.this.field_146297_k.func_147108_a((GuiScreen)null);
            GuiScreenDemo.this.field_146297_k.field_71417_B.func_198034_i();
         }
      });
   }

   public void func_146276_q_() {
      super.func_146276_q_();
      GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
      this.field_146297_k.func_110434_K().func_110577_a(field_146348_f);
      int i = (this.field_146294_l - 248) / 2;
      int j = (this.field_146295_m - 166) / 2;
      this.func_73729_b(i, j, 0, 0, 248, 166);
   }

   public void func_73863_a(int p_73863_1_, int p_73863_2_, float p_73863_3_) {
      this.func_146276_q_();
      int i = (this.field_146294_l - 248) / 2 + 10;
      int j = (this.field_146295_m - 166) / 2 + 8;
      this.field_146289_q.func_211126_b(I18n.func_135052_a("demo.help.title"), (float)i, (float)j, 2039583);
      j = j + 12;
      GameSettings gamesettings = this.field_146297_k.field_71474_y;
      this.field_146289_q.func_211126_b(I18n.func_135052_a("demo.help.movementShort", gamesettings.field_74351_w.func_197978_k(), gamesettings.field_74370_x.func_197978_k(), gamesettings.field_74368_y.func_197978_k(), gamesettings.field_74366_z.func_197978_k()), (float)i, (float)j, 5197647);
      this.field_146289_q.func_211126_b(I18n.func_135052_a("demo.help.movementMouse"), (float)i, (float)(j + 12), 5197647);
      this.field_146289_q.func_211126_b(I18n.func_135052_a("demo.help.jump", gamesettings.field_74314_A.func_197978_k()), (float)i, (float)(j + 24), 5197647);
      this.field_146289_q.func_211126_b(I18n.func_135052_a("demo.help.inventory", gamesettings.field_151445_Q.func_197978_k()), (float)i, (float)(j + 36), 5197647);
      this.field_146289_q.func_78279_b(I18n.func_135052_a("demo.help.fullWrapped"), i, j + 68, 218, 2039583);
      super.func_73863_a(p_73863_1_, p_73863_2_, p_73863_3_);
   }
}
