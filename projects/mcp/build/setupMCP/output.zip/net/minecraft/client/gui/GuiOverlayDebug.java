package net.minecraft.client.gui;

import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import java.util.List;
import java.util.Locale;
import java.util.Map.Entry;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.ClientBrandRetriever;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.fluid.IFluidState;
import net.minecraft.network.NetworkManager;
import net.minecraft.server.integrated.IntegratedServer;
import net.minecraft.state.IProperty;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.FrameTimer;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.Util;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceFluidMode;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.registry.IRegistry;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.EnumLightType;
import net.minecraft.world.ForcedChunksSaveData;
import net.minecraft.world.World;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.dimension.DimensionType;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class GuiOverlayDebug extends Gui {
   private final Minecraft field_175242_a;
   private final FontRenderer field_175241_f;
   private RayTraceResult field_211537_g;
   private RayTraceResult field_211538_h;

   public GuiOverlayDebug(Minecraft p_i45543_1_) {
      this.field_175242_a = p_i45543_1_;
      this.field_175241_f = p_i45543_1_.field_71466_p;
   }

   public void func_194818_a() {
      this.field_175242_a.field_71424_I.func_76320_a("debug");
      GlStateManager.func_179094_E();
      Entity entity = this.field_175242_a.func_175606_aa();
      this.field_211537_g = entity.func_174822_a(20.0D, 0.0F, RayTraceFluidMode.NEVER);
      this.field_211538_h = entity.func_174822_a(20.0D, 0.0F, RayTraceFluidMode.ALWAYS);
      this.func_180798_a();
      this.func_194819_c();
      GlStateManager.func_179121_F();
      if (this.field_175242_a.field_71474_y.field_181657_aC) {
         this.func_181554_e();
      }

      this.field_175242_a.field_71424_I.func_76319_b();
   }

   protected void func_180798_a() {
      List<String> list = this.func_209011_c();
      list.add("");
      list.add("Debug: Pie [shift]: " + (this.field_175242_a.field_71474_y.field_74329_Q ? "visible" : "hidden") + " FPS [alt]: " + (this.field_175242_a.field_71474_y.field_181657_aC ? "visible" : "hidden"));
      list.add("For help: press F3 + Q");

      for(int i = 0; i < list.size(); ++i) {
         String s = list.get(i);
         if (!Strings.isNullOrEmpty(s)) {
            int j = this.field_175241_f.field_78288_b;
            int k = this.field_175241_f.func_78256_a(s);
            int l = 2;
            int i1 = 2 + j * i;
            func_73734_a(1, i1 - 1, 2 + k + 1, i1 + j - 1, -1873784752);
            this.field_175241_f.func_211126_b(s, 2.0F, (float)i1, 14737632);
         }
      }

   }

   protected void func_194819_c() {
      List<String> list = this.func_175238_c();

      for(int i = 0; i < list.size(); ++i) {
         String s = list.get(i);
         if (!Strings.isNullOrEmpty(s)) {
            int j = this.field_175241_f.field_78288_b;
            int k = this.field_175241_f.func_78256_a(s);
            int l = this.field_175242_a.field_195558_d.func_198107_o() - 2 - k;
            int i1 = 2 + j * i;
            func_73734_a(l - 1, i1 - 1, l + k + 1, i1 + j - 1, -1873784752);
            this.field_175241_f.func_211126_b(s, (float)l, (float)i1, 14737632);
         }
      }

   }

   protected List<String> func_209011_c() {
      IntegratedServer integratedserver = this.field_175242_a.func_71401_C();
      NetworkManager networkmanager = this.field_175242_a.func_147114_u().func_147298_b();
      float f = networkmanager.func_211390_n();
      float f1 = networkmanager.func_211393_m();
      String s;
      if (integratedserver != null) {
         s = String.format("Integrated server @ %.0f ms ticks, %.0f tx, %.0f rx", integratedserver.func_211149_aT(), f, f1);
      } else {
         s = String.format("\"%s\" server, %.0f tx, %.0f rx", this.field_175242_a.field_71439_g.func_142021_k(), f, f1);
      }

      BlockPos blockpos = new BlockPos(this.field_175242_a.func_175606_aa().field_70165_t, this.field_175242_a.func_175606_aa().func_174813_aQ().field_72338_b, this.field_175242_a.func_175606_aa().field_70161_v);
      if (this.field_175242_a.func_189648_am()) {
         return Lists.newArrayList("Minecraft 1.13.2 (" + this.field_175242_a.func_175600_c() + "/" + ClientBrandRetriever.getClientModName() + ")", this.field_175242_a.field_71426_K, s, this.field_175242_a.field_71438_f.func_72735_c(), this.field_175242_a.field_71438_f.func_72723_d(), "P: " + this.field_175242_a.field_71452_i.func_78869_b() + ". T: " + this.field_175242_a.field_71441_e.func_72981_t(), this.field_175242_a.field_71441_e.func_72827_u(), "", String.format("Chunk-relative: %d %d %d", blockpos.func_177958_n() & 15, blockpos.func_177956_o() & 15, blockpos.func_177952_p() & 15));
      } else {
         Entity entity = this.field_175242_a.func_175606_aa();
         EnumFacing enumfacing = entity.func_174811_aO();
         String s1 = "Invalid";
         switch(enumfacing) {
         case NORTH:
            s1 = "Towards negative Z";
            break;
         case SOUTH:
            s1 = "Towards positive Z";
            break;
         case WEST:
            s1 = "Towards negative X";
            break;
         case EAST:
            s1 = "Towards positive X";
         }

         DimensionType dimensiontype = this.field_175242_a.field_71441_e.field_73011_w.func_186058_p();
         World world;
         if (integratedserver != null && integratedserver.func_71218_a(dimensiontype) != null) {
            world = integratedserver.func_71218_a(dimensiontype);
         } else {
            world = this.field_175242_a.field_71441_e;
         }

         ForcedChunksSaveData forcedchunkssavedata = world.func_212411_a(dimensiontype, ForcedChunksSaveData::new, "chunks");
         List<String> list = Lists.newArrayList("Minecraft 1.13.2 (" + this.field_175242_a.func_175600_c() + "/" + ClientBrandRetriever.getClientModName() + ("release".equalsIgnoreCase(this.field_175242_a.func_184123_d()) ? "" : "/" + this.field_175242_a.func_184123_d()) + ")", this.field_175242_a.field_71426_K, s, this.field_175242_a.field_71438_f.func_72735_c(), this.field_175242_a.field_71438_f.func_72723_d(), "P: " + this.field_175242_a.field_71452_i.func_78869_b() + ". T: " + this.field_175242_a.field_71441_e.func_72981_t(), this.field_175242_a.field_71441_e.func_72827_u(), DimensionType.func_212678_a(dimensiontype).toString() + " FC: " + (forcedchunkssavedata == null ? "n/a" : Integer.toString(forcedchunkssavedata.func_212438_a().size())), "", String.format(Locale.ROOT, "XYZ: %.3f / %.5f / %.3f", this.field_175242_a.func_175606_aa().field_70165_t, this.field_175242_a.func_175606_aa().func_174813_aQ().field_72338_b, this.field_175242_a.func_175606_aa().field_70161_v), String.format("Block: %d %d %d", blockpos.func_177958_n(), blockpos.func_177956_o(), blockpos.func_177952_p()), String.format("Chunk: %d %d %d in %d %d %d", blockpos.func_177958_n() & 15, blockpos.func_177956_o() & 15, blockpos.func_177952_p() & 15, blockpos.func_177958_n() >> 4, blockpos.func_177956_o() >> 4, blockpos.func_177952_p() >> 4), String.format(Locale.ROOT, "Facing: %s (%s) (%.1f / %.1f)", enumfacing, s1, MathHelper.func_76142_g(entity.field_70177_z), MathHelper.func_76142_g(entity.field_70125_A)));
         if (this.field_175242_a.field_71441_e != null) {
            Chunk chunk = this.field_175242_a.field_71441_e.func_175726_f(blockpos);
            if (this.field_175242_a.field_71441_e.func_175667_e(blockpos) && blockpos.func_177956_o() >= 0 && blockpos.func_177956_o() < 256) {
               if (!chunk.func_76621_g()) {
                  list.add("Biome: " + IRegistry.field_212624_m.func_177774_c(chunk.func_201600_k(blockpos)));
                  list.add("Light: " + chunk.func_201586_a(blockpos, 0, chunk.func_177412_p().field_73011_w.func_191066_m()) + " (" + chunk.func_201587_a(EnumLightType.SKY, blockpos, chunk.func_177412_p().field_73011_w.func_191066_m()) + " sky, " + chunk.func_201587_a(EnumLightType.BLOCK, blockpos, chunk.func_177412_p().field_73011_w.func_191066_m()) + " block)");
                  DifficultyInstance difficultyinstance = this.field_175242_a.field_71441_e.func_175649_E(blockpos);
                  if (this.field_175242_a.func_71387_A() && integratedserver != null) {
                     EntityPlayerMP entityplayermp = integratedserver.func_184103_al().func_177451_a(this.field_175242_a.field_71439_g.func_110124_au());
                     if (entityplayermp != null) {
                        difficultyinstance = entityplayermp.field_70170_p.func_175649_E(new BlockPos(entityplayermp));
                     }
                  }

                  list.add(String.format(Locale.ROOT, "Local Difficulty: %.2f // %.2f (Day %d)", difficultyinstance.func_180168_b(), difficultyinstance.func_180170_c(), this.field_175242_a.field_71441_e.func_72820_D() / 24000L));
               } else {
                  list.add("Waiting for chunk...");
               }
            } else {
               list.add("Outside of world...");
            }
         }

         if (this.field_175242_a.field_71460_t != null && this.field_175242_a.field_71460_t.func_147702_a()) {
            list.add("Shader: " + this.field_175242_a.field_71460_t.func_147706_e().func_148022_b());
         }

         if (this.field_211537_g != null && this.field_211537_g.field_72313_a == RayTraceResult.Type.BLOCK) {
            BlockPos blockpos1 = this.field_211537_g.func_178782_a();
            list.add(String.format("Looking at block: %d %d %d", blockpos1.func_177958_n(), blockpos1.func_177956_o(), blockpos1.func_177952_p()));
         }

         if (this.field_211538_h != null && this.field_211538_h.field_72313_a == RayTraceResult.Type.BLOCK) {
            BlockPos blockpos2 = this.field_211538_h.func_178782_a();
            list.add(String.format("Looking at liquid: %d %d %d", blockpos2.func_177958_n(), blockpos2.func_177956_o(), blockpos2.func_177952_p()));
         }

         return list;
      }
   }

   protected List<String> func_175238_c() {
      long i = Runtime.getRuntime().maxMemory();
      long j = Runtime.getRuntime().totalMemory();
      long k = Runtime.getRuntime().freeMemory();
      long l = j - k;
      List<String> list = Lists.newArrayList(String.format("Java: %s %dbit", System.getProperty("java.version"), this.field_175242_a.func_147111_S() ? 64 : 32), String.format("Mem: % 2d%% %03d/%03dMB", l * 100L / i, func_175240_a(l), func_175240_a(i)), String.format("Allocated: % 2d%% %03dMB", j * 100L / i, func_175240_a(j)), "", String.format("CPU: %s", OpenGlHelper.func_183029_j()), "", String.format("Display: %dx%d (%s)", Minecraft.func_71410_x().field_195558_d.func_198109_k(), Minecraft.func_71410_x().field_195558_d.func_198091_l(), GlStateManager.func_187416_u(7936)), GlStateManager.func_187416_u(7937), GlStateManager.func_187416_u(7938));
      if (this.field_175242_a.func_189648_am()) {
         return list;
      } else {
         if (this.field_211537_g != null && this.field_211537_g.field_72313_a == RayTraceResult.Type.BLOCK) {
            BlockPos blockpos = this.field_211537_g.func_178782_a();
            IBlockState iblockstate = this.field_175242_a.field_71441_e.func_180495_p(blockpos);
            list.add("");
            list.add(TextFormatting.UNDERLINE + "Targeted Block");
            list.add(String.valueOf((Object)IRegistry.field_212618_g.func_177774_c(iblockstate.func_177230_c())));

            for(Entry<IProperty<?>, Comparable<?>> entry : iblockstate.func_206871_b().entrySet()) {
               list.add(this.func_211534_a(entry));
            }

            for(ResourceLocation resourcelocation : this.field_175242_a.func_147114_u().func_199724_l().func_199717_a().func_199913_a(iblockstate.func_177230_c())) {
               list.add("#" + resourcelocation);
            }
         }

         if (this.field_211538_h != null && this.field_211538_h.field_72313_a == RayTraceResult.Type.BLOCK) {
            BlockPos blockpos1 = this.field_211538_h.func_178782_a();
            IFluidState ifluidstate = this.field_175242_a.field_71441_e.func_204610_c(blockpos1);
            list.add("");
            list.add(TextFormatting.UNDERLINE + "Targeted Fluid");
            list.add(String.valueOf((Object)IRegistry.field_212619_h.func_177774_c(ifluidstate.func_206886_c())));

            for(Entry<IProperty<?>, Comparable<?>> entry1 : ifluidstate.func_206871_b().entrySet()) {
               list.add(this.func_211534_a(entry1));
            }

            for(ResourceLocation resourcelocation1 : this.field_175242_a.func_147114_u().func_199724_l().func_205704_c().func_199913_a(ifluidstate.func_206886_c())) {
               list.add("#" + resourcelocation1);
            }
         }

         Entity entity = this.field_175242_a.field_147125_j;
         if (entity != null) {
            list.add("");
            list.add(TextFormatting.UNDERLINE + "Targeted Entity");
            list.add(String.valueOf((Object)IRegistry.field_212629_r.func_177774_c(entity.func_200600_R())));
         }

         return list;
      }
   }

   private String func_211534_a(Entry<IProperty<?>, Comparable<?>> p_211534_1_) {
      IProperty<?> iproperty = p_211534_1_.getKey();
      Comparable<?> comparable = p_211534_1_.getValue();
      String s = Util.func_200269_a(iproperty, comparable);
      if (Boolean.TRUE.equals(comparable)) {
         s = TextFormatting.GREEN + s;
      } else if (Boolean.FALSE.equals(comparable)) {
         s = TextFormatting.RED + s;
      }

      return iproperty.func_177701_a() + ": " + s;
   }

   private void func_181554_e() {
      GlStateManager.func_179097_i();
      FrameTimer frametimer = this.field_175242_a.func_181539_aj();
      int i = frametimer.func_181749_a();
      int j = frametimer.func_181750_b();
      long[] along = frametimer.func_181746_c();
      int k = i;
      int l = 0;
      int i1 = this.field_175242_a.field_195558_d.func_198087_p();
      func_73734_a(0, i1 - 60, 240, i1, -1873784752);

      while(k != j) {
         int j1 = frametimer.func_181748_a(along[k], 30);
         int k1 = this.func_181552_c(MathHelper.func_76125_a(j1, 0, 60), 0, 30, 60);
         this.func_73728_b(l, i1, i1 - j1, k1);
         ++l;
         k = frametimer.func_181751_b(k + 1);
      }

      func_73734_a(1, i1 - 30 + 1, 14, i1 - 30 + 10, -1873784752);
      this.field_175241_f.func_211126_b("60", 2.0F, (float)(i1 - 30 + 2), 14737632);
      this.func_73730_a(0, 239, i1 - 30, -1);
      func_73734_a(1, i1 - 60 + 1, 14, i1 - 60 + 10, -1873784752);
      this.field_175241_f.func_211126_b("30", 2.0F, (float)(i1 - 60 + 2), 14737632);
      this.func_73730_a(0, 239, i1 - 60, -1);
      this.func_73730_a(0, 239, i1 - 1, -1);
      this.func_73728_b(0, i1 - 60, i1, -1);
      this.func_73728_b(239, i1 - 60, i1, -1);
      if (this.field_175242_a.field_71474_y.field_74350_i <= 120) {
         this.func_73730_a(0, 239, i1 - 60 + this.field_175242_a.field_71474_y.field_74350_i / 2, -16711681);
      }

      GlStateManager.func_179126_j();
   }

   private int func_181552_c(int p_181552_1_, int p_181552_2_, int p_181552_3_, int p_181552_4_) {
      return p_181552_1_ < p_181552_3_ ? this.func_181553_a(-16711936, -256, (float)p_181552_1_ / (float)p_181552_3_) : this.func_181553_a(-256, -65536, (float)(p_181552_1_ - p_181552_3_) / (float)(p_181552_4_ - p_181552_3_));
   }

   private int func_181553_a(int p_181553_1_, int p_181553_2_, float p_181553_3_) {
      int i = p_181553_1_ >> 24 & 255;
      int j = p_181553_1_ >> 16 & 255;
      int k = p_181553_1_ >> 8 & 255;
      int l = p_181553_1_ & 255;
      int i1 = p_181553_2_ >> 24 & 255;
      int j1 = p_181553_2_ >> 16 & 255;
      int k1 = p_181553_2_ >> 8 & 255;
      int l1 = p_181553_2_ & 255;
      int i2 = MathHelper.func_76125_a((int)((float)i + (float)(i1 - i) * p_181553_3_), 0, 255);
      int j2 = MathHelper.func_76125_a((int)((float)j + (float)(j1 - j) * p_181553_3_), 0, 255);
      int k2 = MathHelper.func_76125_a((int)((float)k + (float)(k1 - k) * p_181553_3_), 0, 255);
      int l2 = MathHelper.func_76125_a((int)((float)l + (float)(l1 - l) * p_181553_3_), 0, 255);
      return i2 << 24 | j2 << 16 | k2 << 8 | l2;
   }

   private static long func_175240_a(long p_175240_0_) {
      return p_175240_0_ / 1024L / 1024L;
   }
}
