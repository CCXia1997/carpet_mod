package net.minecraft.client.gui;

import com.google.common.base.Predicates;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.Predicate;
import javax.annotation.Nullable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.util.SharedConstants;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class GuiTextField extends Gui implements IGuiEventListener {
   private final int field_175208_g;
   private final FontRenderer field_146211_a;
   public int field_146209_f;
   public int field_146210_g;
   private final int field_146218_h;
   private final int field_146219_i;
   private String field_146216_j = "";
   private int field_146217_k = 32;
   private int field_146214_l;
   private boolean field_146215_m = true;
   private boolean field_146212_n = true;
   private boolean field_146213_o;
   private boolean field_146226_p = true;
   private int field_146225_q;
   private int field_146224_r;
   private int field_146223_s;
   private int field_146222_t = 14737632;
   private int field_146221_u = 7368816;
   private boolean field_146220_v = true;
   private String field_195614_x;
   private BiConsumer<Integer, String> field_175210_x;
   private Predicate<String> field_175209_y = Predicates.alwaysTrue();
   private BiFunction<String, Integer, String> field_195613_A = (p_195610_0_, p_195610_1_) -> {
      return p_195610_0_;
   };

   public GuiTextField(int p_i45542_1_, FontRenderer p_i45542_2_, int p_i45542_3_, int p_i45542_4_, int p_i45542_5_, int p_i45542_6_) {
      this(p_i45542_1_, p_i45542_2_, p_i45542_3_, p_i45542_4_, p_i45542_5_, p_i45542_6_, (GuiTextField)null);
   }

   public GuiTextField(int p_i49853_1_, FontRenderer p_i49853_2_, int p_i49853_3_, int p_i49853_4_, int p_i49853_5_, int p_i49853_6_, @Nullable GuiTextField p_i49853_7_) {
      this.field_175208_g = p_i49853_1_;
      this.field_146211_a = p_i49853_2_;
      this.field_146209_f = p_i49853_3_;
      this.field_146210_g = p_i49853_4_;
      this.field_146218_h = p_i49853_5_;
      this.field_146219_i = p_i49853_6_;
      if (p_i49853_7_ != null) {
         this.func_146180_a(p_i49853_7_.func_146179_b());
      }

   }

   public void func_195609_a(BiConsumer<Integer, String> p_195609_1_) {
      this.field_175210_x = p_195609_1_;
   }

   public void func_195607_a(BiFunction<String, Integer, String> p_195607_1_) {
      this.field_195613_A = p_195607_1_;
   }

   public void func_146178_a() {
      ++this.field_146214_l;
   }

   public void func_146180_a(String p_146180_1_) {
      if (this.field_175209_y.test(p_146180_1_)) {
         if (p_146180_1_.length() > this.field_146217_k) {
            this.field_146216_j = p_146180_1_.substring(0, this.field_146217_k);
         } else {
            this.field_146216_j = p_146180_1_;
         }

         this.func_190516_a(this.field_175208_g, p_146180_1_);
         this.func_146202_e();
      }
   }

   public String func_146179_b() {
      return this.field_146216_j;
   }

   public String func_146207_c() {
      int i = this.field_146224_r < this.field_146223_s ? this.field_146224_r : this.field_146223_s;
      int j = this.field_146224_r < this.field_146223_s ? this.field_146223_s : this.field_146224_r;
      return this.field_146216_j.substring(i, j);
   }

   public void func_200675_a(Predicate<String> p_200675_1_) {
      this.field_175209_y = p_200675_1_;
   }

   public void func_146191_b(String p_146191_1_) {
      String s = "";
      String s1 = SharedConstants.func_71565_a(p_146191_1_);
      int i = this.field_146224_r < this.field_146223_s ? this.field_146224_r : this.field_146223_s;
      int j = this.field_146224_r < this.field_146223_s ? this.field_146223_s : this.field_146224_r;
      int k = this.field_146217_k - this.field_146216_j.length() - (i - j);
      if (!this.field_146216_j.isEmpty()) {
         s = s + this.field_146216_j.substring(0, i);
      }

      int l;
      if (k < s1.length()) {
         s = s + s1.substring(0, k);
         l = k;
      } else {
         s = s + s1;
         l = s1.length();
      }

      if (!this.field_146216_j.isEmpty() && j < this.field_146216_j.length()) {
         s = s + this.field_146216_j.substring(j);
      }

      if (this.field_175209_y.test(s)) {
         this.field_146216_j = s;
         this.func_146182_d(i - this.field_146223_s + l);
         this.func_190516_a(this.field_175208_g, this.field_146216_j);
      }
   }

   public void func_190516_a(int p_190516_1_, String p_190516_2_) {
      if (this.field_175210_x != null) {
         this.field_175210_x.accept(p_190516_1_, p_190516_2_);
      }

   }

   public void func_146177_a(int p_146177_1_) {
      if (!this.field_146216_j.isEmpty()) {
         if (this.field_146223_s != this.field_146224_r) {
            this.func_146191_b("");
         } else {
            this.func_146175_b(this.func_146187_c(p_146177_1_) - this.field_146224_r);
         }
      }
   }

   public void func_146175_b(int p_146175_1_) {
      if (!this.field_146216_j.isEmpty()) {
         if (this.field_146223_s != this.field_146224_r) {
            this.func_146191_b("");
         } else {
            boolean flag = p_146175_1_ < 0;
            int i = flag ? this.field_146224_r + p_146175_1_ : this.field_146224_r;
            int j = flag ? this.field_146224_r : this.field_146224_r + p_146175_1_;
            String s = "";
            if (i >= 0) {
               s = this.field_146216_j.substring(0, i);
            }

            if (j < this.field_146216_j.length()) {
               s = s + this.field_146216_j.substring(j);
            }

            if (this.field_175209_y.test(s)) {
               this.field_146216_j = s;
               if (flag) {
                  this.func_146182_d(p_146175_1_);
               }

               this.func_190516_a(this.field_175208_g, this.field_146216_j);
            }
         }
      }
   }

   public int func_146187_c(int p_146187_1_) {
      return this.func_146183_a(p_146187_1_, this.func_146198_h());
   }

   public int func_146183_a(int p_146183_1_, int p_146183_2_) {
      return this.func_146197_a(p_146183_1_, p_146183_2_, true);
   }

   public int func_146197_a(int p_146197_1_, int p_146197_2_, boolean p_146197_3_) {
      int i = p_146197_2_;
      boolean flag = p_146197_1_ < 0;
      int j = Math.abs(p_146197_1_);

      for(int k = 0; k < j; ++k) {
         if (!flag) {
            int l = this.field_146216_j.length();
            i = this.field_146216_j.indexOf(32, i);
            if (i == -1) {
               i = l;
            } else {
               while(p_146197_3_ && i < l && this.field_146216_j.charAt(i) == ' ') {
                  ++i;
               }
            }
         } else {
            while(p_146197_3_ && i > 0 && this.field_146216_j.charAt(i - 1) == ' ') {
               --i;
            }

            while(i > 0 && this.field_146216_j.charAt(i - 1) != ' ') {
               --i;
            }
         }
      }

      return i;
   }

   public void func_146182_d(int p_146182_1_) {
      this.func_146190_e(this.field_146223_s + p_146182_1_);
   }

   public void func_146190_e(int p_146190_1_) {
      this.func_212422_f(p_146190_1_);
      this.func_146199_i(this.field_146224_r);
      this.func_190516_a(this.field_175208_g, this.field_146216_j);
   }

   public void func_212422_f(int p_212422_1_) {
      this.field_146224_r = MathHelper.func_76125_a(p_212422_1_, 0, this.field_146216_j.length());
   }

   public void func_146196_d() {
      this.func_146190_e(0);
   }

   public void func_146202_e() {
      this.func_146190_e(this.field_146216_j.length());
   }

   public boolean keyPressed(int p_keyPressed_1_, int p_keyPressed_2_, int p_keyPressed_3_) {
      if (this.func_146176_q() && this.func_146206_l()) {
         if (GuiScreen.func_175278_g(p_keyPressed_1_)) {
            this.func_146202_e();
            this.func_146199_i(0);
            return true;
         } else if (GuiScreen.func_175280_f(p_keyPressed_1_)) {
            Minecraft.func_71410_x().field_195559_v.func_197960_a(this.func_146207_c());
            return true;
         } else if (GuiScreen.func_175279_e(p_keyPressed_1_)) {
            if (this.field_146226_p) {
               this.func_146191_b(Minecraft.func_71410_x().field_195559_v.func_197965_a());
            }

            return true;
         } else if (GuiScreen.func_175277_d(p_keyPressed_1_)) {
            Minecraft.func_71410_x().field_195559_v.func_197960_a(this.func_146207_c());
            if (this.field_146226_p) {
               this.func_146191_b("");
            }

            return true;
         } else {
            switch(p_keyPressed_1_) {
            case 259:
               if (GuiScreen.func_146271_m()) {
                  if (this.field_146226_p) {
                     this.func_146177_a(-1);
                  }
               } else if (this.field_146226_p) {
                  this.func_146175_b(-1);
               }

               return true;
            case 260:
            case 264:
            case 265:
            case 266:
            case 267:
            default:
               return p_keyPressed_1_ != 256;
            case 261:
               if (GuiScreen.func_146271_m()) {
                  if (this.field_146226_p) {
                     this.func_146177_a(1);
                  }
               } else if (this.field_146226_p) {
                  this.func_146175_b(1);
               }

               return true;
            case 262:
               if (GuiScreen.func_146272_n()) {
                  if (GuiScreen.func_146271_m()) {
                     this.func_146199_i(this.func_146183_a(1, this.func_146186_n()));
                  } else {
                     this.func_146199_i(this.func_146186_n() + 1);
                  }
               } else if (GuiScreen.func_146271_m()) {
                  this.func_146190_e(this.func_146187_c(1));
               } else {
                  this.func_146182_d(1);
               }

               return true;
            case 263:
               if (GuiScreen.func_146272_n()) {
                  if (GuiScreen.func_146271_m()) {
                     this.func_146199_i(this.func_146183_a(-1, this.func_146186_n()));
                  } else {
                     this.func_146199_i(this.func_146186_n() - 1);
                  }
               } else if (GuiScreen.func_146271_m()) {
                  this.func_146190_e(this.func_146187_c(-1));
               } else {
                  this.func_146182_d(-1);
               }

               return true;
            case 268:
               if (GuiScreen.func_146272_n()) {
                  this.func_146199_i(0);
               } else {
                  this.func_146196_d();
               }

               return true;
            case 269:
               if (GuiScreen.func_146272_n()) {
                  this.func_146199_i(this.field_146216_j.length());
               } else {
                  this.func_146202_e();
               }

               return true;
            }
         }
      } else {
         return false;
      }
   }

   public boolean charTyped(char p_charTyped_1_, int p_charTyped_2_) {
      if (this.func_146176_q() && this.func_146206_l()) {
         if (SharedConstants.func_71566_a(p_charTyped_1_)) {
            if (this.field_146226_p) {
               this.func_146191_b(Character.toString(p_charTyped_1_));
            }

            return true;
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   public boolean mouseClicked(double p_mouseClicked_1_, double p_mouseClicked_3_, int p_mouseClicked_5_) {
      if (!this.func_146176_q()) {
         return false;
      } else {
         boolean flag = p_mouseClicked_1_ >= (double)this.field_146209_f && p_mouseClicked_1_ < (double)(this.field_146209_f + this.field_146218_h) && p_mouseClicked_3_ >= (double)this.field_146210_g && p_mouseClicked_3_ < (double)(this.field_146210_g + this.field_146219_i);
         if (this.field_146212_n) {
            this.func_146195_b(flag);
         }

         if (this.field_146213_o && flag && p_mouseClicked_5_ == 0) {
            int i = MathHelper.func_76128_c(p_mouseClicked_1_) - this.field_146209_f;
            if (this.field_146215_m) {
               i -= 4;
            }

            String s = this.field_146211_a.func_78269_a(this.field_146216_j.substring(this.field_146225_q), this.func_146200_o());
            this.func_146190_e(this.field_146211_a.func_78269_a(s, i).length() + this.field_146225_q);
            return true;
         } else {
            return false;
         }
      }
   }

   public void func_195608_a(int p_195608_1_, int p_195608_2_, float p_195608_3_) {
      if (this.func_146176_q()) {
         if (this.func_146181_i()) {
            func_73734_a(this.field_146209_f - 1, this.field_146210_g - 1, this.field_146209_f + this.field_146218_h + 1, this.field_146210_g + this.field_146219_i + 1, -6250336);
            func_73734_a(this.field_146209_f, this.field_146210_g, this.field_146209_f + this.field_146218_h, this.field_146210_g + this.field_146219_i, -16777216);
         }

         int i = this.field_146226_p ? this.field_146222_t : this.field_146221_u;
         int j = this.field_146224_r - this.field_146225_q;
         int k = this.field_146223_s - this.field_146225_q;
         String s = this.field_146211_a.func_78269_a(this.field_146216_j.substring(this.field_146225_q), this.func_146200_o());
         boolean flag = j >= 0 && j <= s.length();
         boolean flag1 = this.field_146213_o && this.field_146214_l / 6 % 2 == 0 && flag;
         int l = this.field_146215_m ? this.field_146209_f + 4 : this.field_146209_f;
         int i1 = this.field_146215_m ? this.field_146210_g + (this.field_146219_i - 8) / 2 : this.field_146210_g;
         int j1 = l;
         if (k > s.length()) {
            k = s.length();
         }

         if (!s.isEmpty()) {
            String s1 = flag ? s.substring(0, j) : s;
            j1 = this.field_146211_a.func_175063_a(this.field_195613_A.apply(s1, this.field_146225_q), (float)l, (float)i1, i);
         }

         boolean flag2 = this.field_146224_r < this.field_146216_j.length() || this.field_146216_j.length() >= this.func_146208_g();
         int k1 = j1;
         if (!flag) {
            k1 = j > 0 ? l + this.field_146218_h : l;
         } else if (flag2) {
            k1 = j1 - 1;
            --j1;
         }

         if (!s.isEmpty() && flag && j < s.length()) {
            j1 = this.field_146211_a.func_175063_a(this.field_195613_A.apply(s.substring(j), this.field_146224_r), (float)j1, (float)i1, i);
         }

         if (!flag2 && this.field_195614_x != null) {
            this.field_146211_a.func_175063_a(this.field_195614_x, (float)(k1 - 1), (float)i1, -8355712);
         }

         if (flag1) {
            if (flag2) {
               Gui.func_73734_a(k1, i1 - 1, k1 + 1, i1 + 1 + this.field_146211_a.field_78288_b, -3092272);
            } else {
               this.field_146211_a.func_175063_a("_", (float)k1, (float)i1, i);
            }
         }

         if (k != j) {
            int l1 = l + this.field_146211_a.func_78256_a(s.substring(0, k));
            this.func_146188_c(k1, i1 - 1, l1 - 1, i1 + 1 + this.field_146211_a.field_78288_b);
         }

      }
   }

   private void func_146188_c(int p_146188_1_, int p_146188_2_, int p_146188_3_, int p_146188_4_) {
      if (p_146188_1_ < p_146188_3_) {
         int i = p_146188_1_;
         p_146188_1_ = p_146188_3_;
         p_146188_3_ = i;
      }

      if (p_146188_2_ < p_146188_4_) {
         int j = p_146188_2_;
         p_146188_2_ = p_146188_4_;
         p_146188_4_ = j;
      }

      if (p_146188_3_ > this.field_146209_f + this.field_146218_h) {
         p_146188_3_ = this.field_146209_f + this.field_146218_h;
      }

      if (p_146188_1_ > this.field_146209_f + this.field_146218_h) {
         p_146188_1_ = this.field_146209_f + this.field_146218_h;
      }

      Tessellator tessellator = Tessellator.func_178181_a();
      BufferBuilder bufferbuilder = tessellator.func_178180_c();
      GlStateManager.func_179131_c(0.0F, 0.0F, 255.0F, 255.0F);
      GlStateManager.func_179090_x();
      GlStateManager.func_179115_u();
      GlStateManager.func_187422_a(GlStateManager.LogicOp.OR_REVERSE);
      bufferbuilder.func_181668_a(7, DefaultVertexFormats.field_181705_e);
      bufferbuilder.func_181662_b((double)p_146188_1_, (double)p_146188_4_, 0.0D).func_181675_d();
      bufferbuilder.func_181662_b((double)p_146188_3_, (double)p_146188_4_, 0.0D).func_181675_d();
      bufferbuilder.func_181662_b((double)p_146188_3_, (double)p_146188_2_, 0.0D).func_181675_d();
      bufferbuilder.func_181662_b((double)p_146188_1_, (double)p_146188_2_, 0.0D).func_181675_d();
      tessellator.func_78381_a();
      GlStateManager.func_179134_v();
      GlStateManager.func_179098_w();
   }

   public void func_146203_f(int p_146203_1_) {
      this.field_146217_k = p_146203_1_;
      if (this.field_146216_j.length() > p_146203_1_) {
         this.field_146216_j = this.field_146216_j.substring(0, p_146203_1_);
         this.func_190516_a(this.field_175208_g, this.field_146216_j);
      }

   }

   public int func_146208_g() {
      return this.field_146217_k;
   }

   public int func_146198_h() {
      return this.field_146224_r;
   }

   public boolean func_146181_i() {
      return this.field_146215_m;
   }

   public void func_146185_a(boolean p_146185_1_) {
      this.field_146215_m = p_146185_1_;
   }

   public void func_146193_g(int p_146193_1_) {
      this.field_146222_t = p_146193_1_;
   }

   public void func_146204_h(int p_146204_1_) {
      this.field_146221_u = p_146204_1_;
   }

   public void func_205700_b(boolean p_205700_1_) {
      this.func_146195_b(p_205700_1_);
   }

   public boolean func_207704_ae_() {
      return true;
   }

   public void func_146195_b(boolean p_146195_1_) {
      if (p_146195_1_ && !this.field_146213_o) {
         this.field_146214_l = 0;
      }

      this.field_146213_o = p_146195_1_;
   }

   public boolean func_146206_l() {
      return this.field_146213_o;
   }

   public void func_146184_c(boolean p_146184_1_) {
      this.field_146226_p = p_146184_1_;
   }

   public int func_146186_n() {
      return this.field_146223_s;
   }

   public int func_146200_o() {
      return this.func_146181_i() ? this.field_146218_h - 8 : this.field_146218_h;
   }

   public void func_146199_i(int p_146199_1_) {
      int i = this.field_146216_j.length();
      if (p_146199_1_ > i) {
         p_146199_1_ = i;
      }

      if (p_146199_1_ < 0) {
         p_146199_1_ = 0;
      }

      this.field_146223_s = p_146199_1_;
      if (this.field_146211_a != null) {
         if (this.field_146225_q > i) {
            this.field_146225_q = i;
         }

         int j = this.func_146200_o();
         String s = this.field_146211_a.func_78269_a(this.field_146216_j.substring(this.field_146225_q), j);
         int k = s.length() + this.field_146225_q;
         if (p_146199_1_ == this.field_146225_q) {
            this.field_146225_q -= this.field_146211_a.func_78262_a(this.field_146216_j, j, true).length();
         }

         if (p_146199_1_ > k) {
            this.field_146225_q += p_146199_1_ - k;
         } else if (p_146199_1_ <= this.field_146225_q) {
            this.field_146225_q -= this.field_146225_q - p_146199_1_;
         }

         this.field_146225_q = MathHelper.func_76125_a(this.field_146225_q, 0, i);
      }

   }

   public void func_146205_d(boolean p_146205_1_) {
      this.field_146212_n = p_146205_1_;
   }

   public boolean func_146176_q() {
      return this.field_146220_v;
   }

   public void func_146189_e(boolean p_146189_1_) {
      this.field_146220_v = p_146189_1_;
   }

   public void func_195612_c(@Nullable String p_195612_1_) {
      this.field_195614_x = p_195612_1_;
   }

   public int func_195611_j(int p_195611_1_) {
      return p_195611_1_ > this.field_146216_j.length() ? this.field_146209_f : this.field_146209_f + this.field_146211_a.func_78256_a(this.field_146216_j.substring(0, p_195611_1_));
   }
}
