package net.minecraft.client.gui.spectator;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public interface ISpectatorMenuRecipient {
   void func_175257_a(SpectatorMenu p_175257_1_);
}
