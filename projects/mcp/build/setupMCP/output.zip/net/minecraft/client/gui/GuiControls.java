package net.minecraft.client.gui;

import net.minecraft.client.GameSettings;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.client.util.InputMappings;
import net.minecraft.util.Util;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class GuiControls extends GuiScreen {
   private static final GameSettings.Options[] field_146492_g = new GameSettings.Options[]{GameSettings.Options.INVERT_MOUSE, GameSettings.Options.SENSITIVITY, GameSettings.Options.TOUCHSCREEN, GameSettings.Options.AUTO_JUMP};
   private final GuiScreen field_146496_h;
   protected String field_146495_a = "Controls";
   private final GameSettings field_146497_i;
   public KeyBinding field_146491_f;
   public long field_152177_g;
   private GuiKeyBindingList field_146494_r;
   private GuiButton field_146493_s;

   public GuiControls(GuiScreen p_i1027_1_, GameSettings p_i1027_2_) {
      this.field_146496_h = p_i1027_1_;
      this.field_146497_i = p_i1027_2_;
   }

   protected void func_73866_w_() {
      this.field_146494_r = new GuiKeyBindingList(this, this.field_146297_k);
      this.field_195124_j.add(this.field_146494_r);
      this.func_195073_a(this.field_146494_r);
      this.func_189646_b(new GuiButton(200, this.field_146294_l / 2 - 155 + 160, this.field_146295_m - 29, 150, 20, I18n.func_135052_a("gui.done")) {
         public void func_194829_a(double p_194829_1_, double p_194829_3_) {
            GuiControls.this.field_146297_k.func_147108_a(GuiControls.this.field_146496_h);
         }
      });
      this.field_146493_s = this.func_189646_b(new GuiButton(201, this.field_146294_l / 2 - 155, this.field_146295_m - 29, 150, 20, I18n.func_135052_a("controls.resetAll")) {
         public void func_194829_a(double p_194829_1_, double p_194829_3_) {
            for(KeyBinding keybinding : GuiControls.this.field_146297_k.field_71474_y.field_74324_K) {
               keybinding.func_197979_b(keybinding.func_197977_i());
            }

            KeyBinding.func_74508_b();
         }
      });
      this.field_146495_a = I18n.func_135052_a("controls.title");
      int i = 0;

      for(GameSettings.Options gamesettings$options : field_146492_g) {
         if (gamesettings$options.func_74380_a()) {
            this.func_189646_b(new GuiOptionSlider(gamesettings$options.func_74381_c(), this.field_146294_l / 2 - 155 + i % 2 * 160, 18 + 24 * (i >> 1), gamesettings$options));
         } else {
            this.func_189646_b(new GuiOptionButton(gamesettings$options.func_74381_c(), this.field_146294_l / 2 - 155 + i % 2 * 160, 18 + 24 * (i >> 1), gamesettings$options, this.field_146497_i.func_74297_c(gamesettings$options)) {
               public void func_194829_a(double p_194829_1_, double p_194829_3_) {
                  GuiControls.this.field_146497_i.func_74306_a(this.func_146136_c(), 1);
                  this.field_146126_j = GuiControls.this.field_146497_i.func_74297_c(GameSettings.Options.func_74379_a(this.field_146127_k));
               }
            });
         }

         ++i;
      }

   }

   public boolean mouseClicked(double p_mouseClicked_1_, double p_mouseClicked_3_, int p_mouseClicked_5_) {
      if (this.field_146491_f != null) {
         this.field_146497_i.func_198014_a(this.field_146491_f, InputMappings.Type.MOUSE.func_197944_a(p_mouseClicked_5_));
         this.field_146491_f = null;
         KeyBinding.func_74508_b();
         return true;
      } else if (p_mouseClicked_5_ == 0 && this.field_146494_r.mouseClicked(p_mouseClicked_1_, p_mouseClicked_3_, p_mouseClicked_5_)) {
         this.func_195072_d(true);
         this.func_195073_a(this.field_146494_r);
         return true;
      } else {
         return super.mouseClicked(p_mouseClicked_1_, p_mouseClicked_3_, p_mouseClicked_5_);
      }
   }

   public boolean mouseReleased(double p_mouseReleased_1_, double p_mouseReleased_3_, int p_mouseReleased_5_) {
      if (p_mouseReleased_5_ == 0 && this.field_146494_r.mouseReleased(p_mouseReleased_1_, p_mouseReleased_3_, p_mouseReleased_5_)) {
         this.func_195072_d(false);
         return true;
      } else {
         return super.mouseReleased(p_mouseReleased_1_, p_mouseReleased_3_, p_mouseReleased_5_);
      }
   }

   public boolean keyPressed(int p_keyPressed_1_, int p_keyPressed_2_, int p_keyPressed_3_) {
      if (this.field_146491_f != null) {
         if (p_keyPressed_1_ == 256) {
            this.field_146497_i.func_198014_a(this.field_146491_f, InputMappings.field_197958_a);
         } else {
            this.field_146497_i.func_198014_a(this.field_146491_f, InputMappings.func_197954_a(p_keyPressed_1_, p_keyPressed_2_));
         }

         this.field_146491_f = null;
         this.field_152177_g = Util.func_211177_b();
         KeyBinding.func_74508_b();
         return true;
      } else {
         return super.keyPressed(p_keyPressed_1_, p_keyPressed_2_, p_keyPressed_3_);
      }
   }

   public void func_73863_a(int p_73863_1_, int p_73863_2_, float p_73863_3_) {
      this.func_146276_q_();
      this.field_146494_r.func_148128_a(p_73863_1_, p_73863_2_, p_73863_3_);
      this.func_73732_a(this.field_146289_q, this.field_146495_a, this.field_146294_l / 2, 8, 16777215);
      boolean flag = false;

      for(KeyBinding keybinding : this.field_146497_i.field_74324_K) {
         if (!keybinding.func_197985_l()) {
            flag = true;
            break;
         }
      }

      this.field_146493_s.field_146124_l = flag;
      super.func_73863_a(p_73863_1_, p_73863_2_, p_73863_3_);
   }
}
