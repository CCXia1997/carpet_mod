package net.minecraft.client.gui;

import javax.annotation.Nullable;
import net.minecraft.client.GameSettings;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class GuiOptionsRowList extends GuiListExtended<GuiOptionsRowList.Row> {
   public GuiOptionsRowList(Minecraft p_i45015_1_, int p_i45015_2_, int p_i45015_3_, int p_i45015_4_, int p_i45015_5_, int p_i45015_6_, GameSettings.Options... p_i45015_7_) {
      super(p_i45015_1_, p_i45015_2_, p_i45015_3_, p_i45015_4_, p_i45015_5_, p_i45015_6_);
      this.field_148163_i = false;
      this.func_195085_a(new GuiOptionsRowList.Row(p_i45015_2_, GameSettings.Options.FULLSCREEN_RESOLUTION));

      for(int i = 0; i < p_i45015_7_.length; i += 2) {
         GameSettings.Options gamesettings$options = p_i45015_7_[i];
         GameSettings.Options gamesettings$options1 = i < p_i45015_7_.length - 1 ? p_i45015_7_[i + 1] : null;
         this.func_195085_a(new GuiOptionsRowList.Row(p_i45015_2_, gamesettings$options, gamesettings$options1));
      }

   }

   @Nullable
   private static GuiButton func_195092_b(final Minecraft p_195092_0_, int p_195092_1_, int p_195092_2_, int p_195092_3_, @Nullable final GameSettings.Options p_195092_4_) {
      if (p_195092_4_ == null) {
         return null;
      } else {
         int i = p_195092_4_.func_74381_c();
         return (GuiButton)(p_195092_4_.func_74380_a() ? new GuiOptionSlider(i, p_195092_1_, p_195092_2_, p_195092_3_, 20, p_195092_4_, 0.0D, 1.0D) : new GuiOptionButton(i, p_195092_1_, p_195092_2_, p_195092_3_, 20, p_195092_4_, p_195092_0_.field_71474_y.func_74297_c(p_195092_4_)) {
            public void func_194829_a(double p_194829_1_, double p_194829_3_) {
               p_195092_0_.field_71474_y.func_74306_a(p_195092_4_, 1);
               this.field_146126_j = p_195092_0_.field_71474_y.func_74297_c(GameSettings.Options.func_74379_a(this.field_146127_k));
            }
         });
      }
   }

   public int func_148139_c() {
      return 400;
   }

   protected int func_148137_d() {
      return super.func_148137_d() + 32;
   }

   @OnlyIn(Dist.CLIENT)
   public final class Row extends GuiListExtended.IGuiListEntry<GuiOptionsRowList.Row> {
      @Nullable
      private final GuiButton field_148323_b;
      @Nullable
      private final GuiButton field_148324_c;

      public Row(@Nullable GuiButton p_i48071_2_, @Nullable GuiButton p_i48071_3_) {
         this.field_148323_b = p_i48071_2_;
         this.field_148324_c = p_i48071_3_;
      }

      public Row(int p_i48072_2_, GameSettings.Options p_i48072_3_) {
         this(GuiOptionsRowList.func_195092_b(GuiOptionsRowList.this.field_148161_k, p_i48072_2_ / 2 - 155, 0, 310, p_i48072_3_), (GuiButton)null);
      }

      public Row(int p_i48073_2_, GameSettings.Options p_i48073_3_, @Nullable GameSettings.Options p_i48073_4_) {
         this(GuiOptionsRowList.func_195092_b(GuiOptionsRowList.this.field_148161_k, p_i48073_2_ / 2 - 155, 0, 150, p_i48073_3_), GuiOptionsRowList.func_195092_b(GuiOptionsRowList.this.field_148161_k, p_i48073_2_ / 2 - 155 + 160, 0, 150, p_i48073_4_));
      }

      public void func_194999_a(int p_194999_1_, int p_194999_2_, int p_194999_3_, int p_194999_4_, boolean p_194999_5_, float p_194999_6_) {
         if (this.field_148323_b != null) {
            this.field_148323_b.field_146129_i = this.func_195001_c();
            this.field_148323_b.func_194828_a(p_194999_3_, p_194999_4_, p_194999_6_);
         }

         if (this.field_148324_c != null) {
            this.field_148324_c.field_146129_i = this.func_195001_c();
            this.field_148324_c.func_194828_a(p_194999_3_, p_194999_4_, p_194999_6_);
         }

      }

      public boolean mouseClicked(double p_mouseClicked_1_, double p_mouseClicked_3_, int p_mouseClicked_5_) {
         if (this.field_148323_b.mouseClicked(p_mouseClicked_1_, p_mouseClicked_3_, p_mouseClicked_5_)) {
            return true;
         } else {
            return this.field_148324_c != null && this.field_148324_c.mouseClicked(p_mouseClicked_1_, p_mouseClicked_3_, p_mouseClicked_5_);
         }
      }

      public boolean mouseReleased(double p_mouseReleased_1_, double p_mouseReleased_3_, int p_mouseReleased_5_) {
         boolean flag = this.field_148323_b != null && this.field_148323_b.mouseReleased(p_mouseReleased_1_, p_mouseReleased_3_, p_mouseReleased_5_);
         boolean flag1 = this.field_148324_c != null && this.field_148324_c.mouseReleased(p_mouseReleased_1_, p_mouseReleased_3_, p_mouseReleased_5_);
         return flag || flag1;
      }

      public void func_195000_a(float p_195000_1_) {
      }
   }
}
