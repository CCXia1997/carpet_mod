package net.minecraft.client.gui;

import net.minecraft.client.resources.I18n;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class GuiMemoryErrorScreen extends GuiScreen {
   protected void func_73866_w_() {
      this.func_189646_b(new GuiOptionButton(0, this.field_146294_l / 2 - 155, this.field_146295_m / 4 + 120 + 12, I18n.func_135052_a("gui.toTitle")) {
         public void func_194829_a(double p_194829_1_, double p_194829_3_) {
            GuiMemoryErrorScreen.this.field_146297_k.func_147108_a(new GuiMainMenu());
         }
      });
      this.func_189646_b(new GuiOptionButton(1, this.field_146294_l / 2 - 155 + 160, this.field_146295_m / 4 + 120 + 12, I18n.func_135052_a("menu.quit")) {
         public void func_194829_a(double p_194829_1_, double p_194829_3_) {
            GuiMemoryErrorScreen.this.field_146297_k.func_71400_g();
         }
      });
   }

   public boolean func_195120_Y_() {
      return false;
   }

   public void func_73863_a(int p_73863_1_, int p_73863_2_, float p_73863_3_) {
      this.func_146276_q_();
      this.func_73732_a(this.field_146289_q, "Out of memory!", this.field_146294_l / 2, this.field_146295_m / 4 - 60 + 20, 16777215);
      this.func_73731_b(this.field_146289_q, "Minecraft has run out of memory.", this.field_146294_l / 2 - 140, this.field_146295_m / 4 - 60 + 60 + 0, 10526880);
      this.func_73731_b(this.field_146289_q, "This could be caused by a bug in the game or by the", this.field_146294_l / 2 - 140, this.field_146295_m / 4 - 60 + 60 + 18, 10526880);
      this.func_73731_b(this.field_146289_q, "Java Virtual Machine not being allocated enough", this.field_146294_l / 2 - 140, this.field_146295_m / 4 - 60 + 60 + 27, 10526880);
      this.func_73731_b(this.field_146289_q, "memory.", this.field_146294_l / 2 - 140, this.field_146295_m / 4 - 60 + 60 + 36, 10526880);
      this.func_73731_b(this.field_146289_q, "To prevent level corruption, the current game has quit.", this.field_146294_l / 2 - 140, this.field_146295_m / 4 - 60 + 60 + 54, 10526880);
      this.func_73731_b(this.field_146289_q, "We've tried to free up enough memory to let you go back to", this.field_146294_l / 2 - 140, this.field_146295_m / 4 - 60 + 60 + 63, 10526880);
      this.func_73731_b(this.field_146289_q, "the main menu and back to playing, but this may not have worked.", this.field_146294_l / 2 - 140, this.field_146295_m / 4 - 60 + 60 + 72, 10526880);
      this.func_73731_b(this.field_146289_q, "Please restart the game if you see this message again.", this.field_146294_l / 2 - 140, this.field_146295_m / 4 - 60 + 60 + 81, 10526880);
      super.func_73863_a(p_73863_1_, p_73863_2_, p_73863_3_);
   }
}
