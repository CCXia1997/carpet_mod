package net.minecraft.client.gui;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.concurrent.atomic.AtomicInteger;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ServerAddress;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.network.NetHandlerLoginClient;
import net.minecraft.client.resources.I18n;
import net.minecraft.network.EnumConnectionState;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.handshake.client.CPacketHandshake;
import net.minecraft.network.login.client.CPacketLoginStart;
import net.minecraft.util.DefaultUncaughtExceptionHandler;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@OnlyIn(Dist.CLIENT)
public class GuiConnecting extends GuiScreen {
   private static final AtomicInteger field_146372_a = new AtomicInteger(0);
   private static final Logger field_146370_f = LogManager.getLogger();
   private NetworkManager field_146371_g;
   private boolean field_146373_h;
   private final GuiScreen field_146374_i;
   private ITextComponent field_209515_s = new TextComponentTranslation("connect.connecting");

   public GuiConnecting(GuiScreen p_i1181_1_, Minecraft p_i1181_2_, ServerData p_i1181_3_) {
      this.field_146297_k = p_i1181_2_;
      this.field_146374_i = p_i1181_1_;
      ServerAddress serveraddress = ServerAddress.func_78860_a(p_i1181_3_.field_78845_b);
      p_i1181_2_.func_71403_a((WorldClient)null);
      p_i1181_2_.func_71351_a(p_i1181_3_);
      this.func_146367_a(serveraddress.func_78861_a(), serveraddress.func_78864_b());
   }

   public GuiConnecting(GuiScreen p_i1182_1_, Minecraft p_i1182_2_, String p_i1182_3_, int p_i1182_4_) {
      this.field_146297_k = p_i1182_2_;
      this.field_146374_i = p_i1182_1_;
      p_i1182_2_.func_71403_a((WorldClient)null);
      this.func_146367_a(p_i1182_3_, p_i1182_4_);
   }

   private void func_146367_a(final String p_146367_1_, final int p_146367_2_) {
      field_146370_f.info("Connecting to {}, {}", p_146367_1_, p_146367_2_);
      Thread thread = new Thread("Server Connector #" + field_146372_a.incrementAndGet()) {
         public void run() {
            InetAddress inetaddress = null;

            try {
               if (GuiConnecting.this.field_146373_h) {
                  return;
               }

               inetaddress = InetAddress.getByName(p_146367_1_);
               GuiConnecting.this.field_146371_g = NetworkManager.func_181124_a(inetaddress, p_146367_2_, GuiConnecting.this.field_146297_k.field_71474_y.func_181148_f());
               GuiConnecting.this.field_146371_g.func_150719_a(new NetHandlerLoginClient(GuiConnecting.this.field_146371_g, GuiConnecting.this.field_146297_k, GuiConnecting.this.field_146374_i, (p_209549_1_) -> {
                  GuiConnecting.this.func_209514_a(p_209549_1_);
               }));
               GuiConnecting.this.field_146371_g.func_179290_a(new CPacketHandshake(p_146367_1_, p_146367_2_, EnumConnectionState.LOGIN));
               GuiConnecting.this.field_146371_g.func_179290_a(new CPacketLoginStart(GuiConnecting.this.field_146297_k.func_110432_I().func_148256_e()));
            } catch (UnknownHostException unknownhostexception) {
               if (GuiConnecting.this.field_146373_h) {
                  return;
               }

               GuiConnecting.field_146370_f.error("Couldn't connect to server", (Throwable)unknownhostexception);
               GuiConnecting.this.field_146297_k.func_152344_a(() -> {
                  GuiConnecting.this.field_146297_k.func_147108_a(new GuiDisconnected(GuiConnecting.this.field_146374_i, "connect.failed", new TextComponentTranslation("disconnect.genericReason", "Unknown host")));
               });
            } catch (Exception exception) {
               if (GuiConnecting.this.field_146373_h) {
                  return;
               }

               GuiConnecting.field_146370_f.error("Couldn't connect to server", (Throwable)exception);
               String s = inetaddress == null ? exception.toString() : exception.toString().replaceAll(inetaddress + ":" + p_146367_2_, "");
               GuiConnecting.this.field_146297_k.func_152344_a(() -> {
                  GuiConnecting.this.field_146297_k.func_147108_a(new GuiDisconnected(GuiConnecting.this.field_146374_i, "connect.failed", new TextComponentTranslation("disconnect.genericReason", s)));
               });
            }

         }
      };
      thread.setUncaughtExceptionHandler(new DefaultUncaughtExceptionHandler(field_146370_f));
      thread.start();
   }

   private void func_209514_a(ITextComponent p_209514_1_) {
      this.field_209515_s = p_209514_1_;
   }

   public void func_73876_c() {
      if (this.field_146371_g != null) {
         if (this.field_146371_g.func_150724_d()) {
            this.field_146371_g.func_74428_b();
         } else {
            this.field_146371_g.func_179293_l();
         }
      }

   }

   public boolean func_195120_Y_() {
      return false;
   }

   protected void func_73866_w_() {
      this.func_189646_b(new GuiButton(0, this.field_146294_l / 2 - 100, this.field_146295_m / 4 + 120 + 12, I18n.func_135052_a("gui.cancel")) {
         public void func_194829_a(double p_194829_1_, double p_194829_3_) {
            GuiConnecting.this.field_146373_h = true;
            if (GuiConnecting.this.field_146371_g != null) {
               GuiConnecting.this.field_146371_g.func_150718_a(new TextComponentTranslation("connect.aborted"));
            }

            GuiConnecting.this.field_146297_k.func_147108_a(GuiConnecting.this.field_146374_i);
         }
      });
   }

   public void func_73863_a(int p_73863_1_, int p_73863_2_, float p_73863_3_) {
      this.func_146276_q_();
      this.func_73732_a(this.field_146289_q, this.field_209515_s.func_150254_d(), this.field_146294_l / 2, this.field_146295_m / 2 - 50, 16777215);
      super.func_73863_a(p_73863_1_, p_73863_2_, p_73863_3_);
   }
}
