package net.minecraft.client.gui;

import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Ordering;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.stream.Collectors;
import net.minecraft.client.GameSettings;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.chat.IChatListener;
import net.minecraft.client.gui.chat.NarratorChatListener;
import net.minecraft.client.gui.chat.NormalChatListener;
import net.minecraft.client.gui.chat.OverlayChatListener;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.ItemRenderer;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.client.resources.I18n;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.IAttributeInstance;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.MobEffects;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.scoreboard.Score;
import net.minecraft.scoreboard.ScoreObjective;
import net.minecraft.scoreboard.ScorePlayerTeam;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.EnumHandSide;
import net.minecraft.util.FoodStats;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.StringUtils;
import net.minecraft.util.Util;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.text.ChatType;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.world.GameType;
import net.minecraft.world.border.WorldBorder;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class GuiIngame extends Gui {
   private static final ResourceLocation field_110329_b = new ResourceLocation("textures/misc/vignette.png");
   private static final ResourceLocation field_110330_c = new ResourceLocation("textures/gui/widgets.png");
   private static final ResourceLocation field_110328_d = new ResourceLocation("textures/misc/pumpkinblur.png");
   private final Random field_73842_c = new Random();
   private final Minecraft field_73839_d;
   private final ItemRenderer field_73841_b;
   private final GuiNewChat field_73840_e;
   private int field_73837_f;
   private String field_73838_g = "";
   private int field_73845_h;
   private boolean field_73844_j;
   public float field_73843_a = 1.0F;
   private int field_92017_k;
   private ItemStack field_92016_l = ItemStack.field_190927_a;
   private final GuiOverlayDebug field_175198_t;
   private final GuiSubtitleOverlay field_184049_t;
   private final GuiSpectator field_175197_u;
   private final GuiPlayerTabOverlay field_175196_v;
   private final GuiBossOverlay field_184050_w;
   private int field_175195_w;
   private String field_175201_x = "";
   private String field_175200_y = "";
   private int field_175199_z;
   private int field_175192_A;
   private int field_175193_B;
   private int field_175194_C;
   private int field_175189_D;
   private long field_175190_E;
   private long field_175191_F;
   private int field_194811_H;
   private int field_194812_I;
   private final Map<ChatType, List<IChatListener>> field_191743_I = Maps.newHashMap();

   public GuiIngame(Minecraft p_i46325_1_) {
      this.field_73839_d = p_i46325_1_;
      this.field_73841_b = p_i46325_1_.func_175599_af();
      this.field_175198_t = new GuiOverlayDebug(p_i46325_1_);
      this.field_175197_u = new GuiSpectator(p_i46325_1_);
      this.field_73840_e = new GuiNewChat(p_i46325_1_);
      this.field_175196_v = new GuiPlayerTabOverlay(p_i46325_1_, this);
      this.field_184050_w = new GuiBossOverlay(p_i46325_1_);
      this.field_184049_t = new GuiSubtitleOverlay(p_i46325_1_);

      for(ChatType chattype : ChatType.values()) {
         this.field_191743_I.put(chattype, Lists.newArrayList());
      }

      IChatListener ichatlistener = NarratorChatListener.field_193643_a;
      this.field_191743_I.get(ChatType.CHAT).add(new NormalChatListener(p_i46325_1_));
      this.field_191743_I.get(ChatType.CHAT).add(ichatlistener);
      this.field_191743_I.get(ChatType.SYSTEM).add(new NormalChatListener(p_i46325_1_));
      this.field_191743_I.get(ChatType.SYSTEM).add(ichatlistener);
      this.field_191743_I.get(ChatType.GAME_INFO).add(new OverlayChatListener(p_i46325_1_));
      this.func_175177_a();
   }

   public void func_175177_a() {
      this.field_175199_z = 10;
      this.field_175192_A = 70;
      this.field_175193_B = 20;
   }

   public void func_175180_a(float p_175180_1_) {
      this.field_194811_H = this.field_73839_d.field_195558_d.func_198107_o();
      this.field_194812_I = this.field_73839_d.field_195558_d.func_198087_p();
      FontRenderer fontrenderer = this.func_175179_f();
      GlStateManager.func_179147_l();
      if (Minecraft.func_71375_t()) {
         this.func_212303_b(this.field_73839_d.func_175606_aa());
      } else {
         GlStateManager.func_179126_j();
         GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
      }

      ItemStack itemstack = this.field_73839_d.field_71439_g.field_71071_by.func_70440_f(3);
      if (this.field_73839_d.field_71474_y.field_74320_O == 0 && itemstack.func_77973_b() == Blocks.field_196625_cS.func_199767_j()) {
         this.func_194808_p();
      }

      if (!this.field_73839_d.field_71439_g.func_70644_a(MobEffects.field_76431_k)) {
         float f = this.field_73839_d.field_71439_g.field_71080_cy + (this.field_73839_d.field_71439_g.field_71086_bY - this.field_73839_d.field_71439_g.field_71080_cy) * p_175180_1_;
         if (f > 0.0F) {
            this.func_194805_e(f);
         }
      }

      if (this.field_73839_d.field_71442_b.func_178889_l() == GameType.SPECTATOR) {
         this.field_175197_u.func_195622_a(p_175180_1_);
      } else if (!this.field_73839_d.field_71474_y.field_74319_N) {
         this.func_194806_b(p_175180_1_);
      }

      if (!this.field_73839_d.field_71474_y.field_74319_N) {
         GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
         this.field_73839_d.func_110434_K().func_110577_a(field_110324_m);
         GlStateManager.func_179147_l();
         GlStateManager.func_179141_d();
         this.func_194798_c(p_175180_1_);
         GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
         this.field_73839_d.field_71424_I.func_76320_a("bossHealth");
         this.field_184050_w.func_184051_a();
         this.field_73839_d.field_71424_I.func_76319_b();
         GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
         this.field_73839_d.func_110434_K().func_110577_a(field_110324_m);
         if (this.field_73839_d.field_71442_b.func_78755_b()) {
            this.func_194807_n();
         }

         this.func_194799_o();
         GlStateManager.func_179084_k();
         int k = this.field_194811_H / 2 - 91;
         if (this.field_73839_d.field_71439_g.func_110317_t()) {
            this.func_194803_a(k);
         } else if (this.field_73839_d.field_71442_b.func_78763_f()) {
            this.func_194804_b(k);
         }

         if (this.field_73839_d.field_71474_y.field_92117_D && this.field_73839_d.field_71442_b.func_178889_l() != GameType.SPECTATOR) {
            this.func_194801_c();
         } else if (this.field_73839_d.field_71439_g.func_175149_v()) {
            this.field_175197_u.func_195623_a();
         }
      }

      if (this.field_73839_d.field_71439_g.func_71060_bI() > 0) {
         this.field_73839_d.field_71424_I.func_76320_a("sleep");
         GlStateManager.func_179097_i();
         GlStateManager.func_179118_c();
         float f2 = (float)this.field_73839_d.field_71439_g.func_71060_bI();
         float f1 = f2 / 100.0F;
         if (f1 > 1.0F) {
            f1 = 1.0F - (f2 - 100.0F) / 10.0F;
         }

         int i = (int)(220.0F * f1) << 24 | 1052704;
         func_73734_a(0, 0, this.field_194811_H, this.field_194812_I, i);
         GlStateManager.func_179141_d();
         GlStateManager.func_179126_j();
         this.field_73839_d.field_71424_I.func_76319_b();
         GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
      }

      if (this.field_73839_d.func_71355_q()) {
         this.func_194810_d();
      }

      this.func_194809_b();
      if (this.field_73839_d.field_71474_y.field_74330_P) {
         this.field_175198_t.func_194818_a();
      }

      if (!this.field_73839_d.field_71474_y.field_74319_N) {
         if (this.field_73845_h > 0) {
            this.field_73839_d.field_71424_I.func_76320_a("overlayMessage");
            float f3 = (float)this.field_73845_h - p_175180_1_;
            int l = (int)(f3 * 255.0F / 20.0F);
            if (l > 255) {
               l = 255;
            }

            if (l > 8) {
               GlStateManager.func_179094_E();
               GlStateManager.func_179109_b((float)(this.field_194811_H / 2), (float)(this.field_194812_I - 68), 0.0F);
               GlStateManager.func_179147_l();
               GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
               int j1 = 16777215;
               if (this.field_73844_j) {
                  j1 = MathHelper.func_181758_c(f3 / 50.0F, 0.7F, 0.6F) & 16777215;
               }

               fontrenderer.func_211126_b(this.field_73838_g, (float)(-fontrenderer.func_78256_a(this.field_73838_g) / 2), -4.0F, j1 + (l << 24 & -16777216));
               GlStateManager.func_179084_k();
               GlStateManager.func_179121_F();
            }

            this.field_73839_d.field_71424_I.func_76319_b();
         }

         if (this.field_175195_w > 0) {
            this.field_73839_d.field_71424_I.func_76320_a("titleAndSubtitle");
            float f4 = (float)this.field_175195_w - p_175180_1_;
            int i1 = 255;
            if (this.field_175195_w > this.field_175193_B + this.field_175192_A) {
               float f5 = (float)(this.field_175199_z + this.field_175192_A + this.field_175193_B) - f4;
               i1 = (int)(f5 * 255.0F / (float)this.field_175199_z);
            }

            if (this.field_175195_w <= this.field_175193_B) {
               i1 = (int)(f4 * 255.0F / (float)this.field_175193_B);
            }

            i1 = MathHelper.func_76125_a(i1, 0, 255);
            if (i1 > 8) {
               GlStateManager.func_179094_E();
               GlStateManager.func_179109_b((float)(this.field_194811_H / 2), (float)(this.field_194812_I / 2), 0.0F);
               GlStateManager.func_179147_l();
               GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
               GlStateManager.func_179094_E();
               GlStateManager.func_179152_a(4.0F, 4.0F, 4.0F);
               int k1 = i1 << 24 & -16777216;
               fontrenderer.func_175063_a(this.field_175201_x, (float)(-fontrenderer.func_78256_a(this.field_175201_x) / 2), -10.0F, 16777215 | k1);
               GlStateManager.func_179121_F();
               GlStateManager.func_179094_E();
               GlStateManager.func_179152_a(2.0F, 2.0F, 2.0F);
               fontrenderer.func_175063_a(this.field_175200_y, (float)(-fontrenderer.func_78256_a(this.field_175200_y) / 2), 5.0F, 16777215 | k1);
               GlStateManager.func_179121_F();
               GlStateManager.func_179084_k();
               GlStateManager.func_179121_F();
            }

            this.field_73839_d.field_71424_I.func_76319_b();
         }

         this.field_184049_t.func_195620_a();
         Scoreboard scoreboard = this.field_73839_d.field_71441_e.func_96441_U();
         ScoreObjective scoreobjective = null;
         ScorePlayerTeam scoreplayerteam = scoreboard.func_96509_i(this.field_73839_d.field_71439_g.func_195047_I_());
         if (scoreplayerteam != null) {
            int j = scoreplayerteam.func_178775_l().func_175746_b();
            if (j >= 0) {
               scoreobjective = scoreboard.func_96539_a(3 + j);
            }
         }

         ScoreObjective scoreobjective1 = scoreobjective != null ? scoreobjective : scoreboard.func_96539_a(1);
         if (scoreobjective1 != null) {
            this.func_194802_a(scoreobjective1);
         }

         GlStateManager.func_179147_l();
         GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
         GlStateManager.func_179118_c();
         GlStateManager.func_179094_E();
         GlStateManager.func_179109_b(0.0F, (float)(this.field_194812_I - 48), 0.0F);
         this.field_73839_d.field_71424_I.func_76320_a("chat");
         this.field_73840_e.func_146230_a(this.field_73837_f);
         this.field_73839_d.field_71424_I.func_76319_b();
         GlStateManager.func_179121_F();
         scoreobjective1 = scoreboard.func_96539_a(0);
         if (!this.field_73839_d.field_71474_y.field_74321_H.func_151470_d() || this.field_73839_d.func_71387_A() && this.field_73839_d.field_71439_g.field_71174_a.func_175106_d().size() <= 1 && scoreobjective1 == null) {
            this.field_175196_v.func_175246_a(false);
         } else {
            this.field_175196_v.func_175246_a(true);
            this.field_175196_v.func_175249_a(this.field_194811_H, scoreboard, scoreobjective1);
         }
      }

      GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
      GlStateManager.func_179140_f();
      GlStateManager.func_179141_d();
   }

   private void func_194798_c(float p_194798_1_) {
      GameSettings gamesettings = this.field_73839_d.field_71474_y;
      if (gamesettings.field_74320_O == 0) {
         if (this.field_73839_d.field_71442_b.func_178889_l() == GameType.SPECTATOR && this.field_73839_d.field_147125_j == null) {
            RayTraceResult raytraceresult = this.field_73839_d.field_71476_x;
            if (raytraceresult == null || raytraceresult.field_72313_a != RayTraceResult.Type.BLOCK) {
               return;
            }

            BlockPos blockpos = raytraceresult.func_178782_a();
            if (!this.field_73839_d.field_71441_e.func_180495_p(blockpos).func_177230_c().func_149716_u() || !(this.field_73839_d.field_71441_e.func_175625_s(blockpos) instanceof IInventory)) {
               return;
            }
         }

         if (gamesettings.field_74330_P && !gamesettings.field_74319_N && !this.field_73839_d.field_71439_g.func_175140_cp() && !gamesettings.field_178879_v) {
            GlStateManager.func_179094_E();
            GlStateManager.func_179109_b((float)(this.field_194811_H / 2), (float)(this.field_194812_I / 2), this.field_73735_i);
            Entity entity = this.field_73839_d.func_175606_aa();
            GlStateManager.func_179114_b(entity.field_70127_C + (entity.field_70125_A - entity.field_70127_C) * p_194798_1_, -1.0F, 0.0F, 0.0F);
            GlStateManager.func_179114_b(entity.field_70126_B + (entity.field_70177_z - entity.field_70126_B) * p_194798_1_, 0.0F, 1.0F, 0.0F);
            GlStateManager.func_179152_a(-1.0F, -1.0F, -1.0F);
            OpenGlHelper.func_188785_m(10);
            GlStateManager.func_179121_F();
         } else {
            GlStateManager.func_187428_a(GlStateManager.SourceFactor.ONE_MINUS_DST_COLOR, GlStateManager.DestFactor.ONE_MINUS_SRC_COLOR, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
            int l = 15;
            this.func_175174_a((float)this.field_194811_H / 2.0F - 7.5F, (float)this.field_194812_I / 2.0F - 7.5F, 0, 0, 15, 15);
            if (this.field_73839_d.field_71474_y.field_186716_M == 1) {
               float f = this.field_73839_d.field_71439_g.func_184825_o(0.0F);
               boolean flag = false;
               if (this.field_73839_d.field_147125_j != null && this.field_73839_d.field_147125_j instanceof EntityLivingBase && f >= 1.0F) {
                  flag = this.field_73839_d.field_71439_g.func_184818_cX() > 5.0F;
                  flag = flag & this.field_73839_d.field_147125_j.func_70089_S();
               }

               int i = this.field_194812_I / 2 - 7 + 16;
               int j = this.field_194811_H / 2 - 8;
               if (flag) {
                  this.func_73729_b(j, i, 68, 94, 16, 16);
               } else if (f < 1.0F) {
                  int k = (int)(f * 17.0F);
                  this.func_73729_b(j, i, 36, 94, 16, 4);
                  this.func_73729_b(j, i, 52, 94, k, 4);
               }
            }
         }

      }
   }

   protected void func_194809_b() {
      Collection<PotionEffect> collection = this.field_73839_d.field_71439_g.func_70651_bq();
      if (!collection.isEmpty()) {
         this.field_73839_d.func_110434_K().func_110577_a(GuiContainer.field_147001_a);
         GlStateManager.func_179147_l();
         int i = 0;
         int j = 0;

         for(PotionEffect potioneffect : Ordering.natural().reverse().sortedCopy(collection)) {
            Potion potion = potioneffect.func_188419_a();
            if (potion.func_76400_d() && potioneffect.func_205348_f()) {
               int k = this.field_194811_H;
               int l = 1;
               if (this.field_73839_d.func_71355_q()) {
                  l += 15;
               }

               int i1 = potion.func_76392_e();
               if (potion.func_188408_i()) {
                  ++i;
                  k = k - 25 * i;
               } else {
                  ++j;
                  k = k - 25 * j;
                  l += 26;
               }

               GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
               float f = 1.0F;
               if (potioneffect.func_82720_e()) {
                  this.func_73729_b(k, l, 165, 166, 24, 24);
               } else {
                  this.func_73729_b(k, l, 141, 166, 24, 24);
                  if (potioneffect.func_76459_b() <= 200) {
                     int j1 = 10 - potioneffect.func_76459_b() / 20;
                     f = MathHelper.func_76131_a((float)potioneffect.func_76459_b() / 10.0F / 5.0F * 0.5F, 0.0F, 0.5F) + MathHelper.func_76134_b((float)potioneffect.func_76459_b() * (float)Math.PI / 5.0F) * MathHelper.func_76131_a((float)j1 / 10.0F * 0.25F, 0.0F, 0.25F);
                  }
               }

               GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, f);
               int l1 = i1 % 12;
               int k1 = i1 / 12;
               this.func_73729_b(k + 3, l + 3, l1 * 18, 198 + k1 * 18, 18, 18);
            }
         }

      }
   }

   protected void func_194806_b(float p_194806_1_) {
      EntityPlayer entityplayer = this.func_212304_m();
      if (entityplayer != null) {
         GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
         this.field_73839_d.func_110434_K().func_110577_a(field_110330_c);
         ItemStack itemstack = entityplayer.func_184592_cb();
         EnumHandSide enumhandside = entityplayer.func_184591_cq().func_188468_a();
         int i = this.field_194811_H / 2;
         float f = this.field_73735_i;
         int j = 182;
         int k = 91;
         this.field_73735_i = -90.0F;
         this.func_73729_b(i - 91, this.field_194812_I - 22, 0, 0, 182, 22);
         this.func_73729_b(i - 91 - 1 + entityplayer.field_71071_by.field_70461_c * 20, this.field_194812_I - 22 - 1, 0, 22, 24, 22);
         if (!itemstack.func_190926_b()) {
            if (enumhandside == EnumHandSide.LEFT) {
               this.func_73729_b(i - 91 - 29, this.field_194812_I - 23, 24, 22, 29, 24);
            } else {
               this.func_73729_b(i + 91, this.field_194812_I - 23, 53, 22, 29, 24);
            }
         }

         this.field_73735_i = f;
         GlStateManager.func_179091_B();
         GlStateManager.func_179147_l();
         GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
         RenderHelper.func_74520_c();

         for(int l = 0; l < 9; ++l) {
            int i1 = i - 90 + l * 20 + 2;
            int j1 = this.field_194812_I - 16 - 3;
            this.func_184044_a(i1, j1, p_194806_1_, entityplayer, entityplayer.field_71071_by.field_70462_a.get(l));
         }

         if (!itemstack.func_190926_b()) {
            int l1 = this.field_194812_I - 16 - 3;
            if (enumhandside == EnumHandSide.LEFT) {
               this.func_184044_a(i - 91 - 26, l1, p_194806_1_, entityplayer, itemstack);
            } else {
               this.func_184044_a(i + 91 + 10, l1, p_194806_1_, entityplayer, itemstack);
            }
         }

         if (this.field_73839_d.field_71474_y.field_186716_M == 2) {
            float f1 = this.field_73839_d.field_71439_g.func_184825_o(0.0F);
            if (f1 < 1.0F) {
               int i2 = this.field_194812_I - 20;
               int j2 = i + 91 + 6;
               if (enumhandside == EnumHandSide.RIGHT) {
                  j2 = i - 91 - 22;
               }

               this.field_73839_d.func_110434_K().func_110577_a(Gui.field_110324_m);
               int k1 = (int)(f1 * 19.0F);
               GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
               this.func_73729_b(j2, i2, 0, 94, 18, 18);
               this.func_73729_b(j2, i2 + 18 - k1, 18, 112 - k1, 18, k1);
            }
         }

         RenderHelper.func_74518_a();
         GlStateManager.func_179101_C();
         GlStateManager.func_179084_k();
      }
   }

   public void func_194803_a(int p_194803_1_) {
      this.field_73839_d.field_71424_I.func_76320_a("jumpBar");
      this.field_73839_d.func_110434_K().func_110577_a(Gui.field_110324_m);
      float f = this.field_73839_d.field_71439_g.func_110319_bJ();
      int i = 182;
      int j = (int)(f * 183.0F);
      int k = this.field_194812_I - 32 + 3;
      this.func_73729_b(p_194803_1_, k, 0, 84, 182, 5);
      if (j > 0) {
         this.func_73729_b(p_194803_1_, k, 0, 89, j, 5);
      }

      this.field_73839_d.field_71424_I.func_76319_b();
   }

   public void func_194804_b(int p_194804_1_) {
      this.field_73839_d.field_71424_I.func_76320_a("expBar");
      this.field_73839_d.func_110434_K().func_110577_a(Gui.field_110324_m);
      int i = this.field_73839_d.field_71439_g.func_71050_bK();
      if (i > 0) {
         int j = 182;
         int k = (int)(this.field_73839_d.field_71439_g.field_71106_cc * 183.0F);
         int l = this.field_194812_I - 32 + 3;
         this.func_73729_b(p_194804_1_, l, 0, 64, 182, 5);
         if (k > 0) {
            this.func_73729_b(p_194804_1_, l, 0, 69, k, 5);
         }
      }

      this.field_73839_d.field_71424_I.func_76319_b();
      if (this.field_73839_d.field_71439_g.field_71068_ca > 0) {
         this.field_73839_d.field_71424_I.func_76320_a("expLevel");
         String s = "" + this.field_73839_d.field_71439_g.field_71068_ca;
         int i1 = (this.field_194811_H - this.func_175179_f().func_78256_a(s)) / 2;
         int j1 = this.field_194812_I - 31 - 4;
         this.func_175179_f().func_211126_b(s, (float)(i1 + 1), (float)j1, 0);
         this.func_175179_f().func_211126_b(s, (float)(i1 - 1), (float)j1, 0);
         this.func_175179_f().func_211126_b(s, (float)i1, (float)(j1 + 1), 0);
         this.func_175179_f().func_211126_b(s, (float)i1, (float)(j1 - 1), 0);
         this.func_175179_f().func_211126_b(s, (float)i1, (float)j1, 8453920);
         this.field_73839_d.field_71424_I.func_76319_b();
      }

   }

   public void func_194801_c() {
      this.field_73839_d.field_71424_I.func_76320_a("selectedItemName");
      if (this.field_92017_k > 0 && !this.field_92016_l.func_190926_b()) {
         ITextComponent itextcomponent = (new TextComponentString("")).func_150257_a(this.field_92016_l.func_200301_q()).func_211708_a(this.field_92016_l.func_77953_t().field_77937_e);
         if (this.field_92016_l.func_82837_s()) {
            itextcomponent.func_211708_a(TextFormatting.ITALIC);
         }

         String s = itextcomponent.func_150254_d();
         int i = (this.field_194811_H - this.func_175179_f().func_78256_a(s)) / 2;
         int j = this.field_194812_I - 59;
         if (!this.field_73839_d.field_71442_b.func_78755_b()) {
            j += 14;
         }

         int k = (int)((float)this.field_92017_k * 256.0F / 10.0F);
         if (k > 255) {
            k = 255;
         }

         if (k > 0) {
            GlStateManager.func_179094_E();
            GlStateManager.func_179147_l();
            GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
            this.func_175179_f().func_175063_a(s, (float)i, (float)j, 16777215 + (k << 24));
            GlStateManager.func_179084_k();
            GlStateManager.func_179121_F();
         }
      }

      this.field_73839_d.field_71424_I.func_76319_b();
   }

   public void func_194810_d() {
      this.field_73839_d.field_71424_I.func_76320_a("demo");
      String s;
      if (this.field_73839_d.field_71441_e.func_82737_E() >= 120500L) {
         s = I18n.func_135052_a("demo.demoExpired");
      } else {
         s = I18n.func_135052_a("demo.remainingTime", StringUtils.func_76337_a((int)(120500L - this.field_73839_d.field_71441_e.func_82737_E())));
      }

      int i = this.func_175179_f().func_78256_a(s);
      this.func_175179_f().func_175063_a(s, (float)(this.field_194811_H - i - 10), 5.0F, 16777215);
      this.field_73839_d.field_71424_I.func_76319_b();
   }

   private void func_194802_a(ScoreObjective p_194802_1_) {
      Scoreboard scoreboard = p_194802_1_.func_96682_a();
      Collection<Score> collection = scoreboard.func_96534_i(p_194802_1_);
      List<Score> list = collection.stream().filter((p_210100_0_) -> {
         return p_210100_0_.func_96653_e() != null && !p_210100_0_.func_96653_e().startsWith("#");
      }).collect(Collectors.toList());
      if (list.size() > 15) {
         collection = Lists.newArrayList(Iterables.skip(list, collection.size() - 15));
      } else {
         collection = list;
      }

      String s = p_194802_1_.func_96678_d().func_150254_d();
      int i = this.func_175179_f().func_78256_a(s);
      int j = i;

      for(Score score : collection) {
         ScorePlayerTeam scoreplayerteam = scoreboard.func_96509_i(score.func_96653_e());
         String s1 = ScorePlayerTeam.func_200541_a(scoreplayerteam, new TextComponentString(score.func_96653_e())).func_150254_d() + ": " + TextFormatting.RED + score.func_96652_c();
         j = Math.max(j, this.func_175179_f().func_78256_a(s1));
      }

      int j1 = collection.size() * this.func_175179_f().field_78288_b;
      int k1 = this.field_194812_I / 2 + j1 / 3;
      int l1 = 3;
      int i2 = this.field_194811_H - j - 3;
      int k = 0;

      for(Score score1 : collection) {
         ++k;
         ScorePlayerTeam scoreplayerteam1 = scoreboard.func_96509_i(score1.func_96653_e());
         String s2 = ScorePlayerTeam.func_200541_a(scoreplayerteam1, new TextComponentString(score1.func_96653_e())).func_150254_d();
         String s3 = TextFormatting.RED + "" + score1.func_96652_c();
         int l = k1 - k * this.func_175179_f().field_78288_b;
         int i1 = this.field_194811_H - 3 + 2;
         func_73734_a(i2 - 2, l, i1, l + this.func_175179_f().field_78288_b, 1342177280);
         this.func_175179_f().func_211126_b(s2, (float)i2, (float)l, 553648127);
         this.func_175179_f().func_211126_b(s3, (float)(i1 - this.func_175179_f().func_78256_a(s3)), (float)l, 553648127);
         if (k == collection.size()) {
            func_73734_a(i2 - 2, l - this.func_175179_f().field_78288_b - 1, i1, l - 1, 1610612736);
            func_73734_a(i2 - 2, l - 1, i1, l, 1342177280);
            this.func_175179_f().func_211126_b(s, (float)(i2 + j / 2 - i / 2), (float)(l - this.func_175179_f().field_78288_b), 553648127);
         }
      }

   }

   private EntityPlayer func_212304_m() {
      return !(this.field_73839_d.func_175606_aa() instanceof EntityPlayer) ? null : (EntityPlayer)this.field_73839_d.func_175606_aa();
   }

   private EntityLivingBase func_212305_n() {
      EntityPlayer entityplayer = this.func_212304_m();
      if (entityplayer != null) {
         Entity entity = entityplayer.func_184187_bx();
         if (entity == null) {
            return null;
         }

         if (entity instanceof EntityLivingBase) {
            return (EntityLivingBase)entity;
         }
      }

      return null;
   }

   private int func_212306_a(EntityLivingBase p_212306_1_) {
      if (p_212306_1_ != null && p_212306_1_.func_203003_aK()) {
         float f = p_212306_1_.func_110138_aP();
         int i = (int)(f + 0.5F) / 2;
         if (i > 30) {
            i = 30;
         }

         return i;
      } else {
         return 0;
      }
   }

   private int func_212302_c(int p_212302_1_) {
      return (int)Math.ceil((double)p_212302_1_ / 10.0D);
   }

   private void func_194807_n() {
      EntityPlayer entityplayer = this.func_212304_m();
      if (entityplayer != null) {
         int i = MathHelper.func_76123_f(entityplayer.func_110143_aJ());
         boolean flag = this.field_175191_F > (long)this.field_73837_f && (this.field_175191_F - (long)this.field_73837_f) / 3L % 2L == 1L;
         long j = Util.func_211177_b();
         if (i < this.field_175194_C && entityplayer.field_70172_ad > 0) {
            this.field_175190_E = j;
            this.field_175191_F = (long)(this.field_73837_f + 20);
         } else if (i > this.field_175194_C && entityplayer.field_70172_ad > 0) {
            this.field_175190_E = j;
            this.field_175191_F = (long)(this.field_73837_f + 10);
         }

         if (j - this.field_175190_E > 1000L) {
            this.field_175194_C = i;
            this.field_175189_D = i;
            this.field_175190_E = j;
         }

         this.field_175194_C = i;
         int k = this.field_175189_D;
         this.field_73842_c.setSeed((long)(this.field_73837_f * 312871));
         FoodStats foodstats = entityplayer.func_71024_bL();
         int l = foodstats.func_75116_a();
         IAttributeInstance iattributeinstance = entityplayer.func_110148_a(SharedMonsterAttributes.field_111267_a);
         int i1 = this.field_194811_H / 2 - 91;
         int j1 = this.field_194811_H / 2 + 91;
         int k1 = this.field_194812_I - 39;
         float f = (float)iattributeinstance.func_111126_e();
         int l1 = MathHelper.func_76123_f(entityplayer.func_110139_bj());
         int i2 = MathHelper.func_76123_f((f + (float)l1) / 2.0F / 10.0F);
         int j2 = Math.max(10 - (i2 - 2), 3);
         int k2 = k1 - (i2 - 1) * j2 - 10;
         int l2 = k1 - 10;
         int i3 = l1;
         int j3 = entityplayer.func_70658_aO();
         int k3 = -1;
         if (entityplayer.func_70644_a(MobEffects.field_76428_l)) {
            k3 = this.field_73837_f % MathHelper.func_76123_f(f + 5.0F);
         }

         this.field_73839_d.field_71424_I.func_76320_a("armor");

         for(int l3 = 0; l3 < 10; ++l3) {
            if (j3 > 0) {
               int i4 = i1 + l3 * 8;
               if (l3 * 2 + 1 < j3) {
                  this.func_73729_b(i4, k2, 34, 9, 9, 9);
               }

               if (l3 * 2 + 1 == j3) {
                  this.func_73729_b(i4, k2, 25, 9, 9, 9);
               }

               if (l3 * 2 + 1 > j3) {
                  this.func_73729_b(i4, k2, 16, 9, 9, 9);
               }
            }
         }

         this.field_73839_d.field_71424_I.func_76318_c("health");

         for(int l5 = MathHelper.func_76123_f((f + (float)l1) / 2.0F) - 1; l5 >= 0; --l5) {
            int i6 = 16;
            if (entityplayer.func_70644_a(MobEffects.field_76436_u)) {
               i6 += 36;
            } else if (entityplayer.func_70644_a(MobEffects.field_82731_v)) {
               i6 += 72;
            }

            int j4 = 0;
            if (flag) {
               j4 = 1;
            }

            int k4 = MathHelper.func_76123_f((float)(l5 + 1) / 10.0F) - 1;
            int l4 = i1 + l5 % 10 * 8;
            int i5 = k1 - k4 * j2;
            if (i <= 4) {
               i5 += this.field_73842_c.nextInt(2);
            }

            if (i3 <= 0 && l5 == k3) {
               i5 -= 2;
            }

            int j5 = 0;
            if (entityplayer.field_70170_p.func_72912_H().func_76093_s()) {
               j5 = 5;
            }

            this.func_73729_b(l4, i5, 16 + j4 * 9, 9 * j5, 9, 9);
            if (flag) {
               if (l5 * 2 + 1 < k) {
                  this.func_73729_b(l4, i5, i6 + 54, 9 * j5, 9, 9);
               }

               if (l5 * 2 + 1 == k) {
                  this.func_73729_b(l4, i5, i6 + 63, 9 * j5, 9, 9);
               }
            }

            if (i3 > 0) {
               if (i3 == l1 && l1 % 2 == 1) {
                  this.func_73729_b(l4, i5, i6 + 153, 9 * j5, 9, 9);
                  --i3;
               } else {
                  this.func_73729_b(l4, i5, i6 + 144, 9 * j5, 9, 9);
                  i3 -= 2;
               }
            } else {
               if (l5 * 2 + 1 < i) {
                  this.func_73729_b(l4, i5, i6 + 36, 9 * j5, 9, 9);
               }

               if (l5 * 2 + 1 == i) {
                  this.func_73729_b(l4, i5, i6 + 45, 9 * j5, 9, 9);
               }
            }
         }

         EntityLivingBase entitylivingbase = this.func_212305_n();
         int j6 = this.func_212306_a(entitylivingbase);
         if (j6 == 0) {
            this.field_73839_d.field_71424_I.func_76318_c("food");

            for(int k6 = 0; k6 < 10; ++k6) {
               int i7 = k1;
               int k7 = 16;
               int i8 = 0;
               if (entityplayer.func_70644_a(MobEffects.field_76438_s)) {
                  k7 += 36;
                  i8 = 13;
               }

               if (entityplayer.func_71024_bL().func_75115_e() <= 0.0F && this.field_73837_f % (l * 3 + 1) == 0) {
                  i7 = k1 + (this.field_73842_c.nextInt(3) - 1);
               }

               int k8 = j1 - k6 * 8 - 9;
               this.func_73729_b(k8, i7, 16 + i8 * 9, 27, 9, 9);
               if (k6 * 2 + 1 < l) {
                  this.func_73729_b(k8, i7, k7 + 36, 27, 9, 9);
               }

               if (k6 * 2 + 1 == l) {
                  this.func_73729_b(k8, i7, k7 + 45, 27, 9, 9);
               }
            }

            l2 -= 10;
         }

         this.field_73839_d.field_71424_I.func_76318_c("air");
         int l6 = entityplayer.func_70086_ai();
         int j7 = entityplayer.func_205010_bg();
         if (entityplayer.func_208600_a(FluidTags.field_206959_a) || l6 < j7) {
            int l7 = this.func_212302_c(j6) - 1;
            l2 = l2 - l7 * 10;
            int j8 = MathHelper.func_76143_f((double)(l6 - 2) * 10.0D / (double)j7);
            int l8 = MathHelper.func_76143_f((double)l6 * 10.0D / (double)j7) - j8;

            for(int k5 = 0; k5 < j8 + l8; ++k5) {
               if (k5 < j8) {
                  this.func_73729_b(j1 - k5 * 8 - 9, l2, 16, 18, 9, 9);
               } else {
                  this.func_73729_b(j1 - k5 * 8 - 9, l2, 25, 18, 9, 9);
               }
            }
         }

         this.field_73839_d.field_71424_I.func_76319_b();
      }
   }

   private void func_194799_o() {
      EntityLivingBase entitylivingbase = this.func_212305_n();
      if (entitylivingbase != null) {
         int i = this.func_212306_a(entitylivingbase);
         if (i != 0) {
            int j = (int)Math.ceil((double)entitylivingbase.func_110143_aJ());
            this.field_73839_d.field_71424_I.func_76318_c("mountHealth");
            int k = this.field_194812_I - 39;
            int l = this.field_194811_H / 2 + 91;
            int i1 = k;
            int j1 = 0;

            for(boolean flag = false; i > 0; j1 += 20) {
               int k1 = Math.min(i, 10);
               i -= k1;

               for(int l1 = 0; l1 < k1; ++l1) {
                  int i2 = 52;
                  int j2 = 0;
                  int k2 = l - l1 * 8 - 9;
                  this.func_73729_b(k2, i1, 52 + j2 * 9, 9, 9, 9);
                  if (l1 * 2 + 1 + j1 < j) {
                     this.func_73729_b(k2, i1, 88, 9, 9, 9);
                  }

                  if (l1 * 2 + 1 + j1 == j) {
                     this.func_73729_b(k2, i1, 97, 9, 9, 9);
                  }
               }

               i1 -= 10;
            }

         }
      }
   }

   private void func_194808_p() {
      GlStateManager.func_179097_i();
      GlStateManager.func_179132_a(false);
      GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
      GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
      GlStateManager.func_179118_c();
      this.field_73839_d.func_110434_K().func_110577_a(field_110328_d);
      Tessellator tessellator = Tessellator.func_178181_a();
      BufferBuilder bufferbuilder = tessellator.func_178180_c();
      bufferbuilder.func_181668_a(7, DefaultVertexFormats.field_181707_g);
      bufferbuilder.func_181662_b(0.0D, (double)this.field_194812_I, -90.0D).func_187315_a(0.0D, 1.0D).func_181675_d();
      bufferbuilder.func_181662_b((double)this.field_194811_H, (double)this.field_194812_I, -90.0D).func_187315_a(1.0D, 1.0D).func_181675_d();
      bufferbuilder.func_181662_b((double)this.field_194811_H, 0.0D, -90.0D).func_187315_a(1.0D, 0.0D).func_181675_d();
      bufferbuilder.func_181662_b(0.0D, 0.0D, -90.0D).func_187315_a(0.0D, 0.0D).func_181675_d();
      tessellator.func_78381_a();
      GlStateManager.func_179132_a(true);
      GlStateManager.func_179126_j();
      GlStateManager.func_179141_d();
      GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
   }

   private void func_212307_a(Entity p_212307_1_) {
      if (p_212307_1_ != null) {
         float f = MathHelper.func_76131_a(1.0F - p_212307_1_.func_70013_c(), 0.0F, 1.0F);
         this.field_73843_a = (float)((double)this.field_73843_a + (double)(f - this.field_73843_a) * 0.01D);
      }
   }

   private void func_212303_b(Entity p_212303_1_) {
      WorldBorder worldborder = this.field_73839_d.field_71441_e.func_175723_af();
      float f = (float)worldborder.func_177745_a(p_212303_1_);
      double d0 = Math.min(worldborder.func_177749_o() * (double)worldborder.func_177740_p() * 1000.0D, Math.abs(worldborder.func_177751_j() - worldborder.func_177741_h()));
      double d1 = Math.max((double)worldborder.func_177748_q(), d0);
      if ((double)f < d1) {
         f = 1.0F - (float)((double)f / d1);
      } else {
         f = 0.0F;
      }

      GlStateManager.func_179097_i();
      GlStateManager.func_179132_a(false);
      GlStateManager.func_187428_a(GlStateManager.SourceFactor.ZERO, GlStateManager.DestFactor.ONE_MINUS_SRC_COLOR, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
      if (f > 0.0F) {
         GlStateManager.func_179131_c(0.0F, f, f, 1.0F);
      } else {
         GlStateManager.func_179131_c(this.field_73843_a, this.field_73843_a, this.field_73843_a, 1.0F);
      }

      this.field_73839_d.func_110434_K().func_110577_a(field_110329_b);
      Tessellator tessellator = Tessellator.func_178181_a();
      BufferBuilder bufferbuilder = tessellator.func_178180_c();
      bufferbuilder.func_181668_a(7, DefaultVertexFormats.field_181707_g);
      bufferbuilder.func_181662_b(0.0D, (double)this.field_194812_I, -90.0D).func_187315_a(0.0D, 1.0D).func_181675_d();
      bufferbuilder.func_181662_b((double)this.field_194811_H, (double)this.field_194812_I, -90.0D).func_187315_a(1.0D, 1.0D).func_181675_d();
      bufferbuilder.func_181662_b((double)this.field_194811_H, 0.0D, -90.0D).func_187315_a(1.0D, 0.0D).func_181675_d();
      bufferbuilder.func_181662_b(0.0D, 0.0D, -90.0D).func_187315_a(0.0D, 0.0D).func_181675_d();
      tessellator.func_78381_a();
      GlStateManager.func_179132_a(true);
      GlStateManager.func_179126_j();
      GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
      GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
   }

   private void func_194805_e(float p_194805_1_) {
      if (p_194805_1_ < 1.0F) {
         p_194805_1_ = p_194805_1_ * p_194805_1_;
         p_194805_1_ = p_194805_1_ * p_194805_1_;
         p_194805_1_ = p_194805_1_ * 0.8F + 0.2F;
      }

      GlStateManager.func_179118_c();
      GlStateManager.func_179097_i();
      GlStateManager.func_179132_a(false);
      GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
      GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, p_194805_1_);
      this.field_73839_d.func_110434_K().func_110577_a(TextureMap.field_110575_b);
      TextureAtlasSprite textureatlassprite = this.field_73839_d.func_175602_ab().func_175023_a().func_178122_a(Blocks.field_150427_aO.func_176223_P());
      float f = textureatlassprite.func_94209_e();
      float f1 = textureatlassprite.func_94206_g();
      float f2 = textureatlassprite.func_94212_f();
      float f3 = textureatlassprite.func_94210_h();
      Tessellator tessellator = Tessellator.func_178181_a();
      BufferBuilder bufferbuilder = tessellator.func_178180_c();
      bufferbuilder.func_181668_a(7, DefaultVertexFormats.field_181707_g);
      bufferbuilder.func_181662_b(0.0D, (double)this.field_194812_I, -90.0D).func_187315_a((double)f, (double)f3).func_181675_d();
      bufferbuilder.func_181662_b((double)this.field_194811_H, (double)this.field_194812_I, -90.0D).func_187315_a((double)f2, (double)f3).func_181675_d();
      bufferbuilder.func_181662_b((double)this.field_194811_H, 0.0D, -90.0D).func_187315_a((double)f2, (double)f1).func_181675_d();
      bufferbuilder.func_181662_b(0.0D, 0.0D, -90.0D).func_187315_a((double)f, (double)f1).func_181675_d();
      tessellator.func_78381_a();
      GlStateManager.func_179132_a(true);
      GlStateManager.func_179126_j();
      GlStateManager.func_179141_d();
      GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
   }

   private void func_184044_a(int p_184044_1_, int p_184044_2_, float p_184044_3_, EntityPlayer p_184044_4_, ItemStack p_184044_5_) {
      if (!p_184044_5_.func_190926_b()) {
         float f = (float)p_184044_5_.func_190921_D() - p_184044_3_;
         if (f > 0.0F) {
            GlStateManager.func_179094_E();
            float f1 = 1.0F + f / 5.0F;
            GlStateManager.func_179109_b((float)(p_184044_1_ + 8), (float)(p_184044_2_ + 12), 0.0F);
            GlStateManager.func_179152_a(1.0F / f1, (f1 + 1.0F) / 2.0F, 1.0F);
            GlStateManager.func_179109_b((float)(-(p_184044_1_ + 8)), (float)(-(p_184044_2_ + 12)), 0.0F);
         }

         this.field_73841_b.func_184391_a(p_184044_4_, p_184044_5_, p_184044_1_, p_184044_2_);
         if (f > 0.0F) {
            GlStateManager.func_179121_F();
         }

         this.field_73841_b.func_175030_a(this.field_73839_d.field_71466_p, p_184044_5_, p_184044_1_, p_184044_2_);
      }
   }

   public void func_73831_a() {
      if (this.field_73845_h > 0) {
         --this.field_73845_h;
      }

      if (this.field_175195_w > 0) {
         --this.field_175195_w;
         if (this.field_175195_w <= 0) {
            this.field_175201_x = "";
            this.field_175200_y = "";
         }
      }

      ++this.field_73837_f;
      Entity entity = this.field_73839_d.func_175606_aa();
      if (entity != null) {
         this.func_212307_a(entity);
      }

      if (this.field_73839_d.field_71439_g != null) {
         ItemStack itemstack = this.field_73839_d.field_71439_g.field_71071_by.func_70448_g();
         if (itemstack.func_190926_b()) {
            this.field_92017_k = 0;
         } else if (!this.field_92016_l.func_190926_b() && itemstack.func_77973_b() == this.field_92016_l.func_77973_b() && itemstack.func_200301_q().equals(this.field_92016_l.func_200301_q())) {
            if (this.field_92017_k > 0) {
               --this.field_92017_k;
            }
         } else {
            this.field_92017_k = 40;
         }

         this.field_92016_l = itemstack;
      }

   }

   public void func_73833_a(String p_73833_1_) {
      this.func_110326_a(I18n.func_135052_a("record.nowPlaying", p_73833_1_), true);
   }

   public void func_110326_a(String p_110326_1_, boolean p_110326_2_) {
      this.field_73838_g = p_110326_1_;
      this.field_73845_h = 60;
      this.field_73844_j = p_110326_2_;
   }

   public void func_175178_a(String p_175178_1_, String p_175178_2_, int p_175178_3_, int p_175178_4_, int p_175178_5_) {
      if (p_175178_1_ == null && p_175178_2_ == null && p_175178_3_ < 0 && p_175178_4_ < 0 && p_175178_5_ < 0) {
         this.field_175201_x = "";
         this.field_175200_y = "";
         this.field_175195_w = 0;
      } else if (p_175178_1_ != null) {
         this.field_175201_x = p_175178_1_;
         this.field_175195_w = this.field_175199_z + this.field_175192_A + this.field_175193_B;
      } else if (p_175178_2_ != null) {
         this.field_175200_y = p_175178_2_;
      } else {
         if (p_175178_3_ >= 0) {
            this.field_175199_z = p_175178_3_;
         }

         if (p_175178_4_ >= 0) {
            this.field_175192_A = p_175178_4_;
         }

         if (p_175178_5_ >= 0) {
            this.field_175193_B = p_175178_5_;
         }

         if (this.field_175195_w > 0) {
            this.field_175195_w = this.field_175199_z + this.field_175192_A + this.field_175193_B;
         }

      }
   }

   public void func_175188_a(ITextComponent p_175188_1_, boolean p_175188_2_) {
      this.func_110326_a(p_175188_1_.getString(), p_175188_2_);
   }

   public void func_191742_a(ChatType p_191742_1_, ITextComponent p_191742_2_) {
      for(IChatListener ichatlistener : this.field_191743_I.get(p_191742_1_)) {
         ichatlistener.func_192576_a(p_191742_1_, p_191742_2_);
      }

   }

   public GuiNewChat func_146158_b() {
      return this.field_73840_e;
   }

   public int func_73834_c() {
      return this.field_73837_f;
   }

   public FontRenderer func_175179_f() {
      return this.field_73839_d.field_71466_p;
   }

   public GuiSpectator func_175187_g() {
      return this.field_175197_u;
   }

   public GuiPlayerTabOverlay func_175181_h() {
      return this.field_175196_v;
   }

   public void func_181029_i() {
      this.field_175196_v.func_181030_a();
      this.field_184050_w.func_184057_b();
      this.field_73839_d.func_193033_an().func_191788_b();
   }

   public GuiBossOverlay func_184046_j() {
      return this.field_184050_w;
   }
}
