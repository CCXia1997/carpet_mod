package net.minecraft.client.audio;

import javax.annotation.Nullable;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundCategory;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public interface ISound {
   ResourceLocation func_147650_b();

   @Nullable
   SoundEventAccessor func_184366_a(SoundHandler p_184366_1_);

   Sound func_184364_b();

   SoundCategory func_184365_d();

   boolean func_147657_c();

   boolean func_204200_l();

   int func_147652_d();

   float func_147653_e();

   float func_147655_f();

   float func_147649_g();

   float func_147654_h();

   float func_147651_i();

   ISound.AttenuationType func_147656_j();

   default boolean func_211503_n() {
      return false;
   }

   @OnlyIn(Dist.CLIENT)
   public static enum AttenuationType {
      NONE(0),
      LINEAR(2);

      private final int field_148589_c;

      private AttenuationType(int p_i45110_3_) {
         this.field_148589_c = p_i45110_3_;
      }

      public int func_148586_a() {
         return this.field_148589_c;
      }
   }
}
