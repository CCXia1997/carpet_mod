package net.minecraft.client.gui.recipebook;

import java.util.Iterator;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButtonToggle;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.ItemRenderer;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.util.RecipeBookCategories;
import net.minecraft.client.util.RecipeBookClient;
import net.minecraft.inventory.ContainerRecipeBook;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.IRecipe;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class GuiButtonRecipeTab extends GuiButtonToggle {
   private final RecipeBookCategories field_193921_u;
   private float field_193922_v;

   public GuiButtonRecipeTab(int p_i48773_1_, RecipeBookCategories p_i48773_2_) {
      super(p_i48773_1_, 0, 0, 35, 27, false);
      this.field_193921_u = p_i48773_2_;
      this.func_191751_a(153, 2, 35, 0, GuiRecipeBook.field_191894_a);
   }

   public void func_193918_a(Minecraft p_193918_1_) {
      RecipeBookClient recipebookclient = p_193918_1_.field_71439_g.func_199507_B();
      List<RecipeList> list = recipebookclient.func_202891_a(this.field_193921_u);
      if (p_193918_1_.field_71439_g.field_71070_bA instanceof ContainerRecipeBook) {
         label25:
         for(RecipeList recipelist : list) {
            Iterator iterator = recipelist.func_194208_a(recipebookclient.func_203432_a((ContainerRecipeBook)p_193918_1_.field_71439_g.field_71070_bA)).iterator();

            while(true) {
               if (!iterator.hasNext()) {
                  continue label25;
               }

               IRecipe irecipe = (IRecipe)iterator.next();
               if (recipebookclient.func_194076_e(irecipe)) {
                  break;
               }
            }

            this.field_193922_v = 15.0F;
            return;
         }

      }
   }

   public void func_194828_a(int p_194828_1_, int p_194828_2_, float p_194828_3_) {
      if (this.field_146125_m) {
         if (this.field_193922_v > 0.0F) {
            float f = 1.0F + 0.1F * (float)Math.sin((double)(this.field_193922_v / 15.0F * (float)Math.PI));
            GlStateManager.func_179094_E();
            GlStateManager.func_179109_b((float)(this.field_146128_h + 8), (float)(this.field_146129_i + 12), 0.0F);
            GlStateManager.func_179152_a(1.0F, f, 1.0F);
            GlStateManager.func_179109_b((float)(-(this.field_146128_h + 8)), (float)(-(this.field_146129_i + 12)), 0.0F);
         }

         this.field_146123_n = p_194828_1_ >= this.field_146128_h && p_194828_2_ >= this.field_146129_i && p_194828_1_ < this.field_146128_h + this.field_146120_f && p_194828_2_ < this.field_146129_i + this.field_146121_g;
         Minecraft minecraft = Minecraft.func_71410_x();
         minecraft.func_110434_K().func_110577_a(this.field_191760_o);
         GlStateManager.func_179097_i();
         int i = this.field_191756_q;
         int j = this.field_191757_r;
         if (this.field_191755_p) {
            i += this.field_191758_s;
         }

         if (this.field_146123_n) {
            j += this.field_191759_t;
         }

         int k = this.field_146128_h;
         if (this.field_191755_p) {
            k -= 2;
         }

         GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
         this.func_73729_b(k, this.field_146129_i, i, j, this.field_146120_f, this.field_146121_g);
         GlStateManager.func_179126_j();
         RenderHelper.func_74520_c();
         GlStateManager.func_179140_f();
         this.func_193920_a(minecraft.func_175599_af());
         GlStateManager.func_179145_e();
         RenderHelper.func_74518_a();
         if (this.field_193922_v > 0.0F) {
            GlStateManager.func_179121_F();
            this.field_193922_v -= p_194828_3_;
         }

      }
   }

   private void func_193920_a(ItemRenderer p_193920_1_) {
      List<ItemStack> list = this.field_193921_u.func_202903_a();
      int i = this.field_191755_p ? -2 : 0;
      if (list.size() == 1) {
         p_193920_1_.func_180450_b(list.get(0), this.field_146128_h + 9 + i, this.field_146129_i + 5);
      } else if (list.size() == 2) {
         p_193920_1_.func_180450_b(list.get(0), this.field_146128_h + 3 + i, this.field_146129_i + 5);
         p_193920_1_.func_180450_b(list.get(1), this.field_146128_h + 14 + i, this.field_146129_i + 5);
      }

   }

   public RecipeBookCategories func_201503_d() {
      return this.field_193921_u;
   }

   public boolean func_199500_a(RecipeBookClient p_199500_1_) {
      List<RecipeList> list = p_199500_1_.func_202891_a(this.field_193921_u);
      this.field_146125_m = false;
      if (list != null) {
         for(RecipeList recipelist : list) {
            if (recipelist.func_194209_a() && recipelist.func_194212_c()) {
               this.field_146125_m = true;
               break;
            }
         }
      }

      return this.field_146125_m;
   }
}
