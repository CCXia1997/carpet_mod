package net.minecraft.client.gui;

import java.util.Arrays;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.util.text.TextFormatting;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.apache.commons.lang3.ArrayUtils;

@OnlyIn(Dist.CLIENT)
public class GuiKeyBindingList extends GuiListExtended<GuiKeyBindingList.Entry> {
   private final GuiControls field_148191_k;
   private final Minecraft field_148189_l;
   private int field_148188_n;

   public GuiKeyBindingList(GuiControls p_i45031_1_, Minecraft p_i45031_2_) {
      super(p_i45031_2_, p_i45031_1_.field_146294_l + 45, p_i45031_1_.field_146295_m, 63, p_i45031_1_.field_146295_m - 32, 20);
      this.field_148191_k = p_i45031_1_;
      this.field_148189_l = p_i45031_2_;
      KeyBinding[] akeybinding = ArrayUtils.clone(p_i45031_2_.field_71474_y.field_74324_K);
      Arrays.sort((Object[])akeybinding);
      String s = null;

      for(KeyBinding keybinding : akeybinding) {
         String s1 = keybinding.func_151466_e();
         if (!s1.equals(s)) {
            s = s1;
            this.func_195085_a(new GuiKeyBindingList.CategoryEntry(s1));
         }

         int i = p_i45031_2_.field_71466_p.func_78256_a(I18n.func_135052_a(keybinding.func_151464_g()));
         if (i > this.field_148188_n) {
            this.field_148188_n = i;
         }

         this.func_195085_a(new GuiKeyBindingList.KeyEntry(keybinding));
      }

   }

   protected int func_148137_d() {
      return super.func_148137_d() + 15;
   }

   public int func_148139_c() {
      return super.func_148139_c() + 32;
   }

   @OnlyIn(Dist.CLIENT)
   public class CategoryEntry extends GuiKeyBindingList.Entry {
      private final String field_148285_b;
      private final int field_148286_c;

      public CategoryEntry(String p_i45028_2_) {
         this.field_148285_b = I18n.func_135052_a(p_i45028_2_);
         this.field_148286_c = GuiKeyBindingList.this.field_148189_l.field_71466_p.func_78256_a(this.field_148285_b);
      }

      public void func_194999_a(int p_194999_1_, int p_194999_2_, int p_194999_3_, int p_194999_4_, boolean p_194999_5_, float p_194999_6_) {
         GuiKeyBindingList.this.field_148189_l.field_71466_p.func_211126_b(this.field_148285_b, (float)(GuiKeyBindingList.this.field_148189_l.field_71462_r.field_146294_l / 2 - this.field_148286_c / 2), (float)(this.func_195001_c() + p_194999_2_ - GuiKeyBindingList.this.field_148189_l.field_71466_p.field_78288_b - 1), 16777215);
      }
   }

   @OnlyIn(Dist.CLIENT)
   public abstract static class Entry extends GuiListExtended.IGuiListEntry<GuiKeyBindingList.Entry> {
   }

   @OnlyIn(Dist.CLIENT)
   public class KeyEntry extends GuiKeyBindingList.Entry {
      private final KeyBinding field_148282_b;
      private final String field_148283_c;
      private final GuiButton field_148280_d;
      private final GuiButton field_148281_e;

      private KeyEntry(final KeyBinding p_i45029_2_) {
         this.field_148282_b = p_i45029_2_;
         this.field_148283_c = I18n.func_135052_a(p_i45029_2_.func_151464_g());
         this.field_148280_d = new GuiButton(0, 0, 0, 75, 20, I18n.func_135052_a(p_i45029_2_.func_151464_g())) {
            public void func_194829_a(double p_194829_1_, double p_194829_3_) {
               GuiKeyBindingList.this.field_148191_k.field_146491_f = p_i45029_2_;
            }
         };
         this.field_148281_e = new GuiButton(0, 0, 0, 50, 20, I18n.func_135052_a("controls.reset")) {
            public void func_194829_a(double p_194829_1_, double p_194829_3_) {
               GuiKeyBindingList.this.field_148189_l.field_71474_y.func_198014_a(p_i45029_2_, p_i45029_2_.func_197977_i());
               KeyBinding.func_74508_b();
            }
         };
      }

      public void func_194999_a(int p_194999_1_, int p_194999_2_, int p_194999_3_, int p_194999_4_, boolean p_194999_5_, float p_194999_6_) {
         int i = this.func_195001_c();
         int j = this.func_195002_d();
         boolean flag = GuiKeyBindingList.this.field_148191_k.field_146491_f == this.field_148282_b;
         GuiKeyBindingList.this.field_148189_l.field_71466_p.func_211126_b(this.field_148283_c, (float)(j + 90 - GuiKeyBindingList.this.field_148188_n), (float)(i + p_194999_2_ / 2 - GuiKeyBindingList.this.field_148189_l.field_71466_p.field_78288_b / 2), 16777215);
         this.field_148281_e.field_146128_h = j + 190;
         this.field_148281_e.field_146129_i = i;
         this.field_148281_e.field_146124_l = !this.field_148282_b.func_197985_l();
         this.field_148281_e.func_194828_a(p_194999_3_, p_194999_4_, p_194999_6_);
         this.field_148280_d.field_146128_h = j + 105;
         this.field_148280_d.field_146129_i = i;
         this.field_148280_d.field_146126_j = this.field_148282_b.func_197978_k();
         boolean flag1 = false;
         if (!this.field_148282_b.func_197986_j()) {
            for(KeyBinding keybinding : GuiKeyBindingList.this.field_148189_l.field_71474_y.field_74324_K) {
               if (keybinding != this.field_148282_b && this.field_148282_b.func_197983_b(keybinding)) {
                  flag1 = true;
                  break;
               }
            }
         }

         if (flag) {
            this.field_148280_d.field_146126_j = TextFormatting.WHITE + "> " + TextFormatting.YELLOW + this.field_148280_d.field_146126_j + TextFormatting.WHITE + " <";
         } else if (flag1) {
            this.field_148280_d.field_146126_j = TextFormatting.RED + this.field_148280_d.field_146126_j;
         }

         this.field_148280_d.func_194828_a(p_194999_3_, p_194999_4_, p_194999_6_);
      }

      public boolean mouseClicked(double p_mouseClicked_1_, double p_mouseClicked_3_, int p_mouseClicked_5_) {
         if (this.field_148280_d.mouseClicked(p_mouseClicked_1_, p_mouseClicked_3_, p_mouseClicked_5_)) {
            return true;
         } else {
            return this.field_148281_e.mouseClicked(p_mouseClicked_1_, p_mouseClicked_3_, p_mouseClicked_5_);
         }
      }

      public boolean mouseReleased(double p_mouseReleased_1_, double p_mouseReleased_3_, int p_mouseReleased_5_) {
         return this.field_148280_d.mouseReleased(p_mouseReleased_1_, p_mouseReleased_3_, p_mouseReleased_5_) || this.field_148281_e.mouseReleased(p_mouseReleased_1_, p_mouseReleased_3_, p_mouseReleased_5_);
      }
   }
}
