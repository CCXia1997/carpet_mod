package net.minecraft.client.gui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.resources.ResourcePackListEntryFound;
import net.minecraft.util.text.TextFormatting;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public abstract class GuiResourcePackList extends GuiListExtended<ResourcePackListEntryFound> {
   protected final Minecraft field_148205_k;

   public GuiResourcePackList(Minecraft p_i47648_1_, int p_i47648_2_, int p_i47648_3_) {
      super(p_i47648_1_, p_i47648_2_, p_i47648_3_, 32, p_i47648_3_ - 55 + 4, 36);
      this.field_148205_k = p_i47648_1_;
      this.field_148163_i = false;
      this.func_148133_a(true, (int)((float)p_i47648_1_.field_71466_p.field_78288_b * 1.5F));
   }

   protected void func_148129_a(int p_148129_1_, int p_148129_2_, Tessellator p_148129_3_) {
      String s = TextFormatting.UNDERLINE + "" + TextFormatting.BOLD + this.func_148202_k();
      this.field_148205_k.field_71466_p.func_211126_b(s, (float)(p_148129_1_ + this.field_148155_a / 2 - this.field_148205_k.field_71466_p.func_78256_a(s) / 2), (float)Math.min(this.field_148153_b + 3, p_148129_2_), 16777215);
   }

   protected abstract String func_148202_k();

   public int func_148139_c() {
      return this.field_148155_a;
   }

   protected int func_148137_d() {
      return this.field_148151_d - 6;
   }

   public void func_195095_a(ResourcePackListEntryFound p_195095_1_) {
      super.func_195085_a(p_195095_1_);
   }
}
