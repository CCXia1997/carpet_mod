package net.minecraft.client.gui;

import com.mojang.datafixers.Dynamic;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.client.resources.I18n;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTDynamicOps;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.world.gen.FlatGenSettings;
import net.minecraft.world.gen.FlatLayerInfo;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class GuiCreateFlatWorld extends GuiScreen {
   private final GuiCreateWorld field_146385_f;
   private FlatGenSettings field_146387_g = FlatGenSettings.func_82649_e();
   private String field_146393_h;
   private String field_146394_i;
   private String field_146391_r;
   private GuiCreateFlatWorld.Details field_146390_s;
   private GuiButton field_146389_t;
   private GuiButton field_146388_u;
   private GuiButton field_146386_v;

   public GuiCreateFlatWorld(GuiCreateWorld p_i49700_1_, NBTTagCompound p_i49700_2_) {
      this.field_146385_f = p_i49700_1_;
      this.func_210503_a(p_i49700_2_);
   }

   public String func_210501_h() {
      return this.field_146387_g.toString();
   }

   public NBTTagCompound func_210504_i() {
      return (NBTTagCompound)this.field_146387_g.func_210834_a(NBTDynamicOps.field_210820_a).getValue();
   }

   public void func_210502_a(String p_210502_1_) {
      this.field_146387_g = FlatGenSettings.func_82651_a(p_210502_1_);
   }

   public void func_210503_a(NBTTagCompound p_210503_1_) {
      this.field_146387_g = FlatGenSettings.func_210835_a(new Dynamic<>(NBTDynamicOps.field_210820_a, p_210503_1_));
   }

   protected void func_73866_w_() {
      this.field_146393_h = I18n.func_135052_a("createWorld.customize.flat.title");
      this.field_146394_i = I18n.func_135052_a("createWorld.customize.flat.tile");
      this.field_146391_r = I18n.func_135052_a("createWorld.customize.flat.height");
      this.field_146390_s = new GuiCreateFlatWorld.Details();
      this.field_195124_j.add(this.field_146390_s);
      this.field_146389_t = this.func_189646_b(new GuiButton(2, this.field_146294_l / 2 - 154, this.field_146295_m - 52, 100, 20, I18n.func_135052_a("createWorld.customize.flat.addLayer") + " (NYI)") {
         public void func_194829_a(double p_194829_1_, double p_194829_3_) {
            GuiCreateFlatWorld.this.field_146387_g.func_82645_d();
            GuiCreateFlatWorld.this.func_146375_g();
         }
      });
      this.field_146388_u = this.func_189646_b(new GuiButton(3, this.field_146294_l / 2 - 50, this.field_146295_m - 52, 100, 20, I18n.func_135052_a("createWorld.customize.flat.editLayer") + " (NYI)") {
         public void func_194829_a(double p_194829_1_, double p_194829_3_) {
            GuiCreateFlatWorld.this.field_146387_g.func_82645_d();
            GuiCreateFlatWorld.this.func_146375_g();
         }
      });
      this.field_146386_v = this.func_189646_b(new GuiButton(4, this.field_146294_l / 2 - 155, this.field_146295_m - 52, 150, 20, I18n.func_135052_a("createWorld.customize.flat.removeLayer")) {
         public void func_194829_a(double p_194829_1_, double p_194829_3_) {
            if (GuiCreateFlatWorld.this.func_146382_i()) {
               List<FlatLayerInfo> list = GuiCreateFlatWorld.this.field_146387_g.func_82650_c();
               int i = list.size() - GuiCreateFlatWorld.this.field_146390_s.field_148228_k - 1;
               list.remove(i);
               GuiCreateFlatWorld.this.field_146390_s.field_148228_k = Math.min(GuiCreateFlatWorld.this.field_146390_s.field_148228_k, list.size() - 1);
               GuiCreateFlatWorld.this.field_146387_g.func_82645_d();
               GuiCreateFlatWorld.this.func_146375_g();
            }
         }
      });
      this.func_189646_b(new GuiButton(0, this.field_146294_l / 2 - 155, this.field_146295_m - 28, 150, 20, I18n.func_135052_a("gui.done")) {
         public void func_194829_a(double p_194829_1_, double p_194829_3_) {
            GuiCreateFlatWorld.this.field_146385_f.field_146334_a = GuiCreateFlatWorld.this.func_210504_i();
            GuiCreateFlatWorld.this.field_146297_k.func_147108_a(GuiCreateFlatWorld.this.field_146385_f);
            GuiCreateFlatWorld.this.field_146387_g.func_82645_d();
            GuiCreateFlatWorld.this.func_146375_g();
         }
      });
      this.func_189646_b(new GuiButton(5, this.field_146294_l / 2 + 5, this.field_146295_m - 52, 150, 20, I18n.func_135052_a("createWorld.customize.presets")) {
         public void func_194829_a(double p_194829_1_, double p_194829_3_) {
            GuiCreateFlatWorld.this.field_146297_k.func_147108_a(new GuiFlatPresets(GuiCreateFlatWorld.this));
            GuiCreateFlatWorld.this.field_146387_g.func_82645_d();
            GuiCreateFlatWorld.this.func_146375_g();
         }
      });
      this.func_189646_b(new GuiButton(1, this.field_146294_l / 2 + 5, this.field_146295_m - 28, 150, 20, I18n.func_135052_a("gui.cancel")) {
         public void func_194829_a(double p_194829_1_, double p_194829_3_) {
            GuiCreateFlatWorld.this.field_146297_k.func_147108_a(GuiCreateFlatWorld.this.field_146385_f);
            GuiCreateFlatWorld.this.field_146387_g.func_82645_d();
            GuiCreateFlatWorld.this.func_146375_g();
         }
      });
      this.field_146389_t.field_146125_m = false;
      this.field_146388_u.field_146125_m = false;
      this.field_146387_g.func_82645_d();
      this.func_146375_g();
   }

   public void func_146375_g() {
      boolean flag = this.func_146382_i();
      this.field_146386_v.field_146124_l = flag;
      this.field_146388_u.field_146124_l = flag;
      this.field_146388_u.field_146124_l = false;
      this.field_146389_t.field_146124_l = false;
   }

   private boolean func_146382_i() {
      return this.field_146390_s.field_148228_k > -1 && this.field_146390_s.field_148228_k < this.field_146387_g.func_82650_c().size();
   }

   @Nullable
   public IGuiEventListener getFocused() {
      return this.field_146390_s;
   }

   public void func_73863_a(int p_73863_1_, int p_73863_2_, float p_73863_3_) {
      this.func_146276_q_();
      this.field_146390_s.func_148128_a(p_73863_1_, p_73863_2_, p_73863_3_);
      this.func_73732_a(this.field_146289_q, this.field_146393_h, this.field_146294_l / 2, 8, 16777215);
      int i = this.field_146294_l / 2 - 92 - 16;
      this.func_73731_b(this.field_146289_q, this.field_146394_i, i, 32, 16777215);
      this.func_73731_b(this.field_146289_q, this.field_146391_r, i + 2 + 213 - this.field_146289_q.func_78256_a(this.field_146391_r), 32, 16777215);
      super.func_73863_a(p_73863_1_, p_73863_2_, p_73863_3_);
   }

   @OnlyIn(Dist.CLIENT)
   class Details extends GuiSlot {
      public int field_148228_k = -1;

      public Details() {
         super(GuiCreateFlatWorld.this.field_146297_k, GuiCreateFlatWorld.this.field_146294_l, GuiCreateFlatWorld.this.field_146295_m, 43, GuiCreateFlatWorld.this.field_146295_m - 60, 24);
      }

      private void func_148225_a(int p_148225_1_, int p_148225_2_, ItemStack p_148225_3_) {
         this.func_148226_e(p_148225_1_ + 1, p_148225_2_ + 1);
         GlStateManager.func_179091_B();
         if (!p_148225_3_.func_190926_b()) {
            RenderHelper.func_74520_c();
            GuiCreateFlatWorld.this.field_146296_j.func_175042_a(p_148225_3_, p_148225_1_ + 2, p_148225_2_ + 2);
            RenderHelper.func_74518_a();
         }

         GlStateManager.func_179101_C();
      }

      private void func_148226_e(int p_148226_1_, int p_148226_2_) {
         this.func_148224_c(p_148226_1_, p_148226_2_, 0, 0);
      }

      private void func_148224_c(int p_148224_1_, int p_148224_2_, int p_148224_3_, int p_148224_4_) {
         GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
         this.field_148161_k.func_110434_K().func_110577_a(field_110323_l);
         float f = 0.0078125F;
         float f1 = 0.0078125F;
         int i = 18;
         int j = 18;
         Tessellator tessellator = Tessellator.func_178181_a();
         BufferBuilder bufferbuilder = tessellator.func_178180_c();
         bufferbuilder.func_181668_a(7, DefaultVertexFormats.field_181707_g);
         bufferbuilder.func_181662_b((double)(p_148224_1_ + 0), (double)(p_148224_2_ + 18), (double)this.field_73735_i).func_187315_a((double)((float)(p_148224_3_ + 0) * 0.0078125F), (double)((float)(p_148224_4_ + 18) * 0.0078125F)).func_181675_d();
         bufferbuilder.func_181662_b((double)(p_148224_1_ + 18), (double)(p_148224_2_ + 18), (double)this.field_73735_i).func_187315_a((double)((float)(p_148224_3_ + 18) * 0.0078125F), (double)((float)(p_148224_4_ + 18) * 0.0078125F)).func_181675_d();
         bufferbuilder.func_181662_b((double)(p_148224_1_ + 18), (double)(p_148224_2_ + 0), (double)this.field_73735_i).func_187315_a((double)((float)(p_148224_3_ + 18) * 0.0078125F), (double)((float)(p_148224_4_ + 0) * 0.0078125F)).func_181675_d();
         bufferbuilder.func_181662_b((double)(p_148224_1_ + 0), (double)(p_148224_2_ + 0), (double)this.field_73735_i).func_187315_a((double)((float)(p_148224_3_ + 0) * 0.0078125F), (double)((float)(p_148224_4_ + 0) * 0.0078125F)).func_181675_d();
         tessellator.func_78381_a();
      }

      protected int func_148127_b() {
         return GuiCreateFlatWorld.this.field_146387_g.func_82650_c().size();
      }

      protected boolean func_195078_a(int p_195078_1_, int p_195078_2_, double p_195078_3_, double p_195078_5_) {
         this.field_148228_k = p_195078_1_;
         GuiCreateFlatWorld.this.func_146375_g();
         return true;
      }

      protected boolean func_148131_a(int p_148131_1_) {
         return p_148131_1_ == this.field_148228_k;
      }

      protected void func_148123_a() {
      }

      protected void func_192637_a(int p_192637_1_, int p_192637_2_, int p_192637_3_, int p_192637_4_, int p_192637_5_, int p_192637_6_, float p_192637_7_) {
         FlatLayerInfo flatlayerinfo = GuiCreateFlatWorld.this.field_146387_g.func_82650_c().get(GuiCreateFlatWorld.this.field_146387_g.func_82650_c().size() - p_192637_1_ - 1);
         IBlockState iblockstate = flatlayerinfo.func_175900_c();
         Block block = iblockstate.func_177230_c();
         Item item = block.func_199767_j();
         if (item == Items.field_190931_a) {
            if (block == Blocks.field_150355_j) {
               item = Items.field_151131_as;
            } else if (block == Blocks.field_150353_l) {
               item = Items.field_151129_at;
            }
         }

         ItemStack itemstack = new ItemStack(item);
         String s = item.func_200295_i(itemstack).func_150254_d();
         this.func_148225_a(p_192637_2_, p_192637_3_, itemstack);
         GuiCreateFlatWorld.this.field_146289_q.func_211126_b(s, (float)(p_192637_2_ + 18 + 5), (float)(p_192637_3_ + 3), 16777215);
         String s1;
         if (p_192637_1_ == 0) {
            s1 = I18n.func_135052_a("createWorld.customize.flat.layer.top", flatlayerinfo.func_82657_a());
         } else if (p_192637_1_ == GuiCreateFlatWorld.this.field_146387_g.func_82650_c().size() - 1) {
            s1 = I18n.func_135052_a("createWorld.customize.flat.layer.bottom", flatlayerinfo.func_82657_a());
         } else {
            s1 = I18n.func_135052_a("createWorld.customize.flat.layer", flatlayerinfo.func_82657_a());
         }

         GuiCreateFlatWorld.this.field_146289_q.func_211126_b(s1, (float)(p_192637_2_ + 2 + 213 - GuiCreateFlatWorld.this.field_146289_q.func_78256_a(s1)), (float)(p_192637_3_ + 3), 16777215);
      }

      protected int func_148137_d() {
         return this.field_148155_a - 70;
      }
   }
}
