package net.minecraft.client.gui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.I18n;
import net.minecraft.util.Util;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class ServerListEntryLanScan extends ServerSelectionList.Entry {
   private final Minecraft field_148288_a = Minecraft.func_71410_x();

   public void func_194999_a(int p_194999_1_, int p_194999_2_, int p_194999_3_, int p_194999_4_, boolean p_194999_5_, float p_194999_6_) {
      int i = this.func_195001_c() + p_194999_2_ / 2 - this.field_148288_a.field_71466_p.field_78288_b / 2;
      this.field_148288_a.field_71466_p.func_211126_b(I18n.func_135052_a("lanServer.scanning"), (float)(this.field_148288_a.field_71462_r.field_146294_l / 2 - this.field_148288_a.field_71466_p.func_78256_a(I18n.func_135052_a("lanServer.scanning")) / 2), (float)i, 16777215);
      String s;
      switch((int)(Util.func_211177_b() / 300L % 4L)) {
      case 0:
      default:
         s = "O o o";
         break;
      case 1:
      case 3:
         s = "o O o";
         break;
      case 2:
         s = "o o O";
      }

      this.field_148288_a.field_71466_p.func_211126_b(s, (float)(this.field_148288_a.field_71462_r.field_146294_l / 2 - this.field_148288_a.field_71466_p.func_78256_a(s) / 2), (float)(i + this.field_148288_a.field_71466_p.field_78288_b), 8421504);
   }
}
