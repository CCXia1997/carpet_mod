package net.minecraft.advancements.criterion;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.minecraft.advancements.ICriterionTrigger;
import net.minecraft.advancements.PlayerAdvancements;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.entity.projectile.EntityFishHook;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;

public class FishingRodHookedTrigger implements ICriterionTrigger<FishingRodHookedTrigger.Instance> {
   private static final ResourceLocation field_204821_a = new ResourceLocation("fishing_rod_hooked");
   private final Map<PlayerAdvancements, FishingRodHookedTrigger.Listeners> field_204822_b = Maps.newHashMap();

   public ResourceLocation func_192163_a() {
      return field_204821_a;
   }

   public void func_192165_a(PlayerAdvancements p_192165_1_, ICriterionTrigger.Listener<FishingRodHookedTrigger.Instance> p_192165_2_) {
      FishingRodHookedTrigger.Listeners fishingrodhookedtrigger$listeners = this.field_204822_b.get(p_192165_1_);
      if (fishingrodhookedtrigger$listeners == null) {
         fishingrodhookedtrigger$listeners = new FishingRodHookedTrigger.Listeners(p_192165_1_);
         this.field_204822_b.put(p_192165_1_, fishingrodhookedtrigger$listeners);
      }

      fishingrodhookedtrigger$listeners.func_204858_a(p_192165_2_);
   }

   public void func_192164_b(PlayerAdvancements p_192164_1_, ICriterionTrigger.Listener<FishingRodHookedTrigger.Instance> p_192164_2_) {
      FishingRodHookedTrigger.Listeners fishingrodhookedtrigger$listeners = this.field_204822_b.get(p_192164_1_);
      if (fishingrodhookedtrigger$listeners != null) {
         fishingrodhookedtrigger$listeners.func_204861_b(p_192164_2_);
         if (fishingrodhookedtrigger$listeners.func_204860_a()) {
            this.field_204822_b.remove(p_192164_1_);
         }
      }

   }

   public void func_192167_a(PlayerAdvancements p_192167_1_) {
      this.field_204822_b.remove(p_192167_1_);
   }

   public FishingRodHookedTrigger.Instance func_192166_a(JsonObject p_192166_1_, JsonDeserializationContext p_192166_2_) {
      ItemPredicate itempredicate = ItemPredicate.func_192492_a(p_192166_1_.get("rod"));
      EntityPredicate entitypredicate = EntityPredicate.func_192481_a(p_192166_1_.get("entity"));
      ItemPredicate itempredicate1 = ItemPredicate.func_192492_a(p_192166_1_.get("item"));
      return new FishingRodHookedTrigger.Instance(itempredicate, entitypredicate, itempredicate1);
   }

   public void func_204820_a(EntityPlayerMP p_204820_1_, ItemStack p_204820_2_, EntityFishHook p_204820_3_, Collection<ItemStack> p_204820_4_) {
      FishingRodHookedTrigger.Listeners fishingrodhookedtrigger$listeners = this.field_204822_b.get(p_204820_1_.func_192039_O());
      if (fishingrodhookedtrigger$listeners != null) {
         fishingrodhookedtrigger$listeners.func_204859_a(p_204820_1_, p_204820_2_, p_204820_3_, p_204820_4_);
      }

   }

   public static class Instance extends AbstractCriterionInstance {
      private final ItemPredicate field_204831_a;
      private final EntityPredicate field_204832_b;
      private final ItemPredicate field_204833_c;

      public Instance(ItemPredicate p_i48916_1_, EntityPredicate p_i48916_2_, ItemPredicate p_i48916_3_) {
         super(FishingRodHookedTrigger.field_204821_a);
         this.field_204831_a = p_i48916_1_;
         this.field_204832_b = p_i48916_2_;
         this.field_204833_c = p_i48916_3_;
      }

      public static FishingRodHookedTrigger.Instance func_204829_a(ItemPredicate p_204829_0_, EntityPredicate p_204829_1_, ItemPredicate p_204829_2_) {
         return new FishingRodHookedTrigger.Instance(p_204829_0_, p_204829_1_, p_204829_2_);
      }

      public boolean func_204830_a(EntityPlayerMP p_204830_1_, ItemStack p_204830_2_, EntityFishHook p_204830_3_, Collection<ItemStack> p_204830_4_) {
         if (!this.field_204831_a.func_192493_a(p_204830_2_)) {
            return false;
         } else if (!this.field_204832_b.func_192482_a(p_204830_1_, p_204830_3_.field_146043_c)) {
            return false;
         } else {
            if (this.field_204833_c != ItemPredicate.field_192495_a) {
               boolean flag = false;
               if (p_204830_3_.field_146043_c instanceof EntityItem) {
                  EntityItem entityitem = (EntityItem)p_204830_3_.field_146043_c;
                  if (this.field_204833_c.func_192493_a(entityitem.func_92059_d())) {
                     flag = true;
                  }
               }

               for(ItemStack itemstack : p_204830_4_) {
                  if (this.field_204833_c.func_192493_a(itemstack)) {
                     flag = true;
                     break;
                  }
               }

               if (!flag) {
                  return false;
               }
            }

            return true;
         }
      }

      public JsonElement func_200288_b() {
         JsonObject jsonobject = new JsonObject();
         jsonobject.add("rod", this.field_204831_a.func_200319_a());
         jsonobject.add("entity", this.field_204832_b.func_204006_a());
         jsonobject.add("item", this.field_204833_c.func_200319_a());
         return jsonobject;
      }
   }

   static class Listeners {
      private final PlayerAdvancements field_204862_a;
      private final Set<ICriterionTrigger.Listener<FishingRodHookedTrigger.Instance>> field_204863_b = Sets.newHashSet();

      public Listeners(PlayerAdvancements p_i48917_1_) {
         this.field_204862_a = p_i48917_1_;
      }

      public boolean func_204860_a() {
         return this.field_204863_b.isEmpty();
      }

      public void func_204858_a(ICriterionTrigger.Listener<FishingRodHookedTrigger.Instance> p_204858_1_) {
         this.field_204863_b.add(p_204858_1_);
      }

      public void func_204861_b(ICriterionTrigger.Listener<FishingRodHookedTrigger.Instance> p_204861_1_) {
         this.field_204863_b.remove(p_204861_1_);
      }

      public void func_204859_a(EntityPlayerMP p_204859_1_, ItemStack p_204859_2_, EntityFishHook p_204859_3_, Collection<ItemStack> p_204859_4_) {
         List<ICriterionTrigger.Listener<FishingRodHookedTrigger.Instance>> list = null;

         for(ICriterionTrigger.Listener<FishingRodHookedTrigger.Instance> listener : this.field_204863_b) {
            if (listener.func_192158_a().func_204830_a(p_204859_1_, p_204859_2_, p_204859_3_, p_204859_4_)) {
               if (list == null) {
                  list = Lists.newArrayList();
               }

               list.add(listener);
            }
         }

         if (list != null) {
            for(ICriterionTrigger.Listener<FishingRodHookedTrigger.Instance> listener1 : list) {
               listener1.func_192159_a(this.field_204862_a);
            }
         }

      }
   }
}
