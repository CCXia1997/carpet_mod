package net.minecraft.advancements.criterion;

import com.google.common.collect.Lists;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonSyntaxException;
import java.util.List;
import java.util.Map;
import javax.annotation.Nullable;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.PotionType;
import net.minecraft.potion.PotionUtils;
import net.minecraft.tags.ItemTags;
import net.minecraft.tags.Tag;
import net.minecraft.util.IItemProvider;
import net.minecraft.util.JsonUtils;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.registry.IRegistry;

public class ItemPredicate {
   public static final ItemPredicate field_192495_a = new ItemPredicate();
   @Nullable
   private final Tag<Item> field_200018_b;
   @Nullable
   private final Item field_192496_b;
   private final MinMaxBounds.IntBound field_192498_d;
   private final MinMaxBounds.IntBound field_193444_e;
   private final EnchantmentPredicate[] field_192499_e;
   @Nullable
   private final PotionType field_192500_f;
   private final NBTPredicate field_193445_h;

   public ItemPredicate() {
      this.field_200018_b = null;
      this.field_192496_b = null;
      this.field_192500_f = null;
      this.field_192498_d = MinMaxBounds.IntBound.field_211347_e;
      this.field_193444_e = MinMaxBounds.IntBound.field_211347_e;
      this.field_192499_e = new EnchantmentPredicate[0];
      this.field_193445_h = NBTPredicate.field_193479_a;
   }

   public ItemPredicate(@Nullable Tag<Item> p_i49722_1_, @Nullable Item p_i49722_2_, MinMaxBounds.IntBound p_i49722_3_, MinMaxBounds.IntBound p_i49722_4_, EnchantmentPredicate[] p_i49722_5_, @Nullable PotionType p_i49722_6_, NBTPredicate p_i49722_7_) {
      this.field_200018_b = p_i49722_1_;
      this.field_192496_b = p_i49722_2_;
      this.field_192498_d = p_i49722_3_;
      this.field_193444_e = p_i49722_4_;
      this.field_192499_e = p_i49722_5_;
      this.field_192500_f = p_i49722_6_;
      this.field_193445_h = p_i49722_7_;
   }

   public boolean func_192493_a(ItemStack p_192493_1_) {
      if (this.field_200018_b != null && !this.field_200018_b.func_199685_a_(p_192493_1_.func_77973_b())) {
         return false;
      } else if (this.field_192496_b != null && p_192493_1_.func_77973_b() != this.field_192496_b) {
         return false;
      } else if (!this.field_192498_d.func_211339_d(p_192493_1_.func_190916_E())) {
         return false;
      } else if (!this.field_193444_e.func_211335_c() && !p_192493_1_.func_77984_f()) {
         return false;
      } else if (!this.field_193444_e.func_211339_d(p_192493_1_.func_77958_k() - p_192493_1_.func_77952_i())) {
         return false;
      } else if (!this.field_193445_h.func_193478_a(p_192493_1_)) {
         return false;
      } else {
         Map<Enchantment, Integer> map = EnchantmentHelper.func_82781_a(p_192493_1_);

         for(int i = 0; i < this.field_192499_e.length; ++i) {
            if (!this.field_192499_e[i].func_192463_a(map)) {
               return false;
            }
         }

         PotionType potiontype = PotionUtils.func_185191_c(p_192493_1_);
         if (this.field_192500_f != null && this.field_192500_f != potiontype) {
            return false;
         } else {
            return true;
         }
      }
   }

   public static ItemPredicate func_192492_a(@Nullable JsonElement p_192492_0_) {
      if (p_192492_0_ != null && !p_192492_0_.isJsonNull()) {
         JsonObject jsonobject = JsonUtils.func_151210_l(p_192492_0_, "item");
         MinMaxBounds.IntBound minmaxbounds$intbound = MinMaxBounds.IntBound.func_211344_a(jsonobject.get("count"));
         MinMaxBounds.IntBound minmaxbounds$intbound1 = MinMaxBounds.IntBound.func_211344_a(jsonobject.get("durability"));
         if (jsonobject.has("data")) {
            throw new JsonParseException("Disallowed data tag found");
         } else {
            NBTPredicate nbtpredicate = NBTPredicate.func_193476_a(jsonobject.get("nbt"));
            Item item = null;
            if (jsonobject.has("item")) {
               ResourceLocation resourcelocation = new ResourceLocation(JsonUtils.func_151200_h(jsonobject, "item"));
               item = IRegistry.field_212630_s.func_212608_b(resourcelocation);
               if (item == null) {
                  throw new JsonSyntaxException("Unknown item id '" + resourcelocation + "'");
               }
            }

            Tag<Item> tag = null;
            if (jsonobject.has("tag")) {
               ResourceLocation resourcelocation1 = new ResourceLocation(JsonUtils.func_151200_h(jsonobject, "tag"));
               tag = ItemTags.func_199903_a().func_199910_a(resourcelocation1);
               if (tag == null) {
                  throw new JsonSyntaxException("Unknown item tag '" + resourcelocation1 + "'");
               }
            }

            EnchantmentPredicate[] aenchantmentpredicate = EnchantmentPredicate.func_192465_b(jsonobject.get("enchantments"));
            PotionType potiontype = null;
            if (jsonobject.has("potion")) {
               ResourceLocation resourcelocation2 = new ResourceLocation(JsonUtils.func_151200_h(jsonobject, "potion"));
               if (!IRegistry.field_212621_j.func_212607_c(resourcelocation2)) {
                  throw new JsonSyntaxException("Unknown potion '" + resourcelocation2 + "'");
               }

               potiontype = IRegistry.field_212621_j.func_82594_a(resourcelocation2);
            }

            return new ItemPredicate(tag, item, minmaxbounds$intbound, minmaxbounds$intbound1, aenchantmentpredicate, potiontype, nbtpredicate);
         }
      } else {
         return field_192495_a;
      }
   }

   public JsonElement func_200319_a() {
      if (this == field_192495_a) {
         return JsonNull.INSTANCE;
      } else {
         JsonObject jsonobject = new JsonObject();
         if (this.field_192496_b != null) {
            jsonobject.addProperty("item", IRegistry.field_212630_s.func_177774_c(this.field_192496_b).toString());
         }

         if (this.field_200018_b != null) {
            jsonobject.addProperty("tag", this.field_200018_b.func_199886_b().toString());
         }

         jsonobject.add("count", this.field_192498_d.func_200321_c());
         jsonobject.add("durability", this.field_193444_e.func_200321_c());
         jsonobject.add("nbt", this.field_193445_h.func_200322_a());
         if (this.field_192499_e.length > 0) {
            JsonArray jsonarray = new JsonArray();

            for(EnchantmentPredicate enchantmentpredicate : this.field_192499_e) {
               jsonarray.add(enchantmentpredicate.func_200306_a());
            }

            jsonobject.add("enchantments", jsonarray);
         }

         if (this.field_192500_f != null) {
            jsonobject.addProperty("potion", IRegistry.field_212621_j.func_177774_c(this.field_192500_f).toString());
         }

         return jsonobject;
      }
   }

   public static ItemPredicate[] func_192494_b(@Nullable JsonElement p_192494_0_) {
      if (p_192494_0_ != null && !p_192494_0_.isJsonNull()) {
         JsonArray jsonarray = JsonUtils.func_151207_m(p_192494_0_, "items");
         ItemPredicate[] aitempredicate = new ItemPredicate[jsonarray.size()];

         for(int i = 0; i < aitempredicate.length; ++i) {
            aitempredicate[i] = func_192492_a(jsonarray.get(i));
         }

         return aitempredicate;
      } else {
         return new ItemPredicate[0];
      }
   }

   public static class Builder {
      private final List<EnchantmentPredicate> field_200312_a = Lists.newArrayList();
      @Nullable
      private Item field_200313_b;
      @Nullable
      private Tag<Item> field_200314_c;
      private MinMaxBounds.IntBound field_200315_d = MinMaxBounds.IntBound.field_211347_e;
      private MinMaxBounds.IntBound field_200316_e = MinMaxBounds.IntBound.field_211347_e;
      @Nullable
      private PotionType field_200317_f;
      private NBTPredicate field_200318_g = NBTPredicate.field_193479_a;

      public static ItemPredicate.Builder func_200309_a() {
         return new ItemPredicate.Builder();
      }

      public ItemPredicate.Builder func_200308_a(IItemProvider p_200308_1_) {
         this.field_200313_b = p_200308_1_.func_199767_j();
         return this;
      }

      public ItemPredicate.Builder func_200307_a(Tag<Item> p_200307_1_) {
         this.field_200314_c = p_200307_1_;
         return this;
      }

      public ItemPredicate.Builder func_200311_a(MinMaxBounds.IntBound p_200311_1_) {
         this.field_200315_d = p_200311_1_;
         return this;
      }

      public ItemPredicate func_200310_b() {
         return new ItemPredicate(this.field_200314_c, this.field_200313_b, this.field_200315_d, this.field_200316_e, this.field_200312_a.toArray(new EnchantmentPredicate[0]), this.field_200317_f, this.field_200318_g);
      }
   }
}
