package net.minecraft.advancements.criterion;

import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import javax.annotation.Nullable;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.util.DamageSource;
import net.minecraft.util.JsonUtils;

public class DamagePredicate {
   public static final DamagePredicate field_192366_a = DamagePredicate.Builder.func_203971_a().func_203970_b();
   private final MinMaxBounds.FloatBound field_192367_b;
   private final MinMaxBounds.FloatBound field_192368_c;
   private final EntityPredicate field_192369_d;
   private final Boolean field_192370_e;
   private final DamageSourcePredicate field_192371_f;

   public DamagePredicate() {
      this.field_192367_b = MinMaxBounds.FloatBound.field_211359_e;
      this.field_192368_c = MinMaxBounds.FloatBound.field_211359_e;
      this.field_192369_d = EntityPredicate.field_192483_a;
      this.field_192370_e = null;
      this.field_192371_f = DamageSourcePredicate.field_192449_a;
   }

   public DamagePredicate(MinMaxBounds.FloatBound p_i49725_1_, MinMaxBounds.FloatBound p_i49725_2_, EntityPredicate p_i49725_3_, @Nullable Boolean p_i49725_4_, DamageSourcePredicate p_i49725_5_) {
      this.field_192367_b = p_i49725_1_;
      this.field_192368_c = p_i49725_2_;
      this.field_192369_d = p_i49725_3_;
      this.field_192370_e = p_i49725_4_;
      this.field_192371_f = p_i49725_5_;
   }

   public boolean func_192365_a(EntityPlayerMP p_192365_1_, DamageSource p_192365_2_, float p_192365_3_, float p_192365_4_, boolean p_192365_5_) {
      if (this == field_192366_a) {
         return true;
      } else if (!this.field_192367_b.func_211354_d(p_192365_3_)) {
         return false;
      } else if (!this.field_192368_c.func_211354_d(p_192365_4_)) {
         return false;
      } else if (!this.field_192369_d.func_192482_a(p_192365_1_, p_192365_2_.func_76346_g())) {
         return false;
      } else if (this.field_192370_e != null && this.field_192370_e != p_192365_5_) {
         return false;
      } else {
         return this.field_192371_f.func_193418_a(p_192365_1_, p_192365_2_);
      }
   }

   public static DamagePredicate func_192364_a(@Nullable JsonElement p_192364_0_) {
      if (p_192364_0_ != null && !p_192364_0_.isJsonNull()) {
         JsonObject jsonobject = JsonUtils.func_151210_l(p_192364_0_, "damage");
         MinMaxBounds.FloatBound minmaxbounds$floatbound = MinMaxBounds.FloatBound.func_211356_a(jsonobject.get("dealt"));
         MinMaxBounds.FloatBound minmaxbounds$floatbound1 = MinMaxBounds.FloatBound.func_211356_a(jsonobject.get("taken"));
         Boolean obool = jsonobject.has("blocked") ? JsonUtils.func_151212_i(jsonobject, "blocked") : null;
         EntityPredicate entitypredicate = EntityPredicate.func_192481_a(jsonobject.get("source_entity"));
         DamageSourcePredicate damagesourcepredicate = DamageSourcePredicate.func_192447_a(jsonobject.get("type"));
         return new DamagePredicate(minmaxbounds$floatbound, minmaxbounds$floatbound1, entitypredicate, obool, damagesourcepredicate);
      } else {
         return field_192366_a;
      }
   }

   public JsonElement func_203977_a() {
      if (this == field_192366_a) {
         return JsonNull.INSTANCE;
      } else {
         JsonObject jsonobject = new JsonObject();
         jsonobject.add("dealt", this.field_192367_b.func_200321_c());
         jsonobject.add("taken", this.field_192368_c.func_200321_c());
         jsonobject.add("source_entity", this.field_192369_d.func_204006_a());
         jsonobject.add("type", this.field_192371_f.func_203991_a());
         if (this.field_192370_e != null) {
            jsonobject.addProperty("blocked", this.field_192370_e);
         }

         return jsonobject;
      }
   }

   public static class Builder {
      private MinMaxBounds.FloatBound field_203972_a = MinMaxBounds.FloatBound.field_211359_e;
      private MinMaxBounds.FloatBound field_203973_b = MinMaxBounds.FloatBound.field_211359_e;
      private EntityPredicate field_203974_c = EntityPredicate.field_192483_a;
      private Boolean field_203975_d;
      private DamageSourcePredicate field_203976_e = DamageSourcePredicate.field_192449_a;

      public static DamagePredicate.Builder func_203971_a() {
         return new DamagePredicate.Builder();
      }

      public DamagePredicate.Builder func_203968_a(Boolean p_203968_1_) {
         this.field_203975_d = p_203968_1_;
         return this;
      }

      public DamagePredicate.Builder func_203969_a(DamageSourcePredicate.Builder p_203969_1_) {
         this.field_203976_e = p_203969_1_.func_203979_b();
         return this;
      }

      public DamagePredicate func_203970_b() {
         return new DamagePredicate(this.field_203972_a, this.field_203973_b, this.field_203974_c, this.field_203975_d, this.field_203976_e);
      }
   }
}
