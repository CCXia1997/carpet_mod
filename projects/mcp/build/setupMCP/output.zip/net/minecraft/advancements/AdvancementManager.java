package net.minecraft.advancements;

import com.google.common.collect.Maps;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Collection;
import java.util.Map;
import javax.annotation.Nullable;
import net.minecraft.resources.IResource;
import net.minecraft.resources.IResourceManager;
import net.minecraft.resources.IResourceManagerReloadListener;
import net.minecraft.util.EnumTypeAdapterFactory;
import net.minecraft.util.JsonUtils;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.Style;
import org.apache.commons.io.IOUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class AdvancementManager implements IResourceManagerReloadListener {
   private static final Logger field_192782_a = LogManager.getLogger();
   private static final Gson field_192783_b = (new GsonBuilder()).registerTypeHierarchyAdapter(Advancement.Builder.class, (JsonDeserializer<Advancement.Builder>)(p_210124_0_, p_210124_1_, p_210124_2_) -> {
      JsonObject jsonobject = JsonUtils.func_151210_l(p_210124_0_, "advancement");
      return Advancement.Builder.func_192059_a(jsonobject, p_210124_2_);
   }).registerTypeAdapter(AdvancementRewards.class, new AdvancementRewards.Deserializer()).registerTypeHierarchyAdapter(ITextComponent.class, new ITextComponent.Serializer()).registerTypeHierarchyAdapter(Style.class, new Style.Serializer()).registerTypeAdapterFactory(new EnumTypeAdapterFactory()).create();
   private static final AdvancementList field_195443_e = new AdvancementList();
   public static final int field_195441_a = "advancements/".length();
   public static final int field_195442_b = ".json".length();
   private boolean field_193768_e;

   private Map<ResourceLocation, Advancement.Builder> func_195439_b(IResourceManager p_195439_1_) {
      Map<ResourceLocation, Advancement.Builder> map = Maps.newHashMap();

      for(ResourceLocation resourcelocation : p_195439_1_.func_199003_a("advancements", (p_195440_0_) -> {
         return p_195440_0_.endsWith(".json");
      })) {
         String s = resourcelocation.func_110623_a();
         ResourceLocation resourcelocation1 = new ResourceLocation(resourcelocation.func_110624_b(), s.substring(field_195441_a, s.length() - field_195442_b));

         try (IResource iresource = p_195439_1_.func_199002_a(resourcelocation)) {
            Advancement.Builder advancement$builder = JsonUtils.func_188178_a(field_192783_b, IOUtils.toString(iresource.func_199027_b(), StandardCharsets.UTF_8), Advancement.Builder.class);
            if (advancement$builder == null) {
               field_192782_a.error("Couldn't load custom advancement {} from {} as it's empty or null", resourcelocation1, resourcelocation);
            } else {
               map.put(resourcelocation1, advancement$builder);
            }
         } catch (IllegalArgumentException | JsonParseException jsonparseexception) {
            field_192782_a.error("Parsing error loading custom advancement {}: {}", resourcelocation1, jsonparseexception.getMessage());
            this.field_193768_e = true;
         } catch (IOException ioexception) {
            field_192782_a.error("Couldn't read custom advancement {} from {}", resourcelocation1, resourcelocation, ioexception);
            this.field_193768_e = true;
         }
      }

      return map;
   }

   @Nullable
   public Advancement func_192778_a(ResourceLocation p_192778_1_) {
      return field_195443_e.func_192084_a(p_192778_1_);
   }

   public Collection<Advancement> func_195438_b() {
      return field_195443_e.func_195651_c();
   }

   public void func_195410_a(IResourceManager p_195410_1_) {
      this.field_193768_e = false;
      field_195443_e.func_192087_a();
      Map<ResourceLocation, Advancement.Builder> map = this.func_195439_b(p_195410_1_);
      field_195443_e.func_192083_a(map);

      for(Advancement advancement : field_195443_e.func_192088_b()) {
         if (advancement.func_192068_c() != null) {
            AdvancementTreeNode.func_192323_a(advancement);
         }
      }

   }
}
