package net.minecraft.advancements.criterion;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import java.util.Map;
import javax.annotation.Nullable;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.util.JsonUtils;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.registry.IRegistry;

public class EnchantmentPredicate {
   public static final EnchantmentPredicate field_192466_a = new EnchantmentPredicate();
   private final Enchantment field_192467_b;
   private final MinMaxBounds.IntBound field_192468_c;

   public EnchantmentPredicate() {
      this.field_192467_b = null;
      this.field_192468_c = MinMaxBounds.IntBound.field_211347_e;
   }

   public EnchantmentPredicate(@Nullable Enchantment p_i49723_1_, MinMaxBounds.IntBound p_i49723_2_) {
      this.field_192467_b = p_i49723_1_;
      this.field_192468_c = p_i49723_2_;
   }

   public boolean func_192463_a(Map<Enchantment, Integer> p_192463_1_) {
      if (this.field_192467_b != null) {
         if (!p_192463_1_.containsKey(this.field_192467_b)) {
            return false;
         }

         int i = p_192463_1_.get(this.field_192467_b);
         if (this.field_192468_c != null && !this.field_192468_c.func_211339_d(i)) {
            return false;
         }
      } else if (this.field_192468_c != null) {
         for(Integer integer : p_192463_1_.values()) {
            if (this.field_192468_c.func_211339_d(integer)) {
               return true;
            }
         }

         return false;
      }

      return true;
   }

   public JsonElement func_200306_a() {
      if (this == field_192466_a) {
         return JsonNull.INSTANCE;
      } else {
         JsonObject jsonobject = new JsonObject();
         if (this.field_192467_b != null) {
            jsonobject.addProperty("enchantment", IRegistry.field_212628_q.func_177774_c(this.field_192467_b).toString());
         }

         jsonobject.add("levels", this.field_192468_c.func_200321_c());
         return jsonobject;
      }
   }

   public static EnchantmentPredicate func_192464_a(@Nullable JsonElement p_192464_0_) {
      if (p_192464_0_ != null && !p_192464_0_.isJsonNull()) {
         JsonObject jsonobject = JsonUtils.func_151210_l(p_192464_0_, "enchantment");
         Enchantment enchantment = null;
         if (jsonobject.has("enchantment")) {
            ResourceLocation resourcelocation = new ResourceLocation(JsonUtils.func_151200_h(jsonobject, "enchantment"));
            enchantment = IRegistry.field_212628_q.func_212608_b(resourcelocation);
            if (enchantment == null) {
               throw new JsonSyntaxException("Unknown enchantment '" + resourcelocation + "'");
            }
         }

         MinMaxBounds.IntBound minmaxbounds$intbound = MinMaxBounds.IntBound.func_211344_a(jsonobject.get("levels"));
         return new EnchantmentPredicate(enchantment, minmaxbounds$intbound);
      } else {
         return field_192466_a;
      }
   }

   public static EnchantmentPredicate[] func_192465_b(@Nullable JsonElement p_192465_0_) {
      if (p_192465_0_ != null && !p_192465_0_.isJsonNull()) {
         JsonArray jsonarray = JsonUtils.func_151207_m(p_192465_0_, "enchantments");
         EnchantmentPredicate[] aenchantmentpredicate = new EnchantmentPredicate[jsonarray.size()];

         for(int i = 0; i < aenchantmentpredicate.length; ++i) {
            aenchantmentpredicate[i] = func_192464_a(jsonarray.get(i));
         }

         return aenchantmentpredicate;
      } else {
         return new EnchantmentPredicate[0];
      }
   }
}
