package net.minecraft.advancements.criterion;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import javax.annotation.Nullable;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.util.JsonUtils;

public class EntityPredicate {
   public static final EntityPredicate field_192483_a = new EntityPredicate(EntityTypePredicate.field_209371_a, DistancePredicate.field_193423_a, LocationPredicate.field_193455_a, MobEffectsPredicate.field_193473_a, NBTPredicate.field_193479_a);
   public static final EntityPredicate[] field_204851_b = new EntityPredicate[0];
   private final EntityTypePredicate field_192484_b;
   private final DistancePredicate field_192485_c;
   private final LocationPredicate field_193435_d;
   private final MobEffectsPredicate field_193436_e;
   private final NBTPredicate field_193437_f;

   private EntityPredicate(EntityTypePredicate p_i49391_1_, DistancePredicate p_i49391_2_, LocationPredicate p_i49391_3_, MobEffectsPredicate p_i49391_4_, NBTPredicate p_i49391_5_) {
      this.field_192484_b = p_i49391_1_;
      this.field_192485_c = p_i49391_2_;
      this.field_193435_d = p_i49391_3_;
      this.field_193436_e = p_i49391_4_;
      this.field_193437_f = p_i49391_5_;
   }

   public boolean func_192482_a(EntityPlayerMP p_192482_1_, @Nullable Entity p_192482_2_) {
      if (this == field_192483_a) {
         return true;
      } else if (p_192482_2_ == null) {
         return false;
      } else if (!this.field_192484_b.func_209368_a(p_192482_2_.func_200600_R())) {
         return false;
      } else if (!this.field_192485_c.func_193422_a(p_192482_1_.field_70165_t, p_192482_1_.field_70163_u, p_192482_1_.field_70161_v, p_192482_2_.field_70165_t, p_192482_2_.field_70163_u, p_192482_2_.field_70161_v)) {
         return false;
      } else if (!this.field_193435_d.func_193452_a(p_192482_1_.func_71121_q(), p_192482_2_.field_70165_t, p_192482_2_.field_70163_u, p_192482_2_.field_70161_v)) {
         return false;
      } else if (!this.field_193436_e.func_193469_a(p_192482_2_)) {
         return false;
      } else {
         return this.field_193437_f.func_193475_a(p_192482_2_);
      }
   }

   public static EntityPredicate func_192481_a(@Nullable JsonElement p_192481_0_) {
      if (p_192481_0_ != null && !p_192481_0_.isJsonNull()) {
         JsonObject jsonobject = JsonUtils.func_151210_l(p_192481_0_, "entity");
         EntityTypePredicate entitytypepredicate = EntityTypePredicate.func_209370_a(jsonobject.get("type"));
         DistancePredicate distancepredicate = DistancePredicate.func_193421_a(jsonobject.get("distance"));
         LocationPredicate locationpredicate = LocationPredicate.func_193454_a(jsonobject.get("location"));
         MobEffectsPredicate mobeffectspredicate = MobEffectsPredicate.func_193471_a(jsonobject.get("effects"));
         NBTPredicate nbtpredicate = NBTPredicate.func_193476_a(jsonobject.get("nbt"));
         return (new EntityPredicate.Builder()).func_209366_a(entitytypepredicate).func_203997_a(distancepredicate).func_203999_a(locationpredicate).func_209367_a(mobeffectspredicate).func_209365_a(nbtpredicate).func_204000_b();
      } else {
         return field_192483_a;
      }
   }

   public static EntityPredicate[] func_204849_b(@Nullable JsonElement p_204849_0_) {
      if (p_204849_0_ != null && !p_204849_0_.isJsonNull()) {
         JsonArray jsonarray = JsonUtils.func_151207_m(p_204849_0_, "entities");
         EntityPredicate[] aentitypredicate = new EntityPredicate[jsonarray.size()];

         for(int i = 0; i < jsonarray.size(); ++i) {
            aentitypredicate[i] = func_192481_a(jsonarray.get(i));
         }

         return aentitypredicate;
      } else {
         return field_204851_b;
      }
   }

   public JsonElement func_204006_a() {
      if (this == field_192483_a) {
         return JsonNull.INSTANCE;
      } else {
         JsonObject jsonobject = new JsonObject();
         jsonobject.add("type", this.field_192484_b.func_209369_a());
         jsonobject.add("distance", this.field_192485_c.func_203994_a());
         jsonobject.add("location", this.field_193435_d.func_204009_a());
         jsonobject.add("effects", this.field_193436_e.func_204013_b());
         jsonobject.add("nbt", this.field_193437_f.func_200322_a());
         return jsonobject;
      }
   }

   public static JsonElement func_204850_a(EntityPredicate[] p_204850_0_) {
      if (p_204850_0_ == field_204851_b) {
         return JsonNull.INSTANCE;
      } else {
         JsonArray jsonarray = new JsonArray();

         for(int i = 0; i < p_204850_0_.length; ++i) {
            JsonElement jsonelement = p_204850_0_[i].func_204006_a();
            if (!jsonelement.isJsonNull()) {
               jsonarray.add(jsonelement);
            }
         }

         return jsonarray;
      }
   }

   public static class Builder {
      private EntityTypePredicate field_204001_a = EntityTypePredicate.field_209371_a;
      private DistancePredicate field_204002_b = DistancePredicate.field_193423_a;
      private LocationPredicate field_204003_c = LocationPredicate.field_193455_a;
      private MobEffectsPredicate field_204004_d = MobEffectsPredicate.field_193473_a;
      private NBTPredicate field_204005_e = NBTPredicate.field_193479_a;

      public static EntityPredicate.Builder func_203996_a() {
         return new EntityPredicate.Builder();
      }

      public EntityPredicate.Builder func_203998_a(EntityType<?> p_203998_1_) {
         this.field_204001_a = new EntityTypePredicate(p_203998_1_);
         return this;
      }

      public EntityPredicate.Builder func_209366_a(EntityTypePredicate p_209366_1_) {
         this.field_204001_a = p_209366_1_;
         return this;
      }

      public EntityPredicate.Builder func_203997_a(DistancePredicate p_203997_1_) {
         this.field_204002_b = p_203997_1_;
         return this;
      }

      public EntityPredicate.Builder func_203999_a(LocationPredicate p_203999_1_) {
         this.field_204003_c = p_203999_1_;
         return this;
      }

      public EntityPredicate.Builder func_209367_a(MobEffectsPredicate p_209367_1_) {
         this.field_204004_d = p_209367_1_;
         return this;
      }

      public EntityPredicate.Builder func_209365_a(NBTPredicate p_209365_1_) {
         this.field_204005_e = p_209365_1_;
         return this;
      }

      public EntityPredicate func_204000_b() {
         return this.field_204001_a == EntityTypePredicate.field_209371_a && this.field_204002_b == DistancePredicate.field_193423_a && this.field_204003_c == LocationPredicate.field_193455_a && this.field_204004_d == MobEffectsPredicate.field_193473_a && this.field_204005_e == NBTPredicate.field_193479_a ? EntityPredicate.field_192483_a : new EntityPredicate(this.field_204001_a, this.field_204002_b, this.field_204003_c, this.field_204004_d, this.field_204005_e);
      }
   }
}
