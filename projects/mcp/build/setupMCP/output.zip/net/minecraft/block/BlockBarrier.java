package net.minecraft.block;

import net.minecraft.block.state.IBlockState;
import net.minecraft.util.EnumBlockRenderType;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.World;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class BlockBarrier extends Block {
   protected BlockBarrier(Block.Properties p_i48447_1_) {
      super(p_i48447_1_);
   }

   public boolean func_200123_i(IBlockState p_200123_1_, IBlockReader p_200123_2_, BlockPos p_200123_3_) {
      return true;
   }

   public EnumBlockRenderType func_149645_b(IBlockState p_149645_1_) {
      return EnumBlockRenderType.INVISIBLE;
   }

   public boolean func_200124_e(IBlockState p_200124_1_) {
      return false;
   }

   @OnlyIn(Dist.CLIENT)
   public float func_185485_f(IBlockState p_185485_1_) {
      return 1.0F;
   }

   public void func_196255_a(IBlockState p_196255_1_, World p_196255_2_, BlockPos p_196255_3_, float p_196255_4_, int p_196255_5_) {
   }
}
