package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.init.Fluids;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IWorld;
import net.minecraft.world.World;

public class BlockCoralFin extends BlockCoralFan {
   private final Block field_211887_b;

   protected BlockCoralFin(Block p_i49775_1_, Block.Properties p_i49775_2_) {
      super(p_i49775_2_);
      this.field_211887_b = p_i49775_1_;
   }

   public void func_196259_b(IBlockState p_196259_1_, World p_196259_2_, BlockPos p_196259_3_, IBlockState p_196259_4_) {
      this.func_212558_a(p_196259_1_, p_196259_2_, p_196259_3_);
   }

   public void func_196267_b(IBlockState p_196267_1_, World p_196267_2_, BlockPos p_196267_3_, Random p_196267_4_) {
      if (!func_212557_b_(p_196267_1_, p_196267_2_, p_196267_3_)) {
         p_196267_2_.func_180501_a(p_196267_3_, this.field_211887_b.func_176223_P().func_206870_a(field_212560_b, Boolean.valueOf(false)), 2);
      }

   }

   public IBlockState func_196271_a(IBlockState p_196271_1_, EnumFacing p_196271_2_, IBlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      if (p_196271_2_ == EnumFacing.DOWN && !p_196271_1_.func_196955_c(p_196271_4_, p_196271_5_)) {
         return Blocks.field_150350_a.func_176223_P();
      } else {
         this.func_212558_a(p_196271_1_, p_196271_4_, p_196271_5_);
         if (p_196271_1_.func_177229_b(field_212560_b)) {
            p_196271_4_.func_205219_F_().func_205360_a(p_196271_5_, Fluids.field_204546_a, Fluids.field_204546_a.func_205569_a(p_196271_4_));
         }

         return super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
      }
   }
}
