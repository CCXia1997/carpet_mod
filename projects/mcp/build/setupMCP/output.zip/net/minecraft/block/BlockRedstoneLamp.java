package net.minecraft.block;

import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.state.IBlockState;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class BlockRedstoneLamp extends Block {
   public static final BooleanProperty field_196502_a = BlockRedstoneTorch.field_196528_a;

   public BlockRedstoneLamp(Block.Properties p_i48343_1_) {
      super(p_i48343_1_);
      this.func_180632_j(this.func_176223_P().func_206870_a(field_196502_a, Boolean.valueOf(false)));
   }

   public int func_149750_m(IBlockState p_149750_1_) {
      return p_149750_1_.func_177229_b(field_196502_a) ? super.func_149750_m(p_149750_1_) : 0;
   }

   public void func_196259_b(IBlockState p_196259_1_, World p_196259_2_, BlockPos p_196259_3_, IBlockState p_196259_4_) {
      super.func_196259_b(p_196259_1_, p_196259_2_, p_196259_3_, p_196259_4_);
   }

   @Nullable
   public IBlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      return this.func_176223_P().func_206870_a(field_196502_a, Boolean.valueOf(p_196258_1_.func_195991_k().func_175640_z(p_196258_1_.func_195995_a())));
   }

   public void func_189540_a(IBlockState p_189540_1_, World p_189540_2_, BlockPos p_189540_3_, Block p_189540_4_, BlockPos p_189540_5_) {
      if (!p_189540_2_.field_72995_K) {
         boolean flag = p_189540_1_.func_177229_b(field_196502_a);
         if (flag != p_189540_2_.func_175640_z(p_189540_3_)) {
            if (flag) {
               p_189540_2_.func_205220_G_().func_205360_a(p_189540_3_, this, 4);
            } else {
               p_189540_2_.func_180501_a(p_189540_3_, p_189540_1_.func_177231_a(field_196502_a), 2);
            }
         }

      }
   }

   public void func_196267_b(IBlockState p_196267_1_, World p_196267_2_, BlockPos p_196267_3_, Random p_196267_4_) {
      if (!p_196267_2_.field_72995_K) {
         if (p_196267_1_.func_177229_b(field_196502_a) && !p_196267_2_.func_175640_z(p_196267_3_)) {
            p_196267_2_.func_180501_a(p_196267_3_, p_196267_1_.func_177231_a(field_196502_a), 2);
         }

      }
   }

   protected void func_206840_a(StateContainer.Builder<Block, IBlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_196502_a);
   }
}
