package net.minecraft.block;

import java.util.List;
import java.util.Random;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.World;
import net.minecraft.world.gen.feature.CompositeFlowerFeature;

public class BlockGrass extends BlockDirtSnowySpreadable implements IGrowable {
   public BlockGrass(Block.Properties p_i48388_1_) {
      super(p_i48388_1_);
   }

   public boolean func_176473_a(IBlockReader p_176473_1_, BlockPos p_176473_2_, IBlockState p_176473_3_, boolean p_176473_4_) {
      return p_176473_1_.func_180495_p(p_176473_2_.func_177984_a()).func_196958_f();
   }

   public boolean func_180670_a(World p_180670_1_, Random p_180670_2_, BlockPos p_180670_3_, IBlockState p_180670_4_) {
      return true;
   }

   public void func_176474_b(World p_176474_1_, Random p_176474_2_, BlockPos p_176474_3_, IBlockState p_176474_4_) {
      BlockPos blockpos = p_176474_3_.func_177984_a();
      IBlockState iblockstate = Blocks.field_150349_c.func_176223_P();

      for(int i = 0; i < 128; ++i) {
         BlockPos blockpos1 = blockpos;
         int j = 0;

         while(true) {
            if (j >= i / 16) {
               IBlockState iblockstate2 = p_176474_1_.func_180495_p(blockpos1);
               if (iblockstate2.func_177230_c() == iblockstate.func_177230_c() && p_176474_2_.nextInt(10) == 0) {
                  ((IGrowable)iblockstate.func_177230_c()).func_176474_b(p_176474_1_, p_176474_2_, blockpos1, iblockstate2);
               }

               if (!iblockstate2.func_196958_f()) {
                  break;
               }

               IBlockState iblockstate1;
               if (p_176474_2_.nextInt(8) == 0) {
                  List<CompositeFlowerFeature<?>> list = p_176474_1_.func_180494_b(blockpos1).func_201853_g();
                  if (list.isEmpty()) {
                     break;
                  }

                  iblockstate1 = list.get(0).func_202354_a(p_176474_2_, blockpos1);
               } else {
                  iblockstate1 = iblockstate;
               }

               if (iblockstate1.func_196955_c(p_176474_1_, blockpos1)) {
                  p_176474_1_.func_180501_a(blockpos1, iblockstate1, 3);
               }
               break;
            }

            blockpos1 = blockpos1.func_177982_a(p_176474_2_.nextInt(3) - 1, (p_176474_2_.nextInt(3) - 1) * p_176474_2_.nextInt(3) / 2, p_176474_2_.nextInt(3) - 1);
            if (p_176474_1_.func_180495_p(blockpos1.func_177977_b()).func_177230_c() != this || p_176474_1_.func_180495_p(blockpos1).func_185898_k()) {
               break;
            }

            ++j;
         }
      }

   }

   public boolean func_200124_e(IBlockState p_200124_1_) {
      return true;
   }

   public BlockRenderLayer func_180664_k() {
      return BlockRenderLayer.CUTOUT_MIPPED;
   }
}
