package net.minecraft.block;

import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.InventoryHelper;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.item.ItemStack;
import net.minecraft.pathfinding.PathType;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.DirectionProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.stats.StatList;
import net.minecraft.tileentity.IHopper;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityHopper;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.EnumBlockRenderType;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.IBooleanFunction;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.shapes.VoxelShapes;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.World;

public class BlockHopper extends BlockContainer {
   public static final DirectionProperty field_176430_a = BlockStateProperties.field_208156_I;
   public static final BooleanProperty field_176429_b = BlockStateProperties.field_208180_g;
   private static final VoxelShape field_196328_c = Block.func_208617_a(0.0D, 10.0D, 0.0D, 16.0D, 16.0D, 16.0D);
   private static final VoxelShape field_196339_z = Block.func_208617_a(4.0D, 4.0D, 4.0D, 12.0D, 10.0D, 12.0D);
   private static final VoxelShape field_199607_z = VoxelShapes.func_197872_a(field_196339_z, field_196328_c);
   private static final VoxelShape field_196326_A = VoxelShapes.func_197878_a(field_199607_z, IHopper.field_200101_a, IBooleanFunction.ONLY_FIRST);
   private static final VoxelShape field_196333_G = VoxelShapes.func_197872_a(field_196326_A, Block.func_208617_a(6.0D, 0.0D, 6.0D, 10.0D, 4.0D, 10.0D));
   private static final VoxelShape field_196334_H = VoxelShapes.func_197872_a(field_196326_A, Block.func_208617_a(12.0D, 4.0D, 6.0D, 16.0D, 8.0D, 10.0D));
   private static final VoxelShape field_196335_I = VoxelShapes.func_197872_a(field_196326_A, Block.func_208617_a(6.0D, 4.0D, 0.0D, 10.0D, 8.0D, 4.0D));
   private static final VoxelShape field_196336_J = VoxelShapes.func_197872_a(field_196326_A, Block.func_208617_a(6.0D, 4.0D, 12.0D, 10.0D, 8.0D, 16.0D));
   private static final VoxelShape field_196337_K = VoxelShapes.func_197872_a(field_196326_A, Block.func_208617_a(0.0D, 4.0D, 6.0D, 4.0D, 8.0D, 10.0D));
   private static final VoxelShape field_199602_G = IHopper.field_200101_a;
   private static final VoxelShape field_199603_H = VoxelShapes.func_197872_a(IHopper.field_200101_a, Block.func_208617_a(12.0D, 8.0D, 6.0D, 16.0D, 10.0D, 10.0D));
   private static final VoxelShape field_199604_I = VoxelShapes.func_197872_a(IHopper.field_200101_a, Block.func_208617_a(6.0D, 8.0D, 0.0D, 10.0D, 10.0D, 4.0D));
   private static final VoxelShape field_199605_J = VoxelShapes.func_197872_a(IHopper.field_200101_a, Block.func_208617_a(6.0D, 8.0D, 12.0D, 10.0D, 10.0D, 16.0D));
   private static final VoxelShape field_199606_K = VoxelShapes.func_197872_a(IHopper.field_200101_a, Block.func_208617_a(0.0D, 8.0D, 6.0D, 4.0D, 10.0D, 10.0D));

   public BlockHopper(Block.Properties p_i48378_1_) {
      super(p_i48378_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_176430_a, EnumFacing.DOWN).func_206870_a(field_176429_b, Boolean.valueOf(true)));
   }

   public VoxelShape func_196244_b(IBlockState p_196244_1_, IBlockReader p_196244_2_, BlockPos p_196244_3_) {
      switch((EnumFacing)p_196244_1_.func_177229_b(field_176430_a)) {
      case DOWN:
         return field_196333_G;
      case NORTH:
         return field_196335_I;
      case SOUTH:
         return field_196336_J;
      case WEST:
         return field_196337_K;
      case EAST:
         return field_196334_H;
      default:
         return field_196326_A;
      }
   }

   public VoxelShape func_199600_g(IBlockState p_199600_1_, IBlockReader p_199600_2_, BlockPos p_199600_3_) {
      switch((EnumFacing)p_199600_1_.func_177229_b(field_176430_a)) {
      case DOWN:
         return field_199602_G;
      case NORTH:
         return field_199604_I;
      case SOUTH:
         return field_199605_J;
      case WEST:
         return field_199606_K;
      case EAST:
         return field_199603_H;
      default:
         return IHopper.field_200101_a;
      }
   }

   public IBlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      EnumFacing enumfacing = p_196258_1_.func_196000_l().func_176734_d();
      return this.func_176223_P().func_206870_a(field_176430_a, enumfacing.func_176740_k() == EnumFacing.Axis.Y ? EnumFacing.DOWN : enumfacing).func_206870_a(field_176429_b, Boolean.valueOf(true));
   }

   public TileEntity func_196283_a_(IBlockReader p_196283_1_) {
      return new TileEntityHopper();
   }

   public void func_180633_a(World p_180633_1_, BlockPos p_180633_2_, IBlockState p_180633_3_, EntityLivingBase p_180633_4_, ItemStack p_180633_5_) {
      if (p_180633_5_.func_82837_s()) {
         TileEntity tileentity = p_180633_1_.func_175625_s(p_180633_2_);
         if (tileentity instanceof TileEntityHopper) {
            ((TileEntityHopper)tileentity).func_200226_a(p_180633_5_.func_200301_q());
         }
      }

   }

   public boolean func_185481_k(IBlockState p_185481_1_) {
      return true;
   }

   public void func_196259_b(IBlockState p_196259_1_, World p_196259_2_, BlockPos p_196259_3_, IBlockState p_196259_4_) {
      if (p_196259_4_.func_177230_c() != p_196259_1_.func_177230_c()) {
         this.func_176427_e(p_196259_2_, p_196259_3_, p_196259_1_);
      }
   }

   public boolean func_196250_a(IBlockState p_196250_1_, World p_196250_2_, BlockPos p_196250_3_, EntityPlayer p_196250_4_, EnumHand p_196250_5_, EnumFacing p_196250_6_, float p_196250_7_, float p_196250_8_, float p_196250_9_) {
      if (p_196250_2_.field_72995_K) {
         return true;
      } else {
         TileEntity tileentity = p_196250_2_.func_175625_s(p_196250_3_);
         if (tileentity instanceof TileEntityHopper) {
            p_196250_4_.func_71007_a((TileEntityHopper)tileentity);
            p_196250_4_.func_195066_a(StatList.field_188084_R);
         }

         return true;
      }
   }

   public void func_189540_a(IBlockState p_189540_1_, World p_189540_2_, BlockPos p_189540_3_, Block p_189540_4_, BlockPos p_189540_5_) {
      this.func_176427_e(p_189540_2_, p_189540_3_, p_189540_1_);
   }

   private void func_176427_e(World p_176427_1_, BlockPos p_176427_2_, IBlockState p_176427_3_) {
      boolean flag = !p_176427_1_.func_175640_z(p_176427_2_);
      if (flag != p_176427_3_.func_177229_b(field_176429_b)) {
         p_176427_1_.func_180501_a(p_176427_2_, p_176427_3_.func_206870_a(field_176429_b, Boolean.valueOf(flag)), 4);
      }

   }

   public void func_196243_a(IBlockState p_196243_1_, World p_196243_2_, BlockPos p_196243_3_, IBlockState p_196243_4_, boolean p_196243_5_) {
      if (p_196243_1_.func_177230_c() != p_196243_4_.func_177230_c()) {
         TileEntity tileentity = p_196243_2_.func_175625_s(p_196243_3_);
         if (tileentity instanceof TileEntityHopper) {
            InventoryHelper.func_180175_a(p_196243_2_, p_196243_3_, (TileEntityHopper)tileentity);
            p_196243_2_.func_175666_e(p_196243_3_, this);
         }

         super.func_196243_a(p_196243_1_, p_196243_2_, p_196243_3_, p_196243_4_, p_196243_5_);
      }
   }

   public EnumBlockRenderType func_149645_b(IBlockState p_149645_1_) {
      return EnumBlockRenderType.MODEL;
   }

   public boolean func_149686_d(IBlockState p_149686_1_) {
      return false;
   }

   public boolean func_149740_M(IBlockState p_149740_1_) {
      return true;
   }

   public int func_180641_l(IBlockState p_180641_1_, World p_180641_2_, BlockPos p_180641_3_) {
      return Container.func_178144_a(p_180641_2_.func_175625_s(p_180641_3_));
   }

   public BlockRenderLayer func_180664_k() {
      return BlockRenderLayer.CUTOUT_MIPPED;
   }

   public IBlockState func_185499_a(IBlockState p_185499_1_, Rotation p_185499_2_) {
      return p_185499_1_.func_206870_a(field_176430_a, p_185499_2_.func_185831_a(p_185499_1_.func_177229_b(field_176430_a)));
   }

   public IBlockState func_185471_a(IBlockState p_185471_1_, Mirror p_185471_2_) {
      return p_185471_1_.func_185907_a(p_185471_2_.func_185800_a(p_185471_1_.func_177229_b(field_176430_a)));
   }

   protected void func_206840_a(StateContainer.Builder<Block, IBlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_176430_a, field_176429_b);
   }

   public BlockFaceShape func_193383_a(IBlockReader p_193383_1_, IBlockState p_193383_2_, BlockPos p_193383_3_, EnumFacing p_193383_4_) {
      return p_193383_4_ == EnumFacing.UP ? BlockFaceShape.BOWL : BlockFaceShape.UNDEFINED;
   }

   public void func_196262_a(IBlockState p_196262_1_, World p_196262_2_, BlockPos p_196262_3_, Entity p_196262_4_) {
      TileEntity tileentity = p_196262_2_.func_175625_s(p_196262_3_);
      if (tileentity instanceof TileEntityHopper) {
         ((TileEntityHopper)tileentity).func_200113_a(p_196262_4_);
      }

   }

   public boolean func_196266_a(IBlockState p_196266_1_, IBlockReader p_196266_2_, BlockPos p_196266_3_, PathType p_196266_4_) {
      return false;
   }
}
