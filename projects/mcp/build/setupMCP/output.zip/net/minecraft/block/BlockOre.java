package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.util.IItemProvider;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.World;

public class BlockOre extends Block {
   public BlockOre(Block.Properties p_i48357_1_) {
      super(p_i48357_1_);
   }

   public IItemProvider func_199769_a(IBlockState p_199769_1_, World p_199769_2_, BlockPos p_199769_3_, int p_199769_4_) {
      if (this == Blocks.field_150365_q) {
         return Items.field_151044_h;
      } else if (this == Blocks.field_150482_ag) {
         return Items.field_151045_i;
      } else if (this == Blocks.field_150369_x) {
         return Items.field_196128_bn;
      } else if (this == Blocks.field_150412_bA) {
         return Items.field_151166_bC;
      } else {
         return (IItemProvider)(this == Blocks.field_196766_fg ? Items.field_151128_bU : this);
      }
   }

   public int func_196264_a(IBlockState p_196264_1_, Random p_196264_2_) {
      return this == Blocks.field_150369_x ? 4 + p_196264_2_.nextInt(5) : 1;
   }

   public int func_196251_a(IBlockState p_196251_1_, int p_196251_2_, World p_196251_3_, BlockPos p_196251_4_, Random p_196251_5_) {
      if (p_196251_2_ > 0 && this != this.func_199769_a(this.func_176194_O().func_177619_a().iterator().next(), p_196251_3_, p_196251_4_, p_196251_2_)) {
         int i = p_196251_5_.nextInt(p_196251_2_ + 2) - 1;
         if (i < 0) {
            i = 0;
         }

         return this.func_196264_a(p_196251_1_, p_196251_5_) * (i + 1);
      } else {
         return this.func_196264_a(p_196251_1_, p_196251_5_);
      }
   }

   public void func_196255_a(IBlockState p_196255_1_, World p_196255_2_, BlockPos p_196255_3_, float p_196255_4_, int p_196255_5_) {
      super.func_196255_a(p_196255_1_, p_196255_2_, p_196255_3_, p_196255_4_, p_196255_5_);
      if (this.func_199769_a(p_196255_1_, p_196255_2_, p_196255_3_, p_196255_5_) != this) {
         int i = 0;
         if (this == Blocks.field_150365_q) {
            i = MathHelper.func_76136_a(p_196255_2_.field_73012_v, 0, 2);
         } else if (this == Blocks.field_150482_ag) {
            i = MathHelper.func_76136_a(p_196255_2_.field_73012_v, 3, 7);
         } else if (this == Blocks.field_150412_bA) {
            i = MathHelper.func_76136_a(p_196255_2_.field_73012_v, 3, 7);
         } else if (this == Blocks.field_150369_x) {
            i = MathHelper.func_76136_a(p_196255_2_.field_73012_v, 2, 5);
         } else if (this == Blocks.field_196766_fg) {
            i = MathHelper.func_76136_a(p_196255_2_.field_73012_v, 2, 5);
         }

         this.func_180637_b(p_196255_2_, p_196255_3_, i);
      }

   }

   public ItemStack func_185473_a(IBlockReader p_185473_1_, BlockPos p_185473_2_, IBlockState p_185473_3_) {
      return new ItemStack(this);
   }
}
