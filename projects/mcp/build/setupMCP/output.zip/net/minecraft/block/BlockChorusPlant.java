package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.pathfinding.PathType;
import net.minecraft.state.StateContainer;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.IItemProvider;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.IWorldReaderBase;
import net.minecraft.world.World;

public class BlockChorusPlant extends BlockSixWay {
   protected BlockChorusPlant(Block.Properties p_i48428_1_) {
      super(0.3125F, p_i48428_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_196488_a, Boolean.valueOf(false)).func_206870_a(field_196490_b, Boolean.valueOf(false)).func_206870_a(field_196492_c, Boolean.valueOf(false)).func_206870_a(field_196495_y, Boolean.valueOf(false)).func_206870_a(field_196496_z, Boolean.valueOf(false)).func_206870_a(field_196489_A, Boolean.valueOf(false)));
   }

   public IBlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      return this.func_196497_a(p_196258_1_.func_195991_k(), p_196258_1_.func_195995_a());
   }

   public IBlockState func_196497_a(IBlockReader p_196497_1_, BlockPos p_196497_2_) {
      Block block = p_196497_1_.func_180495_p(p_196497_2_.func_177977_b()).func_177230_c();
      Block block1 = p_196497_1_.func_180495_p(p_196497_2_.func_177984_a()).func_177230_c();
      Block block2 = p_196497_1_.func_180495_p(p_196497_2_.func_177978_c()).func_177230_c();
      Block block3 = p_196497_1_.func_180495_p(p_196497_2_.func_177974_f()).func_177230_c();
      Block block4 = p_196497_1_.func_180495_p(p_196497_2_.func_177968_d()).func_177230_c();
      Block block5 = p_196497_1_.func_180495_p(p_196497_2_.func_177976_e()).func_177230_c();
      return this.func_176223_P().func_206870_a(field_196489_A, Boolean.valueOf(block == this || block == Blocks.field_185766_cS || block == Blocks.field_150377_bs)).func_206870_a(field_196496_z, Boolean.valueOf(block1 == this || block1 == Blocks.field_185766_cS)).func_206870_a(field_196488_a, Boolean.valueOf(block2 == this || block2 == Blocks.field_185766_cS)).func_206870_a(field_196490_b, Boolean.valueOf(block3 == this || block3 == Blocks.field_185766_cS)).func_206870_a(field_196492_c, Boolean.valueOf(block4 == this || block4 == Blocks.field_185766_cS)).func_206870_a(field_196495_y, Boolean.valueOf(block5 == this || block5 == Blocks.field_185766_cS));
   }

   public IBlockState func_196271_a(IBlockState p_196271_1_, EnumFacing p_196271_2_, IBlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      if (!p_196271_1_.func_196955_c(p_196271_4_, p_196271_5_)) {
         p_196271_4_.func_205220_G_().func_205360_a(p_196271_5_, this, 1);
         return super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
      } else {
         Block block = p_196271_3_.func_177230_c();
         boolean flag = block == this || block == Blocks.field_185766_cS || p_196271_2_ == EnumFacing.DOWN && block == Blocks.field_150377_bs;
         return p_196271_1_.func_206870_a(field_196491_B.get(p_196271_2_), Boolean.valueOf(flag));
      }
   }

   public void func_196267_b(IBlockState p_196267_1_, World p_196267_2_, BlockPos p_196267_3_, Random p_196267_4_) {
      if (!p_196267_1_.func_196955_c(p_196267_2_, p_196267_3_)) {
         p_196267_2_.func_175655_b(p_196267_3_, true);
      }

   }

   public IItemProvider func_199769_a(IBlockState p_199769_1_, World p_199769_2_, BlockPos p_199769_3_, int p_199769_4_) {
      return Items.field_185161_cS;
   }

   public int func_196264_a(IBlockState p_196264_1_, Random p_196264_2_) {
      return p_196264_2_.nextInt(2);
   }

   public boolean func_149686_d(IBlockState p_149686_1_) {
      return false;
   }

   public boolean func_196260_a(IBlockState p_196260_1_, IWorldReaderBase p_196260_2_, BlockPos p_196260_3_) {
      IBlockState iblockstate = p_196260_2_.func_180495_p(p_196260_3_.func_177977_b());
      boolean flag = !p_196260_2_.func_180495_p(p_196260_3_.func_177984_a()).func_196958_f() && !iblockstate.func_196958_f();

      for(EnumFacing enumfacing : EnumFacing.Plane.HORIZONTAL) {
         BlockPos blockpos = p_196260_3_.func_177972_a(enumfacing);
         Block block = p_196260_2_.func_180495_p(blockpos).func_177230_c();
         if (block == this) {
            if (flag) {
               return false;
            }

            Block block1 = p_196260_2_.func_180495_p(blockpos.func_177977_b()).func_177230_c();
            if (block1 == this || block1 == Blocks.field_150377_bs) {
               return true;
            }
         }
      }

      Block block2 = iblockstate.func_177230_c();
      return block2 == this || block2 == Blocks.field_150377_bs;
   }

   public BlockRenderLayer func_180664_k() {
      return BlockRenderLayer.CUTOUT;
   }

   protected void func_206840_a(StateContainer.Builder<Block, IBlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_196488_a, field_196490_b, field_196492_c, field_196495_y, field_196496_z, field_196489_A);
   }

   public BlockFaceShape func_193383_a(IBlockReader p_193383_1_, IBlockState p_193383_2_, BlockPos p_193383_3_, EnumFacing p_193383_4_) {
      return BlockFaceShape.UNDEFINED;
   }

   public boolean func_196266_a(IBlockState p_196266_1_, IBlockReader p_196266_2_, BlockPos p_196266_3_, PathType p_196266_4_) {
      return false;
   }
}
