package net.minecraft.block;

import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.IBlockState;
import net.minecraft.fluid.IFluidState;
import net.minecraft.init.Blocks;
import net.minecraft.init.Fluids;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.pathfinding.PathType;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.IWorldReaderBase;

public class BlockWall extends BlockFourWay {
   public static final BooleanProperty field_176256_a = BlockStateProperties.field_208149_B;
   private final VoxelShape[] field_196422_D;
   private final VoxelShape[] field_196423_E;

   public BlockWall(Block.Properties p_i48301_1_) {
      super(0.0F, 3.0F, 0.0F, 14.0F, 24.0F, p_i48301_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_176256_a, Boolean.valueOf(true)).func_206870_a(field_196409_a, Boolean.valueOf(false)).func_206870_a(field_196411_b, Boolean.valueOf(false)).func_206870_a(field_196413_c, Boolean.valueOf(false)).func_206870_a(field_196414_y, Boolean.valueOf(false)).func_206870_a(field_204514_u, Boolean.valueOf(false)));
      this.field_196422_D = this.func_196408_a(4.0F, 3.0F, 16.0F, 0.0F, 14.0F);
      this.field_196423_E = this.func_196408_a(4.0F, 3.0F, 24.0F, 0.0F, 24.0F);
   }

   public VoxelShape func_196244_b(IBlockState p_196244_1_, IBlockReader p_196244_2_, BlockPos p_196244_3_) {
      return p_196244_1_.func_177229_b(field_176256_a) ? this.field_196422_D[this.func_196406_i(p_196244_1_)] : super.func_196244_b(p_196244_1_, p_196244_2_, p_196244_3_);
   }

   public VoxelShape func_196268_f(IBlockState p_196268_1_, IBlockReader p_196268_2_, BlockPos p_196268_3_) {
      return p_196268_1_.func_177229_b(field_176256_a) ? this.field_196423_E[this.func_196406_i(p_196268_1_)] : super.func_196268_f(p_196268_1_, p_196268_2_, p_196268_3_);
   }

   public boolean func_149686_d(IBlockState p_149686_1_) {
      return false;
   }

   public boolean func_196266_a(IBlockState p_196266_1_, IBlockReader p_196266_2_, BlockPos p_196266_3_, PathType p_196266_4_) {
      return false;
   }

   private boolean func_196421_a(IBlockState p_196421_1_, BlockFaceShape p_196421_2_) {
      Block block = p_196421_1_.func_177230_c();
      boolean flag = p_196421_2_ == BlockFaceShape.MIDDLE_POLE_THICK || p_196421_2_ == BlockFaceShape.MIDDLE_POLE && block instanceof BlockFenceGate;
      return !func_194143_e(block) && p_196421_2_ == BlockFaceShape.SOLID || flag;
   }

   public static boolean func_194143_e(Block p_194143_0_) {
      return Block.func_193382_c(p_194143_0_) || p_194143_0_ == Blocks.field_180401_cv || p_194143_0_ == Blocks.field_150440_ba || p_194143_0_ == Blocks.field_150423_aK || p_194143_0_ == Blocks.field_196625_cS || p_194143_0_ == Blocks.field_196628_cT || p_194143_0_ == Blocks.field_185778_de || p_194143_0_ == Blocks.field_150335_W;
   }

   public IBlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      IWorldReaderBase iworldreaderbase = p_196258_1_.func_195991_k();
      BlockPos blockpos = p_196258_1_.func_195995_a();
      IFluidState ifluidstate = p_196258_1_.func_195991_k().func_204610_c(p_196258_1_.func_195995_a());
      BlockPos blockpos1 = blockpos.func_177978_c();
      BlockPos blockpos2 = blockpos.func_177974_f();
      BlockPos blockpos3 = blockpos.func_177968_d();
      BlockPos blockpos4 = blockpos.func_177976_e();
      IBlockState iblockstate = iworldreaderbase.func_180495_p(blockpos1);
      IBlockState iblockstate1 = iworldreaderbase.func_180495_p(blockpos2);
      IBlockState iblockstate2 = iworldreaderbase.func_180495_p(blockpos3);
      IBlockState iblockstate3 = iworldreaderbase.func_180495_p(blockpos4);
      boolean flag = this.func_196421_a(iblockstate, iblockstate.func_193401_d(iworldreaderbase, blockpos1, EnumFacing.SOUTH));
      boolean flag1 = this.func_196421_a(iblockstate1, iblockstate1.func_193401_d(iworldreaderbase, blockpos2, EnumFacing.WEST));
      boolean flag2 = this.func_196421_a(iblockstate2, iblockstate2.func_193401_d(iworldreaderbase, blockpos3, EnumFacing.NORTH));
      boolean flag3 = this.func_196421_a(iblockstate3, iblockstate3.func_193401_d(iworldreaderbase, blockpos4, EnumFacing.EAST));
      boolean flag4 = (!flag || flag1 || !flag2 || flag3) && (flag || !flag1 || flag2 || !flag3);
      return this.func_176223_P().func_206870_a(field_176256_a, Boolean.valueOf(flag4 || !iworldreaderbase.func_175623_d(blockpos.func_177984_a()))).func_206870_a(field_196409_a, Boolean.valueOf(flag)).func_206870_a(field_196411_b, Boolean.valueOf(flag1)).func_206870_a(field_196413_c, Boolean.valueOf(flag2)).func_206870_a(field_196414_y, Boolean.valueOf(flag3)).func_206870_a(field_204514_u, Boolean.valueOf(ifluidstate.func_206886_c() == Fluids.field_204546_a));
   }

   public IBlockState func_196271_a(IBlockState p_196271_1_, EnumFacing p_196271_2_, IBlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      if (p_196271_1_.func_177229_b(field_204514_u)) {
         p_196271_4_.func_205219_F_().func_205360_a(p_196271_5_, Fluids.field_204546_a, Fluids.field_204546_a.func_205569_a(p_196271_4_));
      }

      if (p_196271_2_ == EnumFacing.DOWN) {
         return super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
      } else {
         boolean flag = p_196271_2_ == EnumFacing.NORTH ? this.func_196421_a(p_196271_3_, p_196271_3_.func_193401_d(p_196271_4_, p_196271_6_, p_196271_2_.func_176734_d())) : p_196271_1_.func_177229_b(field_196409_a);
         boolean flag1 = p_196271_2_ == EnumFacing.EAST ? this.func_196421_a(p_196271_3_, p_196271_3_.func_193401_d(p_196271_4_, p_196271_6_, p_196271_2_.func_176734_d())) : p_196271_1_.func_177229_b(field_196411_b);
         boolean flag2 = p_196271_2_ == EnumFacing.SOUTH ? this.func_196421_a(p_196271_3_, p_196271_3_.func_193401_d(p_196271_4_, p_196271_6_, p_196271_2_.func_176734_d())) : p_196271_1_.func_177229_b(field_196413_c);
         boolean flag3 = p_196271_2_ == EnumFacing.WEST ? this.func_196421_a(p_196271_3_, p_196271_3_.func_193401_d(p_196271_4_, p_196271_6_, p_196271_2_.func_176734_d())) : p_196271_1_.func_177229_b(field_196414_y);
         boolean flag4 = (!flag || flag1 || !flag2 || flag3) && (flag || !flag1 || flag2 || !flag3);
         return p_196271_1_.func_206870_a(field_176256_a, Boolean.valueOf(flag4 || !p_196271_4_.func_175623_d(p_196271_5_.func_177984_a()))).func_206870_a(field_196409_a, Boolean.valueOf(flag)).func_206870_a(field_196411_b, Boolean.valueOf(flag1)).func_206870_a(field_196413_c, Boolean.valueOf(flag2)).func_206870_a(field_196414_y, Boolean.valueOf(flag3));
      }
   }

   protected void func_206840_a(StateContainer.Builder<Block, IBlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_176256_a, field_196409_a, field_196411_b, field_196414_y, field_196413_c, field_204514_u);
   }

   public BlockFaceShape func_193383_a(IBlockReader p_193383_1_, IBlockState p_193383_2_, BlockPos p_193383_3_, EnumFacing p_193383_4_) {
      return p_193383_4_ != EnumFacing.UP && p_193383_4_ != EnumFacing.DOWN ? BlockFaceShape.MIDDLE_POLE_THICK : BlockFaceShape.CENTER_BIG;
   }
}
