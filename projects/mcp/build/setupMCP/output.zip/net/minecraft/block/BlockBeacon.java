package net.minecraft.block;

import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.stats.StatList;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityBeacon;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.EnumBlockRenderType;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.HttpUtil;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraft.world.chunk.Chunk;

public class BlockBeacon extends BlockContainer {
   public BlockBeacon(Block.Properties p_i48443_1_) {
      super(p_i48443_1_);
   }

   public TileEntity func_196283_a_(IBlockReader p_196283_1_) {
      return new TileEntityBeacon();
   }

   public boolean func_196250_a(IBlockState p_196250_1_, World p_196250_2_, BlockPos p_196250_3_, EntityPlayer p_196250_4_, EnumHand p_196250_5_, EnumFacing p_196250_6_, float p_196250_7_, float p_196250_8_, float p_196250_9_) {
      if (p_196250_2_.field_72995_K) {
         return true;
      } else {
         TileEntity tileentity = p_196250_2_.func_175625_s(p_196250_3_);
         if (tileentity instanceof TileEntityBeacon) {
            p_196250_4_.func_71007_a((TileEntityBeacon)tileentity);
            p_196250_4_.func_195066_a(StatList.field_188082_P);
         }

         return true;
      }
   }

   public boolean func_149686_d(IBlockState p_149686_1_) {
      return false;
   }

   public EnumBlockRenderType func_149645_b(IBlockState p_149645_1_) {
      return EnumBlockRenderType.MODEL;
   }

   public void func_180633_a(World p_180633_1_, BlockPos p_180633_2_, IBlockState p_180633_3_, EntityLivingBase p_180633_4_, ItemStack p_180633_5_) {
      if (p_180633_5_.func_82837_s()) {
         TileEntity tileentity = p_180633_1_.func_175625_s(p_180633_2_);
         if (tileentity instanceof TileEntityBeacon) {
            ((TileEntityBeacon)tileentity).func_200227_a(p_180633_5_.func_200301_q());
         }
      }

   }

   public BlockRenderLayer func_180664_k() {
      return BlockRenderLayer.CUTOUT;
   }

   public static void func_176450_d(World p_176450_0_, BlockPos p_176450_1_) {
      HttpUtil.field_180193_a.submit(() -> {
         Chunk chunk = p_176450_0_.func_175726_f(p_176450_1_);

         for(int i = p_176450_1_.func_177956_o() - 1; i >= 0; --i) {
            BlockPos blockpos = new BlockPos(p_176450_1_.func_177958_n(), i, p_176450_1_.func_177952_p());
            if (!chunk.func_177444_d(blockpos)) {
               break;
            }

            IBlockState iblockstate = p_176450_0_.func_180495_p(blockpos);
            if (iblockstate.func_177230_c() == Blocks.field_150461_bJ) {
               ((WorldServer)p_176450_0_).func_152344_a(() -> {
                  TileEntity tileentity = p_176450_0_.func_175625_s(blockpos);
                  if (tileentity instanceof TileEntityBeacon) {
                     ((TileEntityBeacon)tileentity).func_174908_m();
                     p_176450_0_.func_175641_c(blockpos, Blocks.field_150461_bJ, 1, 0);
                  }

               });
            }
         }

      });
   }
}
