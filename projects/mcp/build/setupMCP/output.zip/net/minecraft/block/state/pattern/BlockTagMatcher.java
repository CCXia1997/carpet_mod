package net.minecraft.block.state.pattern;

import javax.annotation.Nullable;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.tags.Tag;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockReader;

public class BlockTagMatcher implements IBlockMatcherReaderAware<IBlockState> {
   private final Tag<Block> field_206905_a;

   public BlockTagMatcher(Tag<Block> p_i49004_1_) {
      this.field_206905_a = p_i49004_1_;
   }

   public static BlockTagMatcher func_206904_a(Tag<Block> p_206904_0_) {
      return new BlockTagMatcher(p_206904_0_);
   }

   public boolean test(@Nullable IBlockState p_test_1_, IBlockReader p_test_2_, BlockPos p_test_3_) {
      return p_test_1_ != null && p_test_1_.func_203425_a(this.field_206905_a);
   }
}
