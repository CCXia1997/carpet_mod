package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.state.IntegerProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.util.IItemProvider;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorldReaderBase;
import net.minecraft.world.World;

public class BlockCrops extends BlockBush implements IGrowable {
   public static final IntegerProperty field_176488_a = BlockStateProperties.field_208170_W;
   private static final VoxelShape[] field_196393_a = new VoxelShape[]{Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 2.0D, 16.0D), Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 4.0D, 16.0D), Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 6.0D, 16.0D), Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 8.0D, 16.0D), Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 10.0D, 16.0D), Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 12.0D, 16.0D), Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 14.0D, 16.0D), Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 16.0D, 16.0D)};

   protected BlockCrops(Block.Properties p_i48421_1_) {
      super(p_i48421_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(this.func_185524_e(), Integer.valueOf(0)));
   }

   public VoxelShape func_196244_b(IBlockState p_196244_1_, IBlockReader p_196244_2_, BlockPos p_196244_3_) {
      return field_196393_a[p_196244_1_.func_177229_b(this.func_185524_e())];
   }

   protected boolean func_200014_a_(IBlockState p_200014_1_, IBlockReader p_200014_2_, BlockPos p_200014_3_) {
      return p_200014_1_.func_177230_c() == Blocks.field_150458_ak;
   }

   public IntegerProperty func_185524_e() {
      return field_176488_a;
   }

   public int func_185526_g() {
      return 7;
   }

   protected int func_185527_x(IBlockState p_185527_1_) {
      return p_185527_1_.func_177229_b(this.func_185524_e());
   }

   public IBlockState func_185528_e(int p_185528_1_) {
      return this.func_176223_P().func_206870_a(this.func_185524_e(), Integer.valueOf(p_185528_1_));
   }

   public boolean func_185525_y(IBlockState p_185525_1_) {
      return p_185525_1_.func_177229_b(this.func_185524_e()) >= this.func_185526_g();
   }

   public void func_196267_b(IBlockState p_196267_1_, World p_196267_2_, BlockPos p_196267_3_, Random p_196267_4_) {
      super.func_196267_b(p_196267_1_, p_196267_2_, p_196267_3_, p_196267_4_);
      if (p_196267_2_.func_201669_a(p_196267_3_.func_177984_a(), 0) >= 9) {
         int i = this.func_185527_x(p_196267_1_);
         if (i < this.func_185526_g()) {
            float f = func_180672_a(this, p_196267_2_, p_196267_3_);
            if (p_196267_4_.nextInt((int)(25.0F / f) + 1) == 0) {
               p_196267_2_.func_180501_a(p_196267_3_, this.func_185528_e(i + 1), 2);
            }
         }
      }

   }

   public void func_176487_g(World p_176487_1_, BlockPos p_176487_2_, IBlockState p_176487_3_) {
      int i = this.func_185527_x(p_176487_3_) + this.func_185529_b(p_176487_1_);
      int j = this.func_185526_g();
      if (i > j) {
         i = j;
      }

      p_176487_1_.func_180501_a(p_176487_2_, this.func_185528_e(i), 2);
   }

   protected int func_185529_b(World p_185529_1_) {
      return MathHelper.func_76136_a(p_185529_1_.field_73012_v, 2, 5);
   }

   protected static float func_180672_a(Block p_180672_0_, IBlockReader p_180672_1_, BlockPos p_180672_2_) {
      float f = 1.0F;
      BlockPos blockpos = p_180672_2_.func_177977_b();

      for(int i = -1; i <= 1; ++i) {
         for(int j = -1; j <= 1; ++j) {
            float f1 = 0.0F;
            IBlockState iblockstate = p_180672_1_.func_180495_p(blockpos.func_177982_a(i, 0, j));
            if (iblockstate.func_177230_c() == Blocks.field_150458_ak) {
               f1 = 1.0F;
               if (iblockstate.func_177229_b(BlockFarmland.field_176531_a) > 0) {
                  f1 = 3.0F;
               }
            }

            if (i != 0 || j != 0) {
               f1 /= 4.0F;
            }

            f += f1;
         }
      }

      BlockPos blockpos1 = p_180672_2_.func_177978_c();
      BlockPos blockpos2 = p_180672_2_.func_177968_d();
      BlockPos blockpos3 = p_180672_2_.func_177976_e();
      BlockPos blockpos4 = p_180672_2_.func_177974_f();
      boolean flag = p_180672_0_ == p_180672_1_.func_180495_p(blockpos3).func_177230_c() || p_180672_0_ == p_180672_1_.func_180495_p(blockpos4).func_177230_c();
      boolean flag1 = p_180672_0_ == p_180672_1_.func_180495_p(blockpos1).func_177230_c() || p_180672_0_ == p_180672_1_.func_180495_p(blockpos2).func_177230_c();
      if (flag && flag1) {
         f /= 2.0F;
      } else {
         boolean flag2 = p_180672_0_ == p_180672_1_.func_180495_p(blockpos3.func_177978_c()).func_177230_c() || p_180672_0_ == p_180672_1_.func_180495_p(blockpos4.func_177978_c()).func_177230_c() || p_180672_0_ == p_180672_1_.func_180495_p(blockpos4.func_177968_d()).func_177230_c() || p_180672_0_ == p_180672_1_.func_180495_p(blockpos3.func_177968_d()).func_177230_c();
         if (flag2) {
            f /= 2.0F;
         }
      }

      return f;
   }

   public boolean func_196260_a(IBlockState p_196260_1_, IWorldReaderBase p_196260_2_, BlockPos p_196260_3_) {
      return (p_196260_2_.func_201669_a(p_196260_3_, 0) >= 8 || p_196260_2_.func_175678_i(p_196260_3_)) && super.func_196260_a(p_196260_1_, p_196260_2_, p_196260_3_);
   }

   protected IItemProvider func_199772_f() {
      return Items.field_151014_N;
   }

   protected IItemProvider func_199773_g() {
      return Items.field_151015_O;
   }

   public void func_196255_a(IBlockState p_196255_1_, World p_196255_2_, BlockPos p_196255_3_, float p_196255_4_, int p_196255_5_) {
      super.func_196255_a(p_196255_1_, p_196255_2_, p_196255_3_, p_196255_4_, 0);
      if (!p_196255_2_.field_72995_K) {
         int i = this.func_185527_x(p_196255_1_);
         if (i >= this.func_185526_g()) {
            int j = 3 + p_196255_5_;

            for(int k = 0; k < j; ++k) {
               if (p_196255_2_.field_73012_v.nextInt(2 * this.func_185526_g()) <= i) {
                  func_180635_a(p_196255_2_, p_196255_3_, new ItemStack(this.func_199772_f()));
               }
            }
         }

      }
   }

   public IItemProvider func_199769_a(IBlockState p_199769_1_, World p_199769_2_, BlockPos p_199769_3_, int p_199769_4_) {
      return this.func_185525_y(p_199769_1_) ? this.func_199773_g() : this.func_199772_f();
   }

   public ItemStack func_185473_a(IBlockReader p_185473_1_, BlockPos p_185473_2_, IBlockState p_185473_3_) {
      return new ItemStack(this.func_199772_f());
   }

   public boolean func_176473_a(IBlockReader p_176473_1_, BlockPos p_176473_2_, IBlockState p_176473_3_, boolean p_176473_4_) {
      return !this.func_185525_y(p_176473_3_);
   }

   public boolean func_180670_a(World p_180670_1_, Random p_180670_2_, BlockPos p_180670_3_, IBlockState p_180670_4_) {
      return true;
   }

   public void func_176474_b(World p_176474_1_, Random p_176474_2_, BlockPos p_176474_3_, IBlockState p_176474_4_) {
      this.func_176487_g(p_176474_1_, p_176474_3_, p_176474_4_);
   }

   protected void func_206840_a(StateContainer.Builder<Block, IBlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_176488_a);
   }
}
