package net.minecraft.block;

import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.state.IBlockState;
import net.minecraft.fluid.Fluid;
import net.minecraft.fluid.IFluidState;
import net.minecraft.init.Blocks;
import net.minecraft.init.Fluids;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.IntegerProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.IWorldReaderBase;
import net.minecraft.world.World;

public class BlockSeaPickle extends BlockBush implements IGrowable, IBucketPickupHandler, ILiquidContainer {
   public static final IntegerProperty field_204902_a = BlockStateProperties.field_208135_aj;
   public static final BooleanProperty field_204903_b = BlockStateProperties.field_208198_y;
   protected static final VoxelShape field_204904_c = Block.func_208617_a(6.0D, 0.0D, 6.0D, 10.0D, 6.0D, 10.0D);
   protected static final VoxelShape field_204905_t = Block.func_208617_a(3.0D, 0.0D, 3.0D, 13.0D, 6.0D, 13.0D);
   protected static final VoxelShape field_204906_u = Block.func_208617_a(2.0D, 0.0D, 2.0D, 14.0D, 6.0D, 14.0D);
   protected static final VoxelShape field_204907_v = Block.func_208617_a(2.0D, 0.0D, 2.0D, 14.0D, 7.0D, 14.0D);

   protected BlockSeaPickle(Block.Properties p_i48924_1_) {
      super(p_i48924_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_204902_a, Integer.valueOf(1)).func_206870_a(field_204903_b, Boolean.valueOf(true)));
   }

   public int func_149750_m(IBlockState p_149750_1_) {
      return this.func_204901_j(p_149750_1_) ? 0 : super.func_149750_m(p_149750_1_) + 3 * p_149750_1_.func_177229_b(field_204902_a);
   }

   @Nullable
   public IBlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      IBlockState iblockstate = p_196258_1_.func_195991_k().func_180495_p(p_196258_1_.func_195995_a());
      if (iblockstate.func_177230_c() == this) {
         return iblockstate.func_206870_a(field_204902_a, Integer.valueOf(Math.min(4, iblockstate.func_177229_b(field_204902_a) + 1)));
      } else {
         IFluidState ifluidstate = p_196258_1_.func_195991_k().func_204610_c(p_196258_1_.func_195995_a());
         boolean flag = ifluidstate.func_206884_a(FluidTags.field_206959_a) && ifluidstate.func_206882_g() == 8;
         return super.func_196258_a(p_196258_1_).func_206870_a(field_204903_b, Boolean.valueOf(flag));
      }
   }

   private boolean func_204901_j(IBlockState p_204901_1_) {
      return !p_204901_1_.func_177229_b(field_204903_b);
   }

   protected boolean func_200014_a_(IBlockState p_200014_1_, IBlockReader p_200014_2_, BlockPos p_200014_3_) {
      return !p_200014_1_.func_196952_d(p_200014_2_, p_200014_3_).func_212434_a(EnumFacing.UP).func_197766_b();
   }

   public boolean func_196260_a(IBlockState p_196260_1_, IWorldReaderBase p_196260_2_, BlockPos p_196260_3_) {
      BlockPos blockpos = p_196260_3_.func_177977_b();
      return this.func_200014_a_(p_196260_2_.func_180495_p(blockpos), p_196260_2_, blockpos);
   }

   public IBlockState func_196271_a(IBlockState p_196271_1_, EnumFacing p_196271_2_, IBlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      if (!p_196271_1_.func_196955_c(p_196271_4_, p_196271_5_)) {
         return Blocks.field_150350_a.func_176223_P();
      } else {
         if (p_196271_1_.func_177229_b(field_204903_b)) {
            p_196271_4_.func_205219_F_().func_205360_a(p_196271_5_, Fluids.field_204546_a, Fluids.field_204546_a.func_205569_a(p_196271_4_));
         }

         return super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
      }
   }

   public boolean func_196253_a(IBlockState p_196253_1_, BlockItemUseContext p_196253_2_) {
      return p_196253_2_.func_195996_i().func_77973_b() == this.func_199767_j() && p_196253_1_.func_177229_b(field_204902_a) < 4 ? true : super.func_196253_a(p_196253_1_, p_196253_2_);
   }

   public VoxelShape func_196244_b(IBlockState p_196244_1_, IBlockReader p_196244_2_, BlockPos p_196244_3_) {
      switch(p_196244_1_.func_177229_b(field_204902_a)) {
      case 1:
      default:
         return field_204904_c;
      case 2:
         return field_204905_t;
      case 3:
         return field_204906_u;
      case 4:
         return field_204907_v;
      }
   }

   public Fluid func_204508_a(IWorld p_204508_1_, BlockPos p_204508_2_, IBlockState p_204508_3_) {
      if (p_204508_3_.func_177229_b(field_204903_b)) {
         p_204508_1_.func_180501_a(p_204508_2_, p_204508_3_.func_206870_a(field_204903_b, Boolean.valueOf(false)), 3);
         return Fluids.field_204546_a;
      } else {
         return Fluids.field_204541_a;
      }
   }

   public IFluidState func_204507_t(IBlockState p_204507_1_) {
      return p_204507_1_.func_177229_b(field_204903_b) ? Fluids.field_204546_a.func_207204_a(false) : super.func_204507_t(p_204507_1_);
   }

   public boolean func_204510_a(IBlockReader p_204510_1_, BlockPos p_204510_2_, IBlockState p_204510_3_, Fluid p_204510_4_) {
      return !p_204510_3_.func_177229_b(field_204903_b) && p_204510_4_ == Fluids.field_204546_a;
   }

   public boolean func_204509_a(IWorld p_204509_1_, BlockPos p_204509_2_, IBlockState p_204509_3_, IFluidState p_204509_4_) {
      if (!p_204509_3_.func_177229_b(field_204903_b) && p_204509_4_.func_206886_c() == Fluids.field_204546_a) {
         if (!p_204509_1_.func_201670_d()) {
            p_204509_1_.func_180501_a(p_204509_2_, p_204509_3_.func_206870_a(field_204903_b, Boolean.valueOf(true)), 3);
            p_204509_1_.func_205219_F_().func_205360_a(p_204509_2_, p_204509_4_.func_206886_c(), p_204509_4_.func_206886_c().func_205569_a(p_204509_1_));
         }

         return true;
      } else {
         return false;
      }
   }

   protected void func_206840_a(StateContainer.Builder<Block, IBlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_204902_a, field_204903_b);
   }

   public int func_196264_a(IBlockState p_196264_1_, Random p_196264_2_) {
      return p_196264_1_.func_177229_b(field_204902_a);
   }

   public boolean func_176473_a(IBlockReader p_176473_1_, BlockPos p_176473_2_, IBlockState p_176473_3_, boolean p_176473_4_) {
      return true;
   }

   public boolean func_180670_a(World p_180670_1_, Random p_180670_2_, BlockPos p_180670_3_, IBlockState p_180670_4_) {
      return true;
   }

   public void func_176474_b(World p_176474_1_, Random p_176474_2_, BlockPos p_176474_3_, IBlockState p_176474_4_) {
      if (!this.func_204901_j(p_176474_4_) && p_176474_1_.func_180495_p(p_176474_3_.func_177977_b()).func_203425_a(BlockTags.field_205598_B)) {
         int i = 5;
         int j = 1;
         int k = 2;
         int l = 0;
         int i1 = p_176474_3_.func_177958_n() - 2;
         int j1 = 0;

         for(int k1 = 0; k1 < 5; ++k1) {
            for(int l1 = 0; l1 < j; ++l1) {
               int i2 = 2 + p_176474_3_.func_177956_o() - 1;

               for(int j2 = i2 - 2; j2 < i2; ++j2) {
                  BlockPos blockpos = new BlockPos(i1 + k1, j2, p_176474_3_.func_177952_p() - j1 + l1);
                  if (blockpos != p_176474_3_ && p_176474_2_.nextInt(6) == 0 && p_176474_1_.func_180495_p(blockpos).func_177230_c() == Blocks.field_150355_j) {
                     IBlockState iblockstate = p_176474_1_.func_180495_p(blockpos.func_177977_b());
                     if (iblockstate.func_203425_a(BlockTags.field_205598_B)) {
                        p_176474_1_.func_180501_a(blockpos, Blocks.field_204913_jW.func_176223_P().func_206870_a(field_204902_a, Integer.valueOf(p_176474_2_.nextInt(4) + 1)), 3);
                     }
                  }
               }
            }

            if (l < 2) {
               j += 2;
               ++j1;
            } else {
               j -= 2;
               --j1;
            }

            ++l;
         }

         p_176474_1_.func_180501_a(p_176474_3_, p_176474_4_.func_206870_a(field_204902_a, Integer.valueOf(4)), 2);
      }

   }
}
