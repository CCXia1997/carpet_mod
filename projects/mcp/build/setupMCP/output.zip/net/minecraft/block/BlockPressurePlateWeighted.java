package net.minecraft.block;

import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.state.IntegerProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.IWorld;
import net.minecraft.world.IWorldReaderBase;
import net.minecraft.world.World;

public class BlockPressurePlateWeighted extends BlockBasePressurePlate {
   public static final IntegerProperty field_176579_a = BlockStateProperties.field_208136_ak;
   private final int field_150068_a;

   protected BlockPressurePlateWeighted(int p_i48295_1_, Block.Properties p_i48295_2_) {
      super(p_i48295_2_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_176579_a, Integer.valueOf(0)));
      this.field_150068_a = p_i48295_1_;
   }

   protected int func_180669_e(World p_180669_1_, BlockPos p_180669_2_) {
      int i = Math.min(p_180669_1_.func_72872_a(Entity.class, field_185511_c.func_186670_a(p_180669_2_)).size(), this.field_150068_a);
      if (i > 0) {
         float f = (float)Math.min(this.field_150068_a, i) / (float)this.field_150068_a;
         return MathHelper.func_76123_f(f * 15.0F);
      } else {
         return 0;
      }
   }

   protected void func_185507_b(IWorld p_185507_1_, BlockPos p_185507_2_) {
      p_185507_1_.func_184133_a((EntityPlayer)null, p_185507_2_, SoundEvents.field_187776_dp, SoundCategory.BLOCKS, 0.3F, 0.90000004F);
   }

   protected void func_185508_c(IWorld p_185508_1_, BlockPos p_185508_2_) {
      p_185508_1_.func_184133_a((EntityPlayer)null, p_185508_2_, SoundEvents.field_187774_do, SoundCategory.BLOCKS, 0.3F, 0.75F);
   }

   protected int func_176576_e(IBlockState p_176576_1_) {
      return p_176576_1_.func_177229_b(field_176579_a);
   }

   protected IBlockState func_176575_a(IBlockState p_176575_1_, int p_176575_2_) {
      return p_176575_1_.func_206870_a(field_176579_a, Integer.valueOf(p_176575_2_));
   }

   public int func_149738_a(IWorldReaderBase p_149738_1_) {
      return 10;
   }

   protected void func_206840_a(StateContainer.Builder<Block, IBlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_176579_a);
   }
}
