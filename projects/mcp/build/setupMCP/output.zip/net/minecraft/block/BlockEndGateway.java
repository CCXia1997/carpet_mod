package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Particles;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityEndGateway;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.World;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class BlockEndGateway extends BlockContainer {
   protected BlockEndGateway(Block.Properties p_i48407_1_) {
      super(p_i48407_1_);
   }

   public TileEntity func_196283_a_(IBlockReader p_196283_1_) {
      return new TileEntityEndGateway();
   }

   public boolean func_149686_d(IBlockState p_149686_1_) {
      return false;
   }

   public int func_196264_a(IBlockState p_196264_1_, Random p_196264_2_) {
      return 0;
   }

   @OnlyIn(Dist.CLIENT)
   public void func_180655_c(IBlockState p_180655_1_, World p_180655_2_, BlockPos p_180655_3_, Random p_180655_4_) {
      TileEntity tileentity = p_180655_2_.func_175625_s(p_180655_3_);
      if (tileentity instanceof TileEntityEndGateway) {
         int i = ((TileEntityEndGateway)tileentity).func_195493_h();

         for(int j = 0; j < i; ++j) {
            double d0 = (double)((float)p_180655_3_.func_177958_n() + p_180655_4_.nextFloat());
            double d1 = (double)((float)p_180655_3_.func_177956_o() + p_180655_4_.nextFloat());
            double d2 = (double)((float)p_180655_3_.func_177952_p() + p_180655_4_.nextFloat());
            double d3 = ((double)p_180655_4_.nextFloat() - 0.5D) * 0.5D;
            double d4 = ((double)p_180655_4_.nextFloat() - 0.5D) * 0.5D;
            double d5 = ((double)p_180655_4_.nextFloat() - 0.5D) * 0.5D;
            int k = p_180655_4_.nextInt(2) * 2 - 1;
            if (p_180655_4_.nextBoolean()) {
               d2 = (double)p_180655_3_.func_177952_p() + 0.5D + 0.25D * (double)k;
               d5 = (double)(p_180655_4_.nextFloat() * 2.0F * (float)k);
            } else {
               d0 = (double)p_180655_3_.func_177958_n() + 0.5D + 0.25D * (double)k;
               d3 = (double)(p_180655_4_.nextFloat() * 2.0F * (float)k);
            }

            p_180655_2_.func_195594_a(Particles.field_197599_J, d0, d1, d2, d3, d4, d5);
         }

      }
   }

   public ItemStack func_185473_a(IBlockReader p_185473_1_, BlockPos p_185473_2_, IBlockState p_185473_3_) {
      return ItemStack.field_190927_a;
   }

   public BlockFaceShape func_193383_a(IBlockReader p_193383_1_, IBlockState p_193383_2_, BlockPos p_193383_3_, EnumFacing p_193383_4_) {
      return BlockFaceShape.UNDEFINED;
   }
}
