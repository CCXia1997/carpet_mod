package net.minecraft.block;

import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.pathfinding.PathType;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.shapes.VoxelShapes;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.World;

public class BlockFenceGate extends BlockHorizontal {
   public static final BooleanProperty field_176466_a = BlockStateProperties.field_208193_t;
   public static final BooleanProperty field_176465_b = BlockStateProperties.field_208194_u;
   public static final BooleanProperty field_176467_M = BlockStateProperties.field_208189_p;
   protected static final VoxelShape field_185541_d = Block.func_208617_a(0.0D, 0.0D, 6.0D, 16.0D, 16.0D, 10.0D);
   protected static final VoxelShape field_185542_e = Block.func_208617_a(6.0D, 0.0D, 0.0D, 10.0D, 16.0D, 16.0D);
   protected static final VoxelShape field_185543_f = Block.func_208617_a(0.0D, 0.0D, 6.0D, 16.0D, 13.0D, 10.0D);
   protected static final VoxelShape field_185544_g = Block.func_208617_a(6.0D, 0.0D, 0.0D, 10.0D, 13.0D, 16.0D);
   protected static final VoxelShape field_208068_x = Block.func_208617_a(0.0D, 0.0D, 6.0D, 16.0D, 24.0D, 10.0D);
   protected static final VoxelShape field_185540_C = Block.func_208617_a(6.0D, 0.0D, 0.0D, 10.0D, 24.0D, 16.0D);
   protected static final VoxelShape field_208069_z = VoxelShapes.func_197872_a(Block.func_208617_a(0.0D, 5.0D, 7.0D, 2.0D, 16.0D, 9.0D), Block.func_208617_a(14.0D, 5.0D, 7.0D, 16.0D, 16.0D, 9.0D));
   protected static final VoxelShape field_185539_B = VoxelShapes.func_197872_a(Block.func_208617_a(7.0D, 5.0D, 0.0D, 9.0D, 16.0D, 2.0D), Block.func_208617_a(7.0D, 5.0D, 14.0D, 9.0D, 16.0D, 16.0D));
   protected static final VoxelShape field_208066_B = VoxelShapes.func_197872_a(Block.func_208617_a(0.0D, 2.0D, 7.0D, 2.0D, 13.0D, 9.0D), Block.func_208617_a(14.0D, 2.0D, 7.0D, 16.0D, 13.0D, 9.0D));
   protected static final VoxelShape field_208067_C = VoxelShapes.func_197872_a(Block.func_208617_a(7.0D, 2.0D, 0.0D, 9.0D, 13.0D, 2.0D), Block.func_208617_a(7.0D, 2.0D, 14.0D, 9.0D, 13.0D, 16.0D));

   public BlockFenceGate(Block.Properties p_i48398_1_) {
      super(p_i48398_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_176466_a, Boolean.valueOf(false)).func_206870_a(field_176465_b, Boolean.valueOf(false)).func_206870_a(field_176467_M, Boolean.valueOf(false)));
   }

   public VoxelShape func_196244_b(IBlockState p_196244_1_, IBlockReader p_196244_2_, BlockPos p_196244_3_) {
      if (p_196244_1_.func_177229_b(field_176467_M)) {
         return p_196244_1_.func_177229_b(field_185512_D).func_176740_k() == EnumFacing.Axis.X ? field_185544_g : field_185543_f;
      } else {
         return p_196244_1_.func_177229_b(field_185512_D).func_176740_k() == EnumFacing.Axis.X ? field_185542_e : field_185541_d;
      }
   }

   public IBlockState func_196271_a(IBlockState p_196271_1_, EnumFacing p_196271_2_, IBlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      EnumFacing.Axis enumfacing$axis = p_196271_2_.func_176740_k();
      if (p_196271_1_.func_177229_b(field_185512_D).func_176746_e().func_176740_k() != enumfacing$axis) {
         return super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
      } else {
         boolean flag = this.func_196380_i(p_196271_3_) || this.func_196380_i(p_196271_4_.func_180495_p(p_196271_5_.func_177972_a(p_196271_2_.func_176734_d())));
         return p_196271_1_.func_206870_a(field_176467_M, Boolean.valueOf(flag));
      }
   }

   public VoxelShape func_196268_f(IBlockState p_196268_1_, IBlockReader p_196268_2_, BlockPos p_196268_3_) {
      if (p_196268_1_.func_177229_b(field_176466_a)) {
         return VoxelShapes.func_197880_a();
      } else {
         return p_196268_1_.func_177229_b(field_185512_D).func_176740_k() == EnumFacing.Axis.Z ? field_208068_x : field_185540_C;
      }
   }

   public VoxelShape func_196247_c(IBlockState p_196247_1_, IBlockReader p_196247_2_, BlockPos p_196247_3_) {
      if (p_196247_1_.func_177229_b(field_176467_M)) {
         return p_196247_1_.func_177229_b(field_185512_D).func_176740_k() == EnumFacing.Axis.X ? field_208067_C : field_208066_B;
      } else {
         return p_196247_1_.func_177229_b(field_185512_D).func_176740_k() == EnumFacing.Axis.X ? field_185539_B : field_208069_z;
      }
   }

   public boolean func_149686_d(IBlockState p_149686_1_) {
      return false;
   }

   public boolean func_196266_a(IBlockState p_196266_1_, IBlockReader p_196266_2_, BlockPos p_196266_3_, PathType p_196266_4_) {
      switch(p_196266_4_) {
      case LAND:
         return p_196266_1_.func_177229_b(field_176466_a);
      case WATER:
         return false;
      case AIR:
         return p_196266_1_.func_177229_b(field_176466_a);
      default:
         return false;
      }
   }

   public IBlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      World world = p_196258_1_.func_195991_k();
      BlockPos blockpos = p_196258_1_.func_195995_a();
      boolean flag = world.func_175640_z(blockpos);
      EnumFacing enumfacing = p_196258_1_.func_195992_f();
      EnumFacing.Axis enumfacing$axis = enumfacing.func_176740_k();
      boolean flag1 = enumfacing$axis == EnumFacing.Axis.Z && (this.func_196380_i(world.func_180495_p(blockpos.func_177976_e())) || this.func_196380_i(world.func_180495_p(blockpos.func_177974_f()))) || enumfacing$axis == EnumFacing.Axis.X && (this.func_196380_i(world.func_180495_p(blockpos.func_177978_c())) || this.func_196380_i(world.func_180495_p(blockpos.func_177968_d())));
      return this.func_176223_P().func_206870_a(field_185512_D, enumfacing).func_206870_a(field_176466_a, Boolean.valueOf(flag)).func_206870_a(field_176465_b, Boolean.valueOf(flag)).func_206870_a(field_176467_M, Boolean.valueOf(flag1));
   }

   private boolean func_196380_i(IBlockState p_196380_1_) {
      return p_196380_1_.func_177230_c() == Blocks.field_150463_bK || p_196380_1_.func_177230_c() == Blocks.field_196723_eg;
   }

   public boolean func_196250_a(IBlockState p_196250_1_, World p_196250_2_, BlockPos p_196250_3_, EntityPlayer p_196250_4_, EnumHand p_196250_5_, EnumFacing p_196250_6_, float p_196250_7_, float p_196250_8_, float p_196250_9_) {
      if (p_196250_1_.func_177229_b(field_176466_a)) {
         p_196250_1_ = p_196250_1_.func_206870_a(field_176466_a, Boolean.valueOf(false));
         p_196250_2_.func_180501_a(p_196250_3_, p_196250_1_, 10);
      } else {
         EnumFacing enumfacing = p_196250_4_.func_174811_aO();
         if (p_196250_1_.func_177229_b(field_185512_D) == enumfacing.func_176734_d()) {
            p_196250_1_ = p_196250_1_.func_206870_a(field_185512_D, enumfacing);
         }

         p_196250_1_ = p_196250_1_.func_206870_a(field_176466_a, Boolean.valueOf(true));
         p_196250_2_.func_180501_a(p_196250_3_, p_196250_1_, 10);
      }

      p_196250_2_.func_180498_a(p_196250_4_, p_196250_1_.func_177229_b(field_176466_a) ? 1008 : 1014, p_196250_3_, 0);
      return true;
   }

   public void func_189540_a(IBlockState p_189540_1_, World p_189540_2_, BlockPos p_189540_3_, Block p_189540_4_, BlockPos p_189540_5_) {
      if (!p_189540_2_.field_72995_K) {
         boolean flag = p_189540_2_.func_175640_z(p_189540_3_);
         if (p_189540_1_.func_177229_b(field_176465_b) != flag) {
            p_189540_2_.func_180501_a(p_189540_3_, p_189540_1_.func_206870_a(field_176465_b, Boolean.valueOf(flag)).func_206870_a(field_176466_a, Boolean.valueOf(flag)), 2);
            if (p_189540_1_.func_177229_b(field_176466_a) != flag) {
               p_189540_2_.func_180498_a((EntityPlayer)null, flag ? 1008 : 1014, p_189540_3_, 0);
            }
         }

      }
   }

   protected void func_206840_a(StateContainer.Builder<Block, IBlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_185512_D, field_176466_a, field_176465_b, field_176467_M);
   }

   public BlockFaceShape func_193383_a(IBlockReader p_193383_1_, IBlockState p_193383_2_, BlockPos p_193383_3_, EnumFacing p_193383_4_) {
      if (p_193383_4_ != EnumFacing.UP && p_193383_4_ != EnumFacing.DOWN) {
         return p_193383_2_.func_177229_b(field_185512_D).func_176740_k() == p_193383_4_.func_176746_e().func_176740_k() ? BlockFaceShape.MIDDLE_POLE : BlockFaceShape.UNDEFINED;
      } else {
         return BlockFaceShape.UNDEFINED;
      }
   }
}
