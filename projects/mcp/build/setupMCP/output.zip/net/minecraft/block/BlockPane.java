package net.minecraft.block;

import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.IBlockState;
import net.minecraft.fluid.IFluidState;
import net.minecraft.init.Blocks;
import net.minecraft.init.Fluids;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.state.StateContainer;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class BlockPane extends BlockFourWay {
   protected BlockPane(Block.Properties p_i48373_1_) {
      super(1.0F, 1.0F, 16.0F, 16.0F, 16.0F, p_i48373_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_196409_a, Boolean.valueOf(false)).func_206870_a(field_196411_b, Boolean.valueOf(false)).func_206870_a(field_196413_c, Boolean.valueOf(false)).func_206870_a(field_196414_y, Boolean.valueOf(false)).func_206870_a(field_204514_u, Boolean.valueOf(false)));
   }

   public IBlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      IBlockReader iblockreader = p_196258_1_.func_195991_k();
      BlockPos blockpos = p_196258_1_.func_195995_a();
      IFluidState ifluidstate = p_196258_1_.func_195991_k().func_204610_c(p_196258_1_.func_195995_a());
      BlockPos blockpos1 = blockpos.func_177978_c();
      BlockPos blockpos2 = blockpos.func_177968_d();
      BlockPos blockpos3 = blockpos.func_177976_e();
      BlockPos blockpos4 = blockpos.func_177974_f();
      IBlockState iblockstate = iblockreader.func_180495_p(blockpos1);
      IBlockState iblockstate1 = iblockreader.func_180495_p(blockpos2);
      IBlockState iblockstate2 = iblockreader.func_180495_p(blockpos3);
      IBlockState iblockstate3 = iblockreader.func_180495_p(blockpos4);
      return this.func_176223_P().func_206870_a(field_196409_a, Boolean.valueOf(this.func_196417_a(iblockstate, iblockstate.func_193401_d(iblockreader, blockpos1, EnumFacing.SOUTH)))).func_206870_a(field_196413_c, Boolean.valueOf(this.func_196417_a(iblockstate1, iblockstate1.func_193401_d(iblockreader, blockpos2, EnumFacing.NORTH)))).func_206870_a(field_196414_y, Boolean.valueOf(this.func_196417_a(iblockstate2, iblockstate2.func_193401_d(iblockreader, blockpos3, EnumFacing.EAST)))).func_206870_a(field_196411_b, Boolean.valueOf(this.func_196417_a(iblockstate3, iblockstate3.func_193401_d(iblockreader, blockpos4, EnumFacing.WEST)))).func_206870_a(field_204514_u, Boolean.valueOf(ifluidstate.func_206886_c() == Fluids.field_204546_a));
   }

   public IBlockState func_196271_a(IBlockState p_196271_1_, EnumFacing p_196271_2_, IBlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      if (p_196271_1_.func_177229_b(field_204514_u)) {
         p_196271_4_.func_205219_F_().func_205360_a(p_196271_5_, Fluids.field_204546_a, Fluids.field_204546_a.func_205569_a(p_196271_4_));
      }

      return p_196271_2_.func_176740_k().func_176722_c() ? p_196271_1_.func_206870_a(field_196415_z.get(p_196271_2_), Boolean.valueOf(this.func_196417_a(p_196271_3_, p_196271_3_.func_193401_d(p_196271_4_, p_196271_6_, p_196271_2_.func_176734_d())))) : super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
   }

   public boolean func_149686_d(IBlockState p_149686_1_) {
      return false;
   }

   @OnlyIn(Dist.CLIENT)
   public boolean func_200122_a(IBlockState p_200122_1_, IBlockState p_200122_2_, EnumFacing p_200122_3_) {
      if (p_200122_2_.func_177230_c() == this) {
         if (!p_200122_3_.func_176740_k().func_176722_c()) {
            return true;
         }

         if (p_200122_1_.func_177229_b(field_196415_z.get(p_200122_3_)) && p_200122_2_.func_177229_b(field_196415_z.get(p_200122_3_.func_176734_d()))) {
            return true;
         }
      }

      return super.func_200122_a(p_200122_1_, p_200122_2_, p_200122_3_);
   }

   public final boolean func_196417_a(IBlockState p_196417_1_, BlockFaceShape p_196417_2_) {
      Block block = p_196417_1_.func_177230_c();
      return !func_196418_h(block) && p_196417_2_ == BlockFaceShape.SOLID || p_196417_2_ == BlockFaceShape.MIDDLE_POLE_THIN;
   }

   public static boolean func_196418_h(Block p_196418_0_) {
      return p_196418_0_ instanceof BlockShulkerBox || p_196418_0_ instanceof BlockLeaves || p_196418_0_ == Blocks.field_150461_bJ || p_196418_0_ == Blocks.field_150383_bp || p_196418_0_ == Blocks.field_150426_aN || p_196418_0_ == Blocks.field_150432_aD || p_196418_0_ == Blocks.field_180398_cJ || p_196418_0_ == Blocks.field_150331_J || p_196418_0_ == Blocks.field_150320_F || p_196418_0_ == Blocks.field_150332_K || p_196418_0_ == Blocks.field_150440_ba || p_196418_0_ == Blocks.field_150423_aK || p_196418_0_ == Blocks.field_196625_cS || p_196418_0_ == Blocks.field_196628_cT || p_196418_0_ == Blocks.field_180401_cv;
   }

   protected boolean func_149700_E() {
      return true;
   }

   public BlockRenderLayer func_180664_k() {
      return BlockRenderLayer.CUTOUT_MIPPED;
   }

   protected void func_206840_a(StateContainer.Builder<Block, IBlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_196409_a, field_196411_b, field_196414_y, field_196413_c, field_204514_u);
   }

   public BlockFaceShape func_193383_a(IBlockReader p_193383_1_, IBlockState p_193383_2_, BlockPos p_193383_3_, EnumFacing p_193383_4_) {
      return p_193383_4_ != EnumFacing.UP && p_193383_4_ != EnumFacing.DOWN ? BlockFaceShape.MIDDLE_POLE_THIN : BlockFaceShape.CENTER_SMALL;
   }
}
