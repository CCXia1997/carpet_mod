package net.minecraft.block;

import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.EntityZombie;
import net.minecraft.entity.passive.EntityTurtle;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.item.ItemStack;
import net.minecraft.state.IntegerProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.IItemProvider;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.World;

public class BlockTurtleEgg extends Block {
   private static final VoxelShape field_203172_c = Block.func_208617_a(3.0D, 0.0D, 3.0D, 12.0D, 7.0D, 12.0D);
   private static final VoxelShape field_206843_t = Block.func_208617_a(1.0D, 0.0D, 1.0D, 15.0D, 7.0D, 15.0D);
   public static final IntegerProperty field_203170_a = BlockStateProperties.field_208128_ac;
   public static final IntegerProperty field_203171_b = BlockStateProperties.field_208127_ab;

   public BlockTurtleEgg(Block.Properties p_i48778_1_) {
      super(p_i48778_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_203170_a, Integer.valueOf(0)).func_206870_a(field_203171_b, Integer.valueOf(1)));
   }

   public void func_176199_a(World p_176199_1_, BlockPos p_176199_2_, Entity p_176199_3_) {
      this.func_203167_a(p_176199_1_, p_176199_2_, p_176199_3_, 100);
      super.func_176199_a(p_176199_1_, p_176199_2_, p_176199_3_);
   }

   public void func_180658_a(World p_180658_1_, BlockPos p_180658_2_, Entity p_180658_3_, float p_180658_4_) {
      if (!(p_180658_3_ instanceof EntityZombie)) {
         this.func_203167_a(p_180658_1_, p_180658_2_, p_180658_3_, 3);
      }

      super.func_180658_a(p_180658_1_, p_180658_2_, p_180658_3_, p_180658_4_);
   }

   private void func_203167_a(World p_203167_1_, BlockPos p_203167_2_, Entity p_203167_3_, int p_203167_4_) {
      if (!this.func_212570_a(p_203167_1_, p_203167_3_)) {
         super.func_176199_a(p_203167_1_, p_203167_2_, p_203167_3_);
      } else {
         if (!p_203167_1_.field_72995_K && p_203167_1_.field_73012_v.nextInt(p_203167_4_) == 0) {
            this.func_203166_c(p_203167_1_, p_203167_2_, p_203167_1_.func_180495_p(p_203167_2_));
         }

      }
   }

   private void func_203166_c(World p_203166_1_, BlockPos p_203166_2_, IBlockState p_203166_3_) {
      p_203166_1_.func_184133_a((EntityPlayer)null, p_203166_2_, SoundEvents.field_203281_iz, SoundCategory.BLOCKS, 0.7F, 0.9F + p_203166_1_.field_73012_v.nextFloat() * 0.2F);
      int i = p_203166_3_.func_177229_b(field_203171_b);
      if (i <= 1) {
         p_203166_1_.func_175655_b(p_203166_2_, false);
      } else {
         p_203166_1_.func_180501_a(p_203166_2_, p_203166_3_.func_206870_a(field_203171_b, Integer.valueOf(i - 1)), 2);
         p_203166_1_.func_175718_b(2001, p_203166_2_, Block.func_196246_j(p_203166_3_));
      }

   }

   public void func_196267_b(IBlockState p_196267_1_, World p_196267_2_, BlockPos p_196267_3_, Random p_196267_4_) {
      if (this.func_203169_a(p_196267_2_) && this.func_203168_a(p_196267_2_, p_196267_3_)) {
         int i = p_196267_1_.func_177229_b(field_203170_a);
         if (i < 2) {
            p_196267_2_.func_184133_a((EntityPlayer)null, p_196267_3_, SoundEvents.field_203280_iy, SoundCategory.BLOCKS, 0.7F, 0.9F + p_196267_4_.nextFloat() * 0.2F);
            p_196267_2_.func_180501_a(p_196267_3_, p_196267_1_.func_206870_a(field_203170_a, Integer.valueOf(i + 1)), 2);
         } else {
            p_196267_2_.func_184133_a((EntityPlayer)null, p_196267_3_, SoundEvents.field_203279_ix, SoundCategory.BLOCKS, 0.7F, 0.9F + p_196267_4_.nextFloat() * 0.2F);
            p_196267_2_.func_175698_g(p_196267_3_);
            if (!p_196267_2_.field_72995_K) {
               for(int j = 0; j < p_196267_1_.func_177229_b(field_203171_b); ++j) {
                  p_196267_2_.func_175718_b(2001, p_196267_3_, Block.func_196246_j(p_196267_1_));
                  EntityTurtle entityturtle = new EntityTurtle(p_196267_2_);
                  entityturtle.func_70873_a(-24000);
                  entityturtle.func_203011_g(p_196267_3_);
                  entityturtle.func_70012_b((double)p_196267_3_.func_177958_n() + 0.3D + (double)j * 0.2D, (double)p_196267_3_.func_177956_o(), (double)p_196267_3_.func_177952_p() + 0.3D, 0.0F, 0.0F);
                  p_196267_2_.func_72838_d(entityturtle);
               }
            }
         }
      }

   }

   private boolean func_203168_a(IBlockReader p_203168_1_, BlockPos p_203168_2_) {
      return p_203168_1_.func_180495_p(p_203168_2_.func_177977_b()).func_177230_c() == Blocks.field_150354_m;
   }

   public void func_196259_b(IBlockState p_196259_1_, World p_196259_2_, BlockPos p_196259_3_, IBlockState p_196259_4_) {
      if (this.func_203168_a(p_196259_2_, p_196259_3_) && !p_196259_2_.field_72995_K) {
         p_196259_2_.func_175718_b(2005, p_196259_3_, 0);
      }

   }

   private boolean func_203169_a(World p_203169_1_) {
      float f = p_203169_1_.func_72826_c(1.0F);
      if ((double)f < 0.69D && (double)f > 0.65D) {
         return true;
      } else {
         return p_203169_1_.field_73012_v.nextInt(500) == 0;
      }
   }

   protected boolean func_149700_E() {
      return true;
   }

   public void func_180657_a(World p_180657_1_, EntityPlayer p_180657_2_, BlockPos p_180657_3_, IBlockState p_180657_4_, @Nullable TileEntity p_180657_5_, ItemStack p_180657_6_) {
      super.func_180657_a(p_180657_1_, p_180657_2_, p_180657_3_, p_180657_4_, p_180657_5_, p_180657_6_);
      this.func_203166_c(p_180657_1_, p_180657_3_, p_180657_4_);
   }

   public IItemProvider func_199769_a(IBlockState p_199769_1_, World p_199769_2_, BlockPos p_199769_3_, int p_199769_4_) {
      return Items.field_190931_a;
   }

   public boolean func_196253_a(IBlockState p_196253_1_, BlockItemUseContext p_196253_2_) {
      return p_196253_2_.func_195996_i().func_77973_b() == this.func_199767_j() && p_196253_1_.func_177229_b(field_203171_b) < 4 ? true : super.func_196253_a(p_196253_1_, p_196253_2_);
   }

   @Nullable
   public IBlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      IBlockState iblockstate = p_196258_1_.func_195991_k().func_180495_p(p_196258_1_.func_195995_a());
      return iblockstate.func_177230_c() == this ? iblockstate.func_206870_a(field_203171_b, Integer.valueOf(Math.min(4, iblockstate.func_177229_b(field_203171_b) + 1))) : super.func_196258_a(p_196258_1_);
   }

   public BlockRenderLayer func_180664_k() {
      return BlockRenderLayer.CUTOUT;
   }

   public boolean func_149686_d(IBlockState p_149686_1_) {
      return false;
   }

   public VoxelShape func_196244_b(IBlockState p_196244_1_, IBlockReader p_196244_2_, BlockPos p_196244_3_) {
      return p_196244_1_.func_177229_b(field_203171_b) > 1 ? field_206843_t : field_203172_c;
   }

   public BlockFaceShape func_193383_a(IBlockReader p_193383_1_, IBlockState p_193383_2_, BlockPos p_193383_3_, EnumFacing p_193383_4_) {
      return BlockFaceShape.UNDEFINED;
   }

   protected void func_206840_a(StateContainer.Builder<Block, IBlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_203170_a, field_203171_b);
   }

   private boolean func_212570_a(World p_212570_1_, Entity p_212570_2_) {
      if (p_212570_2_ instanceof EntityTurtle) {
         return false;
      } else {
         return p_212570_2_ instanceof EntityLivingBase && !(p_212570_2_ instanceof EntityPlayer) ? p_212570_1_.func_82736_K().func_82766_b("mobGriefing") : true;
      }
   }
}
