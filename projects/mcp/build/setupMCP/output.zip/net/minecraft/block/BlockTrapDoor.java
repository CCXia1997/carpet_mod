package net.minecraft.block;

import javax.annotation.Nullable;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.fluid.Fluid;
import net.minecraft.fluid.IFluidState;
import net.minecraft.init.Fluids;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.pathfinding.PathType;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.EnumProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.state.properties.Half;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.World;

public class BlockTrapDoor extends BlockHorizontal implements IBucketPickupHandler, ILiquidContainer {
   public static final BooleanProperty field_176283_b = BlockStateProperties.field_208193_t;
   public static final EnumProperty<Half> field_176285_M = BlockStateProperties.field_208164_Q;
   public static final BooleanProperty field_196381_c = BlockStateProperties.field_208194_u;
   public static final BooleanProperty field_204614_t = BlockStateProperties.field_208198_y;
   protected static final VoxelShape field_185734_d = Block.func_208617_a(0.0D, 0.0D, 0.0D, 3.0D, 16.0D, 16.0D);
   protected static final VoxelShape field_185735_e = Block.func_208617_a(13.0D, 0.0D, 0.0D, 16.0D, 16.0D, 16.0D);
   protected static final VoxelShape field_185736_f = Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 16.0D, 3.0D);
   protected static final VoxelShape field_185737_g = Block.func_208617_a(0.0D, 0.0D, 13.0D, 16.0D, 16.0D, 16.0D);
   protected static final VoxelShape field_185732_B = Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 3.0D, 16.0D);
   protected static final VoxelShape field_185733_C = Block.func_208617_a(0.0D, 13.0D, 0.0D, 16.0D, 16.0D, 16.0D);

   protected BlockTrapDoor(Block.Properties p_i48307_1_) {
      super(p_i48307_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_185512_D, EnumFacing.NORTH).func_206870_a(field_176283_b, Boolean.valueOf(false)).func_206870_a(field_176285_M, Half.BOTTOM).func_206870_a(field_196381_c, Boolean.valueOf(false)).func_206870_a(field_204614_t, Boolean.valueOf(false)));
   }

   public VoxelShape func_196244_b(IBlockState p_196244_1_, IBlockReader p_196244_2_, BlockPos p_196244_3_) {
      if (!p_196244_1_.func_177229_b(field_176283_b)) {
         return p_196244_1_.func_177229_b(field_176285_M) == Half.TOP ? field_185733_C : field_185732_B;
      } else {
         switch((EnumFacing)p_196244_1_.func_177229_b(field_185512_D)) {
         case NORTH:
         default:
            return field_185737_g;
         case SOUTH:
            return field_185736_f;
         case WEST:
            return field_185735_e;
         case EAST:
            return field_185734_d;
         }
      }
   }

   public boolean func_149686_d(IBlockState p_149686_1_) {
      return false;
   }

   public boolean func_196266_a(IBlockState p_196266_1_, IBlockReader p_196266_2_, BlockPos p_196266_3_, PathType p_196266_4_) {
      switch(p_196266_4_) {
      case LAND:
         return p_196266_1_.func_177229_b(field_176283_b);
      case WATER:
         return p_196266_1_.func_177229_b(field_204614_t);
      case AIR:
         return p_196266_1_.func_177229_b(field_176283_b);
      default:
         return false;
      }
   }

   public boolean func_196250_a(IBlockState p_196250_1_, World p_196250_2_, BlockPos p_196250_3_, EntityPlayer p_196250_4_, EnumHand p_196250_5_, EnumFacing p_196250_6_, float p_196250_7_, float p_196250_8_, float p_196250_9_) {
      if (this.field_149764_J == Material.field_151573_f) {
         return false;
      } else {
         p_196250_1_ = p_196250_1_.func_177231_a(field_176283_b);
         p_196250_2_.func_180501_a(p_196250_3_, p_196250_1_, 2);
         if (p_196250_1_.func_177229_b(field_204614_t)) {
            p_196250_2_.func_205219_F_().func_205360_a(p_196250_3_, Fluids.field_204546_a, Fluids.field_204546_a.func_205569_a(p_196250_2_));
         }

         this.func_185731_a(p_196250_4_, p_196250_2_, p_196250_3_, p_196250_1_.func_177229_b(field_176283_b));
         return true;
      }
   }

   protected void func_185731_a(@Nullable EntityPlayer p_185731_1_, World p_185731_2_, BlockPos p_185731_3_, boolean p_185731_4_) {
      if (p_185731_4_) {
         int i = this.field_149764_J == Material.field_151573_f ? 1037 : 1007;
         p_185731_2_.func_180498_a(p_185731_1_, i, p_185731_3_, 0);
      } else {
         int j = this.field_149764_J == Material.field_151573_f ? 1036 : 1013;
         p_185731_2_.func_180498_a(p_185731_1_, j, p_185731_3_, 0);
      }

   }

   public void func_189540_a(IBlockState p_189540_1_, World p_189540_2_, BlockPos p_189540_3_, Block p_189540_4_, BlockPos p_189540_5_) {
      if (!p_189540_2_.field_72995_K) {
         boolean flag = p_189540_2_.func_175640_z(p_189540_3_);
         if (flag != p_189540_1_.func_177229_b(field_196381_c)) {
            if (p_189540_1_.func_177229_b(field_176283_b) != flag) {
               p_189540_1_ = p_189540_1_.func_206870_a(field_176283_b, Boolean.valueOf(flag));
               this.func_185731_a((EntityPlayer)null, p_189540_2_, p_189540_3_, flag);
            }

            p_189540_2_.func_180501_a(p_189540_3_, p_189540_1_.func_206870_a(field_196381_c, Boolean.valueOf(flag)), 2);
            if (p_189540_1_.func_177229_b(field_204614_t)) {
               p_189540_2_.func_205219_F_().func_205360_a(p_189540_3_, Fluids.field_204546_a, Fluids.field_204546_a.func_205569_a(p_189540_2_));
            }
         }

      }
   }

   public IBlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      IBlockState iblockstate = this.func_176223_P();
      IFluidState ifluidstate = p_196258_1_.func_195991_k().func_204610_c(p_196258_1_.func_195995_a());
      EnumFacing enumfacing = p_196258_1_.func_196000_l();
      if (!p_196258_1_.func_196012_c() && enumfacing.func_176740_k().func_176722_c()) {
         iblockstate = iblockstate.func_206870_a(field_185512_D, enumfacing).func_206870_a(field_176285_M, p_196258_1_.func_195993_n() > 0.5F ? Half.TOP : Half.BOTTOM);
      } else {
         iblockstate = iblockstate.func_206870_a(field_185512_D, p_196258_1_.func_195992_f().func_176734_d()).func_206870_a(field_176285_M, enumfacing == EnumFacing.UP ? Half.BOTTOM : Half.TOP);
      }

      if (p_196258_1_.func_195991_k().func_175640_z(p_196258_1_.func_195995_a())) {
         iblockstate = iblockstate.func_206870_a(field_176283_b, Boolean.valueOf(true)).func_206870_a(field_196381_c, Boolean.valueOf(true));
      }

      return iblockstate.func_206870_a(field_204614_t, Boolean.valueOf(ifluidstate.func_206886_c() == Fluids.field_204546_a));
   }

   public BlockRenderLayer func_180664_k() {
      return BlockRenderLayer.CUTOUT;
   }

   protected void func_206840_a(StateContainer.Builder<Block, IBlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_185512_D, field_176283_b, field_176285_M, field_196381_c, field_204614_t);
   }

   public BlockFaceShape func_193383_a(IBlockReader p_193383_1_, IBlockState p_193383_2_, BlockPos p_193383_3_, EnumFacing p_193383_4_) {
      return (p_193383_4_ == EnumFacing.UP && p_193383_2_.func_177229_b(field_176285_M) == Half.TOP || p_193383_4_ == EnumFacing.DOWN && p_193383_2_.func_177229_b(field_176285_M) == Half.BOTTOM) && !p_193383_2_.func_177229_b(field_176283_b) ? BlockFaceShape.SOLID : BlockFaceShape.UNDEFINED;
   }

   public Fluid func_204508_a(IWorld p_204508_1_, BlockPos p_204508_2_, IBlockState p_204508_3_) {
      if (p_204508_3_.func_177229_b(field_204614_t)) {
         p_204508_1_.func_180501_a(p_204508_2_, p_204508_3_.func_206870_a(field_204614_t, Boolean.valueOf(false)), 3);
         return Fluids.field_204546_a;
      } else {
         return Fluids.field_204541_a;
      }
   }

   public IFluidState func_204507_t(IBlockState p_204507_1_) {
      return p_204507_1_.func_177229_b(field_204614_t) ? Fluids.field_204546_a.func_207204_a(false) : super.func_204507_t(p_204507_1_);
   }

   public boolean func_204510_a(IBlockReader p_204510_1_, BlockPos p_204510_2_, IBlockState p_204510_3_, Fluid p_204510_4_) {
      return !p_204510_3_.func_177229_b(field_204614_t) && p_204510_4_ == Fluids.field_204546_a;
   }

   public boolean func_204509_a(IWorld p_204509_1_, BlockPos p_204509_2_, IBlockState p_204509_3_, IFluidState p_204509_4_) {
      if (!p_204509_3_.func_177229_b(field_204614_t) && p_204509_4_.func_206886_c() == Fluids.field_204546_a) {
         if (!p_204509_1_.func_201670_d()) {
            p_204509_1_.func_180501_a(p_204509_2_, p_204509_3_.func_206870_a(field_204614_t, Boolean.valueOf(true)), 3);
            p_204509_1_.func_205219_F_().func_205360_a(p_204509_2_, p_204509_4_.func_206886_c(), p_204509_4_.func_206886_c().func_205569_a(p_204509_1_));
         }

         return true;
      } else {
         return false;
      }
   }

   public IBlockState func_196271_a(IBlockState p_196271_1_, EnumFacing p_196271_2_, IBlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      if (p_196271_1_.func_177229_b(field_204614_t)) {
         p_196271_4_.func_205219_F_().func_205360_a(p_196271_5_, Fluids.field_204546_a, Fluids.field_204546_a.func_205569_a(p_196271_4_));
      }

      return super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
   }
}
