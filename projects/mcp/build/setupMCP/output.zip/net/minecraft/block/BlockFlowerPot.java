package net.minecraft.block;

import com.google.common.collect.Maps;
import java.util.Map;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.stats.StatList;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.EnumBlockRenderType;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.IItemProvider;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.World;

public class BlockFlowerPot extends Block {
   private static final Map<Block, Block> field_196451_b = Maps.newHashMap();
   protected static final VoxelShape field_196450_a = Block.func_208617_a(5.0D, 0.0D, 5.0D, 11.0D, 6.0D, 11.0D);
   private final Block field_196452_c;

   public BlockFlowerPot(Block p_i48395_1_, Block.Properties p_i48395_2_) {
      super(p_i48395_2_);
      this.field_196452_c = p_i48395_1_;
      field_196451_b.put(p_i48395_1_, this);
   }

   public VoxelShape func_196244_b(IBlockState p_196244_1_, IBlockReader p_196244_2_, BlockPos p_196244_3_) {
      return field_196450_a;
   }

   public EnumBlockRenderType func_149645_b(IBlockState p_149645_1_) {
      return EnumBlockRenderType.MODEL;
   }

   public boolean func_149686_d(IBlockState p_149686_1_) {
      return false;
   }

   public boolean func_196250_a(IBlockState p_196250_1_, World p_196250_2_, BlockPos p_196250_3_, EntityPlayer p_196250_4_, EnumHand p_196250_5_, EnumFacing p_196250_6_, float p_196250_7_, float p_196250_8_, float p_196250_9_) {
      ItemStack itemstack = p_196250_4_.func_184586_b(p_196250_5_);
      Item item = itemstack.func_77973_b();
      Block block = item instanceof ItemBlock ? field_196451_b.getOrDefault(((ItemBlock)item).func_179223_d(), Blocks.field_150350_a) : Blocks.field_150350_a;
      boolean flag = block == Blocks.field_150350_a;
      boolean flag1 = this.field_196452_c == Blocks.field_150350_a;
      if (flag != flag1) {
         if (flag1) {
            p_196250_2_.func_180501_a(p_196250_3_, block.func_176223_P(), 3);
            p_196250_4_.func_195066_a(StatList.field_188088_V);
            if (!p_196250_4_.field_71075_bZ.field_75098_d) {
               itemstack.func_190918_g(1);
            }
         } else {
            ItemStack itemstack1 = new ItemStack(this.field_196452_c);
            if (itemstack.func_190926_b()) {
               p_196250_4_.func_184611_a(p_196250_5_, itemstack1);
            } else if (!p_196250_4_.func_191521_c(itemstack1)) {
               p_196250_4_.func_71019_a(itemstack1, false);
            }

            p_196250_2_.func_180501_a(p_196250_3_, Blocks.field_150457_bL.func_176223_P(), 3);
         }
      }

      return true;
   }

   public ItemStack func_185473_a(IBlockReader p_185473_1_, BlockPos p_185473_2_, IBlockState p_185473_3_) {
      return this.field_196452_c == Blocks.field_150350_a ? super.func_185473_a(p_185473_1_, p_185473_2_, p_185473_3_) : new ItemStack(this.field_196452_c);
   }

   public IItemProvider func_199769_a(IBlockState p_199769_1_, World p_199769_2_, BlockPos p_199769_3_, int p_199769_4_) {
      return Blocks.field_150457_bL;
   }

   public void func_196255_a(IBlockState p_196255_1_, World p_196255_2_, BlockPos p_196255_3_, float p_196255_4_, int p_196255_5_) {
      super.func_196255_a(p_196255_1_, p_196255_2_, p_196255_3_, p_196255_4_, p_196255_5_);
      if (this.field_196452_c != Blocks.field_150350_a) {
         func_180635_a(p_196255_2_, p_196255_3_, new ItemStack(this.field_196452_c));
      }

   }

   public IBlockState func_196271_a(IBlockState p_196271_1_, EnumFacing p_196271_2_, IBlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      return p_196271_2_ == EnumFacing.DOWN && !p_196271_1_.func_196955_c(p_196271_4_, p_196271_5_) ? Blocks.field_150350_a.func_176223_P() : super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
   }

   public BlockRenderLayer func_180664_k() {
      return BlockRenderLayer.CUTOUT;
   }

   public BlockFaceShape func_193383_a(IBlockReader p_193383_1_, IBlockState p_193383_2_, BlockPos p_193383_3_, EnumFacing p_193383_4_) {
      return BlockFaceShape.UNDEFINED;
   }
}
