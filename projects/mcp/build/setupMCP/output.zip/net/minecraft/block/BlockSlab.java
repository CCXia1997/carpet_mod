package net.minecraft.block;

import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.IBlockState;
import net.minecraft.fluid.Fluid;
import net.minecraft.fluid.IFluidState;
import net.minecraft.init.Fluids;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.item.ItemStack;
import net.minecraft.pathfinding.PathType;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.EnumProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.state.properties.SlabType;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.shapes.VoxelShapes;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;

public class BlockSlab extends Block implements IBucketPickupHandler, ILiquidContainer {
   public static final EnumProperty<SlabType> field_196505_a = BlockStateProperties.field_208145_at;
   public static final BooleanProperty field_204512_b = BlockStateProperties.field_208198_y;
   protected static final VoxelShape field_196506_b = Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 8.0D, 16.0D);
   protected static final VoxelShape field_196507_c = Block.func_208617_a(0.0D, 8.0D, 0.0D, 16.0D, 16.0D, 16.0D);

   public BlockSlab(Block.Properties p_i48331_1_) {
      super(p_i48331_1_);
      this.func_180632_j(this.func_176223_P().func_206870_a(field_196505_a, SlabType.BOTTOM).func_206870_a(field_204512_b, Boolean.valueOf(false)));
   }

   public int func_200011_d(IBlockState p_200011_1_, IBlockReader p_200011_2_, BlockPos p_200011_3_) {
      return p_200011_2_.func_201572_C();
   }

   protected void func_206840_a(StateContainer.Builder<Block, IBlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_196505_a, field_204512_b);
   }

   protected boolean func_149700_E() {
      return false;
   }

   public VoxelShape func_196244_b(IBlockState p_196244_1_, IBlockReader p_196244_2_, BlockPos p_196244_3_) {
      SlabType slabtype = p_196244_1_.func_177229_b(field_196505_a);
      switch(slabtype) {
      case DOUBLE:
         return VoxelShapes.func_197868_b();
      case TOP:
         return field_196507_c;
      default:
         return field_196506_b;
      }
   }

   public boolean func_185481_k(IBlockState p_185481_1_) {
      return p_185481_1_.func_177229_b(field_196505_a) == SlabType.DOUBLE || p_185481_1_.func_177229_b(field_196505_a) == SlabType.TOP;
   }

   public BlockFaceShape func_193383_a(IBlockReader p_193383_1_, IBlockState p_193383_2_, BlockPos p_193383_3_, EnumFacing p_193383_4_) {
      SlabType slabtype = p_193383_2_.func_177229_b(field_196505_a);
      if (slabtype == SlabType.DOUBLE) {
         return BlockFaceShape.SOLID;
      } else if (p_193383_4_ == EnumFacing.UP && slabtype == SlabType.TOP) {
         return BlockFaceShape.SOLID;
      } else {
         return p_193383_4_ == EnumFacing.DOWN && slabtype == SlabType.BOTTOM ? BlockFaceShape.SOLID : BlockFaceShape.UNDEFINED;
      }
   }

   @Nullable
   public IBlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      IBlockState iblockstate = p_196258_1_.func_195991_k().func_180495_p(p_196258_1_.func_195995_a());
      if (iblockstate.func_177230_c() == this) {
         return iblockstate.func_206870_a(field_196505_a, SlabType.DOUBLE).func_206870_a(field_204512_b, Boolean.valueOf(false));
      } else {
         IFluidState ifluidstate = p_196258_1_.func_195991_k().func_204610_c(p_196258_1_.func_195995_a());
         IBlockState iblockstate1 = this.func_176223_P().func_206870_a(field_196505_a, SlabType.BOTTOM).func_206870_a(field_204512_b, Boolean.valueOf(ifluidstate.func_206886_c() == Fluids.field_204546_a));
         EnumFacing enumfacing = p_196258_1_.func_196000_l();
         return enumfacing != EnumFacing.DOWN && (enumfacing == EnumFacing.UP || !((double)p_196258_1_.func_195993_n() > 0.5D)) ? iblockstate1 : iblockstate1.func_206870_a(field_196505_a, SlabType.TOP);
      }
   }

   public int func_196264_a(IBlockState p_196264_1_, Random p_196264_2_) {
      return p_196264_1_.func_177229_b(field_196505_a) == SlabType.DOUBLE ? 2 : 1;
   }

   public boolean func_149686_d(IBlockState p_149686_1_) {
      return p_149686_1_.func_177229_b(field_196505_a) == SlabType.DOUBLE;
   }

   public boolean func_196253_a(IBlockState p_196253_1_, BlockItemUseContext p_196253_2_) {
      ItemStack itemstack = p_196253_2_.func_195996_i();
      SlabType slabtype = p_196253_1_.func_177229_b(field_196505_a);
      if (slabtype != SlabType.DOUBLE && itemstack.func_77973_b() == this.func_199767_j()) {
         if (p_196253_2_.func_196012_c()) {
            boolean flag = (double)p_196253_2_.func_195993_n() > 0.5D;
            EnumFacing enumfacing = p_196253_2_.func_196000_l();
            if (slabtype == SlabType.BOTTOM) {
               return enumfacing == EnumFacing.UP || flag && enumfacing.func_176740_k().func_176722_c();
            } else {
               return enumfacing == EnumFacing.DOWN || !flag && enumfacing.func_176740_k().func_176722_c();
            }
         } else {
            return true;
         }
      } else {
         return false;
      }
   }

   public Fluid func_204508_a(IWorld p_204508_1_, BlockPos p_204508_2_, IBlockState p_204508_3_) {
      if (p_204508_3_.func_177229_b(field_204512_b)) {
         p_204508_1_.func_180501_a(p_204508_2_, p_204508_3_.func_206870_a(field_204512_b, Boolean.valueOf(false)), 3);
         return Fluids.field_204546_a;
      } else {
         return Fluids.field_204541_a;
      }
   }

   public IFluidState func_204507_t(IBlockState p_204507_1_) {
      return p_204507_1_.func_177229_b(field_204512_b) ? Fluids.field_204546_a.func_207204_a(false) : super.func_204507_t(p_204507_1_);
   }

   public boolean func_204510_a(IBlockReader p_204510_1_, BlockPos p_204510_2_, IBlockState p_204510_3_, Fluid p_204510_4_) {
      return p_204510_3_.func_177229_b(field_196505_a) != SlabType.DOUBLE && !p_204510_3_.func_177229_b(field_204512_b) && p_204510_4_ == Fluids.field_204546_a;
   }

   public boolean func_204509_a(IWorld p_204509_1_, BlockPos p_204509_2_, IBlockState p_204509_3_, IFluidState p_204509_4_) {
      if (p_204509_3_.func_177229_b(field_196505_a) != SlabType.DOUBLE && !p_204509_3_.func_177229_b(field_204512_b) && p_204509_4_.func_206886_c() == Fluids.field_204546_a) {
         if (!p_204509_1_.func_201670_d()) {
            p_204509_1_.func_180501_a(p_204509_2_, p_204509_3_.func_206870_a(field_204512_b, Boolean.valueOf(true)), 3);
            p_204509_1_.func_205219_F_().func_205360_a(p_204509_2_, p_204509_4_.func_206886_c(), p_204509_4_.func_206886_c().func_205569_a(p_204509_1_));
         }

         return true;
      } else {
         return false;
      }
   }

   public IBlockState func_196271_a(IBlockState p_196271_1_, EnumFacing p_196271_2_, IBlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      if (p_196271_1_.func_177229_b(field_204512_b)) {
         p_196271_4_.func_205219_F_().func_205360_a(p_196271_5_, Fluids.field_204546_a, Fluids.field_204546_a.func_205569_a(p_196271_4_));
      }

      return super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
   }

   public boolean func_196266_a(IBlockState p_196266_1_, IBlockReader p_196266_2_, BlockPos p_196266_3_, PathType p_196266_4_) {
      switch(p_196266_4_) {
      case LAND:
         return p_196266_1_.func_177229_b(field_196505_a) == SlabType.BOTTOM;
      case WATER:
         return p_196266_2_.func_204610_c(p_196266_3_).func_206884_a(FluidTags.field_206959_a);
      case AIR:
         return false;
      default:
         return false;
      }
   }
}
