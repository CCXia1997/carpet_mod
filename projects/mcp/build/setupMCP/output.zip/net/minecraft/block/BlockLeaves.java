package net.minecraft.block;

import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.init.Particles;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.item.ItemStack;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.IntegerProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.stats.StatList;
import net.minecraft.tags.BlockTags;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.IItemProvider;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.World;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class BlockLeaves extends Block {
   public static final IntegerProperty field_208494_a = BlockStateProperties.field_208514_aa;
   public static final BooleanProperty field_208495_b = BlockStateProperties.field_208515_s;
   protected static boolean field_196478_c;

   public BlockLeaves(Block.Properties p_i48370_1_) {
      super(p_i48370_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_208494_a, Integer.valueOf(7)).func_206870_a(field_208495_b, Boolean.valueOf(false)));
   }

   public boolean func_149653_t(IBlockState p_149653_1_) {
      return p_149653_1_.func_177229_b(field_208494_a) == 7 && !p_149653_1_.func_177229_b(field_208495_b);
   }

   public void func_196265_a(IBlockState p_196265_1_, World p_196265_2_, BlockPos p_196265_3_, Random p_196265_4_) {
      if (!p_196265_1_.func_177229_b(field_208495_b) && p_196265_1_.func_177229_b(field_208494_a) == 7) {
         p_196265_1_.func_196949_c(p_196265_2_, p_196265_3_, 0);
         p_196265_2_.func_175698_g(p_196265_3_);
      }

   }

   public void func_196267_b(IBlockState p_196267_1_, World p_196267_2_, BlockPos p_196267_3_, Random p_196267_4_) {
      p_196267_2_.func_180501_a(p_196267_3_, func_208493_b(p_196267_1_, p_196267_2_, p_196267_3_), 3);
   }

   public int func_200011_d(IBlockState p_200011_1_, IBlockReader p_200011_2_, BlockPos p_200011_3_) {
      return 1;
   }

   public IBlockState func_196271_a(IBlockState p_196271_1_, EnumFacing p_196271_2_, IBlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      int i = func_208492_w(p_196271_3_) + 1;
      if (i != 1 || p_196271_1_.func_177229_b(field_208494_a) != i) {
         p_196271_4_.func_205220_G_().func_205360_a(p_196271_5_, this, 1);
      }

      return p_196271_1_;
   }

   private static IBlockState func_208493_b(IBlockState p_208493_0_, IWorld p_208493_1_, BlockPos p_208493_2_) {
      int i = 7;

      try (BlockPos.PooledMutableBlockPos blockpos$pooledmutableblockpos = BlockPos.PooledMutableBlockPos.func_185346_s()) {
         for(EnumFacing enumfacing : EnumFacing.values()) {
            blockpos$pooledmutableblockpos.func_189533_g(p_208493_2_).func_189536_c(enumfacing);
            i = Math.min(i, func_208492_w(p_208493_1_.func_180495_p(blockpos$pooledmutableblockpos)) + 1);
            if (i == 1) {
               break;
            }
         }
      }

      return p_208493_0_.func_206870_a(field_208494_a, Integer.valueOf(i));
   }

   private static int func_208492_w(IBlockState p_208492_0_) {
      if (BlockTags.field_200031_h.func_199685_a_(p_208492_0_.func_177230_c())) {
         return 0;
      } else {
         return p_208492_0_.func_177230_c() instanceof BlockLeaves ? p_208492_0_.func_177229_b(field_208494_a) : 7;
      }
   }

   @OnlyIn(Dist.CLIENT)
   public void func_180655_c(IBlockState p_180655_1_, World p_180655_2_, BlockPos p_180655_3_, Random p_180655_4_) {
      if (p_180655_2_.func_175727_C(p_180655_3_.func_177984_a()) && !p_180655_2_.func_180495_p(p_180655_3_.func_177977_b()).func_185896_q() && p_180655_4_.nextInt(15) == 1) {
         double d0 = (double)((float)p_180655_3_.func_177958_n() + p_180655_4_.nextFloat());
         double d1 = (double)p_180655_3_.func_177956_o() - 0.05D;
         double d2 = (double)((float)p_180655_3_.func_177952_p() + p_180655_4_.nextFloat());
         p_180655_2_.func_195594_a(Particles.field_197618_k, d0, d1, d2, 0.0D, 0.0D, 0.0D);
      }

   }

   public int func_196264_a(IBlockState p_196264_1_, Random p_196264_2_) {
      return p_196264_2_.nextInt(20) == 0 ? 1 : 0;
   }

   public IItemProvider func_199769_a(IBlockState p_199769_1_, World p_199769_2_, BlockPos p_199769_3_, int p_199769_4_) {
      Block block = p_199769_1_.func_177230_c();
      if (block == Blocks.field_196642_W) {
         return Blocks.field_196674_t;
      } else if (block == Blocks.field_196645_X) {
         return Blocks.field_196675_u;
      } else if (block == Blocks.field_196647_Y) {
         return Blocks.field_196676_v;
      } else if (block == Blocks.field_196648_Z) {
         return Blocks.field_196678_w;
      } else if (block == Blocks.field_196572_aa) {
         return Blocks.field_196679_x;
      } else {
         return block == Blocks.field_196574_ab ? Blocks.field_196680_y : Blocks.field_196674_t;
      }
   }

   public void func_196255_a(IBlockState p_196255_1_, World p_196255_2_, BlockPos p_196255_3_, float p_196255_4_, int p_196255_5_) {
      if (!p_196255_2_.field_72995_K) {
         int i = this.func_196472_i(p_196255_1_);
         if (p_196255_5_ > 0) {
            i -= 2 << p_196255_5_;
            if (i < 10) {
               i = 10;
            }
         }

         if (p_196255_2_.field_73012_v.nextInt(i) == 0) {
            func_180635_a(p_196255_2_, p_196255_3_, new ItemStack(this.func_199769_a(p_196255_1_, p_196255_2_, p_196255_3_, p_196255_5_)));
         }

         i = 200;
         if (p_196255_5_ > 0) {
            i -= 10 << p_196255_5_;
            if (i < 40) {
               i = 40;
            }
         }

         this.func_196474_a(p_196255_2_, p_196255_3_, p_196255_1_, i);
      }

   }

   protected void func_196474_a(World p_196474_1_, BlockPos p_196474_2_, IBlockState p_196474_3_, int p_196474_4_) {
      if ((p_196474_3_.func_177230_c() == Blocks.field_196642_W || p_196474_3_.func_177230_c() == Blocks.field_196574_ab) && p_196474_1_.field_73012_v.nextInt(p_196474_4_) == 0) {
         func_180635_a(p_196474_1_, p_196474_2_, new ItemStack(Items.field_151034_e));
      }

   }

   protected int func_196472_i(IBlockState p_196472_1_) {
      return p_196472_1_.func_177230_c() == Blocks.field_196648_Z ? 40 : 20;
   }

   @OnlyIn(Dist.CLIENT)
   public static void func_196475_b(boolean p_196475_0_) {
      field_196478_c = p_196475_0_;
   }

   public BlockRenderLayer func_180664_k() {
      return field_196478_c ? BlockRenderLayer.CUTOUT_MIPPED : BlockRenderLayer.SOLID;
   }

   public boolean func_176214_u(IBlockState p_176214_1_) {
      return false;
   }

   public void func_180657_a(World p_180657_1_, EntityPlayer p_180657_2_, BlockPos p_180657_3_, IBlockState p_180657_4_, @Nullable TileEntity p_180657_5_, ItemStack p_180657_6_) {
      if (!p_180657_1_.field_72995_K && p_180657_6_.func_77973_b() == Items.field_151097_aZ) {
         p_180657_2_.func_71029_a(StatList.field_188065_ae.func_199076_b(this));
         p_180657_2_.func_71020_j(0.005F);
         func_180635_a(p_180657_1_, p_180657_3_, new ItemStack(this));
      } else {
         super.func_180657_a(p_180657_1_, p_180657_2_, p_180657_3_, p_180657_4_, p_180657_5_, p_180657_6_);
      }
   }

   protected void func_206840_a(StateContainer.Builder<Block, IBlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_208494_a, field_208495_b);
   }

   public IBlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      return func_208493_b(this.func_176223_P().func_206870_a(field_208495_b, Boolean.valueOf(true)), p_196258_1_.func_195991_k(), p_196258_1_.func_195995_a());
   }
}
