package net.minecraft.block;

import com.google.common.cache.LoadingCache;
import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.BlockWorldState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.block.state.pattern.BlockPattern;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Particles;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.state.EnumProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.Rotation;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.World;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class BlockPortal extends Block {
   public static final EnumProperty<EnumFacing.Axis> field_176550_a = BlockStateProperties.field_208199_z;
   protected static final VoxelShape field_185683_b = Block.func_208617_a(0.0D, 0.0D, 6.0D, 16.0D, 16.0D, 10.0D);
   protected static final VoxelShape field_185684_c = Block.func_208617_a(6.0D, 0.0D, 0.0D, 10.0D, 16.0D, 16.0D);

   public BlockPortal(Block.Properties p_i48352_1_) {
      super(p_i48352_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_176550_a, EnumFacing.Axis.X));
   }

   public VoxelShape func_196244_b(IBlockState p_196244_1_, IBlockReader p_196244_2_, BlockPos p_196244_3_) {
      switch((EnumFacing.Axis)p_196244_1_.func_177229_b(field_176550_a)) {
      case Z:
         return field_185684_c;
      case X:
      default:
         return field_185683_b;
      }
   }

   public void func_196267_b(IBlockState p_196267_1_, World p_196267_2_, BlockPos p_196267_3_, Random p_196267_4_) {
      if (p_196267_2_.field_73011_w.func_76569_d() && p_196267_2_.func_82736_K().func_82766_b("doMobSpawning") && p_196267_4_.nextInt(2000) < p_196267_2_.func_175659_aa().func_151525_a()) {
         int i = p_196267_3_.func_177956_o();

         BlockPos blockpos;
         for(blockpos = p_196267_3_; !p_196267_2_.func_180495_p(blockpos).func_185896_q() && blockpos.func_177956_o() > 0; blockpos = blockpos.func_177977_b()) {
            ;
         }

         if (i > 0 && !p_196267_2_.func_180495_p(blockpos.func_177984_a()).func_185915_l()) {
            Entity entity = EntityType.field_200785_Y.func_208050_a(p_196267_2_, (NBTTagCompound)null, (ITextComponent)null, (EntityPlayer)null, blockpos.func_177984_a(), false, false);
            if (entity != null) {
               entity.field_71088_bW = entity.func_82147_ab();
            }
         }
      }

   }

   public boolean func_149686_d(IBlockState p_149686_1_) {
      return false;
   }

   public boolean func_176548_d(IWorld p_176548_1_, BlockPos p_176548_2_) {
      BlockPortal.Size blockportal$size = this.func_201816_b(p_176548_1_, p_176548_2_);
      if (blockportal$size != null) {
         blockportal$size.func_150859_c();
         return true;
      } else {
         return false;
      }
   }

   @Nullable
   public BlockPortal.Size func_201816_b(IWorld p_201816_1_, BlockPos p_201816_2_) {
      BlockPortal.Size blockportal$size = new BlockPortal.Size(p_201816_1_, p_201816_2_, EnumFacing.Axis.X);
      if (blockportal$size.func_150860_b() && blockportal$size.field_150864_e == 0) {
         return blockportal$size;
      } else {
         BlockPortal.Size blockportal$size1 = new BlockPortal.Size(p_201816_1_, p_201816_2_, EnumFacing.Axis.Z);
         return blockportal$size1.func_150860_b() && blockportal$size1.field_150864_e == 0 ? blockportal$size1 : null;
      }
   }

   public IBlockState func_196271_a(IBlockState p_196271_1_, EnumFacing p_196271_2_, IBlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      EnumFacing.Axis enumfacing$axis = p_196271_2_.func_176740_k();
      EnumFacing.Axis enumfacing$axis1 = p_196271_1_.func_177229_b(field_176550_a);
      boolean flag = enumfacing$axis1 != enumfacing$axis && enumfacing$axis.func_176722_c();
      return !flag && p_196271_3_.func_177230_c() != this && !(new BlockPortal.Size(p_196271_4_, p_196271_5_, enumfacing$axis1)).func_208508_f() ? Blocks.field_150350_a.func_176223_P() : super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
   }

   public int func_196264_a(IBlockState p_196264_1_, Random p_196264_2_) {
      return 0;
   }

   public BlockRenderLayer func_180664_k() {
      return BlockRenderLayer.TRANSLUCENT;
   }

   public void func_196262_a(IBlockState p_196262_1_, World p_196262_2_, BlockPos p_196262_3_, Entity p_196262_4_) {
      if (!p_196262_4_.func_184218_aH() && !p_196262_4_.func_184207_aI() && p_196262_4_.func_184222_aU()) {
         p_196262_4_.func_181015_d(p_196262_3_);
      }

   }

   @OnlyIn(Dist.CLIENT)
   public void func_180655_c(IBlockState p_180655_1_, World p_180655_2_, BlockPos p_180655_3_, Random p_180655_4_) {
      if (p_180655_4_.nextInt(100) == 0) {
         p_180655_2_.func_184134_a((double)p_180655_3_.func_177958_n() + 0.5D, (double)p_180655_3_.func_177956_o() + 0.5D, (double)p_180655_3_.func_177952_p() + 0.5D, SoundEvents.field_187810_eg, SoundCategory.BLOCKS, 0.5F, p_180655_4_.nextFloat() * 0.4F + 0.8F, false);
      }

      for(int i = 0; i < 4; ++i) {
         double d0 = (double)((float)p_180655_3_.func_177958_n() + p_180655_4_.nextFloat());
         double d1 = (double)((float)p_180655_3_.func_177956_o() + p_180655_4_.nextFloat());
         double d2 = (double)((float)p_180655_3_.func_177952_p() + p_180655_4_.nextFloat());
         double d3 = ((double)p_180655_4_.nextFloat() - 0.5D) * 0.5D;
         double d4 = ((double)p_180655_4_.nextFloat() - 0.5D) * 0.5D;
         double d5 = ((double)p_180655_4_.nextFloat() - 0.5D) * 0.5D;
         int j = p_180655_4_.nextInt(2) * 2 - 1;
         if (p_180655_2_.func_180495_p(p_180655_3_.func_177976_e()).func_177230_c() != this && p_180655_2_.func_180495_p(p_180655_3_.func_177974_f()).func_177230_c() != this) {
            d0 = (double)p_180655_3_.func_177958_n() + 0.5D + 0.25D * (double)j;
            d3 = (double)(p_180655_4_.nextFloat() * 2.0F * (float)j);
         } else {
            d2 = (double)p_180655_3_.func_177952_p() + 0.5D + 0.25D * (double)j;
            d5 = (double)(p_180655_4_.nextFloat() * 2.0F * (float)j);
         }

         p_180655_2_.func_195594_a(Particles.field_197599_J, d0, d1, d2, d3, d4, d5);
      }

   }

   public ItemStack func_185473_a(IBlockReader p_185473_1_, BlockPos p_185473_2_, IBlockState p_185473_3_) {
      return ItemStack.field_190927_a;
   }

   public IBlockState func_185499_a(IBlockState p_185499_1_, Rotation p_185499_2_) {
      switch(p_185499_2_) {
      case COUNTERCLOCKWISE_90:
      case CLOCKWISE_90:
         switch((EnumFacing.Axis)p_185499_1_.func_177229_b(field_176550_a)) {
         case Z:
            return p_185499_1_.func_206870_a(field_176550_a, EnumFacing.Axis.X);
         case X:
            return p_185499_1_.func_206870_a(field_176550_a, EnumFacing.Axis.Z);
         default:
            return p_185499_1_;
         }
      default:
         return p_185499_1_;
      }
   }

   protected void func_206840_a(StateContainer.Builder<Block, IBlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_176550_a);
   }

   public BlockPattern.PatternHelper func_181089_f(IWorld p_181089_1_, BlockPos p_181089_2_) {
      EnumFacing.Axis enumfacing$axis = EnumFacing.Axis.Z;
      BlockPortal.Size blockportal$size = new BlockPortal.Size(p_181089_1_, p_181089_2_, EnumFacing.Axis.X);
      LoadingCache<BlockPos, BlockWorldState> loadingcache = BlockPattern.func_181627_a(p_181089_1_, true);
      if (!blockportal$size.func_150860_b()) {
         enumfacing$axis = EnumFacing.Axis.X;
         blockportal$size = new BlockPortal.Size(p_181089_1_, p_181089_2_, EnumFacing.Axis.Z);
      }

      if (!blockportal$size.func_150860_b()) {
         return new BlockPattern.PatternHelper(p_181089_2_, EnumFacing.NORTH, EnumFacing.UP, loadingcache, 1, 1, 1);
      } else {
         int[] aint = new int[EnumFacing.AxisDirection.values().length];
         EnumFacing enumfacing = blockportal$size.field_150866_c.func_176735_f();
         BlockPos blockpos = blockportal$size.field_150861_f.func_177981_b(blockportal$size.func_181100_a() - 1);

         for(EnumFacing.AxisDirection enumfacing$axisdirection : EnumFacing.AxisDirection.values()) {
            BlockPattern.PatternHelper blockpattern$patternhelper = new BlockPattern.PatternHelper(enumfacing.func_176743_c() == enumfacing$axisdirection ? blockpos : blockpos.func_177967_a(blockportal$size.field_150866_c, blockportal$size.func_181101_b() - 1), EnumFacing.func_181076_a(enumfacing$axisdirection, enumfacing$axis), EnumFacing.UP, loadingcache, blockportal$size.func_181101_b(), blockportal$size.func_181100_a(), 1);

            for(int i = 0; i < blockportal$size.func_181101_b(); ++i) {
               for(int j = 0; j < blockportal$size.func_181100_a(); ++j) {
                  BlockWorldState blockworldstate = blockpattern$patternhelper.func_177670_a(i, j, 1);
                  if (!blockworldstate.func_177509_a().func_196958_f()) {
                     ++aint[enumfacing$axisdirection.ordinal()];
                  }
               }
            }
         }

         EnumFacing.AxisDirection enumfacing$axisdirection1 = EnumFacing.AxisDirection.POSITIVE;

         for(EnumFacing.AxisDirection enumfacing$axisdirection2 : EnumFacing.AxisDirection.values()) {
            if (aint[enumfacing$axisdirection2.ordinal()] < aint[enumfacing$axisdirection1.ordinal()]) {
               enumfacing$axisdirection1 = enumfacing$axisdirection2;
            }
         }

         return new BlockPattern.PatternHelper(enumfacing.func_176743_c() == enumfacing$axisdirection1 ? blockpos : blockpos.func_177967_a(blockportal$size.field_150866_c, blockportal$size.func_181101_b() - 1), EnumFacing.func_181076_a(enumfacing$axisdirection1, enumfacing$axis), EnumFacing.UP, loadingcache, blockportal$size.func_181101_b(), blockportal$size.func_181100_a(), 1);
      }
   }

   public BlockFaceShape func_193383_a(IBlockReader p_193383_1_, IBlockState p_193383_2_, BlockPos p_193383_3_, EnumFacing p_193383_4_) {
      return BlockFaceShape.UNDEFINED;
   }

   public static class Size {
      private final IWorld field_150867_a;
      private final EnumFacing.Axis field_150865_b;
      private final EnumFacing field_150866_c;
      private final EnumFacing field_150863_d;
      private int field_150864_e;
      private BlockPos field_150861_f;
      private int field_150862_g;
      private int field_150868_h;

      public Size(IWorld p_i48740_1_, BlockPos p_i48740_2_, EnumFacing.Axis p_i48740_3_) {
         this.field_150867_a = p_i48740_1_;
         this.field_150865_b = p_i48740_3_;
         if (p_i48740_3_ == EnumFacing.Axis.X) {
            this.field_150863_d = EnumFacing.EAST;
            this.field_150866_c = EnumFacing.WEST;
         } else {
            this.field_150863_d = EnumFacing.NORTH;
            this.field_150866_c = EnumFacing.SOUTH;
         }

         for(BlockPos blockpos = p_i48740_2_; p_i48740_2_.func_177956_o() > blockpos.func_177956_o() - 21 && p_i48740_2_.func_177956_o() > 0 && this.func_196900_a(p_i48740_1_.func_180495_p(p_i48740_2_.func_177977_b())); p_i48740_2_ = p_i48740_2_.func_177977_b()) {
            ;
         }

         int i = this.func_180120_a(p_i48740_2_, this.field_150863_d) - 1;
         if (i >= 0) {
            this.field_150861_f = p_i48740_2_.func_177967_a(this.field_150863_d, i);
            this.field_150868_h = this.func_180120_a(this.field_150861_f, this.field_150866_c);
            if (this.field_150868_h < 2 || this.field_150868_h > 21) {
               this.field_150861_f = null;
               this.field_150868_h = 0;
            }
         }

         if (this.field_150861_f != null) {
            this.field_150862_g = this.func_150858_a();
         }

      }

      protected int func_180120_a(BlockPos p_180120_1_, EnumFacing p_180120_2_) {
         int i;
         for(i = 0; i < 22; ++i) {
            BlockPos blockpos = p_180120_1_.func_177967_a(p_180120_2_, i);
            if (!this.func_196900_a(this.field_150867_a.func_180495_p(blockpos)) || this.field_150867_a.func_180495_p(blockpos.func_177977_b()).func_177230_c() != Blocks.field_150343_Z) {
               break;
            }
         }

         Block block = this.field_150867_a.func_180495_p(p_180120_1_.func_177967_a(p_180120_2_, i)).func_177230_c();
         return block == Blocks.field_150343_Z ? i : 0;
      }

      public int func_181100_a() {
         return this.field_150862_g;
      }

      public int func_181101_b() {
         return this.field_150868_h;
      }

      protected int func_150858_a() {
         label56:
         for(this.field_150862_g = 0; this.field_150862_g < 21; ++this.field_150862_g) {
            for(int i = 0; i < this.field_150868_h; ++i) {
               BlockPos blockpos = this.field_150861_f.func_177967_a(this.field_150866_c, i).func_177981_b(this.field_150862_g);
               IBlockState iblockstate = this.field_150867_a.func_180495_p(blockpos);
               if (!this.func_196900_a(iblockstate)) {
                  break label56;
               }

               Block block = iblockstate.func_177230_c();
               if (block == Blocks.field_150427_aO) {
                  ++this.field_150864_e;
               }

               if (i == 0) {
                  block = this.field_150867_a.func_180495_p(blockpos.func_177972_a(this.field_150863_d)).func_177230_c();
                  if (block != Blocks.field_150343_Z) {
                     break label56;
                  }
               } else if (i == this.field_150868_h - 1) {
                  block = this.field_150867_a.func_180495_p(blockpos.func_177972_a(this.field_150866_c)).func_177230_c();
                  if (block != Blocks.field_150343_Z) {
                     break label56;
                  }
               }
            }
         }

         for(int j = 0; j < this.field_150868_h; ++j) {
            if (this.field_150867_a.func_180495_p(this.field_150861_f.func_177967_a(this.field_150866_c, j).func_177981_b(this.field_150862_g)).func_177230_c() != Blocks.field_150343_Z) {
               this.field_150862_g = 0;
               break;
            }
         }

         if (this.field_150862_g <= 21 && this.field_150862_g >= 3) {
            return this.field_150862_g;
         } else {
            this.field_150861_f = null;
            this.field_150868_h = 0;
            this.field_150862_g = 0;
            return 0;
         }
      }

      protected boolean func_196900_a(IBlockState p_196900_1_) {
         Block block = p_196900_1_.func_177230_c();
         return p_196900_1_.func_196958_f() || block == Blocks.field_150480_ab || block == Blocks.field_150427_aO;
      }

      public boolean func_150860_b() {
         return this.field_150861_f != null && this.field_150868_h >= 2 && this.field_150868_h <= 21 && this.field_150862_g >= 3 && this.field_150862_g <= 21;
      }

      public void func_150859_c() {
         for(int i = 0; i < this.field_150868_h; ++i) {
            BlockPos blockpos = this.field_150861_f.func_177967_a(this.field_150866_c, i);

            for(int j = 0; j < this.field_150862_g; ++j) {
               this.field_150867_a.func_180501_a(blockpos.func_177981_b(j), Blocks.field_150427_aO.func_176223_P().func_206870_a(BlockPortal.field_176550_a, this.field_150865_b), 18);
            }
         }

      }

      private boolean func_196899_f() {
         return this.field_150864_e >= this.field_150868_h * this.field_150862_g;
      }

      public boolean func_208508_f() {
         return this.func_150860_b() && this.func_196899_f();
      }
   }
}
