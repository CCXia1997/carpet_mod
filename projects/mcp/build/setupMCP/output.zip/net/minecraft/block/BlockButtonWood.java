package net.minecraft.block;

import net.minecraft.init.SoundEvents;
import net.minecraft.util.SoundEvent;

public class BlockButtonWood extends BlockButton {
   protected BlockButtonWood(Block.Properties p_i48291_1_) {
      super(true, p_i48291_1_);
   }

   protected SoundEvent func_196369_b(boolean p_196369_1_) {
      return p_196369_1_ ? SoundEvents.field_187885_gS : SoundEvents.field_187883_gR;
   }
}
