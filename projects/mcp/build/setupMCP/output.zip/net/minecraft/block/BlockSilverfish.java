package net.minecraft.block;

import com.google.common.collect.Maps;
import java.util.Map;
import java.util.Random;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.monster.EntitySilverfish;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class BlockSilverfish extends Block {
   private final Block field_196469_a;
   private static final Map<Block, Block> field_196470_b = Maps.newIdentityHashMap();

   public BlockSilverfish(Block p_i48374_1_, Block.Properties p_i48374_2_) {
      super(p_i48374_2_);
      this.field_196469_a = p_i48374_1_;
      field_196470_b.put(p_i48374_1_, this);
   }

   public int func_196264_a(IBlockState p_196264_1_, Random p_196264_2_) {
      return 0;
   }

   public Block func_196468_d() {
      return this.field_196469_a;
   }

   public static boolean func_196466_i(IBlockState p_196466_0_) {
      return field_196470_b.containsKey(p_196466_0_.func_177230_c());
   }

   protected ItemStack func_180643_i(IBlockState p_180643_1_) {
      return new ItemStack(this.field_196469_a);
   }

   public void func_196255_a(IBlockState p_196255_1_, World p_196255_2_, BlockPos p_196255_3_, float p_196255_4_, int p_196255_5_) {
      if (!p_196255_2_.field_72995_K && p_196255_2_.func_82736_K().func_82766_b("doTileDrops")) {
         EntitySilverfish entitysilverfish = new EntitySilverfish(p_196255_2_);
         entitysilverfish.func_70012_b((double)p_196255_3_.func_177958_n() + 0.5D, (double)p_196255_3_.func_177956_o(), (double)p_196255_3_.func_177952_p() + 0.5D, 0.0F, 0.0F);
         p_196255_2_.func_72838_d(entitysilverfish);
         entitysilverfish.func_70656_aK();
      }

   }

   public static IBlockState func_196467_h(Block p_196467_0_) {
      return field_196470_b.get(p_196467_0_).func_176223_P();
   }
}
