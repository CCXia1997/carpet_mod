package net.minecraft.block;

import com.google.common.base.MoreObjects;
import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.item.ItemStack;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.DirectionProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.IWorldReaderBase;
import net.minecraft.world.World;

public class BlockTripWireHook extends Block {
   public static final DirectionProperty field_176264_a = BlockHorizontal.field_185512_D;
   public static final BooleanProperty field_176263_b = BlockStateProperties.field_208194_u;
   public static final BooleanProperty field_176265_M = BlockStateProperties.field_208174_a;
   protected static final VoxelShape field_185743_d = Block.func_208617_a(5.0D, 0.0D, 10.0D, 11.0D, 10.0D, 16.0D);
   protected static final VoxelShape field_185744_e = Block.func_208617_a(5.0D, 0.0D, 0.0D, 11.0D, 10.0D, 6.0D);
   protected static final VoxelShape field_185745_f = Block.func_208617_a(10.0D, 0.0D, 5.0D, 16.0D, 10.0D, 11.0D);
   protected static final VoxelShape field_185746_g = Block.func_208617_a(0.0D, 0.0D, 5.0D, 6.0D, 10.0D, 11.0D);

   public BlockTripWireHook(Block.Properties p_i48304_1_) {
      super(p_i48304_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_176264_a, EnumFacing.NORTH).func_206870_a(field_176263_b, Boolean.valueOf(false)).func_206870_a(field_176265_M, Boolean.valueOf(false)));
   }

   public VoxelShape func_196244_b(IBlockState p_196244_1_, IBlockReader p_196244_2_, BlockPos p_196244_3_) {
      switch((EnumFacing)p_196244_1_.func_177229_b(field_176264_a)) {
      case EAST:
      default:
         return field_185746_g;
      case WEST:
         return field_185745_f;
      case SOUTH:
         return field_185744_e;
      case NORTH:
         return field_185743_d;
      }
   }

   public boolean func_149686_d(IBlockState p_149686_1_) {
      return false;
   }

   public boolean func_196260_a(IBlockState p_196260_1_, IWorldReaderBase p_196260_2_, BlockPos p_196260_3_) {
      EnumFacing enumfacing = p_196260_1_.func_177229_b(field_176264_a);
      BlockPos blockpos = p_196260_3_.func_177972_a(enumfacing.func_176734_d());
      IBlockState iblockstate = p_196260_2_.func_180495_p(blockpos);
      boolean flag = func_193382_c(iblockstate.func_177230_c());
      return !flag && enumfacing.func_176740_k().func_176722_c() && iblockstate.func_193401_d(p_196260_2_, blockpos, enumfacing) == BlockFaceShape.SOLID && !iblockstate.func_185897_m();
   }

   public IBlockState func_196271_a(IBlockState p_196271_1_, EnumFacing p_196271_2_, IBlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      return p_196271_2_.func_176734_d() == p_196271_1_.func_177229_b(field_176264_a) && !p_196271_1_.func_196955_c(p_196271_4_, p_196271_5_) ? Blocks.field_150350_a.func_176223_P() : super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
   }

   @Nullable
   public IBlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      IBlockState iblockstate = this.func_176223_P().func_206870_a(field_176263_b, Boolean.valueOf(false)).func_206870_a(field_176265_M, Boolean.valueOf(false));
      IWorldReaderBase iworldreaderbase = p_196258_1_.func_195991_k();
      BlockPos blockpos = p_196258_1_.func_195995_a();
      EnumFacing[] aenumfacing = p_196258_1_.func_196009_e();

      for(EnumFacing enumfacing : aenumfacing) {
         if (enumfacing.func_176740_k().func_176722_c()) {
            EnumFacing enumfacing1 = enumfacing.func_176734_d();
            iblockstate = iblockstate.func_206870_a(field_176264_a, enumfacing1);
            if (iblockstate.func_196955_c(iworldreaderbase, blockpos)) {
               return iblockstate;
            }
         }
      }

      return null;
   }

   public void func_180633_a(World p_180633_1_, BlockPos p_180633_2_, IBlockState p_180633_3_, EntityLivingBase p_180633_4_, ItemStack p_180633_5_) {
      this.func_176260_a(p_180633_1_, p_180633_2_, p_180633_3_, false, false, -1, (IBlockState)null);
   }

   public void func_176260_a(World p_176260_1_, BlockPos p_176260_2_, IBlockState p_176260_3_, boolean p_176260_4_, boolean p_176260_5_, int p_176260_6_, @Nullable IBlockState p_176260_7_) {
      EnumFacing enumfacing = p_176260_3_.func_177229_b(field_176264_a);
      boolean flag = p_176260_3_.func_177229_b(field_176265_M);
      boolean flag1 = p_176260_3_.func_177229_b(field_176263_b);
      boolean flag2 = !p_176260_4_;
      boolean flag3 = false;
      int i = 0;
      IBlockState[] aiblockstate = new IBlockState[42];

      for(int j = 1; j < 42; ++j) {
         BlockPos blockpos = p_176260_2_.func_177967_a(enumfacing, j);
         IBlockState iblockstate = p_176260_1_.func_180495_p(blockpos);
         if (iblockstate.func_177230_c() == Blocks.field_150479_bC) {
            if (iblockstate.func_177229_b(field_176264_a) == enumfacing.func_176734_d()) {
               i = j;
            }
            break;
         }

         if (iblockstate.func_177230_c() != Blocks.field_150473_bD && j != p_176260_6_) {
            aiblockstate[j] = null;
            flag2 = false;
         } else {
            if (j == p_176260_6_) {
               iblockstate = MoreObjects.firstNonNull(p_176260_7_, iblockstate);
            }

            boolean flag4 = !iblockstate.func_177229_b(BlockTripWire.field_176295_N);
            boolean flag5 = iblockstate.func_177229_b(BlockTripWire.field_176293_a);
            flag3 |= flag4 && flag5;
            aiblockstate[j] = iblockstate;
            if (j == p_176260_6_) {
               p_176260_1_.func_205220_G_().func_205360_a(p_176260_2_, this, this.func_149738_a(p_176260_1_));
               flag2 &= flag4;
            }
         }
      }

      flag2 = flag2 & i > 1;
      flag3 = flag3 & flag2;
      IBlockState iblockstate1 = this.func_176223_P().func_206870_a(field_176265_M, Boolean.valueOf(flag2)).func_206870_a(field_176263_b, Boolean.valueOf(flag3));
      if (i > 0) {
         BlockPos blockpos1 = p_176260_2_.func_177967_a(enumfacing, i);
         EnumFacing enumfacing1 = enumfacing.func_176734_d();
         p_176260_1_.func_180501_a(blockpos1, iblockstate1.func_206870_a(field_176264_a, enumfacing1), 3);
         this.func_176262_b(p_176260_1_, blockpos1, enumfacing1);
         this.func_180694_a(p_176260_1_, blockpos1, flag2, flag3, flag, flag1);
      }

      this.func_180694_a(p_176260_1_, p_176260_2_, flag2, flag3, flag, flag1);
      if (!p_176260_4_) {
         p_176260_1_.func_180501_a(p_176260_2_, iblockstate1.func_206870_a(field_176264_a, enumfacing), 3);
         if (p_176260_5_) {
            this.func_176262_b(p_176260_1_, p_176260_2_, enumfacing);
         }
      }

      if (flag != flag2) {
         for(int k = 1; k < i; ++k) {
            BlockPos blockpos2 = p_176260_2_.func_177967_a(enumfacing, k);
            IBlockState iblockstate2 = aiblockstate[k];
            if (iblockstate2 != null) {
               p_176260_1_.func_180501_a(blockpos2, iblockstate2.func_206870_a(field_176265_M, Boolean.valueOf(flag2)), 3);
               if (!p_176260_1_.func_180495_p(blockpos2).func_196958_f()) {
                  ;
               }
            }
         }
      }

   }

   public void func_196267_b(IBlockState p_196267_1_, World p_196267_2_, BlockPos p_196267_3_, Random p_196267_4_) {
      this.func_176260_a(p_196267_2_, p_196267_3_, p_196267_1_, false, true, -1, (IBlockState)null);
   }

   private void func_180694_a(World p_180694_1_, BlockPos p_180694_2_, boolean p_180694_3_, boolean p_180694_4_, boolean p_180694_5_, boolean p_180694_6_) {
      if (p_180694_4_ && !p_180694_6_) {
         p_180694_1_.func_184133_a((EntityPlayer)null, p_180694_2_, SoundEvents.field_187907_gg, SoundCategory.BLOCKS, 0.4F, 0.6F);
      } else if (!p_180694_4_ && p_180694_6_) {
         p_180694_1_.func_184133_a((EntityPlayer)null, p_180694_2_, SoundEvents.field_187906_gf, SoundCategory.BLOCKS, 0.4F, 0.5F);
      } else if (p_180694_3_ && !p_180694_5_) {
         p_180694_1_.func_184133_a((EntityPlayer)null, p_180694_2_, SoundEvents.field_187905_ge, SoundCategory.BLOCKS, 0.4F, 0.7F);
      } else if (!p_180694_3_ && p_180694_5_) {
         p_180694_1_.func_184133_a((EntityPlayer)null, p_180694_2_, SoundEvents.field_187908_gh, SoundCategory.BLOCKS, 0.4F, 1.2F / (p_180694_1_.field_73012_v.nextFloat() * 0.2F + 0.9F));
      }

   }

   private void func_176262_b(World p_176262_1_, BlockPos p_176262_2_, EnumFacing p_176262_3_) {
      p_176262_1_.func_195593_d(p_176262_2_, this);
      p_176262_1_.func_195593_d(p_176262_2_.func_177972_a(p_176262_3_.func_176734_d()), this);
   }

   public void func_196243_a(IBlockState p_196243_1_, World p_196243_2_, BlockPos p_196243_3_, IBlockState p_196243_4_, boolean p_196243_5_) {
      if (!p_196243_5_ && p_196243_1_.func_177230_c() != p_196243_4_.func_177230_c()) {
         boolean flag = p_196243_1_.func_177229_b(field_176265_M);
         boolean flag1 = p_196243_1_.func_177229_b(field_176263_b);
         if (flag || flag1) {
            this.func_176260_a(p_196243_2_, p_196243_3_, p_196243_1_, true, false, -1, (IBlockState)null);
         }

         if (flag1) {
            p_196243_2_.func_195593_d(p_196243_3_, this);
            p_196243_2_.func_195593_d(p_196243_3_.func_177972_a(p_196243_1_.func_177229_b(field_176264_a).func_176734_d()), this);
         }

         super.func_196243_a(p_196243_1_, p_196243_2_, p_196243_3_, p_196243_4_, p_196243_5_);
      }
   }

   public int func_180656_a(IBlockState p_180656_1_, IBlockReader p_180656_2_, BlockPos p_180656_3_, EnumFacing p_180656_4_) {
      return p_180656_1_.func_177229_b(field_176263_b) ? 15 : 0;
   }

   public int func_176211_b(IBlockState p_176211_1_, IBlockReader p_176211_2_, BlockPos p_176211_3_, EnumFacing p_176211_4_) {
      if (!p_176211_1_.func_177229_b(field_176263_b)) {
         return 0;
      } else {
         return p_176211_1_.func_177229_b(field_176264_a) == p_176211_4_ ? 15 : 0;
      }
   }

   public boolean func_149744_f(IBlockState p_149744_1_) {
      return true;
   }

   public BlockRenderLayer func_180664_k() {
      return BlockRenderLayer.CUTOUT_MIPPED;
   }

   public IBlockState func_185499_a(IBlockState p_185499_1_, Rotation p_185499_2_) {
      return p_185499_1_.func_206870_a(field_176264_a, p_185499_2_.func_185831_a(p_185499_1_.func_177229_b(field_176264_a)));
   }

   public IBlockState func_185471_a(IBlockState p_185471_1_, Mirror p_185471_2_) {
      return p_185471_1_.func_185907_a(p_185471_2_.func_185800_a(p_185471_1_.func_177229_b(field_176264_a)));
   }

   protected void func_206840_a(StateContainer.Builder<Block, IBlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_176264_a, field_176263_b, field_176265_M);
   }

   public BlockFaceShape func_193383_a(IBlockReader p_193383_1_, IBlockState p_193383_2_, BlockPos p_193383_3_, EnumFacing p_193383_4_) {
      return BlockFaceShape.UNDEFINED;
   }
}
