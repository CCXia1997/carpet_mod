package net.minecraft.block;

import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import java.util.Map;
import java.util.Random;
import net.minecraft.block.state.IBlockState;
import net.minecraft.dispenser.BehaviorDefaultDispenseItem;
import net.minecraft.dispenser.BlockSourceImpl;
import net.minecraft.dispenser.IBehaviorDispenseItem;
import net.minecraft.dispenser.IBlockSource;
import net.minecraft.dispenser.IPosition;
import net.minecraft.dispenser.PositionImpl;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.InventoryHelper;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.DirectionProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.stats.StatList;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityDispenser;
import net.minecraft.tileentity.TileEntityDropper;
import net.minecraft.util.EnumBlockRenderType;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.IItemProvider;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.Util;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorldReaderBase;
import net.minecraft.world.World;

public class BlockDispenser extends BlockContainer {
   public static final DirectionProperty field_176441_a = BlockDirectional.field_176387_N;
   public static final BooleanProperty field_176440_b = BlockStateProperties.field_208197_x;
   private static final Map<Item, IBehaviorDispenseItem> field_149943_a = Util.func_200696_a(new Object2ObjectOpenHashMap<>(), (p_212564_0_) -> {
      p_212564_0_.defaultReturnValue(new BehaviorDefaultDispenseItem());
   });

   public static void func_199774_a(IItemProvider p_199774_0_, IBehaviorDispenseItem p_199774_1_) {
      field_149943_a.put(p_199774_0_.func_199767_j(), p_199774_1_);
   }

   protected BlockDispenser(Block.Properties p_i48414_1_) {
      super(p_i48414_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_176441_a, EnumFacing.NORTH).func_206870_a(field_176440_b, Boolean.valueOf(false)));
   }

   public int func_149738_a(IWorldReaderBase p_149738_1_) {
      return 4;
   }

   public boolean func_196250_a(IBlockState p_196250_1_, World p_196250_2_, BlockPos p_196250_3_, EntityPlayer p_196250_4_, EnumHand p_196250_5_, EnumFacing p_196250_6_, float p_196250_7_, float p_196250_8_, float p_196250_9_) {
      if (p_196250_2_.field_72995_K) {
         return true;
      } else {
         TileEntity tileentity = p_196250_2_.func_175625_s(p_196250_3_);
         if (tileentity instanceof TileEntityDispenser) {
            p_196250_4_.func_71007_a((TileEntityDispenser)tileentity);
            if (tileentity instanceof TileEntityDropper) {
               p_196250_4_.func_195066_a(StatList.field_188083_Q);
            } else {
               p_196250_4_.func_195066_a(StatList.field_188085_S);
            }
         }

         return true;
      }
   }

   protected void func_176439_d(World p_176439_1_, BlockPos p_176439_2_) {
      BlockSourceImpl blocksourceimpl = new BlockSourceImpl(p_176439_1_, p_176439_2_);
      TileEntityDispenser tileentitydispenser = blocksourceimpl.func_150835_j();
      int i = tileentitydispenser.func_146017_i();
      if (i < 0) {
         p_176439_1_.func_175718_b(1001, p_176439_2_, 0);
      } else {
         ItemStack itemstack = tileentitydispenser.func_70301_a(i);
         IBehaviorDispenseItem ibehaviordispenseitem = this.func_149940_a(itemstack);
         if (ibehaviordispenseitem != IBehaviorDispenseItem.NOOP) {
            tileentitydispenser.func_70299_a(i, ibehaviordispenseitem.dispense(blocksourceimpl, itemstack));
         }

      }
   }

   protected IBehaviorDispenseItem func_149940_a(ItemStack p_149940_1_) {
      return field_149943_a.get(p_149940_1_.func_77973_b());
   }

   public void func_189540_a(IBlockState p_189540_1_, World p_189540_2_, BlockPos p_189540_3_, Block p_189540_4_, BlockPos p_189540_5_) {
      boolean flag = p_189540_2_.func_175640_z(p_189540_3_) || p_189540_2_.func_175640_z(p_189540_3_.func_177984_a());
      boolean flag1 = p_189540_1_.func_177229_b(field_176440_b);
      if (flag && !flag1) {
         p_189540_2_.func_205220_G_().func_205360_a(p_189540_3_, this, this.func_149738_a(p_189540_2_));
         p_189540_2_.func_180501_a(p_189540_3_, p_189540_1_.func_206870_a(field_176440_b, Boolean.valueOf(true)), 4);
      } else if (!flag && flag1) {
         p_189540_2_.func_180501_a(p_189540_3_, p_189540_1_.func_206870_a(field_176440_b, Boolean.valueOf(false)), 4);
      }

   }

   public void func_196267_b(IBlockState p_196267_1_, World p_196267_2_, BlockPos p_196267_3_, Random p_196267_4_) {
      if (!p_196267_2_.field_72995_K) {
         this.func_176439_d(p_196267_2_, p_196267_3_);
      }

   }

   public TileEntity func_196283_a_(IBlockReader p_196283_1_) {
      return new TileEntityDispenser();
   }

   public IBlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      return this.func_176223_P().func_206870_a(field_176441_a, p_196258_1_.func_196010_d().func_176734_d());
   }

   public void func_180633_a(World p_180633_1_, BlockPos p_180633_2_, IBlockState p_180633_3_, EntityLivingBase p_180633_4_, ItemStack p_180633_5_) {
      if (p_180633_5_.func_82837_s()) {
         TileEntity tileentity = p_180633_1_.func_175625_s(p_180633_2_);
         if (tileentity instanceof TileEntityDispenser) {
            ((TileEntityDispenser)tileentity).func_200226_a(p_180633_5_.func_200301_q());
         }
      }

   }

   public void func_196243_a(IBlockState p_196243_1_, World p_196243_2_, BlockPos p_196243_3_, IBlockState p_196243_4_, boolean p_196243_5_) {
      if (p_196243_1_.func_177230_c() != p_196243_4_.func_177230_c()) {
         TileEntity tileentity = p_196243_2_.func_175625_s(p_196243_3_);
         if (tileentity instanceof TileEntityDispenser) {
            InventoryHelper.func_180175_a(p_196243_2_, p_196243_3_, (TileEntityDispenser)tileentity);
            p_196243_2_.func_175666_e(p_196243_3_, this);
         }

         super.func_196243_a(p_196243_1_, p_196243_2_, p_196243_3_, p_196243_4_, p_196243_5_);
      }
   }

   public static IPosition func_149939_a(IBlockSource p_149939_0_) {
      EnumFacing enumfacing = p_149939_0_.func_189992_e().func_177229_b(field_176441_a);
      double d0 = p_149939_0_.func_82615_a() + 0.7D * (double)enumfacing.func_82601_c();
      double d1 = p_149939_0_.func_82617_b() + 0.7D * (double)enumfacing.func_96559_d();
      double d2 = p_149939_0_.func_82616_c() + 0.7D * (double)enumfacing.func_82599_e();
      return new PositionImpl(d0, d1, d2);
   }

   public boolean func_149740_M(IBlockState p_149740_1_) {
      return true;
   }

   public int func_180641_l(IBlockState p_180641_1_, World p_180641_2_, BlockPos p_180641_3_) {
      return Container.func_178144_a(p_180641_2_.func_175625_s(p_180641_3_));
   }

   public EnumBlockRenderType func_149645_b(IBlockState p_149645_1_) {
      return EnumBlockRenderType.MODEL;
   }

   public IBlockState func_185499_a(IBlockState p_185499_1_, Rotation p_185499_2_) {
      return p_185499_1_.func_206870_a(field_176441_a, p_185499_2_.func_185831_a(p_185499_1_.func_177229_b(field_176441_a)));
   }

   public IBlockState func_185471_a(IBlockState p_185471_1_, Mirror p_185471_2_) {
      return p_185471_1_.func_185907_a(p_185471_2_.func_185800_a(p_185471_1_.func_177229_b(field_176441_a)));
   }

   protected void func_206840_a(StateContainer.Builder<Block, IBlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_176441_a, field_176440_b);
   }
}
