package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.item.ItemStack;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.DirectionProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.tileentity.CommandBlockBaseLogic;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityCommandBlock;
import net.minecraft.util.EnumBlockRenderType;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.StringUtils;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.GameRules;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorldReaderBase;
import net.minecraft.world.World;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class BlockCommandBlock extends BlockContainer {
   private static final Logger field_193388_c = LogManager.getLogger();
   public static final DirectionProperty field_185564_a = BlockDirectional.field_176387_N;
   public static final BooleanProperty field_185565_b = BlockStateProperties.field_208176_c;

   public BlockCommandBlock(Block.Properties p_i48425_1_) {
      super(p_i48425_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_185564_a, EnumFacing.NORTH).func_206870_a(field_185565_b, Boolean.valueOf(false)));
   }

   public TileEntity func_196283_a_(IBlockReader p_196283_1_) {
      TileEntityCommandBlock tileentitycommandblock = new TileEntityCommandBlock();
      tileentitycommandblock.func_184253_b(this == Blocks.field_185777_dd);
      return tileentitycommandblock;
   }

   public void func_189540_a(IBlockState p_189540_1_, World p_189540_2_, BlockPos p_189540_3_, Block p_189540_4_, BlockPos p_189540_5_) {
      if (!p_189540_2_.field_72995_K) {
         TileEntity tileentity = p_189540_2_.func_175625_s(p_189540_3_);
         if (tileentity instanceof TileEntityCommandBlock) {
            TileEntityCommandBlock tileentitycommandblock = (TileEntityCommandBlock)tileentity;
            boolean flag = p_189540_2_.func_175640_z(p_189540_3_);
            boolean flag1 = tileentitycommandblock.func_184255_d();
            tileentitycommandblock.func_184250_a(flag);
            if (!flag1 && !tileentitycommandblock.func_184254_e() && tileentitycommandblock.func_184251_i() != TileEntityCommandBlock.Mode.SEQUENCE) {
               if (flag) {
                  tileentitycommandblock.func_184249_c();
                  p_189540_2_.func_205220_G_().func_205360_a(p_189540_3_, this, this.func_149738_a(p_189540_2_));
               }

            }
         }
      }
   }

   public void func_196267_b(IBlockState p_196267_1_, World p_196267_2_, BlockPos p_196267_3_, Random p_196267_4_) {
      if (!p_196267_2_.field_72995_K) {
         TileEntity tileentity = p_196267_2_.func_175625_s(p_196267_3_);
         if (tileentity instanceof TileEntityCommandBlock) {
            TileEntityCommandBlock tileentitycommandblock = (TileEntityCommandBlock)tileentity;
            CommandBlockBaseLogic commandblockbaselogic = tileentitycommandblock.func_145993_a();
            boolean flag = !StringUtils.func_151246_b(commandblockbaselogic.func_145753_i());
            TileEntityCommandBlock.Mode tileentitycommandblock$mode = tileentitycommandblock.func_184251_i();
            boolean flag1 = tileentitycommandblock.func_184256_g();
            if (tileentitycommandblock$mode == TileEntityCommandBlock.Mode.AUTO) {
               tileentitycommandblock.func_184249_c();
               if (flag1) {
                  this.func_193387_a(p_196267_1_, p_196267_2_, p_196267_3_, commandblockbaselogic, flag);
               } else if (tileentitycommandblock.func_184258_j()) {
                  commandblockbaselogic.func_184167_a(0);
               }

               if (tileentitycommandblock.func_184255_d() || tileentitycommandblock.func_184254_e()) {
                  p_196267_2_.func_205220_G_().func_205360_a(p_196267_3_, this, this.func_149738_a(p_196267_2_));
               }
            } else if (tileentitycommandblock$mode == TileEntityCommandBlock.Mode.REDSTONE) {
               if (flag1) {
                  this.func_193387_a(p_196267_1_, p_196267_2_, p_196267_3_, commandblockbaselogic, flag);
               } else if (tileentitycommandblock.func_184258_j()) {
                  commandblockbaselogic.func_184167_a(0);
               }
            }

            p_196267_2_.func_175666_e(p_196267_3_, this);
         }

      }
   }

   private void func_193387_a(IBlockState p_193387_1_, World p_193387_2_, BlockPos p_193387_3_, CommandBlockBaseLogic p_193387_4_, boolean p_193387_5_) {
      if (p_193387_5_) {
         p_193387_4_.func_145755_a(p_193387_2_);
      } else {
         p_193387_4_.func_184167_a(0);
      }

      func_193386_c(p_193387_2_, p_193387_3_, p_193387_1_.func_177229_b(field_185564_a));
   }

   public int func_149738_a(IWorldReaderBase p_149738_1_) {
      return 1;
   }

   public boolean func_196250_a(IBlockState p_196250_1_, World p_196250_2_, BlockPos p_196250_3_, EntityPlayer p_196250_4_, EnumHand p_196250_5_, EnumFacing p_196250_6_, float p_196250_7_, float p_196250_8_, float p_196250_9_) {
      TileEntity tileentity = p_196250_2_.func_175625_s(p_196250_3_);
      if (tileentity instanceof TileEntityCommandBlock && p_196250_4_.func_195070_dx()) {
         p_196250_4_.func_184824_a((TileEntityCommandBlock)tileentity);
         return true;
      } else {
         return false;
      }
   }

   public boolean func_149740_M(IBlockState p_149740_1_) {
      return true;
   }

   public int func_180641_l(IBlockState p_180641_1_, World p_180641_2_, BlockPos p_180641_3_) {
      TileEntity tileentity = p_180641_2_.func_175625_s(p_180641_3_);
      return tileentity instanceof TileEntityCommandBlock ? ((TileEntityCommandBlock)tileentity).func_145993_a().func_145760_g() : 0;
   }

   public void func_180633_a(World p_180633_1_, BlockPos p_180633_2_, IBlockState p_180633_3_, EntityLivingBase p_180633_4_, ItemStack p_180633_5_) {
      TileEntity tileentity = p_180633_1_.func_175625_s(p_180633_2_);
      if (tileentity instanceof TileEntityCommandBlock) {
         TileEntityCommandBlock tileentitycommandblock = (TileEntityCommandBlock)tileentity;
         CommandBlockBaseLogic commandblockbaselogic = tileentitycommandblock.func_145993_a();
         if (p_180633_5_.func_82837_s()) {
            commandblockbaselogic.func_207405_b(p_180633_5_.func_200301_q());
         }

         if (!p_180633_1_.field_72995_K) {
            if (p_180633_5_.func_179543_a("BlockEntityTag") == null) {
               commandblockbaselogic.func_175573_a(p_180633_1_.func_82736_K().func_82766_b("sendCommandFeedback"));
               tileentitycommandblock.func_184253_b(this == Blocks.field_185777_dd);
            }

            if (tileentitycommandblock.func_184251_i() == TileEntityCommandBlock.Mode.SEQUENCE) {
               boolean flag = p_180633_1_.func_175640_z(p_180633_2_);
               tileentitycommandblock.func_184250_a(flag);
            }
         }

      }
   }

   public int func_196264_a(IBlockState p_196264_1_, Random p_196264_2_) {
      return 0;
   }

   public EnumBlockRenderType func_149645_b(IBlockState p_149645_1_) {
      return EnumBlockRenderType.MODEL;
   }

   public IBlockState func_185499_a(IBlockState p_185499_1_, Rotation p_185499_2_) {
      return p_185499_1_.func_206870_a(field_185564_a, p_185499_2_.func_185831_a(p_185499_1_.func_177229_b(field_185564_a)));
   }

   public IBlockState func_185471_a(IBlockState p_185471_1_, Mirror p_185471_2_) {
      return p_185471_1_.func_185907_a(p_185471_2_.func_185800_a(p_185471_1_.func_177229_b(field_185564_a)));
   }

   protected void func_206840_a(StateContainer.Builder<Block, IBlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_185564_a, field_185565_b);
   }

   public IBlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      return this.func_176223_P().func_206870_a(field_185564_a, p_196258_1_.func_196010_d().func_176734_d());
   }

   private static void func_193386_c(World p_193386_0_, BlockPos p_193386_1_, EnumFacing p_193386_2_) {
      BlockPos.MutableBlockPos blockpos$mutableblockpos = new BlockPos.MutableBlockPos(p_193386_1_);
      GameRules gamerules = p_193386_0_.func_82736_K();

      int i;
      IBlockState iblockstate;
      for(i = gamerules.func_180263_c("maxCommandChainLength"); i-- > 0; p_193386_2_ = iblockstate.func_177229_b(field_185564_a)) {
         blockpos$mutableblockpos.func_189536_c(p_193386_2_);
         iblockstate = p_193386_0_.func_180495_p(blockpos$mutableblockpos);
         Block block = iblockstate.func_177230_c();
         if (block != Blocks.field_185777_dd) {
            break;
         }

         TileEntity tileentity = p_193386_0_.func_175625_s(blockpos$mutableblockpos);
         if (!(tileentity instanceof TileEntityCommandBlock)) {
            break;
         }

         TileEntityCommandBlock tileentitycommandblock = (TileEntityCommandBlock)tileentity;
         if (tileentitycommandblock.func_184251_i() != TileEntityCommandBlock.Mode.SEQUENCE) {
            break;
         }

         if (tileentitycommandblock.func_184255_d() || tileentitycommandblock.func_184254_e()) {
            CommandBlockBaseLogic commandblockbaselogic = tileentitycommandblock.func_145993_a();
            if (tileentitycommandblock.func_184249_c()) {
               if (!commandblockbaselogic.func_145755_a(p_193386_0_)) {
                  break;
               }

               p_193386_0_.func_175666_e(blockpos$mutableblockpos, block);
            } else if (tileentitycommandblock.func_184258_j()) {
               commandblockbaselogic.func_184167_a(0);
            }
         }
      }

      if (i <= 0) {
         int j = Math.max(gamerules.func_180263_c("maxCommandChainLength"), 0);
         field_193388_c.warn("Command Block chain tried to execute more than {} steps!", (int)j);
      }

   }
}
