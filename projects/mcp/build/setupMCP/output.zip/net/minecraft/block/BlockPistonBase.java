package net.minecraft.block;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import java.util.List;
import java.util.Set;
import net.minecraft.block.material.EnumPushReaction;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.BlockPistonStructureHelper;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.item.ItemStack;
import net.minecraft.pathfinding.PathType;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.state.properties.PistonType;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityPiston;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.shapes.VoxelShapes;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;

public class BlockPistonBase extends BlockDirectional {
   public static final BooleanProperty field_176320_b = BlockStateProperties.field_208181_h;
   protected static final VoxelShape field_185648_b = Block.func_208617_a(0.0D, 0.0D, 0.0D, 12.0D, 16.0D, 16.0D);
   protected static final VoxelShape field_185649_c = Block.func_208617_a(4.0D, 0.0D, 0.0D, 16.0D, 16.0D, 16.0D);
   protected static final VoxelShape field_185650_d = Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 16.0D, 12.0D);
   protected static final VoxelShape field_185651_e = Block.func_208617_a(0.0D, 0.0D, 4.0D, 16.0D, 16.0D, 16.0D);
   protected static final VoxelShape field_185652_f = Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 12.0D, 16.0D);
   protected static final VoxelShape field_185653_g = Block.func_208617_a(0.0D, 4.0D, 0.0D, 16.0D, 16.0D, 16.0D);
   private final boolean field_150082_a;

   public BlockPistonBase(boolean p_i48281_1_, Block.Properties p_i48281_2_) {
      super(p_i48281_2_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_176387_N, EnumFacing.NORTH).func_206870_a(field_176320_b, Boolean.valueOf(false)));
      this.field_150082_a = p_i48281_1_;
   }

   public boolean func_176214_u(IBlockState p_176214_1_) {
      return !p_176214_1_.func_177229_b(field_176320_b);
   }

   public VoxelShape func_196244_b(IBlockState p_196244_1_, IBlockReader p_196244_2_, BlockPos p_196244_3_) {
      if (p_196244_1_.func_177229_b(field_176320_b)) {
         switch((EnumFacing)p_196244_1_.func_177229_b(field_176387_N)) {
         case DOWN:
            return field_185653_g;
         case UP:
         default:
            return field_185652_f;
         case NORTH:
            return field_185651_e;
         case SOUTH:
            return field_185650_d;
         case WEST:
            return field_185649_c;
         case EAST:
            return field_185648_b;
         }
      } else {
         return VoxelShapes.func_197868_b();
      }
   }

   public boolean func_185481_k(IBlockState p_185481_1_) {
      return !p_185481_1_.func_177229_b(field_176320_b) || p_185481_1_.func_177229_b(field_176387_N) == EnumFacing.DOWN;
   }

   public void func_180633_a(World p_180633_1_, BlockPos p_180633_2_, IBlockState p_180633_3_, EntityLivingBase p_180633_4_, ItemStack p_180633_5_) {
      if (!p_180633_1_.field_72995_K) {
         this.func_176316_e(p_180633_1_, p_180633_2_, p_180633_3_);
      }

   }

   public void func_189540_a(IBlockState p_189540_1_, World p_189540_2_, BlockPos p_189540_3_, Block p_189540_4_, BlockPos p_189540_5_) {
      if (!p_189540_2_.field_72995_K) {
         this.func_176316_e(p_189540_2_, p_189540_3_, p_189540_1_);
      }

   }

   public void func_196259_b(IBlockState p_196259_1_, World p_196259_2_, BlockPos p_196259_3_, IBlockState p_196259_4_) {
      if (p_196259_4_.func_177230_c() != p_196259_1_.func_177230_c()) {
         if (!p_196259_2_.field_72995_K && p_196259_2_.func_175625_s(p_196259_3_) == null) {
            this.func_176316_e(p_196259_2_, p_196259_3_, p_196259_1_);
         }

      }
   }

   public IBlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      return this.func_176223_P().func_206870_a(field_176387_N, p_196258_1_.func_196010_d().func_176734_d()).func_206870_a(field_176320_b, Boolean.valueOf(false));
   }

   private void func_176316_e(World p_176316_1_, BlockPos p_176316_2_, IBlockState p_176316_3_) {
      EnumFacing enumfacing = p_176316_3_.func_177229_b(field_176387_N);
      boolean flag = this.func_176318_b(p_176316_1_, p_176316_2_, enumfacing);
      if (flag && !p_176316_3_.func_177229_b(field_176320_b)) {
         if ((new BlockPistonStructureHelper(p_176316_1_, p_176316_2_, enumfacing, true)).func_177253_a()) {
            p_176316_1_.func_175641_c(p_176316_2_, this, 0, enumfacing.func_176745_a());
         }
      } else if (!flag && p_176316_3_.func_177229_b(field_176320_b)) {
         BlockPos blockpos = p_176316_2_.func_177967_a(enumfacing, 2);
         IBlockState iblockstate = p_176316_1_.func_180495_p(blockpos);
         int i = 1;
         if (iblockstate.func_177230_c() == Blocks.field_196603_bb && iblockstate.func_177229_b(field_176387_N) == enumfacing) {
            TileEntity tileentity = p_176316_1_.func_175625_s(blockpos);
            if (tileentity instanceof TileEntityPiston) {
               TileEntityPiston tileentitypiston = (TileEntityPiston)tileentity;
               if (tileentitypiston.func_145868_b() && (tileentitypiston.func_145860_a(0.0F) < 0.5F || p_176316_1_.func_82737_E() == tileentitypiston.func_211146_k() || ((WorldServer)p_176316_1_).func_211158_j_())) {
                  i = 2;
               }
            }
         }

         p_176316_1_.func_175641_c(p_176316_2_, this, i, enumfacing.func_176745_a());
      }

   }

   private boolean func_176318_b(World p_176318_1_, BlockPos p_176318_2_, EnumFacing p_176318_3_) {
      for(EnumFacing enumfacing : EnumFacing.values()) {
         if (enumfacing != p_176318_3_ && p_176318_1_.func_175709_b(p_176318_2_.func_177972_a(enumfacing), enumfacing)) {
            return true;
         }
      }

      if (p_176318_1_.func_175709_b(p_176318_2_, EnumFacing.DOWN)) {
         return true;
      } else {
         BlockPos blockpos = p_176318_2_.func_177984_a();

         for(EnumFacing enumfacing1 : EnumFacing.values()) {
            if (enumfacing1 != EnumFacing.DOWN && p_176318_1_.func_175709_b(blockpos.func_177972_a(enumfacing1), enumfacing1)) {
               return true;
            }
         }

         return false;
      }
   }

   public boolean func_189539_a(IBlockState p_189539_1_, World p_189539_2_, BlockPos p_189539_3_, int p_189539_4_, int p_189539_5_) {
      EnumFacing enumfacing = p_189539_1_.func_177229_b(field_176387_N);
      if (!p_189539_2_.field_72995_K) {
         boolean flag = this.func_176318_b(p_189539_2_, p_189539_3_, enumfacing);
         if (flag && (p_189539_4_ == 1 || p_189539_4_ == 2)) {
            p_189539_2_.func_180501_a(p_189539_3_, p_189539_1_.func_206870_a(field_176320_b, Boolean.valueOf(true)), 2);
            return false;
         }

         if (!flag && p_189539_4_ == 0) {
            return false;
         }
      }

      if (p_189539_4_ == 0) {
         if (!this.func_176319_a(p_189539_2_, p_189539_3_, enumfacing, true)) {
            return false;
         }

         p_189539_2_.func_180501_a(p_189539_3_, p_189539_1_.func_206870_a(field_176320_b, Boolean.valueOf(true)), 67);
         p_189539_2_.func_184133_a((EntityPlayer)null, p_189539_3_, SoundEvents.field_187715_dR, SoundCategory.BLOCKS, 0.5F, p_189539_2_.field_73012_v.nextFloat() * 0.25F + 0.6F);
      } else if (p_189539_4_ == 1 || p_189539_4_ == 2) {
         TileEntity tileentity1 = p_189539_2_.func_175625_s(p_189539_3_.func_177972_a(enumfacing));
         if (tileentity1 instanceof TileEntityPiston) {
            ((TileEntityPiston)tileentity1).func_145866_f();
         }

         p_189539_2_.func_180501_a(p_189539_3_, Blocks.field_196603_bb.func_176223_P().func_206870_a(BlockPistonMoving.field_196344_a, enumfacing).func_206870_a(BlockPistonMoving.field_196345_b, this.field_150082_a ? PistonType.STICKY : PistonType.DEFAULT), 3);
         p_189539_2_.func_175690_a(p_189539_3_, BlockPistonMoving.func_196343_a(this.func_176223_P().func_206870_a(field_176387_N, EnumFacing.func_82600_a(p_189539_5_ & 7)), enumfacing, false, true));
         if (this.field_150082_a) {
            BlockPos blockpos = p_189539_3_.func_177982_a(enumfacing.func_82601_c() * 2, enumfacing.func_96559_d() * 2, enumfacing.func_82599_e() * 2);
            IBlockState iblockstate = p_189539_2_.func_180495_p(blockpos);
            Block block = iblockstate.func_177230_c();
            boolean flag1 = false;
            if (block == Blocks.field_196603_bb) {
               TileEntity tileentity = p_189539_2_.func_175625_s(blockpos);
               if (tileentity instanceof TileEntityPiston) {
                  TileEntityPiston tileentitypiston = (TileEntityPiston)tileentity;
                  if (tileentitypiston.func_212363_d() == enumfacing && tileentitypiston.func_145868_b()) {
                     tileentitypiston.func_145866_f();
                     flag1 = true;
                  }
               }
            }

            if (!flag1) {
               if (p_189539_4_ != 1 || iblockstate.func_196958_f() || !func_185646_a(iblockstate, p_189539_2_, blockpos, enumfacing.func_176734_d(), false, enumfacing) || iblockstate.func_185905_o() != EnumPushReaction.NORMAL && block != Blocks.field_150331_J && block != Blocks.field_150320_F) {
                  p_189539_2_.func_175698_g(p_189539_3_.func_177972_a(enumfacing));
               } else {
                  this.func_176319_a(p_189539_2_, p_189539_3_, enumfacing, false);
               }
            }
         } else {
            p_189539_2_.func_175698_g(p_189539_3_.func_177972_a(enumfacing));
         }

         p_189539_2_.func_184133_a((EntityPlayer)null, p_189539_3_, SoundEvents.field_187712_dQ, SoundCategory.BLOCKS, 0.5F, p_189539_2_.field_73012_v.nextFloat() * 0.15F + 0.6F);
      }

      return true;
   }

   public boolean func_149686_d(IBlockState p_149686_1_) {
      return false;
   }

   public static boolean func_185646_a(IBlockState p_185646_0_, World p_185646_1_, BlockPos p_185646_2_, EnumFacing p_185646_3_, boolean p_185646_4_, EnumFacing p_185646_5_) {
      Block block = p_185646_0_.func_177230_c();
      if (block == Blocks.field_150343_Z) {
         return false;
      } else if (!p_185646_1_.func_175723_af().func_177746_a(p_185646_2_)) {
         return false;
      } else if (p_185646_2_.func_177956_o() >= 0 && (p_185646_3_ != EnumFacing.DOWN || p_185646_2_.func_177956_o() != 0)) {
         if (p_185646_2_.func_177956_o() <= p_185646_1_.func_72800_K() - 1 && (p_185646_3_ != EnumFacing.UP || p_185646_2_.func_177956_o() != p_185646_1_.func_72800_K() - 1)) {
            if (block != Blocks.field_150331_J && block != Blocks.field_150320_F) {
               if (p_185646_0_.func_185887_b(p_185646_1_, p_185646_2_) == -1.0F) {
                  return false;
               }

               switch(p_185646_0_.func_185905_o()) {
               case BLOCK:
                  return false;
               case DESTROY:
                  return p_185646_4_;
               case PUSH_ONLY:
                  return p_185646_3_ == p_185646_5_;
               }
            } else if (p_185646_0_.func_177229_b(field_176320_b)) {
               return false;
            }

            return !block.func_149716_u();
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private boolean func_176319_a(World p_176319_1_, BlockPos p_176319_2_, EnumFacing p_176319_3_, boolean p_176319_4_) {
      BlockPos blockpos = p_176319_2_.func_177972_a(p_176319_3_);
      if (!p_176319_4_ && p_176319_1_.func_180495_p(blockpos).func_177230_c() == Blocks.field_150332_K) {
         p_176319_1_.func_180501_a(blockpos, Blocks.field_150350_a.func_176223_P(), 20);
      }

      BlockPistonStructureHelper blockpistonstructurehelper = new BlockPistonStructureHelper(p_176319_1_, p_176319_2_, p_176319_3_, p_176319_4_);
      if (!blockpistonstructurehelper.func_177253_a()) {
         return false;
      } else {
         List<BlockPos> list = blockpistonstructurehelper.func_177254_c();
         List<IBlockState> list1 = Lists.newArrayList();

         for(int i = 0; i < list.size(); ++i) {
            BlockPos blockpos1 = list.get(i);
            list1.add(p_176319_1_.func_180495_p(blockpos1));
         }

         List<BlockPos> list2 = blockpistonstructurehelper.func_177252_d();
         int k = list.size() + list2.size();
         IBlockState[] aiblockstate = new IBlockState[k];
         EnumFacing enumfacing = p_176319_4_ ? p_176319_3_ : p_176319_3_.func_176734_d();
         Set<BlockPos> set = Sets.newHashSet(list);

         for(int j = list2.size() - 1; j >= 0; --j) {
            BlockPos blockpos2 = list2.get(j);
            IBlockState iblockstate = p_176319_1_.func_180495_p(blockpos2);
            iblockstate.func_196949_c(p_176319_1_, blockpos2, 0);
            p_176319_1_.func_180501_a(blockpos2, Blocks.field_150350_a.func_176223_P(), 18);
            --k;
            aiblockstate[k] = iblockstate;
         }

         for(int l = list.size() - 1; l >= 0; --l) {
            BlockPos blockpos3 = list.get(l);
            IBlockState iblockstate3 = p_176319_1_.func_180495_p(blockpos3);
            blockpos3 = blockpos3.func_177972_a(enumfacing);
            set.remove(blockpos3);
            p_176319_1_.func_180501_a(blockpos3, Blocks.field_196603_bb.func_176223_P().func_206870_a(field_176387_N, p_176319_3_), 68);
            p_176319_1_.func_175690_a(blockpos3, BlockPistonMoving.func_196343_a(list1.get(l), p_176319_3_, p_176319_4_, false));
            --k;
            aiblockstate[k] = iblockstate3;
         }

         if (p_176319_4_) {
            PistonType pistontype = this.field_150082_a ? PistonType.STICKY : PistonType.DEFAULT;
            IBlockState iblockstate1 = Blocks.field_150332_K.func_176223_P().func_206870_a(BlockPistonExtension.field_176387_N, p_176319_3_).func_206870_a(BlockPistonExtension.field_176325_b, pistontype);
            IBlockState iblockstate4 = Blocks.field_196603_bb.func_176223_P().func_206870_a(BlockPistonMoving.field_196344_a, p_176319_3_).func_206870_a(BlockPistonMoving.field_196345_b, this.field_150082_a ? PistonType.STICKY : PistonType.DEFAULT);
            set.remove(blockpos);
            p_176319_1_.func_180501_a(blockpos, iblockstate4, 68);
            p_176319_1_.func_175690_a(blockpos, BlockPistonMoving.func_196343_a(iblockstate1, p_176319_3_, true, true));
         }

         for(BlockPos blockpos4 : set) {
            p_176319_1_.func_180501_a(blockpos4, Blocks.field_150350_a.func_176223_P(), 66);
         }

         for(int i1 = list2.size() - 1; i1 >= 0; --i1) {
            IBlockState iblockstate2 = aiblockstate[k++];
            BlockPos blockpos5 = list2.get(i1);
            iblockstate2.func_196948_b(p_176319_1_, blockpos5, 2);
            p_176319_1_.func_195593_d(blockpos5, iblockstate2.func_177230_c());
         }

         for(int j1 = list.size() - 1; j1 >= 0; --j1) {
            p_176319_1_.func_195593_d(list.get(j1), aiblockstate[k++].func_177230_c());
         }

         if (p_176319_4_) {
            p_176319_1_.func_195593_d(blockpos, Blocks.field_150332_K);
         }

         return true;
      }
   }

   public IBlockState func_185499_a(IBlockState p_185499_1_, Rotation p_185499_2_) {
      return p_185499_1_.func_206870_a(field_176387_N, p_185499_2_.func_185831_a(p_185499_1_.func_177229_b(field_176387_N)));
   }

   public IBlockState func_185471_a(IBlockState p_185471_1_, Mirror p_185471_2_) {
      return p_185471_1_.func_185907_a(p_185471_2_.func_185800_a(p_185471_1_.func_177229_b(field_176387_N)));
   }

   protected void func_206840_a(StateContainer.Builder<Block, IBlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_176387_N, field_176320_b);
   }

   public BlockFaceShape func_193383_a(IBlockReader p_193383_1_, IBlockState p_193383_2_, BlockPos p_193383_3_, EnumFacing p_193383_4_) {
      return p_193383_2_.func_177229_b(field_176387_N) != p_193383_4_.func_176734_d() && p_193383_2_.func_177229_b(field_176320_b) ? BlockFaceShape.UNDEFINED : BlockFaceShape.SOLID;
   }

   public int func_200011_d(IBlockState p_200011_1_, IBlockReader p_200011_2_, BlockPos p_200011_3_) {
      return 0;
   }

   public boolean func_196266_a(IBlockState p_196266_1_, IBlockReader p_196266_2_, BlockPos p_196266_3_, PathType p_196266_4_) {
      return false;
   }
}
