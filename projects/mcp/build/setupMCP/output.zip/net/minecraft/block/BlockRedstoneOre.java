package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.particles.RedstoneParticleData;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.IItemProvider;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class BlockRedstoneOre extends Block {
   public static final BooleanProperty field_196501_a = BlockRedstoneTorch.field_196528_a;

   public BlockRedstoneOre(Block.Properties p_i48345_1_) {
      super(p_i48345_1_);
      this.func_180632_j(this.func_176223_P().func_206870_a(field_196501_a, Boolean.valueOf(false)));
   }

   public int func_149750_m(IBlockState p_149750_1_) {
      return p_149750_1_.func_177229_b(field_196501_a) ? super.func_149750_m(p_149750_1_) : 0;
   }

   public void func_196270_a(IBlockState p_196270_1_, World p_196270_2_, BlockPos p_196270_3_, EntityPlayer p_196270_4_) {
      func_196500_d(p_196270_1_, p_196270_2_, p_196270_3_);
      super.func_196270_a(p_196270_1_, p_196270_2_, p_196270_3_, p_196270_4_);
   }

   public void func_176199_a(World p_176199_1_, BlockPos p_176199_2_, Entity p_176199_3_) {
      func_196500_d(p_176199_1_.func_180495_p(p_176199_2_), p_176199_1_, p_176199_2_);
      super.func_176199_a(p_176199_1_, p_176199_2_, p_176199_3_);
   }

   public boolean func_196250_a(IBlockState p_196250_1_, World p_196250_2_, BlockPos p_196250_3_, EntityPlayer p_196250_4_, EnumHand p_196250_5_, EnumFacing p_196250_6_, float p_196250_7_, float p_196250_8_, float p_196250_9_) {
      func_196500_d(p_196250_1_, p_196250_2_, p_196250_3_);
      return super.func_196250_a(p_196250_1_, p_196250_2_, p_196250_3_, p_196250_4_, p_196250_5_, p_196250_6_, p_196250_7_, p_196250_8_, p_196250_9_);
   }

   private static void func_196500_d(IBlockState p_196500_0_, World p_196500_1_, BlockPos p_196500_2_) {
      func_180691_e(p_196500_1_, p_196500_2_);
      if (!p_196500_0_.func_177229_b(field_196501_a)) {
         p_196500_1_.func_180501_a(p_196500_2_, p_196500_0_.func_206870_a(field_196501_a, Boolean.valueOf(true)), 3);
      }

   }

   public void func_196267_b(IBlockState p_196267_1_, World p_196267_2_, BlockPos p_196267_3_, Random p_196267_4_) {
      if (p_196267_1_.func_177229_b(field_196501_a)) {
         p_196267_2_.func_180501_a(p_196267_3_, p_196267_1_.func_206870_a(field_196501_a, Boolean.valueOf(false)), 3);
      }

   }

   public IItemProvider func_199769_a(IBlockState p_199769_1_, World p_199769_2_, BlockPos p_199769_3_, int p_199769_4_) {
      return Items.field_151137_ax;
   }

   public int func_196251_a(IBlockState p_196251_1_, int p_196251_2_, World p_196251_3_, BlockPos p_196251_4_, Random p_196251_5_) {
      return this.func_196264_a(p_196251_1_, p_196251_5_) + p_196251_5_.nextInt(p_196251_2_ + 1);
   }

   public int func_196264_a(IBlockState p_196264_1_, Random p_196264_2_) {
      return 4 + p_196264_2_.nextInt(2);
   }

   public void func_196255_a(IBlockState p_196255_1_, World p_196255_2_, BlockPos p_196255_3_, float p_196255_4_, int p_196255_5_) {
      super.func_196255_a(p_196255_1_, p_196255_2_, p_196255_3_, p_196255_4_, p_196255_5_);
      if (this.func_199769_a(p_196255_1_, p_196255_2_, p_196255_3_, p_196255_5_) != this) {
         int i = 1 + p_196255_2_.field_73012_v.nextInt(5);
         this.func_180637_b(p_196255_2_, p_196255_3_, i);
      }

   }

   @OnlyIn(Dist.CLIENT)
   public void func_180655_c(IBlockState p_180655_1_, World p_180655_2_, BlockPos p_180655_3_, Random p_180655_4_) {
      if (p_180655_1_.func_177229_b(field_196501_a)) {
         func_180691_e(p_180655_2_, p_180655_3_);
      }

   }

   private static void func_180691_e(World p_180691_0_, BlockPos p_180691_1_) {
      double d0 = 0.5625D;
      Random random = p_180691_0_.field_73012_v;

      for(EnumFacing enumfacing : EnumFacing.values()) {
         BlockPos blockpos = p_180691_1_.func_177972_a(enumfacing);
         if (!p_180691_0_.func_180495_p(blockpos).func_200015_d(p_180691_0_, blockpos)) {
            EnumFacing.Axis enumfacing$axis = enumfacing.func_176740_k();
            double d1 = enumfacing$axis == EnumFacing.Axis.X ? 0.5D + 0.5625D * (double)enumfacing.func_82601_c() : (double)random.nextFloat();
            double d2 = enumfacing$axis == EnumFacing.Axis.Y ? 0.5D + 0.5625D * (double)enumfacing.func_96559_d() : (double)random.nextFloat();
            double d3 = enumfacing$axis == EnumFacing.Axis.Z ? 0.5D + 0.5625D * (double)enumfacing.func_82599_e() : (double)random.nextFloat();
            p_180691_0_.func_195594_a(RedstoneParticleData.field_197564_a, (double)p_180691_1_.func_177958_n() + d1, (double)p_180691_1_.func_177956_o() + d2, (double)p_180691_1_.func_177952_p() + d3, 0.0D, 0.0D, 0.0D);
         }
      }

   }

   protected void func_206840_a(StateContainer.Builder<Block, IBlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_196501_a);
   }
}
