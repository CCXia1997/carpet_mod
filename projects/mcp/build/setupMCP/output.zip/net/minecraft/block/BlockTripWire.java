package net.minecraft.block;

import java.util.List;
import java.util.Map;
import java.util.Random;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.World;

public class BlockTripWire extends Block {
   public static final BooleanProperty field_176293_a = BlockStateProperties.field_208194_u;
   public static final BooleanProperty field_176294_M = BlockStateProperties.field_208174_a;
   public static final BooleanProperty field_176295_N = BlockStateProperties.field_208178_e;
   public static final BooleanProperty field_176296_O = BlockSixWay.field_196488_a;
   public static final BooleanProperty field_176291_P = BlockSixWay.field_196490_b;
   public static final BooleanProperty field_176289_Q = BlockSixWay.field_196492_c;
   public static final BooleanProperty field_176292_R = BlockSixWay.field_196495_y;
   private static final Map<EnumFacing, BooleanProperty> field_196537_E = BlockFourWay.field_196415_z;
   protected static final VoxelShape field_185747_B = Block.func_208617_a(0.0D, 1.0D, 0.0D, 16.0D, 2.5D, 16.0D);
   protected static final VoxelShape field_185748_C = Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 8.0D, 16.0D);
   private final BlockTripWireHook field_196538_F;

   public BlockTripWire(BlockTripWireHook p_i48305_1_, Block.Properties p_i48305_2_) {
      super(p_i48305_2_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_176293_a, Boolean.valueOf(false)).func_206870_a(field_176294_M, Boolean.valueOf(false)).func_206870_a(field_176295_N, Boolean.valueOf(false)).func_206870_a(field_176296_O, Boolean.valueOf(false)).func_206870_a(field_176291_P, Boolean.valueOf(false)).func_206870_a(field_176289_Q, Boolean.valueOf(false)).func_206870_a(field_176292_R, Boolean.valueOf(false)));
      this.field_196538_F = p_i48305_1_;
   }

   public VoxelShape func_196244_b(IBlockState p_196244_1_, IBlockReader p_196244_2_, BlockPos p_196244_3_) {
      return p_196244_1_.func_177229_b(field_176294_M) ? field_185747_B : field_185748_C;
   }

   public IBlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      IBlockReader iblockreader = p_196258_1_.func_195991_k();
      BlockPos blockpos = p_196258_1_.func_195995_a();
      return this.func_176223_P().func_206870_a(field_176296_O, Boolean.valueOf(this.func_196536_a(iblockreader.func_180495_p(blockpos.func_177978_c()), EnumFacing.NORTH))).func_206870_a(field_176291_P, Boolean.valueOf(this.func_196536_a(iblockreader.func_180495_p(blockpos.func_177974_f()), EnumFacing.EAST))).func_206870_a(field_176289_Q, Boolean.valueOf(this.func_196536_a(iblockreader.func_180495_p(blockpos.func_177968_d()), EnumFacing.SOUTH))).func_206870_a(field_176292_R, Boolean.valueOf(this.func_196536_a(iblockreader.func_180495_p(blockpos.func_177976_e()), EnumFacing.WEST)));
   }

   public IBlockState func_196271_a(IBlockState p_196271_1_, EnumFacing p_196271_2_, IBlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      return p_196271_2_.func_176740_k().func_176722_c() ? p_196271_1_.func_206870_a(field_196537_E.get(p_196271_2_), Boolean.valueOf(this.func_196536_a(p_196271_3_, p_196271_2_))) : super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
   }

   public boolean func_149686_d(IBlockState p_149686_1_) {
      return false;
   }

   public BlockRenderLayer func_180664_k() {
      return BlockRenderLayer.TRANSLUCENT;
   }

   public void func_196259_b(IBlockState p_196259_1_, World p_196259_2_, BlockPos p_196259_3_, IBlockState p_196259_4_) {
      if (p_196259_4_.func_177230_c() != p_196259_1_.func_177230_c()) {
         this.func_176286_e(p_196259_2_, p_196259_3_, p_196259_1_);
      }
   }

   public void func_196243_a(IBlockState p_196243_1_, World p_196243_2_, BlockPos p_196243_3_, IBlockState p_196243_4_, boolean p_196243_5_) {
      if (!p_196243_5_ && p_196243_1_.func_177230_c() != p_196243_4_.func_177230_c()) {
         this.func_176286_e(p_196243_2_, p_196243_3_, p_196243_1_.func_206870_a(field_176293_a, Boolean.valueOf(true)));
      }
   }

   public void func_176208_a(World p_176208_1_, BlockPos p_176208_2_, IBlockState p_176208_3_, EntityPlayer p_176208_4_) {
      if (!p_176208_1_.field_72995_K && !p_176208_4_.func_184614_ca().func_190926_b() && p_176208_4_.func_184614_ca().func_77973_b() == Items.field_151097_aZ) {
         p_176208_1_.func_180501_a(p_176208_2_, p_176208_3_.func_206870_a(field_176295_N, Boolean.valueOf(true)), 4);
      }

      super.func_176208_a(p_176208_1_, p_176208_2_, p_176208_3_, p_176208_4_);
   }

   private void func_176286_e(World p_176286_1_, BlockPos p_176286_2_, IBlockState p_176286_3_) {
      for(EnumFacing enumfacing : new EnumFacing[]{EnumFacing.SOUTH, EnumFacing.WEST}) {
         for(int i = 1; i < 42; ++i) {
            BlockPos blockpos = p_176286_2_.func_177967_a(enumfacing, i);
            IBlockState iblockstate = p_176286_1_.func_180495_p(blockpos);
            if (iblockstate.func_177230_c() == this.field_196538_F) {
               if (iblockstate.func_177229_b(BlockTripWireHook.field_176264_a) == enumfacing.func_176734_d()) {
                  this.field_196538_F.func_176260_a(p_176286_1_, blockpos, iblockstate, false, true, i, p_176286_3_);
               }
               break;
            }

            if (iblockstate.func_177230_c() != this) {
               break;
            }
         }
      }

   }

   public void func_196262_a(IBlockState p_196262_1_, World p_196262_2_, BlockPos p_196262_3_, Entity p_196262_4_) {
      if (!p_196262_2_.field_72995_K) {
         if (!p_196262_1_.func_177229_b(field_176293_a)) {
            this.func_176288_d(p_196262_2_, p_196262_3_);
         }
      }
   }

   public void func_196267_b(IBlockState p_196267_1_, World p_196267_2_, BlockPos p_196267_3_, Random p_196267_4_) {
      if (!p_196267_2_.field_72995_K) {
         if (p_196267_2_.func_180495_p(p_196267_3_).func_177229_b(field_176293_a)) {
            this.func_176288_d(p_196267_2_, p_196267_3_);
         }
      }
   }

   private void func_176288_d(World p_176288_1_, BlockPos p_176288_2_) {
      IBlockState iblockstate = p_176288_1_.func_180495_p(p_176288_2_);
      boolean flag = iblockstate.func_177229_b(field_176293_a);
      boolean flag1 = false;
      List<? extends Entity> list = p_176288_1_.func_72839_b((Entity)null, iblockstate.func_196954_c(p_176288_1_, p_176288_2_).func_197752_a().func_186670_a(p_176288_2_));
      if (!list.isEmpty()) {
         for(Entity entity : list) {
            if (!entity.func_145773_az()) {
               flag1 = true;
               break;
            }
         }
      }

      if (flag1 != flag) {
         iblockstate = iblockstate.func_206870_a(field_176293_a, Boolean.valueOf(flag1));
         p_176288_1_.func_180501_a(p_176288_2_, iblockstate, 3);
         this.func_176286_e(p_176288_1_, p_176288_2_, iblockstate);
      }

      if (flag1) {
         p_176288_1_.func_205220_G_().func_205360_a(new BlockPos(p_176288_2_), this, this.func_149738_a(p_176288_1_));
      }

   }

   public boolean func_196536_a(IBlockState p_196536_1_, EnumFacing p_196536_2_) {
      Block block = p_196536_1_.func_177230_c();
      if (block == this.field_196538_F) {
         return p_196536_1_.func_177229_b(BlockTripWireHook.field_176264_a) == p_196536_2_.func_176734_d();
      } else {
         return block == this;
      }
   }

   public IBlockState func_185499_a(IBlockState p_185499_1_, Rotation p_185499_2_) {
      switch(p_185499_2_) {
      case CLOCKWISE_180:
         return p_185499_1_.func_206870_a(field_176296_O, p_185499_1_.func_177229_b(field_176289_Q)).func_206870_a(field_176291_P, p_185499_1_.func_177229_b(field_176292_R)).func_206870_a(field_176289_Q, p_185499_1_.func_177229_b(field_176296_O)).func_206870_a(field_176292_R, p_185499_1_.func_177229_b(field_176291_P));
      case COUNTERCLOCKWISE_90:
         return p_185499_1_.func_206870_a(field_176296_O, p_185499_1_.func_177229_b(field_176291_P)).func_206870_a(field_176291_P, p_185499_1_.func_177229_b(field_176289_Q)).func_206870_a(field_176289_Q, p_185499_1_.func_177229_b(field_176292_R)).func_206870_a(field_176292_R, p_185499_1_.func_177229_b(field_176296_O));
      case CLOCKWISE_90:
         return p_185499_1_.func_206870_a(field_176296_O, p_185499_1_.func_177229_b(field_176292_R)).func_206870_a(field_176291_P, p_185499_1_.func_177229_b(field_176296_O)).func_206870_a(field_176289_Q, p_185499_1_.func_177229_b(field_176291_P)).func_206870_a(field_176292_R, p_185499_1_.func_177229_b(field_176289_Q));
      default:
         return p_185499_1_;
      }
   }

   public IBlockState func_185471_a(IBlockState p_185471_1_, Mirror p_185471_2_) {
      switch(p_185471_2_) {
      case LEFT_RIGHT:
         return p_185471_1_.func_206870_a(field_176296_O, p_185471_1_.func_177229_b(field_176289_Q)).func_206870_a(field_176289_Q, p_185471_1_.func_177229_b(field_176296_O));
      case FRONT_BACK:
         return p_185471_1_.func_206870_a(field_176291_P, p_185471_1_.func_177229_b(field_176292_R)).func_206870_a(field_176292_R, p_185471_1_.func_177229_b(field_176291_P));
      default:
         return super.func_185471_a(p_185471_1_, p_185471_2_);
      }
   }

   protected void func_206840_a(StateContainer.Builder<Block, IBlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_176293_a, field_176294_M, field_176295_N, field_176296_O, field_176291_P, field_176292_R, field_176289_Q);
   }

   public BlockFaceShape func_193383_a(IBlockReader p_193383_1_, IBlockState p_193383_2_, BlockPos p_193383_3_, EnumFacing p_193383_4_) {
      return BlockFaceShape.UNDEFINED;
   }
}
