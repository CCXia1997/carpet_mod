package net.minecraft.block;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import java.util.EnumSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import javax.annotation.Nullable;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.particles.RedstoneParticleData;
import net.minecraft.state.EnumProperty;
import net.minecraft.state.IntegerProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.state.properties.RedstoneSide;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.IWorldReaderBase;
import net.minecraft.world.World;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class BlockRedstoneWire extends Block {
   public static final EnumProperty<RedstoneSide> field_176348_a = BlockStateProperties.field_208160_M;
   public static final EnumProperty<RedstoneSide> field_176347_b = BlockStateProperties.field_208159_L;
   public static final EnumProperty<RedstoneSide> field_176349_M = BlockStateProperties.field_208161_N;
   public static final EnumProperty<RedstoneSide> field_176350_N = BlockStateProperties.field_208162_O;
   public static final IntegerProperty field_176351_O = BlockStateProperties.field_208136_ak;
   public static final Map<EnumFacing, EnumProperty<RedstoneSide>> field_196498_A = Maps.newEnumMap(ImmutableMap.of(EnumFacing.NORTH, field_176348_a, EnumFacing.EAST, field_176347_b, EnumFacing.SOUTH, field_176349_M, EnumFacing.WEST, field_176350_N));
   protected static final VoxelShape[] field_196499_B = new VoxelShape[]{Block.func_208617_a(3.0D, 0.0D, 3.0D, 13.0D, 1.0D, 13.0D), Block.func_208617_a(3.0D, 0.0D, 3.0D, 13.0D, 1.0D, 16.0D), Block.func_208617_a(0.0D, 0.0D, 3.0D, 13.0D, 1.0D, 13.0D), Block.func_208617_a(0.0D, 0.0D, 3.0D, 13.0D, 1.0D, 16.0D), Block.func_208617_a(3.0D, 0.0D, 0.0D, 13.0D, 1.0D, 13.0D), Block.func_208617_a(3.0D, 0.0D, 0.0D, 13.0D, 1.0D, 16.0D), Block.func_208617_a(0.0D, 0.0D, 0.0D, 13.0D, 1.0D, 13.0D), Block.func_208617_a(0.0D, 0.0D, 0.0D, 13.0D, 1.0D, 16.0D), Block.func_208617_a(3.0D, 0.0D, 3.0D, 16.0D, 1.0D, 13.0D), Block.func_208617_a(3.0D, 0.0D, 3.0D, 16.0D, 1.0D, 16.0D), Block.func_208617_a(0.0D, 0.0D, 3.0D, 16.0D, 1.0D, 13.0D), Block.func_208617_a(0.0D, 0.0D, 3.0D, 16.0D, 1.0D, 16.0D), Block.func_208617_a(3.0D, 0.0D, 0.0D, 16.0D, 1.0D, 13.0D), Block.func_208617_a(3.0D, 0.0D, 0.0D, 16.0D, 1.0D, 16.0D), Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 1.0D, 13.0D), Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 1.0D, 16.0D)};
   private boolean field_150181_a = true;
   private final Set<BlockPos> field_150179_b = Sets.newHashSet();

   public BlockRedstoneWire(Block.Properties p_i48344_1_) {
      super(p_i48344_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_176348_a, RedstoneSide.NONE).func_206870_a(field_176347_b, RedstoneSide.NONE).func_206870_a(field_176349_M, RedstoneSide.NONE).func_206870_a(field_176350_N, RedstoneSide.NONE).func_206870_a(field_176351_O, Integer.valueOf(0)));
   }

   public VoxelShape func_196244_b(IBlockState p_196244_1_, IBlockReader p_196244_2_, BlockPos p_196244_3_) {
      return field_196499_B[func_185699_x(p_196244_1_)];
   }

   private static int func_185699_x(IBlockState p_185699_0_) {
      int i = 0;
      boolean flag = p_185699_0_.func_177229_b(field_176348_a) != RedstoneSide.NONE;
      boolean flag1 = p_185699_0_.func_177229_b(field_176347_b) != RedstoneSide.NONE;
      boolean flag2 = p_185699_0_.func_177229_b(field_176349_M) != RedstoneSide.NONE;
      boolean flag3 = p_185699_0_.func_177229_b(field_176350_N) != RedstoneSide.NONE;
      if (flag || flag2 && !flag && !flag1 && !flag3) {
         i |= 1 << EnumFacing.NORTH.func_176736_b();
      }

      if (flag1 || flag3 && !flag && !flag1 && !flag2) {
         i |= 1 << EnumFacing.EAST.func_176736_b();
      }

      if (flag2 || flag && !flag1 && !flag2 && !flag3) {
         i |= 1 << EnumFacing.SOUTH.func_176736_b();
      }

      if (flag3 || flag1 && !flag && !flag2 && !flag3) {
         i |= 1 << EnumFacing.WEST.func_176736_b();
      }

      return i;
   }

   public IBlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      IBlockReader iblockreader = p_196258_1_.func_195991_k();
      BlockPos blockpos = p_196258_1_.func_195995_a();
      return this.func_176223_P().func_206870_a(field_176350_N, this.func_208074_a(iblockreader, blockpos, EnumFacing.WEST)).func_206870_a(field_176347_b, this.func_208074_a(iblockreader, blockpos, EnumFacing.EAST)).func_206870_a(field_176348_a, this.func_208074_a(iblockreader, blockpos, EnumFacing.NORTH)).func_206870_a(field_176349_M, this.func_208074_a(iblockreader, blockpos, EnumFacing.SOUTH));
   }

   public IBlockState func_196271_a(IBlockState p_196271_1_, EnumFacing p_196271_2_, IBlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      if (p_196271_2_ == EnumFacing.DOWN) {
         return p_196271_1_;
      } else {
         return p_196271_2_ == EnumFacing.UP ? p_196271_1_.func_206870_a(field_176350_N, this.func_208074_a(p_196271_4_, p_196271_5_, EnumFacing.WEST)).func_206870_a(field_176347_b, this.func_208074_a(p_196271_4_, p_196271_5_, EnumFacing.EAST)).func_206870_a(field_176348_a, this.func_208074_a(p_196271_4_, p_196271_5_, EnumFacing.NORTH)).func_206870_a(field_176349_M, this.func_208074_a(p_196271_4_, p_196271_5_, EnumFacing.SOUTH)) : p_196271_1_.func_206870_a(field_196498_A.get(p_196271_2_), this.func_208074_a(p_196271_4_, p_196271_5_, p_196271_2_));
      }
   }

   public void func_196248_b(IBlockState p_196248_1_, IWorld p_196248_2_, BlockPos p_196248_3_, int p_196248_4_) {
      try (BlockPos.PooledMutableBlockPos blockpos$pooledmutableblockpos = BlockPos.PooledMutableBlockPos.func_185346_s()) {
         for(EnumFacing enumfacing : EnumFacing.Plane.HORIZONTAL) {
            RedstoneSide redstoneside = p_196248_1_.func_177229_b(field_196498_A.get(enumfacing));
            if (redstoneside != RedstoneSide.NONE && p_196248_2_.func_180495_p(blockpos$pooledmutableblockpos.func_189533_g(p_196248_3_).func_189536_c(enumfacing)).func_177230_c() != this) {
               blockpos$pooledmutableblockpos.func_189536_c(EnumFacing.DOWN);
               IBlockState iblockstate = p_196248_2_.func_180495_p(blockpos$pooledmutableblockpos);
               if (iblockstate.func_177230_c() != Blocks.field_190976_dk) {
                  BlockPos blockpos = blockpos$pooledmutableblockpos.func_177972_a(enumfacing.func_176734_d());
                  IBlockState iblockstate1 = iblockstate.func_196956_a(enumfacing.func_176734_d(), p_196248_2_.func_180495_p(blockpos), p_196248_2_, blockpos$pooledmutableblockpos, blockpos);
                  func_196263_a(iblockstate, iblockstate1, p_196248_2_, blockpos$pooledmutableblockpos, p_196248_4_);
               }

               blockpos$pooledmutableblockpos.func_189533_g(p_196248_3_).func_189536_c(enumfacing).func_189536_c(EnumFacing.UP);
               IBlockState iblockstate3 = p_196248_2_.func_180495_p(blockpos$pooledmutableblockpos);
               if (iblockstate3.func_177230_c() != Blocks.field_190976_dk) {
                  BlockPos blockpos1 = blockpos$pooledmutableblockpos.func_177972_a(enumfacing.func_176734_d());
                  IBlockState iblockstate2 = iblockstate3.func_196956_a(enumfacing.func_176734_d(), p_196248_2_.func_180495_p(blockpos1), p_196248_2_, blockpos$pooledmutableblockpos, blockpos1);
                  func_196263_a(iblockstate3, iblockstate2, p_196248_2_, blockpos$pooledmutableblockpos, p_196248_4_);
               }
            }
         }
      }

   }

   private RedstoneSide func_208074_a(IBlockReader p_208074_1_, BlockPos p_208074_2_, EnumFacing p_208074_3_) {
      BlockPos blockpos = p_208074_2_.func_177972_a(p_208074_3_);
      IBlockState iblockstate = p_208074_1_.func_180495_p(p_208074_2_.func_177972_a(p_208074_3_));
      IBlockState iblockstate1 = p_208074_1_.func_180495_p(p_208074_2_.func_177984_a());
      if (!iblockstate1.func_185915_l()) {
         boolean flag = p_208074_1_.func_180495_p(blockpos).func_185896_q() || p_208074_1_.func_180495_p(blockpos).func_177230_c() == Blocks.field_150426_aN;
         if (flag && func_176346_d(p_208074_1_.func_180495_p(blockpos.func_177984_a()))) {
            if (iblockstate.func_185898_k()) {
               return RedstoneSide.UP;
            }

            return RedstoneSide.SIDE;
         }
      }

      return !func_176343_a(p_208074_1_.func_180495_p(blockpos), p_208074_3_) && (iblockstate.func_185915_l() || !func_176346_d(p_208074_1_.func_180495_p(blockpos.func_177977_b()))) ? RedstoneSide.NONE : RedstoneSide.SIDE;
   }

   public boolean func_149686_d(IBlockState p_149686_1_) {
      return false;
   }

   public boolean func_196260_a(IBlockState p_196260_1_, IWorldReaderBase p_196260_2_, BlockPos p_196260_3_) {
      IBlockState iblockstate = p_196260_2_.func_180495_p(p_196260_3_.func_177977_b());
      return iblockstate.func_185896_q() || iblockstate.func_177230_c() == Blocks.field_150426_aN;
   }

   private IBlockState func_176338_e(World p_176338_1_, BlockPos p_176338_2_, IBlockState p_176338_3_) {
      p_176338_3_ = this.func_212568_b(p_176338_1_, p_176338_2_, p_176338_3_);
      List<BlockPos> list = Lists.newArrayList(this.field_150179_b);
      this.field_150179_b.clear();

      for(BlockPos blockpos : list) {
         p_176338_1_.func_195593_d(blockpos, this);
      }

      return p_176338_3_;
   }

   private IBlockState func_212568_b(World p_212568_1_, BlockPos p_212568_2_, IBlockState p_212568_3_) {
      IBlockState iblockstate = p_212568_3_;
      int i = p_212568_3_.func_177229_b(field_176351_O);
      int j = 0;
      j = this.func_212567_a(j, p_212568_3_);
      this.field_150181_a = false;
      int k = p_212568_1_.func_175687_A(p_212568_2_);
      this.field_150181_a = true;
      if (k > 0 && k > j - 1) {
         j = k;
      }

      int l = 0;

      for(EnumFacing enumfacing : EnumFacing.Plane.HORIZONTAL) {
         BlockPos blockpos = p_212568_2_.func_177972_a(enumfacing);
         boolean flag = blockpos.func_177958_n() != p_212568_2_.func_177958_n() || blockpos.func_177952_p() != p_212568_2_.func_177952_p();
         IBlockState iblockstate1 = p_212568_1_.func_180495_p(blockpos);
         if (flag) {
            l = this.func_212567_a(l, iblockstate1);
         }

         if (iblockstate1.func_185915_l() && !p_212568_1_.func_180495_p(p_212568_2_.func_177984_a()).func_185915_l()) {
            if (flag && p_212568_2_.func_177956_o() >= p_212568_2_.func_177956_o()) {
               l = this.func_212567_a(l, p_212568_1_.func_180495_p(blockpos.func_177984_a()));
            }
         } else if (!iblockstate1.func_185915_l() && flag && p_212568_2_.func_177956_o() <= p_212568_2_.func_177956_o()) {
            l = this.func_212567_a(l, p_212568_1_.func_180495_p(blockpos.func_177977_b()));
         }
      }

      if (l > j) {
         j = l - 1;
      } else if (j > 0) {
         --j;
      } else {
         j = 0;
      }

      if (k > j - 1) {
         j = k;
      }

      if (i != j) {
         p_212568_3_ = p_212568_3_.func_206870_a(field_176351_O, Integer.valueOf(j));
         if (p_212568_1_.func_180495_p(p_212568_2_) == iblockstate) {
            p_212568_1_.func_180501_a(p_212568_2_, p_212568_3_, 2);
         }

         this.field_150179_b.add(p_212568_2_);

         for(EnumFacing enumfacing1 : EnumFacing.values()) {
            this.field_150179_b.add(p_212568_2_.func_177972_a(enumfacing1));
         }
      }

      return p_212568_3_;
   }

   private void func_176344_d(World p_176344_1_, BlockPos p_176344_2_) {
      if (p_176344_1_.func_180495_p(p_176344_2_).func_177230_c() == this) {
         p_176344_1_.func_195593_d(p_176344_2_, this);

         for(EnumFacing enumfacing : EnumFacing.values()) {
            p_176344_1_.func_195593_d(p_176344_2_.func_177972_a(enumfacing), this);
         }

      }
   }

   public void func_196259_b(IBlockState p_196259_1_, World p_196259_2_, BlockPos p_196259_3_, IBlockState p_196259_4_) {
      if (p_196259_4_.func_177230_c() != p_196259_1_.func_177230_c() && !p_196259_2_.field_72995_K) {
         this.func_176338_e(p_196259_2_, p_196259_3_, p_196259_1_);

         for(EnumFacing enumfacing : EnumFacing.Plane.VERTICAL) {
            p_196259_2_.func_195593_d(p_196259_3_.func_177972_a(enumfacing), this);
         }

         for(EnumFacing enumfacing1 : EnumFacing.Plane.HORIZONTAL) {
            this.func_176344_d(p_196259_2_, p_196259_3_.func_177972_a(enumfacing1));
         }

         for(EnumFacing enumfacing2 : EnumFacing.Plane.HORIZONTAL) {
            BlockPos blockpos = p_196259_3_.func_177972_a(enumfacing2);
            if (p_196259_2_.func_180495_p(blockpos).func_185915_l()) {
               this.func_176344_d(p_196259_2_, blockpos.func_177984_a());
            } else {
               this.func_176344_d(p_196259_2_, blockpos.func_177977_b());
            }
         }

      }
   }

   public void func_196243_a(IBlockState p_196243_1_, World p_196243_2_, BlockPos p_196243_3_, IBlockState p_196243_4_, boolean p_196243_5_) {
      if (!p_196243_5_ && p_196243_1_.func_177230_c() != p_196243_4_.func_177230_c()) {
         super.func_196243_a(p_196243_1_, p_196243_2_, p_196243_3_, p_196243_4_, p_196243_5_);
         if (!p_196243_2_.field_72995_K) {
            for(EnumFacing enumfacing : EnumFacing.values()) {
               p_196243_2_.func_195593_d(p_196243_3_.func_177972_a(enumfacing), this);
            }

            this.func_176338_e(p_196243_2_, p_196243_3_, p_196243_1_);

            for(EnumFacing enumfacing1 : EnumFacing.Plane.HORIZONTAL) {
               this.func_176344_d(p_196243_2_, p_196243_3_.func_177972_a(enumfacing1));
            }

            for(EnumFacing enumfacing2 : EnumFacing.Plane.HORIZONTAL) {
               BlockPos blockpos = p_196243_3_.func_177972_a(enumfacing2);
               if (p_196243_2_.func_180495_p(blockpos).func_185915_l()) {
                  this.func_176344_d(p_196243_2_, blockpos.func_177984_a());
               } else {
                  this.func_176344_d(p_196243_2_, blockpos.func_177977_b());
               }
            }

         }
      }
   }

   private int func_212567_a(int p_212567_1_, IBlockState p_212567_2_) {
      if (p_212567_2_.func_177230_c() != this) {
         return p_212567_1_;
      } else {
         int i = p_212567_2_.func_177229_b(field_176351_O);
         return i > p_212567_1_ ? i : p_212567_1_;
      }
   }

   public void func_189540_a(IBlockState p_189540_1_, World p_189540_2_, BlockPos p_189540_3_, Block p_189540_4_, BlockPos p_189540_5_) {
      if (!p_189540_2_.field_72995_K) {
         if (p_189540_1_.func_196955_c(p_189540_2_, p_189540_3_)) {
            this.func_176338_e(p_189540_2_, p_189540_3_, p_189540_1_);
         } else {
            p_189540_1_.func_196949_c(p_189540_2_, p_189540_3_, 0);
            p_189540_2_.func_175698_g(p_189540_3_);
         }

      }
   }

   public int func_176211_b(IBlockState p_176211_1_, IBlockReader p_176211_2_, BlockPos p_176211_3_, EnumFacing p_176211_4_) {
      return !this.field_150181_a ? 0 : p_176211_1_.func_185911_a(p_176211_2_, p_176211_3_, p_176211_4_);
   }

   public int func_180656_a(IBlockState p_180656_1_, IBlockReader p_180656_2_, BlockPos p_180656_3_, EnumFacing p_180656_4_) {
      if (!this.field_150181_a) {
         return 0;
      } else {
         int i = p_180656_1_.func_177229_b(field_176351_O);
         if (i == 0) {
            return 0;
         } else if (p_180656_4_ == EnumFacing.UP) {
            return i;
         } else {
            EnumSet<EnumFacing> enumset = EnumSet.noneOf(EnumFacing.class);

            for(EnumFacing enumfacing : EnumFacing.Plane.HORIZONTAL) {
               if (this.func_176339_d(p_180656_2_, p_180656_3_, enumfacing)) {
                  enumset.add(enumfacing);
               }
            }

            if (p_180656_4_.func_176740_k().func_176722_c() && enumset.isEmpty()) {
               return i;
            } else if (enumset.contains(p_180656_4_) && !enumset.contains(p_180656_4_.func_176735_f()) && !enumset.contains(p_180656_4_.func_176746_e())) {
               return i;
            } else {
               return 0;
            }
         }
      }
   }

   private boolean func_176339_d(IBlockReader p_176339_1_, BlockPos p_176339_2_, EnumFacing p_176339_3_) {
      BlockPos blockpos = p_176339_2_.func_177972_a(p_176339_3_);
      IBlockState iblockstate = p_176339_1_.func_180495_p(blockpos);
      boolean flag = iblockstate.func_185915_l();
      boolean flag1 = p_176339_1_.func_180495_p(p_176339_2_.func_177984_a()).func_185915_l();
      if (!flag1 && flag && func_176340_e(p_176339_1_, blockpos.func_177984_a())) {
         return true;
      } else if (func_176343_a(iblockstate, p_176339_3_)) {
         return true;
      } else if (iblockstate.func_177230_c() == Blocks.field_196633_cV && iblockstate.func_177229_b(BlockRedstoneDiode.field_196348_c) && iblockstate.func_177229_b(BlockRedstoneDiode.field_185512_D) == p_176339_3_) {
         return true;
      } else {
         return !flag && func_176340_e(p_176339_1_, blockpos.func_177977_b());
      }
   }

   protected static boolean func_176340_e(IBlockReader p_176340_0_, BlockPos p_176340_1_) {
      return func_176346_d(p_176340_0_.func_180495_p(p_176340_1_));
   }

   protected static boolean func_176346_d(IBlockState p_176346_0_) {
      return func_176343_a(p_176346_0_, (EnumFacing)null);
   }

   protected static boolean func_176343_a(IBlockState p_176343_0_, @Nullable EnumFacing p_176343_1_) {
      Block block = p_176343_0_.func_177230_c();
      if (block == Blocks.field_150488_af) {
         return true;
      } else if (p_176343_0_.func_177230_c() == Blocks.field_196633_cV) {
         EnumFacing enumfacing = p_176343_0_.func_177229_b(BlockRedstoneRepeater.field_185512_D);
         return enumfacing == p_176343_1_ || enumfacing.func_176734_d() == p_176343_1_;
      } else if (Blocks.field_190976_dk == p_176343_0_.func_177230_c()) {
         return p_176343_1_ == p_176343_0_.func_177229_b(BlockObserver.field_176387_N);
      } else {
         return p_176343_0_.func_185897_m() && p_176343_1_ != null;
      }
   }

   public boolean func_149744_f(IBlockState p_149744_1_) {
      return this.field_150181_a;
   }

   @OnlyIn(Dist.CLIENT)
   public static int func_176337_b(int p_176337_0_) {
      float f = (float)p_176337_0_ / 15.0F;
      float f1 = f * 0.6F + 0.4F;
      if (p_176337_0_ == 0) {
         f1 = 0.3F;
      }

      float f2 = f * f * 0.7F - 0.5F;
      float f3 = f * f * 0.6F - 0.7F;
      if (f2 < 0.0F) {
         f2 = 0.0F;
      }

      if (f3 < 0.0F) {
         f3 = 0.0F;
      }

      int i = MathHelper.func_76125_a((int)(f1 * 255.0F), 0, 255);
      int j = MathHelper.func_76125_a((int)(f2 * 255.0F), 0, 255);
      int k = MathHelper.func_76125_a((int)(f3 * 255.0F), 0, 255);
      return -16777216 | i << 16 | j << 8 | k;
   }

   @OnlyIn(Dist.CLIENT)
   public void func_180655_c(IBlockState p_180655_1_, World p_180655_2_, BlockPos p_180655_3_, Random p_180655_4_) {
      int i = p_180655_1_.func_177229_b(field_176351_O);
      if (i != 0) {
         double d0 = (double)p_180655_3_.func_177958_n() + 0.5D + ((double)p_180655_4_.nextFloat() - 0.5D) * 0.2D;
         double d1 = (double)((float)p_180655_3_.func_177956_o() + 0.0625F);
         double d2 = (double)p_180655_3_.func_177952_p() + 0.5D + ((double)p_180655_4_.nextFloat() - 0.5D) * 0.2D;
         float f = (float)i / 15.0F;
         float f1 = f * 0.6F + 0.4F;
         float f2 = Math.max(0.0F, f * f * 0.7F - 0.5F);
         float f3 = Math.max(0.0F, f * f * 0.6F - 0.7F);
         p_180655_2_.func_195594_a(new RedstoneParticleData(f1, f2, f3, 1.0F), d0, d1, d2, 0.0D, 0.0D, 0.0D);
      }
   }

   public BlockRenderLayer func_180664_k() {
      return BlockRenderLayer.CUTOUT;
   }

   public IBlockState func_185499_a(IBlockState p_185499_1_, Rotation p_185499_2_) {
      switch(p_185499_2_) {
      case CLOCKWISE_180:
         return p_185499_1_.func_206870_a(field_176348_a, p_185499_1_.func_177229_b(field_176349_M)).func_206870_a(field_176347_b, p_185499_1_.func_177229_b(field_176350_N)).func_206870_a(field_176349_M, p_185499_1_.func_177229_b(field_176348_a)).func_206870_a(field_176350_N, p_185499_1_.func_177229_b(field_176347_b));
      case COUNTERCLOCKWISE_90:
         return p_185499_1_.func_206870_a(field_176348_a, p_185499_1_.func_177229_b(field_176347_b)).func_206870_a(field_176347_b, p_185499_1_.func_177229_b(field_176349_M)).func_206870_a(field_176349_M, p_185499_1_.func_177229_b(field_176350_N)).func_206870_a(field_176350_N, p_185499_1_.func_177229_b(field_176348_a));
      case CLOCKWISE_90:
         return p_185499_1_.func_206870_a(field_176348_a, p_185499_1_.func_177229_b(field_176350_N)).func_206870_a(field_176347_b, p_185499_1_.func_177229_b(field_176348_a)).func_206870_a(field_176349_M, p_185499_1_.func_177229_b(field_176347_b)).func_206870_a(field_176350_N, p_185499_1_.func_177229_b(field_176349_M));
      default:
         return p_185499_1_;
      }
   }

   public IBlockState func_185471_a(IBlockState p_185471_1_, Mirror p_185471_2_) {
      switch(p_185471_2_) {
      case LEFT_RIGHT:
         return p_185471_1_.func_206870_a(field_176348_a, p_185471_1_.func_177229_b(field_176349_M)).func_206870_a(field_176349_M, p_185471_1_.func_177229_b(field_176348_a));
      case FRONT_BACK:
         return p_185471_1_.func_206870_a(field_176347_b, p_185471_1_.func_177229_b(field_176350_N)).func_206870_a(field_176350_N, p_185471_1_.func_177229_b(field_176347_b));
      default:
         return super.func_185471_a(p_185471_1_, p_185471_2_);
      }
   }

   protected void func_206840_a(StateContainer.Builder<Block, IBlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_176348_a, field_176347_b, field_176349_M, field_176350_N, field_176351_O);
   }

   public BlockFaceShape func_193383_a(IBlockReader p_193383_1_, IBlockState p_193383_2_, BlockPos p_193383_3_, EnumFacing p_193383_4_) {
      return BlockFaceShape.UNDEFINED;
   }
}
