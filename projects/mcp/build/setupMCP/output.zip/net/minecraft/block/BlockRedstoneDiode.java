package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.init.Blocks;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.item.ItemStack;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorldReaderBase;
import net.minecraft.world.TickPriority;
import net.minecraft.world.World;

public abstract class BlockRedstoneDiode extends BlockHorizontal {
   protected static final VoxelShape field_196347_b = Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 2.0D, 16.0D);
   public static final BooleanProperty field_196348_c = BlockStateProperties.field_208194_u;

   protected BlockRedstoneDiode(Block.Properties p_i48416_1_) {
      super(p_i48416_1_);
   }

   public VoxelShape func_196244_b(IBlockState p_196244_1_, IBlockReader p_196244_2_, BlockPos p_196244_3_) {
      return field_196347_b;
   }

   public boolean func_149686_d(IBlockState p_149686_1_) {
      return false;
   }

   public boolean func_196260_a(IBlockState p_196260_1_, IWorldReaderBase p_196260_2_, BlockPos p_196260_3_) {
      return p_196260_2_.func_180495_p(p_196260_3_.func_177977_b()).func_185896_q();
   }

   public void func_196267_b(IBlockState p_196267_1_, World p_196267_2_, BlockPos p_196267_3_, Random p_196267_4_) {
      if (!this.func_176405_b(p_196267_2_, p_196267_3_, p_196267_1_)) {
         boolean flag = p_196267_1_.func_177229_b(field_196348_c);
         boolean flag1 = this.func_176404_e(p_196267_2_, p_196267_3_, p_196267_1_);
         if (flag && !flag1) {
            p_196267_2_.func_180501_a(p_196267_3_, p_196267_1_.func_206870_a(field_196348_c, Boolean.valueOf(false)), 2);
         } else if (!flag) {
            p_196267_2_.func_180501_a(p_196267_3_, p_196267_1_.func_206870_a(field_196348_c, Boolean.valueOf(true)), 2);
            if (!flag1) {
               p_196267_2_.func_205220_G_().func_205362_a(p_196267_3_, this, this.func_196346_i(p_196267_1_), TickPriority.HIGH);
            }
         }

      }
   }

   public int func_176211_b(IBlockState p_176211_1_, IBlockReader p_176211_2_, BlockPos p_176211_3_, EnumFacing p_176211_4_) {
      return p_176211_1_.func_185911_a(p_176211_2_, p_176211_3_, p_176211_4_);
   }

   public int func_180656_a(IBlockState p_180656_1_, IBlockReader p_180656_2_, BlockPos p_180656_3_, EnumFacing p_180656_4_) {
      if (!p_180656_1_.func_177229_b(field_196348_c)) {
         return 0;
      } else {
         return p_180656_1_.func_177229_b(field_185512_D) == p_180656_4_ ? this.func_176408_a(p_180656_2_, p_180656_3_, p_180656_1_) : 0;
      }
   }

   public void func_189540_a(IBlockState p_189540_1_, World p_189540_2_, BlockPos p_189540_3_, Block p_189540_4_, BlockPos p_189540_5_) {
      if (p_189540_1_.func_196955_c(p_189540_2_, p_189540_3_)) {
         this.func_176398_g(p_189540_2_, p_189540_3_, p_189540_1_);
      } else {
         p_189540_1_.func_196949_c(p_189540_2_, p_189540_3_, 0);
         p_189540_2_.func_175698_g(p_189540_3_);

         for(EnumFacing enumfacing : EnumFacing.values()) {
            p_189540_2_.func_195593_d(p_189540_3_.func_177972_a(enumfacing), this);
         }

      }
   }

   protected void func_176398_g(World p_176398_1_, BlockPos p_176398_2_, IBlockState p_176398_3_) {
      if (!this.func_176405_b(p_176398_1_, p_176398_2_, p_176398_3_)) {
         boolean flag = p_176398_3_.func_177229_b(field_196348_c);
         boolean flag1 = this.func_176404_e(p_176398_1_, p_176398_2_, p_176398_3_);
         if (flag != flag1 && !p_176398_1_.func_205220_G_().func_205361_b(p_176398_2_, this)) {
            TickPriority tickpriority = TickPriority.HIGH;
            if (this.func_176402_i(p_176398_1_, p_176398_2_, p_176398_3_)) {
               tickpriority = TickPriority.EXTREMELY_HIGH;
            } else if (flag) {
               tickpriority = TickPriority.VERY_HIGH;
            }

            p_176398_1_.func_205220_G_().func_205362_a(p_176398_2_, this, this.func_196346_i(p_176398_3_), tickpriority);
         }

      }
   }

   public boolean func_176405_b(IWorldReaderBase p_176405_1_, BlockPos p_176405_2_, IBlockState p_176405_3_) {
      return false;
   }

   protected boolean func_176404_e(World p_176404_1_, BlockPos p_176404_2_, IBlockState p_176404_3_) {
      return this.func_176397_f(p_176404_1_, p_176404_2_, p_176404_3_) > 0;
   }

   protected int func_176397_f(World p_176397_1_, BlockPos p_176397_2_, IBlockState p_176397_3_) {
      EnumFacing enumfacing = p_176397_3_.func_177229_b(field_185512_D);
      BlockPos blockpos = p_176397_2_.func_177972_a(enumfacing);
      int i = p_176397_1_.func_175651_c(blockpos, enumfacing);
      if (i >= 15) {
         return i;
      } else {
         IBlockState iblockstate = p_176397_1_.func_180495_p(blockpos);
         return Math.max(i, iblockstate.func_177230_c() == Blocks.field_150488_af ? iblockstate.func_177229_b(BlockRedstoneWire.field_176351_O) : 0);
      }
   }

   protected int func_176407_c(IWorldReaderBase p_176407_1_, BlockPos p_176407_2_, IBlockState p_176407_3_) {
      EnumFacing enumfacing = p_176407_3_.func_177229_b(field_185512_D);
      EnumFacing enumfacing1 = enumfacing.func_176746_e();
      EnumFacing enumfacing2 = enumfacing.func_176735_f();
      return Math.max(this.func_176401_c(p_176407_1_, p_176407_2_.func_177972_a(enumfacing1), enumfacing1), this.func_176401_c(p_176407_1_, p_176407_2_.func_177972_a(enumfacing2), enumfacing2));
   }

   protected int func_176401_c(IWorldReaderBase p_176401_1_, BlockPos p_176401_2_, EnumFacing p_176401_3_) {
      IBlockState iblockstate = p_176401_1_.func_180495_p(p_176401_2_);
      Block block = iblockstate.func_177230_c();
      if (this.func_185545_A(iblockstate)) {
         if (block == Blocks.field_150451_bX) {
            return 15;
         } else {
            return block == Blocks.field_150488_af ? iblockstate.func_177229_b(BlockRedstoneWire.field_176351_O) : p_176401_1_.func_175627_a(p_176401_2_, p_176401_3_);
         }
      } else {
         return 0;
      }
   }

   public boolean func_149744_f(IBlockState p_149744_1_) {
      return true;
   }

   public IBlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      return this.func_176223_P().func_206870_a(field_185512_D, p_196258_1_.func_195992_f().func_176734_d());
   }

   public void func_180633_a(World p_180633_1_, BlockPos p_180633_2_, IBlockState p_180633_3_, EntityLivingBase p_180633_4_, ItemStack p_180633_5_) {
      if (this.func_176404_e(p_180633_1_, p_180633_2_, p_180633_3_)) {
         p_180633_1_.func_205220_G_().func_205360_a(p_180633_2_, this, 1);
      }

   }

   public void func_196259_b(IBlockState p_196259_1_, World p_196259_2_, BlockPos p_196259_3_, IBlockState p_196259_4_) {
      this.func_176400_h(p_196259_2_, p_196259_3_, p_196259_1_);
   }

   public void func_196243_a(IBlockState p_196243_1_, World p_196243_2_, BlockPos p_196243_3_, IBlockState p_196243_4_, boolean p_196243_5_) {
      if (!p_196243_5_ && p_196243_1_.func_177230_c() != p_196243_4_.func_177230_c()) {
         super.func_196243_a(p_196243_1_, p_196243_2_, p_196243_3_, p_196243_4_, p_196243_5_);
         this.func_211326_a(p_196243_2_, p_196243_3_);
         this.func_176400_h(p_196243_2_, p_196243_3_, p_196243_1_);
      }
   }

   protected void func_211326_a(World p_211326_1_, BlockPos p_211326_2_) {
   }

   protected void func_176400_h(World p_176400_1_, BlockPos p_176400_2_, IBlockState p_176400_3_) {
      EnumFacing enumfacing = p_176400_3_.func_177229_b(field_185512_D);
      BlockPos blockpos = p_176400_2_.func_177972_a(enumfacing.func_176734_d());
      p_176400_1_.func_190524_a(blockpos, this, p_176400_2_);
      p_176400_1_.func_175695_a(blockpos, this, enumfacing);
   }

   protected boolean func_185545_A(IBlockState p_185545_1_) {
      return p_185545_1_.func_185897_m();
   }

   protected int func_176408_a(IBlockReader p_176408_1_, BlockPos p_176408_2_, IBlockState p_176408_3_) {
      return 15;
   }

   public static boolean func_185546_B(IBlockState p_185546_0_) {
      return p_185546_0_.func_177230_c() instanceof BlockRedstoneDiode;
   }

   public boolean func_176402_i(IBlockReader p_176402_1_, BlockPos p_176402_2_, IBlockState p_176402_3_) {
      EnumFacing enumfacing = p_176402_3_.func_177229_b(field_185512_D).func_176734_d();
      IBlockState iblockstate = p_176402_1_.func_180495_p(p_176402_2_.func_177972_a(enumfacing));
      return func_185546_B(iblockstate) && iblockstate.func_177229_b(field_185512_D) != enumfacing;
   }

   protected abstract int func_196346_i(IBlockState p_196346_1_);

   public BlockRenderLayer func_180664_k() {
      return BlockRenderLayer.CUTOUT;
   }

   public boolean func_200124_e(IBlockState p_200124_1_) {
      return true;
   }

   public BlockFaceShape func_193383_a(IBlockReader p_193383_1_, IBlockState p_193383_2_, BlockPos p_193383_3_, EnumFacing p_193383_4_) {
      return p_193383_4_ == EnumFacing.DOWN ? BlockFaceShape.SOLID : BlockFaceShape.UNDEFINED;
   }
}
