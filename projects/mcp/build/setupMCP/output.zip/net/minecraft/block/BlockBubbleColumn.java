package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.fluid.Fluid;
import net.minecraft.fluid.IFluidState;
import net.minecraft.init.Blocks;
import net.minecraft.init.Fluids;
import net.minecraft.init.Particles;
import net.minecraft.init.SoundEvents;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.EnumBlockRenderType;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.IWorldReaderBase;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class BlockBubbleColumn extends Block implements IBucketPickupHandler {
   public static final BooleanProperty field_203160_a = BlockStateProperties.field_208179_f;

   public BlockBubbleColumn(Block.Properties p_i48783_1_) {
      super(p_i48783_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_203160_a, Boolean.valueOf(true)));
   }

   public boolean func_149686_d(IBlockState p_149686_1_) {
      return false;
   }

   public void func_196262_a(IBlockState p_196262_1_, World p_196262_2_, BlockPos p_196262_3_, Entity p_196262_4_) {
      IBlockState iblockstate = p_196262_2_.func_180495_p(p_196262_3_.func_177984_a());
      if (iblockstate.func_196958_f()) {
         p_196262_4_.func_203002_i(p_196262_1_.func_177229_b(field_203160_a));
         if (!p_196262_2_.field_72995_K) {
            WorldServer worldserver = (WorldServer)p_196262_2_;

            for(int i = 0; i < 2; ++i) {
               worldserver.func_195598_a(Particles.field_197606_Q, (double)((float)p_196262_3_.func_177958_n() + p_196262_2_.field_73012_v.nextFloat()), (double)(p_196262_3_.func_177956_o() + 1), (double)((float)p_196262_3_.func_177952_p() + p_196262_2_.field_73012_v.nextFloat()), 1, 0.0D, 0.0D, 0.0D, 1.0D);
               worldserver.func_195598_a(Particles.field_197612_e, (double)((float)p_196262_3_.func_177958_n() + p_196262_2_.field_73012_v.nextFloat()), (double)(p_196262_3_.func_177956_o() + 1), (double)((float)p_196262_3_.func_177952_p() + p_196262_2_.field_73012_v.nextFloat()), 1, 0.0D, 0.01D, 0.0D, 0.2D);
            }
         }
      } else {
         p_196262_4_.func_203004_j(p_196262_1_.func_177229_b(field_203160_a));
      }

   }

   public void func_196259_b(IBlockState p_196259_1_, World p_196259_2_, BlockPos p_196259_3_, IBlockState p_196259_4_) {
      func_203159_a(p_196259_2_, p_196259_3_.func_177984_a(), func_203157_b(p_196259_2_, p_196259_3_.func_177977_b()));
   }

   public void func_196267_b(IBlockState p_196267_1_, World p_196267_2_, BlockPos p_196267_3_, Random p_196267_4_) {
      func_203159_a(p_196267_2_, p_196267_3_.func_177984_a(), func_203157_b(p_196267_2_, p_196267_3_));
   }

   public IFluidState func_204507_t(IBlockState p_204507_1_) {
      return Fluids.field_204546_a.func_207204_a(false);
   }

   public static void func_203159_a(IWorld p_203159_0_, BlockPos p_203159_1_, boolean p_203159_2_) {
      if (func_208072_b(p_203159_0_, p_203159_1_)) {
         p_203159_0_.func_180501_a(p_203159_1_, Blocks.field_203203_C.func_176223_P().func_206870_a(field_203160_a, Boolean.valueOf(p_203159_2_)), 2);
      }

   }

   public static boolean func_208072_b(IWorld p_208072_0_, BlockPos p_208072_1_) {
      IFluidState ifluidstate = p_208072_0_.func_204610_c(p_208072_1_);
      return p_208072_0_.func_180495_p(p_208072_1_).func_177230_c() == Blocks.field_150355_j && ifluidstate.func_206882_g() >= 8 && ifluidstate.func_206889_d();
   }

   private static boolean func_203157_b(IBlockReader p_203157_0_, BlockPos p_203157_1_) {
      IBlockState iblockstate = p_203157_0_.func_180495_p(p_203157_1_);
      Block block = iblockstate.func_177230_c();
      if (block == Blocks.field_203203_C) {
         return iblockstate.func_177229_b(field_203160_a);
      } else {
         return block != Blocks.field_150425_aM;
      }
   }

   public int func_149738_a(IWorldReaderBase p_149738_1_) {
      return 5;
   }

   @OnlyIn(Dist.CLIENT)
   public void func_180655_c(IBlockState p_180655_1_, World p_180655_2_, BlockPos p_180655_3_, Random p_180655_4_) {
      double d0 = (double)p_180655_3_.func_177958_n();
      double d1 = (double)p_180655_3_.func_177956_o();
      double d2 = (double)p_180655_3_.func_177952_p();
      if (p_180655_1_.func_177229_b(field_203160_a)) {
         p_180655_2_.func_195589_b(Particles.field_203218_U, d0 + 0.5D, d1 + 0.8D, d2, 0.0D, 0.0D, 0.0D);
         if (p_180655_4_.nextInt(200) == 0) {
            p_180655_2_.func_184134_a(d0, d1, d2, SoundEvents.field_203282_jc, SoundCategory.BLOCKS, 0.2F + p_180655_4_.nextFloat() * 0.2F, 0.9F + p_180655_4_.nextFloat() * 0.15F, false);
         }
      } else {
         p_180655_2_.func_195589_b(Particles.field_203220_f, d0 + 0.5D, d1, d2 + 0.5D, 0.0D, 0.04D, 0.0D);
         p_180655_2_.func_195589_b(Particles.field_203220_f, d0 + (double)p_180655_4_.nextFloat(), d1 + (double)p_180655_4_.nextFloat(), d2 + (double)p_180655_4_.nextFloat(), 0.0D, 0.04D, 0.0D);
         if (p_180655_4_.nextInt(200) == 0) {
            p_180655_2_.func_184134_a(d0, d1, d2, SoundEvents.field_203251_S, SoundCategory.BLOCKS, 0.2F + p_180655_4_.nextFloat() * 0.2F, 0.9F + p_180655_4_.nextFloat() * 0.15F, false);
         }
      }

   }

   public IBlockState func_196271_a(IBlockState p_196271_1_, EnumFacing p_196271_2_, IBlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      if (!p_196271_1_.func_196955_c(p_196271_4_, p_196271_5_)) {
         return Blocks.field_150355_j.func_176223_P();
      } else {
         if (p_196271_2_ == EnumFacing.DOWN) {
            p_196271_4_.func_180501_a(p_196271_5_, Blocks.field_203203_C.func_176223_P().func_206870_a(field_203160_a, Boolean.valueOf(func_203157_b(p_196271_4_, p_196271_6_))), 2);
         } else if (p_196271_2_ == EnumFacing.UP && p_196271_3_.func_177230_c() != Blocks.field_203203_C && func_208072_b(p_196271_4_, p_196271_6_)) {
            p_196271_4_.func_205220_G_().func_205360_a(p_196271_5_, this, this.func_149738_a(p_196271_4_));
         }

         p_196271_4_.func_205219_F_().func_205360_a(p_196271_5_, Fluids.field_204546_a, Fluids.field_204546_a.func_205569_a(p_196271_4_));
         return super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
      }
   }

   public boolean func_196260_a(IBlockState p_196260_1_, IWorldReaderBase p_196260_2_, BlockPos p_196260_3_) {
      Block block = p_196260_2_.func_180495_p(p_196260_3_.func_177977_b()).func_177230_c();
      return block == Blocks.field_203203_C || block == Blocks.field_196814_hQ || block == Blocks.field_150425_aM;
   }

   public boolean func_149703_v() {
      return false;
   }

   public int func_196264_a(IBlockState p_196264_1_, Random p_196264_2_) {
      return 0;
   }

   public BlockRenderLayer func_180664_k() {
      return BlockRenderLayer.TRANSLUCENT;
   }

   public BlockFaceShape func_193383_a(IBlockReader p_193383_1_, IBlockState p_193383_2_, BlockPos p_193383_3_, EnumFacing p_193383_4_) {
      return BlockFaceShape.UNDEFINED;
   }

   public EnumBlockRenderType func_149645_b(IBlockState p_149645_1_) {
      return EnumBlockRenderType.INVISIBLE;
   }

   protected void func_206840_a(StateContainer.Builder<Block, IBlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_203160_a);
   }

   public Fluid func_204508_a(IWorld p_204508_1_, BlockPos p_204508_2_, IBlockState p_204508_3_) {
      p_204508_1_.func_180501_a(p_204508_2_, Blocks.field_150350_a.func_176223_P(), 11);
      return Fluids.field_204546_a;
   }
}
