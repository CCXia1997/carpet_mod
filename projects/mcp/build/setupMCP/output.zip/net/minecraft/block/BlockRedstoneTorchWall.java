package net.minecraft.block;

import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.particles.RedstoneParticleData;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.DirectionProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.IWorldReaderBase;
import net.minecraft.world.World;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class BlockRedstoneTorchWall extends BlockRedstoneTorch {
   public static final DirectionProperty field_196530_b = BlockHorizontal.field_185512_D;
   public static final BooleanProperty field_196531_c = BlockRedstoneTorch.field_196528_a;

   protected BlockRedstoneTorchWall(Block.Properties p_i48341_1_) {
      super(p_i48341_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_196530_b, EnumFacing.NORTH).func_206870_a(field_196531_c, Boolean.valueOf(true)));
   }

   public String func_149739_a() {
      return this.func_199767_j().func_77658_a();
   }

   public VoxelShape func_196244_b(IBlockState p_196244_1_, IBlockReader p_196244_2_, BlockPos p_196244_3_) {
      return Blocks.field_196591_bQ.func_196244_b(p_196244_1_, p_196244_2_, p_196244_3_);
   }

   public boolean func_196260_a(IBlockState p_196260_1_, IWorldReaderBase p_196260_2_, BlockPos p_196260_3_) {
      return Blocks.field_196591_bQ.func_196260_a(p_196260_1_, p_196260_2_, p_196260_3_);
   }

   public IBlockState func_196271_a(IBlockState p_196271_1_, EnumFacing p_196271_2_, IBlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      return Blocks.field_196591_bQ.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
   }

   @Nullable
   public IBlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      IBlockState iblockstate = Blocks.field_196591_bQ.func_196258_a(p_196258_1_);
      return iblockstate == null ? null : this.func_176223_P().func_206870_a(field_196530_b, iblockstate.func_177229_b(field_196530_b));
   }

   @OnlyIn(Dist.CLIENT)
   public void func_180655_c(IBlockState p_180655_1_, World p_180655_2_, BlockPos p_180655_3_, Random p_180655_4_) {
      if (p_180655_1_.func_177229_b(field_196531_c)) {
         EnumFacing enumfacing = p_180655_1_.func_177229_b(field_196530_b).func_176734_d();
         double d0 = 0.27D;
         double d1 = (double)p_180655_3_.func_177958_n() + 0.5D + (p_180655_4_.nextDouble() - 0.5D) * 0.2D + 0.27D * (double)enumfacing.func_82601_c();
         double d2 = (double)p_180655_3_.func_177956_o() + 0.7D + (p_180655_4_.nextDouble() - 0.5D) * 0.2D + 0.22D;
         double d3 = (double)p_180655_3_.func_177952_p() + 0.5D + (p_180655_4_.nextDouble() - 0.5D) * 0.2D + 0.27D * (double)enumfacing.func_82599_e();
         p_180655_2_.func_195594_a(RedstoneParticleData.field_197564_a, d1, d2, d3, 0.0D, 0.0D, 0.0D);
      }
   }

   protected boolean func_176597_g(World p_176597_1_, BlockPos p_176597_2_, IBlockState p_176597_3_) {
      EnumFacing enumfacing = p_176597_3_.func_177229_b(field_196530_b).func_176734_d();
      return p_176597_1_.func_175709_b(p_176597_2_.func_177972_a(enumfacing), enumfacing);
   }

   public int func_180656_a(IBlockState p_180656_1_, IBlockReader p_180656_2_, BlockPos p_180656_3_, EnumFacing p_180656_4_) {
      return p_180656_1_.func_177229_b(field_196531_c) && p_180656_1_.func_177229_b(field_196530_b) != p_180656_4_ ? 15 : 0;
   }

   public IBlockState func_185499_a(IBlockState p_185499_1_, Rotation p_185499_2_) {
      return Blocks.field_196591_bQ.func_185499_a(p_185499_1_, p_185499_2_);
   }

   public IBlockState func_185471_a(IBlockState p_185471_1_, Mirror p_185471_2_) {
      return Blocks.field_196591_bQ.func_185471_a(p_185471_1_, p_185471_2_);
   }

   protected void func_206840_a(StateContainer.Builder<Block, IBlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_196530_b, field_196531_c);
   }
}
