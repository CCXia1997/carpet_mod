package net.minecraft.block;

import net.minecraft.block.material.EnumPushReaction;
import net.minecraft.block.state.IBlockState;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.state.StateContainer;

public class BlockGlazedTerracotta extends BlockHorizontal {
   public BlockGlazedTerracotta(Block.Properties p_i48390_1_) {
      super(p_i48390_1_);
   }

   protected void func_206840_a(StateContainer.Builder<Block, IBlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_185512_D);
   }

   public IBlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      return this.func_176223_P().func_206870_a(field_185512_D, p_196258_1_.func_195992_f().func_176734_d());
   }

   public EnumPushReaction func_149656_h(IBlockState p_149656_1_) {
      return EnumPushReaction.PUSH_ONLY;
   }
}
