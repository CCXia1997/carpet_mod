package net.minecraft.block;

import java.util.Map;
import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Items;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.IItemProvider;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.World;

public class BlockHugeMushroom extends Block {
   public static final BooleanProperty field_196459_a = BlockSixWay.field_196488_a;
   public static final BooleanProperty field_196461_b = BlockSixWay.field_196490_b;
   public static final BooleanProperty field_196463_c = BlockSixWay.field_196492_c;
   public static final BooleanProperty field_196464_y = BlockSixWay.field_196495_y;
   public static final BooleanProperty field_196465_z = BlockSixWay.field_196496_z;
   public static final BooleanProperty field_196460_A = BlockSixWay.field_196489_A;
   private static final Map<EnumFacing, BooleanProperty> field_196462_B = BlockSixWay.field_196491_B;
   @Nullable
   private final Block field_176379_b;

   public BlockHugeMushroom(@Nullable Block p_i48376_1_, Block.Properties p_i48376_2_) {
      super(p_i48376_2_);
      this.field_176379_b = p_i48376_1_;
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_196459_a, Boolean.valueOf(true)).func_206870_a(field_196461_b, Boolean.valueOf(true)).func_206870_a(field_196463_c, Boolean.valueOf(true)).func_206870_a(field_196464_y, Boolean.valueOf(true)).func_206870_a(field_196465_z, Boolean.valueOf(true)).func_206870_a(field_196460_A, Boolean.valueOf(true)));
   }

   public int func_196264_a(IBlockState p_196264_1_, Random p_196264_2_) {
      return Math.max(0, p_196264_2_.nextInt(9) - 6);
   }

   public IItemProvider func_199769_a(IBlockState p_199769_1_, World p_199769_2_, BlockPos p_199769_3_, int p_199769_4_) {
      return (IItemProvider)(this.field_176379_b == null ? Items.field_190931_a : this.field_176379_b);
   }

   public IBlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      IBlockReader iblockreader = p_196258_1_.func_195991_k();
      BlockPos blockpos = p_196258_1_.func_195995_a();
      return this.func_176223_P().func_206870_a(field_196460_A, Boolean.valueOf(this != iblockreader.func_180495_p(blockpos.func_177977_b()).func_177230_c())).func_206870_a(field_196465_z, Boolean.valueOf(this != iblockreader.func_180495_p(blockpos.func_177984_a()).func_177230_c())).func_206870_a(field_196459_a, Boolean.valueOf(this != iblockreader.func_180495_p(blockpos.func_177978_c()).func_177230_c())).func_206870_a(field_196461_b, Boolean.valueOf(this != iblockreader.func_180495_p(blockpos.func_177974_f()).func_177230_c())).func_206870_a(field_196463_c, Boolean.valueOf(this != iblockreader.func_180495_p(blockpos.func_177968_d()).func_177230_c())).func_206870_a(field_196464_y, Boolean.valueOf(this != iblockreader.func_180495_p(blockpos.func_177976_e()).func_177230_c()));
   }

   public IBlockState func_196271_a(IBlockState p_196271_1_, EnumFacing p_196271_2_, IBlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      return p_196271_3_.func_177230_c() == this ? p_196271_1_.func_206870_a(field_196462_B.get(p_196271_2_), Boolean.valueOf(false)) : super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
   }

   public IBlockState func_185499_a(IBlockState p_185499_1_, Rotation p_185499_2_) {
      return p_185499_1_.func_206870_a(field_196462_B.get(p_185499_2_.func_185831_a(EnumFacing.NORTH)), p_185499_1_.func_177229_b(field_196459_a)).func_206870_a(field_196462_B.get(p_185499_2_.func_185831_a(EnumFacing.SOUTH)), p_185499_1_.func_177229_b(field_196463_c)).func_206870_a(field_196462_B.get(p_185499_2_.func_185831_a(EnumFacing.EAST)), p_185499_1_.func_177229_b(field_196461_b)).func_206870_a(field_196462_B.get(p_185499_2_.func_185831_a(EnumFacing.WEST)), p_185499_1_.func_177229_b(field_196464_y)).func_206870_a(field_196462_B.get(p_185499_2_.func_185831_a(EnumFacing.UP)), p_185499_1_.func_177229_b(field_196465_z)).func_206870_a(field_196462_B.get(p_185499_2_.func_185831_a(EnumFacing.DOWN)), p_185499_1_.func_177229_b(field_196460_A));
   }

   public IBlockState func_185471_a(IBlockState p_185471_1_, Mirror p_185471_2_) {
      return p_185471_1_.func_206870_a(field_196462_B.get(p_185471_2_.func_185803_b(EnumFacing.NORTH)), p_185471_1_.func_177229_b(field_196459_a)).func_206870_a(field_196462_B.get(p_185471_2_.func_185803_b(EnumFacing.SOUTH)), p_185471_1_.func_177229_b(field_196463_c)).func_206870_a(field_196462_B.get(p_185471_2_.func_185803_b(EnumFacing.EAST)), p_185471_1_.func_177229_b(field_196461_b)).func_206870_a(field_196462_B.get(p_185471_2_.func_185803_b(EnumFacing.WEST)), p_185471_1_.func_177229_b(field_196464_y)).func_206870_a(field_196462_B.get(p_185471_2_.func_185803_b(EnumFacing.UP)), p_185471_1_.func_177229_b(field_196465_z)).func_206870_a(field_196462_B.get(p_185471_2_.func_185803_b(EnumFacing.DOWN)), p_185471_1_.func_177229_b(field_196460_A));
   }

   protected void func_206840_a(StateContainer.Builder<Block, IBlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_196465_z, field_196460_A, field_196459_a, field_196461_b, field_196463_c, field_196464_y);
   }
}
