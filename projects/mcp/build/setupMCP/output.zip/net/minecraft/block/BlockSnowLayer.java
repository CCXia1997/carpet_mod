package net.minecraft.block;

import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.IBlockState;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Enchantments;
import net.minecraft.init.Items;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.item.ItemStack;
import net.minecraft.pathfinding.PathType;
import net.minecraft.state.IntegerProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.stats.StatList;
import net.minecraft.tags.BlockTags;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.IItemProvider;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.shapes.VoxelShapes;
import net.minecraft.world.EnumLightType;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.IWorldReaderBase;
import net.minecraft.world.World;

public class BlockSnowLayer extends Block {
   public static final IntegerProperty field_176315_a = BlockStateProperties.field_208129_ad;
   protected static final VoxelShape[] field_196508_b = new VoxelShape[]{VoxelShapes.func_197880_a(), Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 2.0D, 16.0D), Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 4.0D, 16.0D), Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 6.0D, 16.0D), Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 8.0D, 16.0D), Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 10.0D, 16.0D), Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 12.0D, 16.0D), Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 14.0D, 16.0D), Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 16.0D, 16.0D)};

   protected BlockSnowLayer(Block.Properties p_i48328_1_) {
      super(p_i48328_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_176315_a, Integer.valueOf(1)));
   }

   public boolean func_196266_a(IBlockState p_196266_1_, IBlockReader p_196266_2_, BlockPos p_196266_3_, PathType p_196266_4_) {
      switch(p_196266_4_) {
      case LAND:
         return p_196266_1_.func_177229_b(field_176315_a) < 5;
      case WATER:
         return false;
      case AIR:
         return false;
      default:
         return false;
      }
   }

   public boolean func_149686_d(IBlockState p_149686_1_) {
      return p_149686_1_.func_177229_b(field_176315_a) == 8;
   }

   public BlockFaceShape func_193383_a(IBlockReader p_193383_1_, IBlockState p_193383_2_, BlockPos p_193383_3_, EnumFacing p_193383_4_) {
      return p_193383_4_ == EnumFacing.DOWN ? BlockFaceShape.SOLID : BlockFaceShape.UNDEFINED;
   }

   public VoxelShape func_196244_b(IBlockState p_196244_1_, IBlockReader p_196244_2_, BlockPos p_196244_3_) {
      return field_196508_b[p_196244_1_.func_177229_b(field_176315_a)];
   }

   public VoxelShape func_196268_f(IBlockState p_196268_1_, IBlockReader p_196268_2_, BlockPos p_196268_3_) {
      return field_196508_b[p_196268_1_.func_177229_b(field_176315_a) - 1];
   }

   public boolean func_196260_a(IBlockState p_196260_1_, IWorldReaderBase p_196260_2_, BlockPos p_196260_3_) {
      IBlockState iblockstate = p_196260_2_.func_180495_p(p_196260_3_.func_177977_b());
      Block block = iblockstate.func_177230_c();
      if (block != Blocks.field_150432_aD && block != Blocks.field_150403_cj && block != Blocks.field_180401_cv) {
         BlockFaceShape blockfaceshape = iblockstate.func_193401_d(p_196260_2_, p_196260_3_.func_177977_b(), EnumFacing.UP);
         return blockfaceshape == BlockFaceShape.SOLID || iblockstate.func_203425_a(BlockTags.field_206952_E) || block == this && iblockstate.func_177229_b(field_176315_a) == 8;
      } else {
         return false;
      }
   }

   public IBlockState func_196271_a(IBlockState p_196271_1_, EnumFacing p_196271_2_, IBlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      return !p_196271_1_.func_196955_c(p_196271_4_, p_196271_5_) ? Blocks.field_150350_a.func_176223_P() : super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
   }

   public void func_180657_a(World p_180657_1_, EntityPlayer p_180657_2_, BlockPos p_180657_3_, IBlockState p_180657_4_, @Nullable TileEntity p_180657_5_, ItemStack p_180657_6_) {
      Integer integer = p_180657_4_.func_177229_b(field_176315_a);
      if (this.func_149700_E() && EnchantmentHelper.func_77506_a(Enchantments.field_185306_r, p_180657_6_) > 0) {
         if (integer == 8) {
            func_180635_a(p_180657_1_, p_180657_3_, new ItemStack(Blocks.field_196604_cC));
         } else {
            for(int i = 0; i < integer; ++i) {
               func_180635_a(p_180657_1_, p_180657_3_, this.func_180643_i(p_180657_4_));
            }
         }
      } else {
         func_180635_a(p_180657_1_, p_180657_3_, new ItemStack(Items.field_151126_ay, integer));
      }

      p_180657_1_.func_175698_g(p_180657_3_);
      p_180657_2_.func_71029_a(StatList.field_188065_ae.func_199076_b(this));
      p_180657_2_.func_71020_j(0.005F);
   }

   public IItemProvider func_199769_a(IBlockState p_199769_1_, World p_199769_2_, BlockPos p_199769_3_, int p_199769_4_) {
      return Items.field_190931_a;
   }

   public void func_196267_b(IBlockState p_196267_1_, World p_196267_2_, BlockPos p_196267_3_, Random p_196267_4_) {
      if (p_196267_2_.func_175642_b(EnumLightType.BLOCK, p_196267_3_) > 11) {
         p_196267_1_.func_196949_c(p_196267_2_, p_196267_3_, 0);
         p_196267_2_.func_175698_g(p_196267_3_);
      }

   }

   public boolean func_196253_a(IBlockState p_196253_1_, BlockItemUseContext p_196253_2_) {
      int i = p_196253_1_.func_177229_b(field_176315_a);
      if (p_196253_2_.func_195996_i().func_77973_b() == this.func_199767_j() && i < 8) {
         if (p_196253_2_.func_196012_c()) {
            return p_196253_2_.func_196000_l() == EnumFacing.UP;
         } else {
            return true;
         }
      } else {
         return i == 1;
      }
   }

   @Nullable
   public IBlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      IBlockState iblockstate = p_196258_1_.func_195991_k().func_180495_p(p_196258_1_.func_195995_a());
      if (iblockstate.func_177230_c() == this) {
         int i = iblockstate.func_177229_b(field_176315_a);
         return iblockstate.func_206870_a(field_176315_a, Integer.valueOf(Math.min(8, i + 1)));
      } else {
         return super.func_196258_a(p_196258_1_);
      }
   }

   protected void func_206840_a(StateContainer.Builder<Block, IBlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_176315_a);
   }

   protected boolean func_149700_E() {
      return true;
   }
}
