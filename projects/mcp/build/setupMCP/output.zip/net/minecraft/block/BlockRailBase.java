package net.minecraft.block;

import net.minecraft.block.material.EnumPushReaction;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.IBlockState;
import net.minecraft.state.IProperty;
import net.minecraft.state.properties.RailShape;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorldReaderBase;
import net.minecraft.world.World;

public abstract class BlockRailBase extends Block {
   protected static final VoxelShape field_185590_a = Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 2.0D, 16.0D);
   protected static final VoxelShape field_190959_b = Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 8.0D, 16.0D);
   private final boolean field_196277_c;

   public static boolean func_208488_a(World p_208488_0_, BlockPos p_208488_1_) {
      return func_208487_j(p_208488_0_.func_180495_p(p_208488_1_));
   }

   public static boolean func_208487_j(IBlockState p_208487_0_) {
      return p_208487_0_.func_203425_a(BlockTags.field_203437_y);
   }

   protected BlockRailBase(boolean p_i48444_1_, Block.Properties p_i48444_2_) {
      super(p_i48444_2_);
      this.field_196277_c = p_i48444_1_;
   }

   public boolean func_208490_b() {
      return this.field_196277_c;
   }

   public VoxelShape func_196244_b(IBlockState p_196244_1_, IBlockReader p_196244_2_, BlockPos p_196244_3_) {
      RailShape railshape = p_196244_1_.func_177230_c() == this ? p_196244_1_.func_177229_b(this.func_176560_l()) : null;
      return railshape != null && railshape.func_208092_c() ? field_190959_b : field_185590_a;
   }

   public BlockFaceShape func_193383_a(IBlockReader p_193383_1_, IBlockState p_193383_2_, BlockPos p_193383_3_, EnumFacing p_193383_4_) {
      return BlockFaceShape.UNDEFINED;
   }

   public boolean func_149686_d(IBlockState p_149686_1_) {
      return false;
   }

   public boolean func_196260_a(IBlockState p_196260_1_, IWorldReaderBase p_196260_2_, BlockPos p_196260_3_) {
      return p_196260_2_.func_180495_p(p_196260_3_.func_177977_b()).func_185896_q();
   }

   public void func_196259_b(IBlockState p_196259_1_, World p_196259_2_, BlockPos p_196259_3_, IBlockState p_196259_4_) {
      if (p_196259_4_.func_177230_c() != p_196259_1_.func_177230_c()) {
         if (!p_196259_2_.field_72995_K) {
            p_196259_1_ = this.func_208489_a(p_196259_2_, p_196259_3_, p_196259_1_, true);
            if (this.field_196277_c) {
               p_196259_1_.func_189546_a(p_196259_2_, p_196259_3_, this, p_196259_3_);
            }
         }

      }
   }

   public void func_189540_a(IBlockState p_189540_1_, World p_189540_2_, BlockPos p_189540_3_, Block p_189540_4_, BlockPos p_189540_5_) {
      if (!p_189540_2_.field_72995_K) {
         RailShape railshape = p_189540_1_.func_177229_b(this.func_176560_l());
         boolean flag = false;
         if (!p_189540_2_.func_180495_p(p_189540_3_.func_177977_b()).func_185896_q()) {
            flag = true;
         }

         if (railshape == RailShape.ASCENDING_EAST && !p_189540_2_.func_180495_p(p_189540_3_.func_177974_f()).func_185896_q()) {
            flag = true;
         } else if (railshape == RailShape.ASCENDING_WEST && !p_189540_2_.func_180495_p(p_189540_3_.func_177976_e()).func_185896_q()) {
            flag = true;
         } else if (railshape == RailShape.ASCENDING_NORTH && !p_189540_2_.func_180495_p(p_189540_3_.func_177978_c()).func_185896_q()) {
            flag = true;
         } else if (railshape == RailShape.ASCENDING_SOUTH && !p_189540_2_.func_180495_p(p_189540_3_.func_177968_d()).func_185896_q()) {
            flag = true;
         }

         if (flag && !p_189540_2_.func_175623_d(p_189540_3_)) {
            p_189540_1_.func_196941_a(p_189540_2_, p_189540_3_, 1.0F, 0);
            p_189540_2_.func_175698_g(p_189540_3_);
         } else {
            this.func_189541_b(p_189540_1_, p_189540_2_, p_189540_3_, p_189540_4_);
         }

      }
   }

   protected void func_189541_b(IBlockState p_189541_1_, World p_189541_2_, BlockPos p_189541_3_, Block p_189541_4_) {
   }

   protected IBlockState func_208489_a(World p_208489_1_, BlockPos p_208489_2_, IBlockState p_208489_3_, boolean p_208489_4_) {
      return p_208489_1_.field_72995_K ? p_208489_3_ : (new BlockRailState(p_208489_1_, p_208489_2_, p_208489_3_)).func_208511_a(p_208489_1_.func_175640_z(p_208489_2_), p_208489_4_).func_196916_c();
   }

   public EnumPushReaction func_149656_h(IBlockState p_149656_1_) {
      return EnumPushReaction.NORMAL;
   }

   public BlockRenderLayer func_180664_k() {
      return BlockRenderLayer.CUTOUT;
   }

   public void func_196243_a(IBlockState p_196243_1_, World p_196243_2_, BlockPos p_196243_3_, IBlockState p_196243_4_, boolean p_196243_5_) {
      if (!p_196243_5_) {
         super.func_196243_a(p_196243_1_, p_196243_2_, p_196243_3_, p_196243_4_, p_196243_5_);
         if (p_196243_1_.func_177229_b(this.func_176560_l()).func_208092_c()) {
            p_196243_2_.func_195593_d(p_196243_3_.func_177984_a(), this);
         }

         if (this.field_196277_c) {
            p_196243_2_.func_195593_d(p_196243_3_, this);
            p_196243_2_.func_195593_d(p_196243_3_.func_177977_b(), this);
         }

      }
   }

   public abstract IProperty<RailShape> func_176560_l();
}
