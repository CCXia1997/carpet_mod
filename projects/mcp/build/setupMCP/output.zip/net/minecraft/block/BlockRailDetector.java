package net.minecraft.block;

import java.util.List;
import java.util.Random;
import java.util.function.Predicate;
import javax.annotation.Nullable;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityMinecart;
import net.minecraft.entity.item.EntityMinecartCommandBlock;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.IInventory;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.EnumProperty;
import net.minecraft.state.IProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.state.properties.RailShape;
import net.minecraft.util.EntitySelectors;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorldReaderBase;
import net.minecraft.world.World;

public class BlockRailDetector extends BlockRailBase {
   public static final EnumProperty<RailShape> field_176573_b = BlockStateProperties.field_208166_S;
   public static final BooleanProperty field_176574_M = BlockStateProperties.field_208194_u;

   public BlockRailDetector(Block.Properties p_i48417_1_) {
      super(true, p_i48417_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_176574_M, Boolean.valueOf(false)).func_206870_a(field_176573_b, RailShape.NORTH_SOUTH));
   }

   public int func_149738_a(IWorldReaderBase p_149738_1_) {
      return 20;
   }

   public boolean func_149744_f(IBlockState p_149744_1_) {
      return true;
   }

   public void func_196262_a(IBlockState p_196262_1_, World p_196262_2_, BlockPos p_196262_3_, Entity p_196262_4_) {
      if (!p_196262_2_.field_72995_K) {
         if (!p_196262_1_.func_177229_b(field_176574_M)) {
            this.func_176570_e(p_196262_2_, p_196262_3_, p_196262_1_);
         }
      }
   }

   public void func_196267_b(IBlockState p_196267_1_, World p_196267_2_, BlockPos p_196267_3_, Random p_196267_4_) {
      if (!p_196267_2_.field_72995_K && p_196267_1_.func_177229_b(field_176574_M)) {
         this.func_176570_e(p_196267_2_, p_196267_3_, p_196267_1_);
      }
   }

   public int func_180656_a(IBlockState p_180656_1_, IBlockReader p_180656_2_, BlockPos p_180656_3_, EnumFacing p_180656_4_) {
      return p_180656_1_.func_177229_b(field_176574_M) ? 15 : 0;
   }

   public int func_176211_b(IBlockState p_176211_1_, IBlockReader p_176211_2_, BlockPos p_176211_3_, EnumFacing p_176211_4_) {
      if (!p_176211_1_.func_177229_b(field_176574_M)) {
         return 0;
      } else {
         return p_176211_4_ == EnumFacing.UP ? 15 : 0;
      }
   }

   private void func_176570_e(World p_176570_1_, BlockPos p_176570_2_, IBlockState p_176570_3_) {
      boolean flag = p_176570_3_.func_177229_b(field_176574_M);
      boolean flag1 = false;
      List<EntityMinecart> list = this.func_200878_a(p_176570_1_, p_176570_2_, EntityMinecart.class, (Predicate<Entity>)null);
      if (!list.isEmpty()) {
         flag1 = true;
      }

      if (flag1 && !flag) {
         p_176570_1_.func_180501_a(p_176570_2_, p_176570_3_.func_206870_a(field_176574_M, Boolean.valueOf(true)), 3);
         this.func_185592_b(p_176570_1_, p_176570_2_, p_176570_3_, true);
         p_176570_1_.func_195593_d(p_176570_2_, this);
         p_176570_1_.func_195593_d(p_176570_2_.func_177977_b(), this);
         p_176570_1_.func_175704_b(p_176570_2_, p_176570_2_);
      }

      if (!flag1 && flag) {
         p_176570_1_.func_180501_a(p_176570_2_, p_176570_3_.func_206870_a(field_176574_M, Boolean.valueOf(false)), 3);
         this.func_185592_b(p_176570_1_, p_176570_2_, p_176570_3_, false);
         p_176570_1_.func_195593_d(p_176570_2_, this);
         p_176570_1_.func_195593_d(p_176570_2_.func_177977_b(), this);
         p_176570_1_.func_175704_b(p_176570_2_, p_176570_2_);
      }

      if (flag1) {
         p_176570_1_.func_205220_G_().func_205360_a(p_176570_2_, this, this.func_149738_a(p_176570_1_));
      }

      p_176570_1_.func_175666_e(p_176570_2_, this);
   }

   protected void func_185592_b(World p_185592_1_, BlockPos p_185592_2_, IBlockState p_185592_3_, boolean p_185592_4_) {
      BlockRailState blockrailstate = new BlockRailState(p_185592_1_, p_185592_2_, p_185592_3_);

      for(BlockPos blockpos : blockrailstate.func_196907_a()) {
         IBlockState iblockstate = p_185592_1_.func_180495_p(blockpos);
         iblockstate.func_189546_a(p_185592_1_, blockpos, iblockstate.func_177230_c(), p_185592_2_);
      }

   }

   public void func_196259_b(IBlockState p_196259_1_, World p_196259_2_, BlockPos p_196259_3_, IBlockState p_196259_4_) {
      if (p_196259_4_.func_177230_c() != p_196259_1_.func_177230_c()) {
         super.func_196259_b(p_196259_1_, p_196259_2_, p_196259_3_, p_196259_4_);
         this.func_176570_e(p_196259_2_, p_196259_3_, p_196259_1_);
      }
   }

   public IProperty<RailShape> func_176560_l() {
      return field_176573_b;
   }

   public boolean func_149740_M(IBlockState p_149740_1_) {
      return true;
   }

   public int func_180641_l(IBlockState p_180641_1_, World p_180641_2_, BlockPos p_180641_3_) {
      if (p_180641_1_.func_177229_b(field_176574_M)) {
         List<EntityMinecartCommandBlock> list = this.func_200878_a(p_180641_2_, p_180641_3_, EntityMinecartCommandBlock.class, (Predicate<Entity>)null);
         if (!list.isEmpty()) {
            return list.get(0).func_145822_e().func_145760_g();
         }

         List<EntityMinecart> list1 = this.func_200878_a(p_180641_2_, p_180641_3_, EntityMinecart.class, EntitySelectors.field_96566_b);
         if (!list1.isEmpty()) {
            return Container.func_94526_b((IInventory)list1.get(0));
         }
      }

      return 0;
   }

   protected <T extends EntityMinecart> List<T> func_200878_a(World p_200878_1_, BlockPos p_200878_2_, Class<T> p_200878_3_, @Nullable Predicate<Entity> p_200878_4_) {
      return p_200878_1_.func_175647_a(p_200878_3_, this.func_176572_a(p_200878_2_), p_200878_4_);
   }

   private AxisAlignedBB func_176572_a(BlockPos p_176572_1_) {
      float f = 0.2F;
      return new AxisAlignedBB((double)((float)p_176572_1_.func_177958_n() + 0.2F), (double)p_176572_1_.func_177956_o(), (double)((float)p_176572_1_.func_177952_p() + 0.2F), (double)((float)(p_176572_1_.func_177958_n() + 1) - 0.2F), (double)((float)(p_176572_1_.func_177956_o() + 1) - 0.2F), (double)((float)(p_176572_1_.func_177952_p() + 1) - 0.2F));
   }

   public IBlockState func_185499_a(IBlockState p_185499_1_, Rotation p_185499_2_) {
      switch(p_185499_2_) {
      case CLOCKWISE_180:
         switch((RailShape)p_185499_1_.func_177229_b(field_176573_b)) {
         case ASCENDING_EAST:
            return p_185499_1_.func_206870_a(field_176573_b, RailShape.ASCENDING_WEST);
         case ASCENDING_WEST:
            return p_185499_1_.func_206870_a(field_176573_b, RailShape.ASCENDING_EAST);
         case ASCENDING_NORTH:
            return p_185499_1_.func_206870_a(field_176573_b, RailShape.ASCENDING_SOUTH);
         case ASCENDING_SOUTH:
            return p_185499_1_.func_206870_a(field_176573_b, RailShape.ASCENDING_NORTH);
         case SOUTH_EAST:
            return p_185499_1_.func_206870_a(field_176573_b, RailShape.NORTH_WEST);
         case SOUTH_WEST:
            return p_185499_1_.func_206870_a(field_176573_b, RailShape.NORTH_EAST);
         case NORTH_WEST:
            return p_185499_1_.func_206870_a(field_176573_b, RailShape.SOUTH_EAST);
         case NORTH_EAST:
            return p_185499_1_.func_206870_a(field_176573_b, RailShape.SOUTH_WEST);
         }
      case COUNTERCLOCKWISE_90:
         switch((RailShape)p_185499_1_.func_177229_b(field_176573_b)) {
         case ASCENDING_EAST:
            return p_185499_1_.func_206870_a(field_176573_b, RailShape.ASCENDING_NORTH);
         case ASCENDING_WEST:
            return p_185499_1_.func_206870_a(field_176573_b, RailShape.ASCENDING_SOUTH);
         case ASCENDING_NORTH:
            return p_185499_1_.func_206870_a(field_176573_b, RailShape.ASCENDING_WEST);
         case ASCENDING_SOUTH:
            return p_185499_1_.func_206870_a(field_176573_b, RailShape.ASCENDING_EAST);
         case SOUTH_EAST:
            return p_185499_1_.func_206870_a(field_176573_b, RailShape.NORTH_EAST);
         case SOUTH_WEST:
            return p_185499_1_.func_206870_a(field_176573_b, RailShape.SOUTH_EAST);
         case NORTH_WEST:
            return p_185499_1_.func_206870_a(field_176573_b, RailShape.SOUTH_WEST);
         case NORTH_EAST:
            return p_185499_1_.func_206870_a(field_176573_b, RailShape.NORTH_WEST);
         case NORTH_SOUTH:
            return p_185499_1_.func_206870_a(field_176573_b, RailShape.EAST_WEST);
         case EAST_WEST:
            return p_185499_1_.func_206870_a(field_176573_b, RailShape.NORTH_SOUTH);
         }
      case CLOCKWISE_90:
         switch((RailShape)p_185499_1_.func_177229_b(field_176573_b)) {
         case ASCENDING_EAST:
            return p_185499_1_.func_206870_a(field_176573_b, RailShape.ASCENDING_SOUTH);
         case ASCENDING_WEST:
            return p_185499_1_.func_206870_a(field_176573_b, RailShape.ASCENDING_NORTH);
         case ASCENDING_NORTH:
            return p_185499_1_.func_206870_a(field_176573_b, RailShape.ASCENDING_EAST);
         case ASCENDING_SOUTH:
            return p_185499_1_.func_206870_a(field_176573_b, RailShape.ASCENDING_WEST);
         case SOUTH_EAST:
            return p_185499_1_.func_206870_a(field_176573_b, RailShape.SOUTH_WEST);
         case SOUTH_WEST:
            return p_185499_1_.func_206870_a(field_176573_b, RailShape.NORTH_WEST);
         case NORTH_WEST:
            return p_185499_1_.func_206870_a(field_176573_b, RailShape.NORTH_EAST);
         case NORTH_EAST:
            return p_185499_1_.func_206870_a(field_176573_b, RailShape.SOUTH_EAST);
         case NORTH_SOUTH:
            return p_185499_1_.func_206870_a(field_176573_b, RailShape.EAST_WEST);
         case EAST_WEST:
            return p_185499_1_.func_206870_a(field_176573_b, RailShape.NORTH_SOUTH);
         }
      default:
         return p_185499_1_;
      }
   }

   public IBlockState func_185471_a(IBlockState p_185471_1_, Mirror p_185471_2_) {
      RailShape railshape = p_185471_1_.func_177229_b(field_176573_b);
      switch(p_185471_2_) {
      case LEFT_RIGHT:
         switch(railshape) {
         case ASCENDING_NORTH:
            return p_185471_1_.func_206870_a(field_176573_b, RailShape.ASCENDING_SOUTH);
         case ASCENDING_SOUTH:
            return p_185471_1_.func_206870_a(field_176573_b, RailShape.ASCENDING_NORTH);
         case SOUTH_EAST:
            return p_185471_1_.func_206870_a(field_176573_b, RailShape.NORTH_EAST);
         case SOUTH_WEST:
            return p_185471_1_.func_206870_a(field_176573_b, RailShape.NORTH_WEST);
         case NORTH_WEST:
            return p_185471_1_.func_206870_a(field_176573_b, RailShape.SOUTH_WEST);
         case NORTH_EAST:
            return p_185471_1_.func_206870_a(field_176573_b, RailShape.SOUTH_EAST);
         default:
            return super.func_185471_a(p_185471_1_, p_185471_2_);
         }
      case FRONT_BACK:
         switch(railshape) {
         case ASCENDING_EAST:
            return p_185471_1_.func_206870_a(field_176573_b, RailShape.ASCENDING_WEST);
         case ASCENDING_WEST:
            return p_185471_1_.func_206870_a(field_176573_b, RailShape.ASCENDING_EAST);
         case ASCENDING_NORTH:
         case ASCENDING_SOUTH:
         default:
            break;
         case SOUTH_EAST:
            return p_185471_1_.func_206870_a(field_176573_b, RailShape.SOUTH_WEST);
         case SOUTH_WEST:
            return p_185471_1_.func_206870_a(field_176573_b, RailShape.SOUTH_EAST);
         case NORTH_WEST:
            return p_185471_1_.func_206870_a(field_176573_b, RailShape.NORTH_EAST);
         case NORTH_EAST:
            return p_185471_1_.func_206870_a(field_176573_b, RailShape.NORTH_WEST);
         }
      }

      return super.func_185471_a(p_185471_1_, p_185471_2_);
   }

   protected void func_206840_a(StateContainer.Builder<Block, IBlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_176573_b, field_176574_M);
   }
}
