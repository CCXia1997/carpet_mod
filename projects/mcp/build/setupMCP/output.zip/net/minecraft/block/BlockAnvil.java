package net.minecraft.block;

import javax.annotation.Nullable;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.item.EntityFallingBlock;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.ContainerRepair;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.pathfinding.PathType;
import net.minecraft.state.DirectionProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.shapes.VoxelShapes;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IInteractionObject;
import net.minecraft.world.World;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class BlockAnvil extends BlockFalling {
   private static final Logger field_185762_e = LogManager.getLogger();
   public static final DirectionProperty field_176506_a = BlockHorizontal.field_185512_D;
   private static final VoxelShape field_196436_c = Block.func_208617_a(2.0D, 0.0D, 2.0D, 14.0D, 4.0D, 14.0D);
   private static final VoxelShape field_196439_y = Block.func_208617_a(3.0D, 4.0D, 4.0D, 13.0D, 5.0D, 12.0D);
   private static final VoxelShape field_196440_z = Block.func_208617_a(4.0D, 5.0D, 6.0D, 12.0D, 10.0D, 10.0D);
   private static final VoxelShape field_196434_A = Block.func_208617_a(0.0D, 10.0D, 3.0D, 16.0D, 16.0D, 13.0D);
   private static final VoxelShape field_196435_B = Block.func_208617_a(4.0D, 4.0D, 3.0D, 12.0D, 5.0D, 13.0D);
   private static final VoxelShape field_196437_C = Block.func_208617_a(6.0D, 5.0D, 4.0D, 10.0D, 10.0D, 12.0D);
   private static final VoxelShape field_196438_D = Block.func_208617_a(3.0D, 10.0D, 0.0D, 13.0D, 16.0D, 16.0D);
   private static final VoxelShape field_185760_c = VoxelShapes.func_197872_a(field_196436_c, VoxelShapes.func_197872_a(field_196439_y, VoxelShapes.func_197872_a(field_196440_z, field_196434_A)));
   private static final VoxelShape field_185761_d = VoxelShapes.func_197872_a(field_196436_c, VoxelShapes.func_197872_a(field_196435_B, VoxelShapes.func_197872_a(field_196437_C, field_196438_D)));

   public BlockAnvil(Block.Properties p_i48450_1_) {
      super(p_i48450_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_176506_a, EnumFacing.NORTH));
   }

   public boolean func_149686_d(IBlockState p_149686_1_) {
      return false;
   }

   public BlockFaceShape func_193383_a(IBlockReader p_193383_1_, IBlockState p_193383_2_, BlockPos p_193383_3_, EnumFacing p_193383_4_) {
      return BlockFaceShape.UNDEFINED;
   }

   public IBlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      return this.func_176223_P().func_206870_a(field_176506_a, p_196258_1_.func_195992_f().func_176746_e());
   }

   public boolean func_196250_a(IBlockState p_196250_1_, World p_196250_2_, BlockPos p_196250_3_, EntityPlayer p_196250_4_, EnumHand p_196250_5_, EnumFacing p_196250_6_, float p_196250_7_, float p_196250_8_, float p_196250_9_) {
      if (!p_196250_2_.field_72995_K) {
         p_196250_4_.func_180468_a(new BlockAnvil.Anvil(p_196250_2_, p_196250_3_));
      }

      return true;
   }

   public VoxelShape func_196244_b(IBlockState p_196244_1_, IBlockReader p_196244_2_, BlockPos p_196244_3_) {
      EnumFacing enumfacing = p_196244_1_.func_177229_b(field_176506_a);
      return enumfacing.func_176740_k() == EnumFacing.Axis.X ? field_185760_c : field_185761_d;
   }

   protected void func_149829_a(EntityFallingBlock p_149829_1_) {
      p_149829_1_.func_145806_a(true);
   }

   public void func_176502_a_(World p_176502_1_, BlockPos p_176502_2_, IBlockState p_176502_3_, IBlockState p_176502_4_) {
      p_176502_1_.func_175718_b(1031, p_176502_2_, 0);
   }

   public void func_190974_b(World p_190974_1_, BlockPos p_190974_2_) {
      p_190974_1_.func_175718_b(1029, p_190974_2_, 0);
   }

   @Nullable
   public static IBlockState func_196433_f(IBlockState p_196433_0_) {
      Block block = p_196433_0_.func_177230_c();
      if (block == Blocks.field_150467_bQ) {
         return Blocks.field_196717_eY.func_176223_P().func_206870_a(field_176506_a, p_196433_0_.func_177229_b(field_176506_a));
      } else {
         return block == Blocks.field_196717_eY ? Blocks.field_196718_eZ.func_176223_P().func_206870_a(field_176506_a, p_196433_0_.func_177229_b(field_176506_a)) : null;
      }
   }

   public IBlockState func_185499_a(IBlockState p_185499_1_, Rotation p_185499_2_) {
      return p_185499_1_.func_206870_a(field_176506_a, p_185499_2_.func_185831_a(p_185499_1_.func_177229_b(field_176506_a)));
   }

   protected void func_206840_a(StateContainer.Builder<Block, IBlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_176506_a);
   }

   public boolean func_196266_a(IBlockState p_196266_1_, IBlockReader p_196266_2_, BlockPos p_196266_3_, PathType p_196266_4_) {
      return false;
   }

   public static class Anvil implements IInteractionObject {
      private final World field_175130_a;
      private final BlockPos field_175129_b;

      public Anvil(World p_i45741_1_, BlockPos p_i45741_2_) {
         this.field_175130_a = p_i45741_1_;
         this.field_175129_b = p_i45741_2_;
      }

      public ITextComponent func_200200_C_() {
         return new TextComponentTranslation(Blocks.field_150467_bQ.func_149739_a());
      }

      public boolean func_145818_k_() {
         return false;
      }

      @Nullable
      public ITextComponent func_200201_e() {
         return null;
      }

      public Container func_174876_a(InventoryPlayer p_174876_1_, EntityPlayer p_174876_2_) {
         return new ContainerRepair(p_174876_1_, this.field_175130_a, this.field_175129_b, p_174876_2_);
      }

      public String func_174875_k() {
         return "minecraft:anvil";
      }
   }
}
