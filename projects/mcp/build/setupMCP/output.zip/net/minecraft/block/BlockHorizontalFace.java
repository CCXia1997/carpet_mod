package net.minecraft.block;

import javax.annotation.Nullable;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.state.EnumProperty;
import net.minecraft.state.properties.AttachFace;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IWorld;
import net.minecraft.world.IWorldReaderBase;

public class BlockHorizontalFace extends BlockHorizontal {
   public static final EnumProperty<AttachFace> field_196366_M = BlockStateProperties.field_208158_K;

   protected BlockHorizontalFace(Block.Properties p_i48402_1_) {
      super(p_i48402_1_);
   }

   public boolean func_196260_a(IBlockState p_196260_1_, IWorldReaderBase p_196260_2_, BlockPos p_196260_3_) {
      EnumFacing enumfacing = func_196365_i(p_196260_1_).func_176734_d();
      BlockPos blockpos = p_196260_3_.func_177972_a(enumfacing);
      IBlockState iblockstate = p_196260_2_.func_180495_p(blockpos);
      Block block = iblockstate.func_177230_c();
      if (func_193384_b(block)) {
         return false;
      } else {
         boolean flag = iblockstate.func_193401_d(p_196260_2_, blockpos, enumfacing.func_176734_d()) == BlockFaceShape.SOLID;
         if (enumfacing == EnumFacing.UP) {
            return block == Blocks.field_150438_bZ || flag;
         } else {
            return !func_193382_c(block) && flag;
         }
      }
   }

   @Nullable
   public IBlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      for(EnumFacing enumfacing : p_196258_1_.func_196009_e()) {
         IBlockState iblockstate;
         if (enumfacing.func_176740_k() == EnumFacing.Axis.Y) {
            iblockstate = this.func_176223_P().func_206870_a(field_196366_M, enumfacing == EnumFacing.UP ? AttachFace.CEILING : AttachFace.FLOOR).func_206870_a(field_185512_D, p_196258_1_.func_195992_f());
         } else {
            iblockstate = this.func_176223_P().func_206870_a(field_196366_M, AttachFace.WALL).func_206870_a(field_185512_D, enumfacing.func_176734_d());
         }

         if (iblockstate.func_196955_c(p_196258_1_.func_195991_k(), p_196258_1_.func_195995_a())) {
            return iblockstate;
         }
      }

      return null;
   }

   public IBlockState func_196271_a(IBlockState p_196271_1_, EnumFacing p_196271_2_, IBlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      return func_196365_i(p_196271_1_).func_176734_d() == p_196271_2_ && !p_196271_1_.func_196955_c(p_196271_4_, p_196271_5_) ? Blocks.field_150350_a.func_176223_P() : super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
   }

   protected static EnumFacing func_196365_i(IBlockState p_196365_0_) {
      switch((AttachFace)p_196365_0_.func_177229_b(field_196366_M)) {
      case CEILING:
         return EnumFacing.DOWN;
      case FLOOR:
         return EnumFacing.UP;
      default:
         return p_196365_0_.func_177229_b(field_185512_D);
      }
   }
}
