package net.minecraft.block;

import net.minecraft.entity.Entity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class BlockHay extends BlockRotatedPillar {
   public BlockHay(Block.Properties p_i48380_1_) {
      super(p_i48380_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_176298_M, EnumFacing.Axis.Y));
   }

   public void func_180658_a(World p_180658_1_, BlockPos p_180658_2_, Entity p_180658_3_, float p_180658_4_) {
      p_180658_3_.func_180430_e(p_180658_4_, 0.2F);
   }
}
