package net.minecraft.block;

import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.IItemProvider;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.World;

public class BlockDeadBush extends BlockBush {
   protected static final VoxelShape field_196397_a = Block.func_208617_a(2.0D, 0.0D, 2.0D, 14.0D, 13.0D, 14.0D);

   protected BlockDeadBush(Block.Properties p_i48418_1_) {
      super(p_i48418_1_);
   }

   public VoxelShape func_196244_b(IBlockState p_196244_1_, IBlockReader p_196244_2_, BlockPos p_196244_3_) {
      return field_196397_a;
   }

   protected boolean func_200014_a_(IBlockState p_200014_1_, IBlockReader p_200014_2_, BlockPos p_200014_3_) {
      Block block = p_200014_1_.func_177230_c();
      return block == Blocks.field_150354_m || block == Blocks.field_196611_F || block == Blocks.field_150405_ch || block == Blocks.field_196777_fo || block == Blocks.field_196778_fp || block == Blocks.field_196780_fq || block == Blocks.field_196782_fr || block == Blocks.field_196783_fs || block == Blocks.field_196785_ft || block == Blocks.field_196787_fu || block == Blocks.field_196789_fv || block == Blocks.field_196791_fw || block == Blocks.field_196793_fx || block == Blocks.field_196795_fy || block == Blocks.field_196797_fz || block == Blocks.field_196719_fA || block == Blocks.field_196720_fB || block == Blocks.field_196721_fC || block == Blocks.field_196722_fD || block == Blocks.field_150346_d || block == Blocks.field_196660_k || block == Blocks.field_196661_l;
   }

   public int func_196264_a(IBlockState p_196264_1_, Random p_196264_2_) {
      return p_196264_2_.nextInt(3);
   }

   public IItemProvider func_199769_a(IBlockState p_199769_1_, World p_199769_2_, BlockPos p_199769_3_, int p_199769_4_) {
      return Items.field_151055_y;
   }

   public void func_180657_a(World p_180657_1_, EntityPlayer p_180657_2_, BlockPos p_180657_3_, IBlockState p_180657_4_, @Nullable TileEntity p_180657_5_, ItemStack p_180657_6_) {
      boolean flag = !p_180657_1_.field_72995_K && p_180657_6_.func_77973_b() == Items.field_151097_aZ;
      if (flag) {
         func_180635_a(p_180657_1_, p_180657_3_, new ItemStack(Blocks.field_196555_aI));
      }

      super.func_180657_a(p_180657_1_, p_180657_2_, p_180657_3_, flag ? Blocks.field_150350_a.func_176223_P() : p_180657_4_, p_180657_5_, p_180657_6_);
   }
}
