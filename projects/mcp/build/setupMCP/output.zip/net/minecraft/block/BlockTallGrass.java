package net.minecraft.block;

import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.stats.StatList;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.IItemProvider;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.World;

public class BlockTallGrass extends BlockBush implements IGrowable {
   protected static final VoxelShape field_196389_a = Block.func_208617_a(2.0D, 0.0D, 2.0D, 14.0D, 13.0D, 14.0D);

   protected BlockTallGrass(Block.Properties p_i48310_1_) {
      super(p_i48310_1_);
   }

   public VoxelShape func_196244_b(IBlockState p_196244_1_, IBlockReader p_196244_2_, BlockPos p_196244_3_) {
      return field_196389_a;
   }

   public IItemProvider func_199769_a(IBlockState p_199769_1_, World p_199769_2_, BlockPos p_199769_3_, int p_199769_4_) {
      return p_199769_2_.field_73012_v.nextInt(8) == 0 ? Items.field_151014_N : Items.field_190931_a;
   }

   public int func_196251_a(IBlockState p_196251_1_, int p_196251_2_, World p_196251_3_, BlockPos p_196251_4_, Random p_196251_5_) {
      return 1 + p_196251_5_.nextInt(p_196251_2_ * 2 + 1);
   }

   public void func_180657_a(World p_180657_1_, EntityPlayer p_180657_2_, BlockPos p_180657_3_, IBlockState p_180657_4_, @Nullable TileEntity p_180657_5_, ItemStack p_180657_6_) {
      if (!p_180657_1_.field_72995_K && p_180657_6_.func_77973_b() == Items.field_151097_aZ) {
         p_180657_2_.func_71029_a(StatList.field_188065_ae.func_199076_b(this));
         p_180657_2_.func_71020_j(0.005F);
         func_180635_a(p_180657_1_, p_180657_3_, new ItemStack(this));
      } else {
         super.func_180657_a(p_180657_1_, p_180657_2_, p_180657_3_, p_180657_4_, p_180657_5_, p_180657_6_);
      }

   }

   public boolean func_176473_a(IBlockReader p_176473_1_, BlockPos p_176473_2_, IBlockState p_176473_3_, boolean p_176473_4_) {
      return true;
   }

   public boolean func_180670_a(World p_180670_1_, Random p_180670_2_, BlockPos p_180670_3_, IBlockState p_180670_4_) {
      return true;
   }

   public void func_176474_b(World p_176474_1_, Random p_176474_2_, BlockPos p_176474_3_, IBlockState p_176474_4_) {
      BlockDoublePlant blockdoubleplant = (BlockDoublePlant)(this == Blocks.field_196554_aH ? Blocks.field_196805_gi : Blocks.field_196804_gh);
      if (blockdoubleplant.func_176223_P().func_196955_c(p_176474_1_, p_176474_3_) && p_176474_1_.func_175623_d(p_176474_3_.func_177984_a())) {
         blockdoubleplant.func_196390_a(p_176474_1_, p_176474_3_, 2);
      }

   }

   public Block.EnumOffsetType func_176218_Q() {
      return Block.EnumOffsetType.XYZ;
   }
}
