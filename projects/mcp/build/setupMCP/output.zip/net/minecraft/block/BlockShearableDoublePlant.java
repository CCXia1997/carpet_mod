package net.minecraft.block;

import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.item.ItemStack;
import net.minecraft.state.EnumProperty;
import net.minecraft.state.properties.DoubleBlockHalf;
import net.minecraft.util.IItemProvider;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class BlockShearableDoublePlant extends BlockDoublePlant {
   public static final EnumProperty<DoubleBlockHalf> field_208063_b = BlockDoublePlant.field_176492_b;
   private final Block field_196392_b;

   public BlockShearableDoublePlant(Block p_i48335_1_, Block.Properties p_i48335_2_) {
      super(p_i48335_2_);
      this.field_196392_b = p_i48335_1_;
   }

   public boolean func_196253_a(IBlockState p_196253_1_, BlockItemUseContext p_196253_2_) {
      boolean flag = super.func_196253_a(p_196253_1_, p_196253_2_);
      return flag && p_196253_2_.func_195996_i().func_77973_b() == this.func_199767_j() ? false : flag;
   }

   protected void func_196391_a(IBlockState p_196391_1_, World p_196391_2_, BlockPos p_196391_3_, ItemStack p_196391_4_) {
      if (p_196391_4_.func_77973_b() == Items.field_151097_aZ) {
         func_180635_a(p_196391_2_, p_196391_3_, new ItemStack(this.field_196392_b, 2));
      } else {
         super.func_196391_a(p_196391_1_, p_196391_2_, p_196391_3_, p_196391_4_);
      }

   }

   public IItemProvider func_199769_a(IBlockState p_199769_1_, World p_199769_2_, BlockPos p_199769_3_, int p_199769_4_) {
      return p_199769_1_.func_177229_b(field_208063_b) == DoubleBlockHalf.LOWER && this == Blocks.field_196804_gh && p_199769_2_.field_73012_v.nextInt(8) == 0 ? Items.field_151014_N : Items.field_190931_a;
   }
}
