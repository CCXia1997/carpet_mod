package net.minecraft.block;

import javax.annotation.Nullable;
import net.minecraft.block.material.EnumPushReaction;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.item.ItemStack;
import net.minecraft.pathfinding.PathType;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.DirectionProperty;
import net.minecraft.state.EnumProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.state.properties.DoorHingeSide;
import net.minecraft.state.properties.DoubleBlockHalf;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.IItemProvider;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.IWorldReaderBase;
import net.minecraft.world.World;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class BlockDoor extends Block {
   public static final DirectionProperty field_176520_a = BlockHorizontal.field_185512_D;
   public static final BooleanProperty field_176519_b = BlockStateProperties.field_208193_t;
   public static final EnumProperty<DoorHingeSide> field_176521_M = BlockStateProperties.field_208142_aq;
   public static final BooleanProperty field_176522_N = BlockStateProperties.field_208194_u;
   public static final EnumProperty<DoubleBlockHalf> field_176523_O = BlockStateProperties.field_208163_P;
   protected static final VoxelShape field_185658_f = Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 16.0D, 3.0D);
   protected static final VoxelShape field_185659_g = Block.func_208617_a(0.0D, 0.0D, 13.0D, 16.0D, 16.0D, 16.0D);
   protected static final VoxelShape field_185656_B = Block.func_208617_a(13.0D, 0.0D, 0.0D, 16.0D, 16.0D, 16.0D);
   protected static final VoxelShape field_185657_C = Block.func_208617_a(0.0D, 0.0D, 0.0D, 3.0D, 16.0D, 16.0D);

   protected BlockDoor(Block.Properties p_i48413_1_) {
      super(p_i48413_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_176520_a, EnumFacing.NORTH).func_206870_a(field_176519_b, Boolean.valueOf(false)).func_206870_a(field_176521_M, DoorHingeSide.LEFT).func_206870_a(field_176522_N, Boolean.valueOf(false)).func_206870_a(field_176523_O, DoubleBlockHalf.LOWER));
   }

   public VoxelShape func_196244_b(IBlockState p_196244_1_, IBlockReader p_196244_2_, BlockPos p_196244_3_) {
      EnumFacing enumfacing = p_196244_1_.func_177229_b(field_176520_a);
      boolean flag = !p_196244_1_.func_177229_b(field_176519_b);
      boolean flag1 = p_196244_1_.func_177229_b(field_176521_M) == DoorHingeSide.RIGHT;
      switch(enumfacing) {
      case EAST:
      default:
         return flag ? field_185657_C : (flag1 ? field_185659_g : field_185658_f);
      case SOUTH:
         return flag ? field_185658_f : (flag1 ? field_185657_C : field_185656_B);
      case WEST:
         return flag ? field_185656_B : (flag1 ? field_185658_f : field_185659_g);
      case NORTH:
         return flag ? field_185659_g : (flag1 ? field_185656_B : field_185657_C);
      }
   }

   public IBlockState func_196271_a(IBlockState p_196271_1_, EnumFacing p_196271_2_, IBlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      DoubleBlockHalf doubleblockhalf = p_196271_1_.func_177229_b(field_176523_O);
      if (p_196271_2_.func_176740_k() == EnumFacing.Axis.Y && doubleblockhalf == DoubleBlockHalf.LOWER == (p_196271_2_ == EnumFacing.UP)) {
         return p_196271_3_.func_177230_c() == this && p_196271_3_.func_177229_b(field_176523_O) != doubleblockhalf ? p_196271_1_.func_206870_a(field_176520_a, p_196271_3_.func_177229_b(field_176520_a)).func_206870_a(field_176519_b, p_196271_3_.func_177229_b(field_176519_b)).func_206870_a(field_176521_M, p_196271_3_.func_177229_b(field_176521_M)).func_206870_a(field_176522_N, p_196271_3_.func_177229_b(field_176522_N)) : Blocks.field_150350_a.func_176223_P();
      } else {
         return doubleblockhalf == DoubleBlockHalf.LOWER && p_196271_2_ == EnumFacing.DOWN && !p_196271_1_.func_196955_c(p_196271_4_, p_196271_5_) ? Blocks.field_150350_a.func_176223_P() : super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
      }
   }

   public void func_180657_a(World p_180657_1_, EntityPlayer p_180657_2_, BlockPos p_180657_3_, IBlockState p_180657_4_, @Nullable TileEntity p_180657_5_, ItemStack p_180657_6_) {
      super.func_180657_a(p_180657_1_, p_180657_2_, p_180657_3_, Blocks.field_150350_a.func_176223_P(), p_180657_5_, p_180657_6_);
   }

   public void func_176208_a(World p_176208_1_, BlockPos p_176208_2_, IBlockState p_176208_3_, EntityPlayer p_176208_4_) {
      DoubleBlockHalf doubleblockhalf = p_176208_3_.func_177229_b(field_176523_O);
      boolean flag = doubleblockhalf == DoubleBlockHalf.LOWER;
      BlockPos blockpos = flag ? p_176208_2_.func_177984_a() : p_176208_2_.func_177977_b();
      IBlockState iblockstate = p_176208_1_.func_180495_p(blockpos);
      if (iblockstate.func_177230_c() == this && iblockstate.func_177229_b(field_176523_O) != doubleblockhalf) {
         p_176208_1_.func_180501_a(blockpos, Blocks.field_150350_a.func_176223_P(), 35);
         p_176208_1_.func_180498_a(p_176208_4_, 2001, blockpos, Block.func_196246_j(iblockstate));
         if (!p_176208_1_.field_72995_K && !p_176208_4_.func_184812_l_()) {
            if (flag) {
               p_176208_3_.func_196949_c(p_176208_1_, p_176208_2_, 0);
            } else {
               iblockstate.func_196949_c(p_176208_1_, blockpos, 0);
            }
         }
      }

      super.func_176208_a(p_176208_1_, p_176208_2_, p_176208_3_, p_176208_4_);
   }

   public boolean func_196266_a(IBlockState p_196266_1_, IBlockReader p_196266_2_, BlockPos p_196266_3_, PathType p_196266_4_) {
      switch(p_196266_4_) {
      case LAND:
         return p_196266_1_.func_177229_b(field_176519_b);
      case WATER:
         return false;
      case AIR:
         return p_196266_1_.func_177229_b(field_176519_b);
      default:
         return false;
      }
   }

   public boolean func_149686_d(IBlockState p_149686_1_) {
      return false;
   }

   private int func_185654_e() {
      return this.field_149764_J == Material.field_151573_f ? 1011 : 1012;
   }

   private int func_185655_g() {
      return this.field_149764_J == Material.field_151573_f ? 1005 : 1006;
   }

   @Nullable
   public IBlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      BlockPos blockpos = p_196258_1_.func_195995_a();
      if (blockpos.func_177956_o() < 255 && p_196258_1_.func_195991_k().func_180495_p(blockpos.func_177984_a()).func_196953_a(p_196258_1_)) {
         World world = p_196258_1_.func_195991_k();
         boolean flag = world.func_175640_z(blockpos) || world.func_175640_z(blockpos.func_177984_a());
         return this.func_176223_P().func_206870_a(field_176520_a, p_196258_1_.func_195992_f()).func_206870_a(field_176521_M, this.func_208073_b(p_196258_1_)).func_206870_a(field_176522_N, Boolean.valueOf(flag)).func_206870_a(field_176519_b, Boolean.valueOf(flag)).func_206870_a(field_176523_O, DoubleBlockHalf.LOWER);
      } else {
         return null;
      }
   }

   public void func_180633_a(World p_180633_1_, BlockPos p_180633_2_, IBlockState p_180633_3_, EntityLivingBase p_180633_4_, ItemStack p_180633_5_) {
      p_180633_1_.func_180501_a(p_180633_2_.func_177984_a(), p_180633_3_.func_206870_a(field_176523_O, DoubleBlockHalf.UPPER), 3);
   }

   private DoorHingeSide func_208073_b(BlockItemUseContext p_208073_1_) {
      IBlockReader iblockreader = p_208073_1_.func_195991_k();
      BlockPos blockpos = p_208073_1_.func_195995_a();
      EnumFacing enumfacing = p_208073_1_.func_195992_f();
      BlockPos blockpos1 = blockpos.func_177984_a();
      EnumFacing enumfacing1 = enumfacing.func_176735_f();
      IBlockState iblockstate = iblockreader.func_180495_p(blockpos.func_177972_a(enumfacing1));
      IBlockState iblockstate1 = iblockreader.func_180495_p(blockpos1.func_177972_a(enumfacing1));
      EnumFacing enumfacing2 = enumfacing.func_176746_e();
      IBlockState iblockstate2 = iblockreader.func_180495_p(blockpos.func_177972_a(enumfacing2));
      IBlockState iblockstate3 = iblockreader.func_180495_p(blockpos1.func_177972_a(enumfacing2));
      int i = (iblockstate.func_185898_k() ? -1 : 0) + (iblockstate1.func_185898_k() ? -1 : 0) + (iblockstate2.func_185898_k() ? 1 : 0) + (iblockstate3.func_185898_k() ? 1 : 0);
      boolean flag = iblockstate.func_177230_c() == this && iblockstate.func_177229_b(field_176523_O) == DoubleBlockHalf.LOWER;
      boolean flag1 = iblockstate2.func_177230_c() == this && iblockstate2.func_177229_b(field_176523_O) == DoubleBlockHalf.LOWER;
      if ((!flag || flag1) && i <= 0) {
         if ((!flag1 || flag) && i >= 0) {
            int j = enumfacing.func_82601_c();
            int k = enumfacing.func_82599_e();
            float f = p_208073_1_.func_195997_m();
            float f1 = p_208073_1_.func_195994_o();
            return (j >= 0 || !(f1 < 0.5F)) && (j <= 0 || !(f1 > 0.5F)) && (k >= 0 || !(f > 0.5F)) && (k <= 0 || !(f < 0.5F)) ? DoorHingeSide.LEFT : DoorHingeSide.RIGHT;
         } else {
            return DoorHingeSide.LEFT;
         }
      } else {
         return DoorHingeSide.RIGHT;
      }
   }

   public boolean func_196250_a(IBlockState p_196250_1_, World p_196250_2_, BlockPos p_196250_3_, EntityPlayer p_196250_4_, EnumHand p_196250_5_, EnumFacing p_196250_6_, float p_196250_7_, float p_196250_8_, float p_196250_9_) {
      if (this.field_149764_J == Material.field_151573_f) {
         return false;
      } else {
         p_196250_1_ = p_196250_1_.func_177231_a(field_176519_b);
         p_196250_2_.func_180501_a(p_196250_3_, p_196250_1_, 10);
         p_196250_2_.func_180498_a(p_196250_4_, p_196250_1_.func_177229_b(field_176519_b) ? this.func_185655_g() : this.func_185654_e(), p_196250_3_, 0);
         return true;
      }
   }

   public void func_176512_a(World p_176512_1_, BlockPos p_176512_2_, boolean p_176512_3_) {
      IBlockState iblockstate = p_176512_1_.func_180495_p(p_176512_2_);
      if (iblockstate.func_177230_c() == this && iblockstate.func_177229_b(field_176519_b) != p_176512_3_) {
         p_176512_1_.func_180501_a(p_176512_2_, iblockstate.func_206870_a(field_176519_b, Boolean.valueOf(p_176512_3_)), 10);
         this.func_196426_b(p_176512_1_, p_176512_2_, p_176512_3_);
      }
   }

   public void func_189540_a(IBlockState p_189540_1_, World p_189540_2_, BlockPos p_189540_3_, Block p_189540_4_, BlockPos p_189540_5_) {
      boolean flag = p_189540_2_.func_175640_z(p_189540_3_) || p_189540_2_.func_175640_z(p_189540_3_.func_177972_a(p_189540_1_.func_177229_b(field_176523_O) == DoubleBlockHalf.LOWER ? EnumFacing.UP : EnumFacing.DOWN));
      if (p_189540_4_ != this && flag != p_189540_1_.func_177229_b(field_176522_N)) {
         if (flag != p_189540_1_.func_177229_b(field_176519_b)) {
            this.func_196426_b(p_189540_2_, p_189540_3_, flag);
         }

         p_189540_2_.func_180501_a(p_189540_3_, p_189540_1_.func_206870_a(field_176522_N, Boolean.valueOf(flag)).func_206870_a(field_176519_b, Boolean.valueOf(flag)), 2);
      }

   }

   public boolean func_196260_a(IBlockState p_196260_1_, IWorldReaderBase p_196260_2_, BlockPos p_196260_3_) {
      IBlockState iblockstate = p_196260_2_.func_180495_p(p_196260_3_.func_177977_b());
      if (p_196260_1_.func_177229_b(field_176523_O) == DoubleBlockHalf.LOWER) {
         return iblockstate.func_185896_q();
      } else {
         return iblockstate.func_177230_c() == this;
      }
   }

   private void func_196426_b(World p_196426_1_, BlockPos p_196426_2_, boolean p_196426_3_) {
      p_196426_1_.func_180498_a((EntityPlayer)null, p_196426_3_ ? this.func_185655_g() : this.func_185654_e(), p_196426_2_, 0);
   }

   public IItemProvider func_199769_a(IBlockState p_199769_1_, World p_199769_2_, BlockPos p_199769_3_, int p_199769_4_) {
      return (IItemProvider)(p_199769_1_.func_177229_b(field_176523_O) == DoubleBlockHalf.UPPER ? Items.field_190931_a : super.func_199769_a(p_199769_1_, p_199769_2_, p_199769_3_, p_199769_4_));
   }

   public EnumPushReaction func_149656_h(IBlockState p_149656_1_) {
      return EnumPushReaction.DESTROY;
   }

   public BlockRenderLayer func_180664_k() {
      return BlockRenderLayer.CUTOUT;
   }

   public IBlockState func_185499_a(IBlockState p_185499_1_, Rotation p_185499_2_) {
      return p_185499_1_.func_206870_a(field_176520_a, p_185499_2_.func_185831_a(p_185499_1_.func_177229_b(field_176520_a)));
   }

   public IBlockState func_185471_a(IBlockState p_185471_1_, Mirror p_185471_2_) {
      return p_185471_2_ == Mirror.NONE ? p_185471_1_ : p_185471_1_.func_185907_a(p_185471_2_.func_185800_a(p_185471_1_.func_177229_b(field_176520_a))).func_177231_a(field_176521_M);
   }

   @OnlyIn(Dist.CLIENT)
   public long func_209900_a(IBlockState p_209900_1_, BlockPos p_209900_2_) {
      return MathHelper.func_180187_c(p_209900_2_.func_177958_n(), p_209900_2_.func_177979_c(p_209900_1_.func_177229_b(field_176523_O) == DoubleBlockHalf.LOWER ? 0 : 1).func_177956_o(), p_209900_2_.func_177952_p());
   }

   protected void func_206840_a(StateContainer.Builder<Block, IBlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_176523_O, field_176520_a, field_176519_b, field_176521_M, field_176522_N);
   }

   public BlockFaceShape func_193383_a(IBlockReader p_193383_1_, IBlockState p_193383_2_, BlockPos p_193383_3_, EnumFacing p_193383_4_) {
      return BlockFaceShape.UNDEFINED;
   }
}
