package net.minecraft.block;

import net.minecraft.block.state.IBlockState;
import net.minecraft.state.EnumProperty;
import net.minecraft.state.IProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.state.properties.RailShape;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class BlockRail extends BlockRailBase {
   public static final EnumProperty<RailShape> field_176565_b = BlockStateProperties.field_208165_R;

   protected BlockRail(Block.Properties p_i48346_1_) {
      super(false, p_i48346_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_176565_b, RailShape.NORTH_SOUTH));
   }

   protected void func_189541_b(IBlockState p_189541_1_, World p_189541_2_, BlockPos p_189541_3_, Block p_189541_4_) {
      if (p_189541_4_.func_176223_P().func_185897_m() && (new BlockRailState(p_189541_2_, p_189541_3_, p_189541_1_)).func_196910_b() == 3) {
         this.func_208489_a(p_189541_2_, p_189541_3_, p_189541_1_, false);
      }

   }

   public IProperty<RailShape> func_176560_l() {
      return field_176565_b;
   }

   public IBlockState func_185499_a(IBlockState p_185499_1_, Rotation p_185499_2_) {
      switch(p_185499_2_) {
      case CLOCKWISE_180:
         switch((RailShape)p_185499_1_.func_177229_b(field_176565_b)) {
         case ASCENDING_EAST:
            return p_185499_1_.func_206870_a(field_176565_b, RailShape.ASCENDING_WEST);
         case ASCENDING_WEST:
            return p_185499_1_.func_206870_a(field_176565_b, RailShape.ASCENDING_EAST);
         case ASCENDING_NORTH:
            return p_185499_1_.func_206870_a(field_176565_b, RailShape.ASCENDING_SOUTH);
         case ASCENDING_SOUTH:
            return p_185499_1_.func_206870_a(field_176565_b, RailShape.ASCENDING_NORTH);
         case SOUTH_EAST:
            return p_185499_1_.func_206870_a(field_176565_b, RailShape.NORTH_WEST);
         case SOUTH_WEST:
            return p_185499_1_.func_206870_a(field_176565_b, RailShape.NORTH_EAST);
         case NORTH_WEST:
            return p_185499_1_.func_206870_a(field_176565_b, RailShape.SOUTH_EAST);
         case NORTH_EAST:
            return p_185499_1_.func_206870_a(field_176565_b, RailShape.SOUTH_WEST);
         }
      case COUNTERCLOCKWISE_90:
         switch((RailShape)p_185499_1_.func_177229_b(field_176565_b)) {
         case ASCENDING_EAST:
            return p_185499_1_.func_206870_a(field_176565_b, RailShape.ASCENDING_NORTH);
         case ASCENDING_WEST:
            return p_185499_1_.func_206870_a(field_176565_b, RailShape.ASCENDING_SOUTH);
         case ASCENDING_NORTH:
            return p_185499_1_.func_206870_a(field_176565_b, RailShape.ASCENDING_WEST);
         case ASCENDING_SOUTH:
            return p_185499_1_.func_206870_a(field_176565_b, RailShape.ASCENDING_EAST);
         case SOUTH_EAST:
            return p_185499_1_.func_206870_a(field_176565_b, RailShape.NORTH_EAST);
         case SOUTH_WEST:
            return p_185499_1_.func_206870_a(field_176565_b, RailShape.SOUTH_EAST);
         case NORTH_WEST:
            return p_185499_1_.func_206870_a(field_176565_b, RailShape.SOUTH_WEST);
         case NORTH_EAST:
            return p_185499_1_.func_206870_a(field_176565_b, RailShape.NORTH_WEST);
         case NORTH_SOUTH:
            return p_185499_1_.func_206870_a(field_176565_b, RailShape.EAST_WEST);
         case EAST_WEST:
            return p_185499_1_.func_206870_a(field_176565_b, RailShape.NORTH_SOUTH);
         }
      case CLOCKWISE_90:
         switch((RailShape)p_185499_1_.func_177229_b(field_176565_b)) {
         case ASCENDING_EAST:
            return p_185499_1_.func_206870_a(field_176565_b, RailShape.ASCENDING_SOUTH);
         case ASCENDING_WEST:
            return p_185499_1_.func_206870_a(field_176565_b, RailShape.ASCENDING_NORTH);
         case ASCENDING_NORTH:
            return p_185499_1_.func_206870_a(field_176565_b, RailShape.ASCENDING_EAST);
         case ASCENDING_SOUTH:
            return p_185499_1_.func_206870_a(field_176565_b, RailShape.ASCENDING_WEST);
         case SOUTH_EAST:
            return p_185499_1_.func_206870_a(field_176565_b, RailShape.SOUTH_WEST);
         case SOUTH_WEST:
            return p_185499_1_.func_206870_a(field_176565_b, RailShape.NORTH_WEST);
         case NORTH_WEST:
            return p_185499_1_.func_206870_a(field_176565_b, RailShape.NORTH_EAST);
         case NORTH_EAST:
            return p_185499_1_.func_206870_a(field_176565_b, RailShape.SOUTH_EAST);
         case NORTH_SOUTH:
            return p_185499_1_.func_206870_a(field_176565_b, RailShape.EAST_WEST);
         case EAST_WEST:
            return p_185499_1_.func_206870_a(field_176565_b, RailShape.NORTH_SOUTH);
         }
      default:
         return p_185499_1_;
      }
   }

   public IBlockState func_185471_a(IBlockState p_185471_1_, Mirror p_185471_2_) {
      RailShape railshape = p_185471_1_.func_177229_b(field_176565_b);
      switch(p_185471_2_) {
      case LEFT_RIGHT:
         switch(railshape) {
         case ASCENDING_NORTH:
            return p_185471_1_.func_206870_a(field_176565_b, RailShape.ASCENDING_SOUTH);
         case ASCENDING_SOUTH:
            return p_185471_1_.func_206870_a(field_176565_b, RailShape.ASCENDING_NORTH);
         case SOUTH_EAST:
            return p_185471_1_.func_206870_a(field_176565_b, RailShape.NORTH_EAST);
         case SOUTH_WEST:
            return p_185471_1_.func_206870_a(field_176565_b, RailShape.NORTH_WEST);
         case NORTH_WEST:
            return p_185471_1_.func_206870_a(field_176565_b, RailShape.SOUTH_WEST);
         case NORTH_EAST:
            return p_185471_1_.func_206870_a(field_176565_b, RailShape.SOUTH_EAST);
         default:
            return super.func_185471_a(p_185471_1_, p_185471_2_);
         }
      case FRONT_BACK:
         switch(railshape) {
         case ASCENDING_EAST:
            return p_185471_1_.func_206870_a(field_176565_b, RailShape.ASCENDING_WEST);
         case ASCENDING_WEST:
            return p_185471_1_.func_206870_a(field_176565_b, RailShape.ASCENDING_EAST);
         case ASCENDING_NORTH:
         case ASCENDING_SOUTH:
         default:
            break;
         case SOUTH_EAST:
            return p_185471_1_.func_206870_a(field_176565_b, RailShape.SOUTH_WEST);
         case SOUTH_WEST:
            return p_185471_1_.func_206870_a(field_176565_b, RailShape.SOUTH_EAST);
         case NORTH_WEST:
            return p_185471_1_.func_206870_a(field_176565_b, RailShape.NORTH_EAST);
         case NORTH_EAST:
            return p_185471_1_.func_206870_a(field_176565_b, RailShape.NORTH_WEST);
         }
      }

      return super.func_185471_a(p_185471_1_, p_185471_2_);
   }

   protected void func_206840_a(StateContainer.Builder<Block, IBlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_176565_b);
   }
}
