package net.minecraft.block;

import net.minecraft.block.state.IBlockState;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.state.EnumProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.Rotation;

public class BlockRotatedPillar extends Block {
   public static final EnumProperty<EnumFacing.Axis> field_176298_M = BlockStateProperties.field_208148_A;

   public BlockRotatedPillar(Block.Properties p_i48339_1_) {
      super(p_i48339_1_);
      this.func_180632_j(this.func_176223_P().func_206870_a(field_176298_M, EnumFacing.Axis.Y));
   }

   public IBlockState func_185499_a(IBlockState p_185499_1_, Rotation p_185499_2_) {
      switch(p_185499_2_) {
      case COUNTERCLOCKWISE_90:
      case CLOCKWISE_90:
         switch((EnumFacing.Axis)p_185499_1_.func_177229_b(field_176298_M)) {
         case X:
            return p_185499_1_.func_206870_a(field_176298_M, EnumFacing.Axis.Z);
         case Z:
            return p_185499_1_.func_206870_a(field_176298_M, EnumFacing.Axis.X);
         default:
            return p_185499_1_;
         }
      default:
         return p_185499_1_;
      }
   }

   protected void func_206840_a(StateContainer.Builder<Block, IBlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_176298_M);
   }

   public IBlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      return this.func_176223_P().func_206870_a(field_176298_M, p_196258_1_.func_196000_l().func_176740_k());
   }
}
