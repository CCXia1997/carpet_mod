package net.minecraft.block;

import javax.annotation.Nullable;
import net.minecraft.advancements.CriteriaTriggers;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.BlockWorldState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.block.state.pattern.BlockMaterialMatcher;
import net.minecraft.block.state.pattern.BlockPattern;
import net.minecraft.block.state.pattern.BlockStateMatcher;
import net.minecraft.block.state.pattern.FactoryBlockPattern;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.boss.EntityWither;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.init.Particles;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntitySkull;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.EnumDifficulty;
import net.minecraft.world.World;

public class BlockSkullWither extends BlockSkull {
   private static BlockPattern field_196300_c;
   private static BlockPattern field_196301_y;

   protected BlockSkullWither(Block.Properties p_i48293_1_) {
      super(BlockSkull.Types.WITHER_SKELETON, p_i48293_1_);
   }

   public void func_180633_a(World p_180633_1_, BlockPos p_180633_2_, IBlockState p_180633_3_, @Nullable EntityLivingBase p_180633_4_, ItemStack p_180633_5_) {
      super.func_180633_a(p_180633_1_, p_180633_2_, p_180633_3_, p_180633_4_, p_180633_5_);
      TileEntity tileentity = p_180633_1_.func_175625_s(p_180633_2_);
      if (tileentity instanceof TileEntitySkull) {
         func_196298_a(p_180633_1_, p_180633_2_, (TileEntitySkull)tileentity);
      }

   }

   public static void func_196298_a(World p_196298_0_, BlockPos p_196298_1_, TileEntitySkull p_196298_2_) {
      Block block = p_196298_2_.func_195044_w().func_177230_c();
      boolean flag = block == Blocks.field_196705_eO || block == Blocks.field_196704_eN;
      if (flag && p_196298_1_.func_177956_o() >= 2 && p_196298_0_.func_175659_aa() != EnumDifficulty.PEACEFUL && !p_196298_0_.field_72995_K) {
         BlockPattern blockpattern = func_196296_d();
         BlockPattern.PatternHelper blockpattern$patternhelper = blockpattern.func_177681_a(p_196298_0_, p_196298_1_);
         if (blockpattern$patternhelper != null) {
            for(int i = 0; i < 3; ++i) {
               TileEntitySkull.func_195486_a(p_196298_0_, blockpattern$patternhelper.func_177670_a(i, 0, 0).func_177508_d());
            }

            for(int k = 0; k < blockpattern.func_177684_c(); ++k) {
               for(int j = 0; j < blockpattern.func_177685_b(); ++j) {
                  p_196298_0_.func_180501_a(blockpattern$patternhelper.func_177670_a(k, j, 0).func_177508_d(), Blocks.field_150350_a.func_176223_P(), 2);
               }
            }

            BlockPos blockpos1 = blockpattern$patternhelper.func_177670_a(1, 0, 0).func_177508_d();
            EntityWither entitywither = new EntityWither(p_196298_0_);
            BlockPos blockpos = blockpattern$patternhelper.func_177670_a(1, 2, 0).func_177508_d();
            entitywither.func_70012_b((double)blockpos.func_177958_n() + 0.5D, (double)blockpos.func_177956_o() + 0.55D, (double)blockpos.func_177952_p() + 0.5D, blockpattern$patternhelper.func_177669_b().func_176740_k() == EnumFacing.Axis.X ? 0.0F : 90.0F, 0.0F);
            entitywither.field_70761_aq = blockpattern$patternhelper.func_177669_b().func_176740_k() == EnumFacing.Axis.X ? 0.0F : 90.0F;
            entitywither.func_82206_m();

            for(EntityPlayerMP entityplayermp : p_196298_0_.func_72872_a(EntityPlayerMP.class, entitywither.func_174813_aQ().func_186662_g(50.0D))) {
               CriteriaTriggers.field_192133_m.func_192229_a(entityplayermp, entitywither);
            }

            p_196298_0_.func_72838_d(entitywither);

            for(int l = 0; l < 120; ++l) {
               p_196298_0_.func_195594_a(Particles.field_197593_D, (double)blockpos1.func_177958_n() + p_196298_0_.field_73012_v.nextDouble(), (double)(blockpos1.func_177956_o() - 2) + p_196298_0_.field_73012_v.nextDouble() * 3.9D, (double)blockpos1.func_177952_p() + p_196298_0_.field_73012_v.nextDouble(), 0.0D, 0.0D, 0.0D);
            }

            for(int i1 = 0; i1 < blockpattern.func_177684_c(); ++i1) {
               for(int j1 = 0; j1 < blockpattern.func_177685_b(); ++j1) {
                  p_196298_0_.func_195592_c(blockpattern$patternhelper.func_177670_a(i1, j1, 0).func_177508_d(), Blocks.field_150350_a);
               }
            }

         }
      }
   }

   public static boolean func_196299_b(World p_196299_0_, BlockPos p_196299_1_, ItemStack p_196299_2_) {
      if (p_196299_2_.func_77973_b() == Items.field_196183_dw && p_196299_1_.func_177956_o() >= 2 && p_196299_0_.func_175659_aa() != EnumDifficulty.PEACEFUL && !p_196299_0_.field_72995_K) {
         return func_196297_e().func_177681_a(p_196299_0_, p_196299_1_) != null;
      } else {
         return false;
      }
   }

   protected static BlockPattern func_196296_d() {
      if (field_196300_c == null) {
         field_196300_c = FactoryBlockPattern.func_177660_a().func_177659_a("^^^", "###", "~#~").func_177662_a('#', BlockWorldState.func_177510_a(BlockStateMatcher.func_177638_a(Blocks.field_150425_aM))).func_177662_a('^', BlockWorldState.func_177510_a(BlockStateMatcher.func_177638_a(Blocks.field_196705_eO).or(BlockStateMatcher.func_177638_a(Blocks.field_196704_eN)))).func_177662_a('~', BlockWorldState.func_177510_a(BlockMaterialMatcher.func_189886_a(Material.field_151579_a))).func_177661_b();
      }

      return field_196300_c;
   }

   protected static BlockPattern func_196297_e() {
      if (field_196301_y == null) {
         field_196301_y = FactoryBlockPattern.func_177660_a().func_177659_a("   ", "###", "~#~").func_177662_a('#', BlockWorldState.func_177510_a(BlockStateMatcher.func_177638_a(Blocks.field_150425_aM))).func_177662_a('~', BlockWorldState.func_177510_a(BlockMaterialMatcher.func_189886_a(Material.field_151579_a))).func_177661_b();
      }

      return field_196301_y;
   }
}
