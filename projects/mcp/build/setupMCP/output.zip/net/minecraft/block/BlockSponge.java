package net.minecraft.block;

import com.google.common.collect.Lists;
import java.util.Queue;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.fluid.IFluidState;
import net.minecraft.init.Blocks;
import net.minecraft.init.Fluids;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.Tuple;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class BlockSponge extends Block {
   protected BlockSponge(Block.Properties p_i48325_1_) {
      super(p_i48325_1_);
   }

   public void func_196259_b(IBlockState p_196259_1_, World p_196259_2_, BlockPos p_196259_3_, IBlockState p_196259_4_) {
      if (p_196259_4_.func_177230_c() != p_196259_1_.func_177230_c()) {
         this.func_196510_a(p_196259_2_, p_196259_3_);
      }
   }

   public void func_189540_a(IBlockState p_189540_1_, World p_189540_2_, BlockPos p_189540_3_, Block p_189540_4_, BlockPos p_189540_5_) {
      this.func_196510_a(p_189540_2_, p_189540_3_);
      super.func_189540_a(p_189540_1_, p_189540_2_, p_189540_3_, p_189540_4_, p_189540_5_);
   }

   protected void func_196510_a(World p_196510_1_, BlockPos p_196510_2_) {
      if (this.func_176312_d(p_196510_1_, p_196510_2_)) {
         p_196510_1_.func_180501_a(p_196510_2_, Blocks.field_196577_ad.func_176223_P(), 2);
         p_196510_1_.func_175718_b(2001, p_196510_2_, Block.func_196246_j(Blocks.field_150355_j.func_176223_P()));
      }

   }

   private boolean func_176312_d(World p_176312_1_, BlockPos p_176312_2_) {
      Queue<Tuple<BlockPos, Integer>> queue = Lists.newLinkedList();
      queue.add(new Tuple<>(p_176312_2_, 0));
      int i = 0;

      while(!queue.isEmpty()) {
         Tuple<BlockPos, Integer> tuple = queue.poll();
         BlockPos blockpos = tuple.func_76341_a();
         int j = tuple.func_76340_b();

         for(EnumFacing enumfacing : EnumFacing.values()) {
            BlockPos blockpos1 = blockpos.func_177972_a(enumfacing);
            IBlockState iblockstate = p_176312_1_.func_180495_p(blockpos1);
            IFluidState ifluidstate = p_176312_1_.func_204610_c(blockpos1);
            Material material = iblockstate.func_185904_a();
            if (ifluidstate.func_206884_a(FluidTags.field_206959_a)) {
               if (iblockstate.func_177230_c() instanceof IBucketPickupHandler && ((IBucketPickupHandler)iblockstate.func_177230_c()).func_204508_a(p_176312_1_, blockpos1, iblockstate) != Fluids.field_204541_a) {
                  ++i;
                  if (j < 6) {
                     queue.add(new Tuple<>(blockpos1, j + 1));
                  }
               } else if (iblockstate.func_177230_c() instanceof BlockFlowingFluid) {
                  p_176312_1_.func_180501_a(blockpos1, Blocks.field_150350_a.func_176223_P(), 3);
                  ++i;
                  if (j < 6) {
                     queue.add(new Tuple<>(blockpos1, j + 1));
                  }
               } else if (material == Material.field_203243_f || material == Material.field_204868_h) {
                  iblockstate.func_196949_c(p_176312_1_, blockpos1, 0);
                  p_176312_1_.func_180501_a(blockpos1, Blocks.field_150350_a.func_176223_P(), 3);
                  ++i;
                  if (j < 6) {
                     queue.add(new Tuple<>(blockpos1, j + 1));
                  }
               }
            }
         }

         if (i > 64) {
            break;
         }
      }

      return i > 0;
   }
}
