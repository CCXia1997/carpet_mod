package net.minecraft.block;

import javax.annotation.Nullable;
import net.minecraft.block.material.EnumPushReaction;
import net.minecraft.block.material.MaterialColor;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Biomes;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.item.EnumDyeColor;
import net.minecraft.item.ItemStack;
import net.minecraft.pathfinding.PathType;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.EnumProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BedPart;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.stats.StatList;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityBed;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumBlockRenderType;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.IItemProvider;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.World;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class BlockBed extends BlockHorizontal implements ITileEntityProvider {
   public static final EnumProperty<BedPart> field_176472_a = BlockStateProperties.field_208139_an;
   public static final BooleanProperty field_176471_b = BlockStateProperties.field_208192_s;
   protected static final VoxelShape field_196351_c = Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 9.0D, 16.0D);
   private final EnumDyeColor field_196352_y;

   public BlockBed(EnumDyeColor p_i48442_1_, Block.Properties p_i48442_2_) {
      super(p_i48442_2_);
      this.field_196352_y = p_i48442_1_;
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_176472_a, BedPart.FOOT).func_206870_a(field_176471_b, Boolean.valueOf(false)));
   }

   public MaterialColor func_180659_g(IBlockState p_180659_1_, IBlockReader p_180659_2_, BlockPos p_180659_3_) {
      return p_180659_1_.func_177229_b(field_176472_a) == BedPart.FOOT ? this.field_196352_y.func_196055_e() : MaterialColor.field_151659_e;
   }

   public boolean func_196250_a(IBlockState p_196250_1_, World p_196250_2_, BlockPos p_196250_3_, EntityPlayer p_196250_4_, EnumHand p_196250_5_, EnumFacing p_196250_6_, float p_196250_7_, float p_196250_8_, float p_196250_9_) {
      if (p_196250_2_.field_72995_K) {
         return true;
      } else {
         if (p_196250_1_.func_177229_b(field_176472_a) != BedPart.HEAD) {
            p_196250_3_ = p_196250_3_.func_177972_a(p_196250_1_.func_177229_b(field_185512_D));
            p_196250_1_ = p_196250_2_.func_180495_p(p_196250_3_);
            if (p_196250_1_.func_177230_c() != this) {
               return true;
            }
         }

         if (p_196250_2_.field_73011_w.func_76567_e() && p_196250_2_.func_180494_b(p_196250_3_) != Biomes.field_76778_j) {
            if (p_196250_1_.func_177229_b(field_176471_b)) {
               EntityPlayer entityplayer = this.func_176470_e(p_196250_2_, p_196250_3_);
               if (entityplayer != null) {
                  p_196250_4_.func_146105_b(new TextComponentTranslation("block.minecraft.bed.occupied"), true);
                  return true;
               }

               p_196250_1_ = p_196250_1_.func_206870_a(field_176471_b, Boolean.valueOf(false));
               p_196250_2_.func_180501_a(p_196250_3_, p_196250_1_, 4);
            }

            EntityPlayer.SleepResult entityplayer$sleepresult = p_196250_4_.func_180469_a(p_196250_3_);
            if (entityplayer$sleepresult == EntityPlayer.SleepResult.OK) {
               p_196250_1_ = p_196250_1_.func_206870_a(field_176471_b, Boolean.valueOf(true));
               p_196250_2_.func_180501_a(p_196250_3_, p_196250_1_, 4);
               return true;
            } else {
               if (entityplayer$sleepresult == EntityPlayer.SleepResult.NOT_POSSIBLE_NOW) {
                  p_196250_4_.func_146105_b(new TextComponentTranslation("block.minecraft.bed.no_sleep"), true);
               } else if (entityplayer$sleepresult == EntityPlayer.SleepResult.NOT_SAFE) {
                  p_196250_4_.func_146105_b(new TextComponentTranslation("block.minecraft.bed.not_safe"), true);
               } else if (entityplayer$sleepresult == EntityPlayer.SleepResult.TOO_FAR_AWAY) {
                  p_196250_4_.func_146105_b(new TextComponentTranslation("block.minecraft.bed.too_far_away"), true);
               }

               return true;
            }
         } else {
            p_196250_2_.func_175698_g(p_196250_3_);
            BlockPos blockpos = p_196250_3_.func_177972_a(p_196250_1_.func_177229_b(field_185512_D).func_176734_d());
            if (p_196250_2_.func_180495_p(blockpos).func_177230_c() == this) {
               p_196250_2_.func_175698_g(blockpos);
            }

            p_196250_2_.func_211529_a((Entity)null, DamageSource.func_199683_a(), (double)p_196250_3_.func_177958_n() + 0.5D, (double)p_196250_3_.func_177956_o() + 0.5D, (double)p_196250_3_.func_177952_p() + 0.5D, 5.0F, true, true);
            return true;
         }
      }
   }

   @Nullable
   private EntityPlayer func_176470_e(World p_176470_1_, BlockPos p_176470_2_) {
      for(EntityPlayer entityplayer : p_176470_1_.field_73010_i) {
         if (entityplayer.func_70608_bn() && entityplayer.field_71081_bT.equals(p_176470_2_)) {
            return entityplayer;
         }
      }

      return null;
   }

   public boolean func_149686_d(IBlockState p_149686_1_) {
      return false;
   }

   public void func_180658_a(World p_180658_1_, BlockPos p_180658_2_, Entity p_180658_3_, float p_180658_4_) {
      super.func_180658_a(p_180658_1_, p_180658_2_, p_180658_3_, p_180658_4_ * 0.5F);
   }

   public void func_176216_a(IBlockReader p_176216_1_, Entity p_176216_2_) {
      if (p_176216_2_.func_70093_af()) {
         super.func_176216_a(p_176216_1_, p_176216_2_);
      } else if (p_176216_2_.field_70181_x < 0.0D) {
         p_176216_2_.field_70181_x = -p_176216_2_.field_70181_x * (double)0.66F;
         if (!(p_176216_2_ instanceof EntityLivingBase)) {
            p_176216_2_.field_70181_x *= 0.8D;
         }
      }

   }

   public IBlockState func_196271_a(IBlockState p_196271_1_, EnumFacing p_196271_2_, IBlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      if (p_196271_2_ == func_208070_a(p_196271_1_.func_177229_b(field_176472_a), p_196271_1_.func_177229_b(field_185512_D))) {
         return p_196271_3_.func_177230_c() == this && p_196271_3_.func_177229_b(field_176472_a) != p_196271_1_.func_177229_b(field_176472_a) ? p_196271_1_.func_206870_a(field_176471_b, p_196271_3_.func_177229_b(field_176471_b)) : Blocks.field_150350_a.func_176223_P();
      } else {
         return super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
      }
   }

   private static EnumFacing func_208070_a(BedPart p_208070_0_, EnumFacing p_208070_1_) {
      return p_208070_0_ == BedPart.FOOT ? p_208070_1_ : p_208070_1_.func_176734_d();
   }

   public void func_180657_a(World p_180657_1_, EntityPlayer p_180657_2_, BlockPos p_180657_3_, IBlockState p_180657_4_, @Nullable TileEntity p_180657_5_, ItemStack p_180657_6_) {
      super.func_180657_a(p_180657_1_, p_180657_2_, p_180657_3_, Blocks.field_150350_a.func_176223_P(), p_180657_5_, p_180657_6_);
   }

   public void func_196243_a(IBlockState p_196243_1_, World p_196243_2_, BlockPos p_196243_3_, IBlockState p_196243_4_, boolean p_196243_5_) {
      if (p_196243_1_.func_177230_c() != p_196243_4_.func_177230_c()) {
         super.func_196243_a(p_196243_1_, p_196243_2_, p_196243_3_, p_196243_4_, p_196243_5_);
         p_196243_2_.func_175713_t(p_196243_3_);
      }
   }

   public void func_176208_a(World p_176208_1_, BlockPos p_176208_2_, IBlockState p_176208_3_, EntityPlayer p_176208_4_) {
      BedPart bedpart = p_176208_3_.func_177229_b(field_176472_a);
      boolean flag = bedpart == BedPart.HEAD;
      BlockPos blockpos = p_176208_2_.func_177972_a(func_208070_a(bedpart, p_176208_3_.func_177229_b(field_185512_D)));
      IBlockState iblockstate = p_176208_1_.func_180495_p(blockpos);
      if (iblockstate.func_177230_c() == this && iblockstate.func_177229_b(field_176472_a) != bedpart) {
         p_176208_1_.func_180501_a(blockpos, Blocks.field_150350_a.func_176223_P(), 35);
         p_176208_1_.func_180498_a(p_176208_4_, 2001, blockpos, Block.func_196246_j(iblockstate));
         if (!p_176208_1_.field_72995_K && !p_176208_4_.func_184812_l_()) {
            if (flag) {
               p_176208_3_.func_196949_c(p_176208_1_, p_176208_2_, 0);
            } else {
               iblockstate.func_196949_c(p_176208_1_, blockpos, 0);
            }
         }

         p_176208_4_.func_71029_a(StatList.field_188065_ae.func_199076_b(this));
      }

      super.func_176208_a(p_176208_1_, p_176208_2_, p_176208_3_, p_176208_4_);
   }

   @Nullable
   public IBlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      EnumFacing enumfacing = p_196258_1_.func_195992_f();
      BlockPos blockpos = p_196258_1_.func_195995_a();
      BlockPos blockpos1 = blockpos.func_177972_a(enumfacing);
      return p_196258_1_.func_195991_k().func_180495_p(blockpos1).func_196953_a(p_196258_1_) ? this.func_176223_P().func_206870_a(field_185512_D, enumfacing) : null;
   }

   public IItemProvider func_199769_a(IBlockState p_199769_1_, World p_199769_2_, BlockPos p_199769_3_, int p_199769_4_) {
      return (IItemProvider)(p_199769_1_.func_177229_b(field_176472_a) == BedPart.FOOT ? Items.field_190931_a : super.func_199769_a(p_199769_1_, p_199769_2_, p_199769_3_, p_199769_4_));
   }

   public VoxelShape func_196244_b(IBlockState p_196244_1_, IBlockReader p_196244_2_, BlockPos p_196244_3_) {
      return field_196351_c;
   }

   @OnlyIn(Dist.CLIENT)
   public boolean func_190946_v(IBlockState p_190946_1_) {
      return true;
   }

   @Nullable
   public static BlockPos func_176468_a(IBlockReader p_176468_0_, BlockPos p_176468_1_, int p_176468_2_) {
      EnumFacing enumfacing = p_176468_0_.func_180495_p(p_176468_1_).func_177229_b(field_185512_D);
      int i = p_176468_1_.func_177958_n();
      int j = p_176468_1_.func_177956_o();
      int k = p_176468_1_.func_177952_p();

      for(int l = 0; l <= 1; ++l) {
         int i1 = i - enumfacing.func_82601_c() * l - 1;
         int j1 = k - enumfacing.func_82599_e() * l - 1;
         int k1 = i1 + 2;
         int l1 = j1 + 2;

         for(int i2 = i1; i2 <= k1; ++i2) {
            for(int j2 = j1; j2 <= l1; ++j2) {
               BlockPos blockpos = new BlockPos(i2, j, j2);
               if (func_176469_d(p_176468_0_, blockpos)) {
                  if (p_176468_2_ <= 0) {
                     return blockpos;
                  }

                  --p_176468_2_;
               }
            }
         }
      }

      return null;
   }

   protected static boolean func_176469_d(IBlockReader p_176469_0_, BlockPos p_176469_1_) {
      return p_176469_0_.func_180495_p(p_176469_1_.func_177977_b()).func_185896_q() && !p_176469_0_.func_180495_p(p_176469_1_).func_185904_a().func_76220_a() && !p_176469_0_.func_180495_p(p_176469_1_.func_177984_a()).func_185904_a().func_76220_a();
   }

   public EnumPushReaction func_149656_h(IBlockState p_149656_1_) {
      return EnumPushReaction.DESTROY;
   }

   public BlockRenderLayer func_180664_k() {
      return BlockRenderLayer.CUTOUT;
   }

   public EnumBlockRenderType func_149645_b(IBlockState p_149645_1_) {
      return EnumBlockRenderType.ENTITYBLOCK_ANIMATED;
   }

   public BlockFaceShape func_193383_a(IBlockReader p_193383_1_, IBlockState p_193383_2_, BlockPos p_193383_3_, EnumFacing p_193383_4_) {
      return BlockFaceShape.UNDEFINED;
   }

   protected void func_206840_a(StateContainer.Builder<Block, IBlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_185512_D, field_176472_a, field_176471_b);
   }

   public TileEntity func_196283_a_(IBlockReader p_196283_1_) {
      return new TileEntityBed(this.field_196352_y);
   }

   public void func_180633_a(World p_180633_1_, BlockPos p_180633_2_, IBlockState p_180633_3_, @Nullable EntityLivingBase p_180633_4_, ItemStack p_180633_5_) {
      super.func_180633_a(p_180633_1_, p_180633_2_, p_180633_3_, p_180633_4_, p_180633_5_);
      if (!p_180633_1_.field_72995_K) {
         BlockPos blockpos = p_180633_2_.func_177972_a(p_180633_3_.func_177229_b(field_185512_D));
         p_180633_1_.func_180501_a(blockpos, p_180633_3_.func_206870_a(field_176472_a, BedPart.HEAD), 3);
         p_180633_1_.func_195592_c(p_180633_2_, Blocks.field_150350_a);
         p_180633_3_.func_196946_a(p_180633_1_, p_180633_2_, 3);
      }

   }

   @OnlyIn(Dist.CLIENT)
   public EnumDyeColor func_196350_d() {
      return this.field_196352_y;
   }

   @OnlyIn(Dist.CLIENT)
   public long func_209900_a(IBlockState p_209900_1_, BlockPos p_209900_2_) {
      BlockPos blockpos = p_209900_2_.func_177967_a(p_209900_1_.func_177229_b(field_185512_D), p_209900_1_.func_177229_b(field_176472_a) == BedPart.HEAD ? 0 : 1);
      return MathHelper.func_180187_c(blockpos.func_177958_n(), p_209900_2_.func_177956_o(), blockpos.func_177952_p());
   }

   public boolean func_196266_a(IBlockState p_196266_1_, IBlockReader p_196266_2_, BlockPos p_196266_3_, PathType p_196266_4_) {
      return false;
   }
}
