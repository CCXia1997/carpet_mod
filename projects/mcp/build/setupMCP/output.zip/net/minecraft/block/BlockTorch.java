package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.init.Particles;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.IWorldReaderBase;
import net.minecraft.world.World;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class BlockTorch extends Block {
   protected static final VoxelShape field_196526_y = Block.func_208617_a(6.0D, 0.0D, 6.0D, 10.0D, 10.0D, 10.0D);

   protected BlockTorch(Block.Properties p_i48308_1_) {
      super(p_i48308_1_);
   }

   public VoxelShape func_196244_b(IBlockState p_196244_1_, IBlockReader p_196244_2_, BlockPos p_196244_3_) {
      return field_196526_y;
   }

   public boolean func_149686_d(IBlockState p_149686_1_) {
      return false;
   }

   public IBlockState func_196271_a(IBlockState p_196271_1_, EnumFacing p_196271_2_, IBlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      return p_196271_2_ == EnumFacing.DOWN && !this.func_196260_a(p_196271_1_, p_196271_4_, p_196271_5_) ? Blocks.field_150350_a.func_176223_P() : super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
   }

   public boolean func_196260_a(IBlockState p_196260_1_, IWorldReaderBase p_196260_2_, BlockPos p_196260_3_) {
      IBlockState iblockstate = p_196260_2_.func_180495_p(p_196260_3_.func_177977_b());
      Block block = iblockstate.func_177230_c();
      boolean flag = block instanceof BlockFence || block instanceof BlockStainedGlass || block == Blocks.field_150359_w || block == Blocks.field_150463_bK || block == Blocks.field_196723_eg || iblockstate.func_185896_q();
      return flag && block != Blocks.field_185775_db;
   }

   @OnlyIn(Dist.CLIENT)
   public void func_180655_c(IBlockState p_180655_1_, World p_180655_2_, BlockPos p_180655_3_, Random p_180655_4_) {
      double d0 = (double)p_180655_3_.func_177958_n() + 0.5D;
      double d1 = (double)p_180655_3_.func_177956_o() + 0.7D;
      double d2 = (double)p_180655_3_.func_177952_p() + 0.5D;
      p_180655_2_.func_195594_a(Particles.field_197601_L, d0, d1, d2, 0.0D, 0.0D, 0.0D);
      p_180655_2_.func_195594_a(Particles.field_197631_x, d0, d1, d2, 0.0D, 0.0D, 0.0D);
   }

   public BlockRenderLayer func_180664_k() {
      return BlockRenderLayer.CUTOUT;
   }

   public BlockFaceShape func_193383_a(IBlockReader p_193383_1_, IBlockState p_193383_2_, BlockPos p_193383_3_, EnumFacing p_193383_4_) {
      return BlockFaceShape.UNDEFINED;
   }
}
