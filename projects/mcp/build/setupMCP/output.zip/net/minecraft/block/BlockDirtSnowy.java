package net.minecraft.block;

import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.IItemProvider;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IWorld;
import net.minecraft.world.World;

public class BlockDirtSnowy extends Block {
   public static final BooleanProperty field_196382_a = BlockStateProperties.field_208196_w;

   protected BlockDirtSnowy(Block.Properties p_i48327_1_) {
      super(p_i48327_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_196382_a, Boolean.valueOf(false)));
   }

   public IBlockState func_196271_a(IBlockState p_196271_1_, EnumFacing p_196271_2_, IBlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      if (p_196271_2_ != EnumFacing.UP) {
         return super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
      } else {
         Block block = p_196271_3_.func_177230_c();
         return p_196271_1_.func_206870_a(field_196382_a, Boolean.valueOf(block == Blocks.field_196604_cC || block == Blocks.field_150433_aE));
      }
   }

   public IBlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      Block block = p_196258_1_.func_195991_k().func_180495_p(p_196258_1_.func_195995_a().func_177984_a()).func_177230_c();
      return this.func_176223_P().func_206870_a(field_196382_a, Boolean.valueOf(block == Blocks.field_196604_cC || block == Blocks.field_150433_aE));
   }

   protected void func_206840_a(StateContainer.Builder<Block, IBlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_196382_a);
   }

   public IItemProvider func_199769_a(IBlockState p_199769_1_, World p_199769_2_, BlockPos p_199769_3_, int p_199769_4_) {
      return Blocks.field_150346_d;
   }
}
