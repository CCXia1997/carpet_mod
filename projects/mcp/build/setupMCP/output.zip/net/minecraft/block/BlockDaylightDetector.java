package net.minecraft.block;

import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.IntegerProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityDaylightDetector;
import net.minecraft.util.EnumBlockRenderType;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.EnumLightType;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.World;

public class BlockDaylightDetector extends BlockContainer {
   public static final IntegerProperty field_176436_a = BlockStateProperties.field_208136_ak;
   public static final BooleanProperty field_196320_b = BlockStateProperties.field_208188_o;
   protected static final VoxelShape field_196321_c = Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 6.0D, 16.0D);

   public BlockDaylightDetector(Block.Properties p_i48419_1_) {
      super(p_i48419_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_176436_a, Integer.valueOf(0)).func_206870_a(field_196320_b, Boolean.valueOf(false)));
   }

   public VoxelShape func_196244_b(IBlockState p_196244_1_, IBlockReader p_196244_2_, BlockPos p_196244_3_) {
      return field_196321_c;
   }

   public int func_180656_a(IBlockState p_180656_1_, IBlockReader p_180656_2_, BlockPos p_180656_3_, EnumFacing p_180656_4_) {
      return p_180656_1_.func_177229_b(field_176436_a);
   }

   public static void func_196319_d(IBlockState p_196319_0_, World p_196319_1_, BlockPos p_196319_2_) {
      if (p_196319_1_.field_73011_w.func_191066_m()) {
         int i = p_196319_1_.func_175642_b(EnumLightType.SKY, p_196319_2_) - p_196319_1_.func_175657_ab();
         float f = p_196319_1_.func_72929_e(1.0F);
         boolean flag = p_196319_0_.func_177229_b(field_196320_b);
         if (flag) {
            i = 15 - i;
         } else if (i > 0) {
            float f1 = f < (float)Math.PI ? 0.0F : ((float)Math.PI * 2F);
            f = f + (f1 - f) * 0.2F;
            i = Math.round((float)i * MathHelper.func_76134_b(f));
         }

         i = MathHelper.func_76125_a(i, 0, 15);
         if (p_196319_0_.func_177229_b(field_176436_a) != i) {
            p_196319_1_.func_180501_a(p_196319_2_, p_196319_0_.func_206870_a(field_176436_a, Integer.valueOf(i)), 3);
         }

      }
   }

   public boolean func_196250_a(IBlockState p_196250_1_, World p_196250_2_, BlockPos p_196250_3_, EntityPlayer p_196250_4_, EnumHand p_196250_5_, EnumFacing p_196250_6_, float p_196250_7_, float p_196250_8_, float p_196250_9_) {
      if (p_196250_4_.func_175142_cm()) {
         if (p_196250_2_.field_72995_K) {
            return true;
         } else {
            IBlockState iblockstate = p_196250_1_.func_177231_a(field_196320_b);
            p_196250_2_.func_180501_a(p_196250_3_, iblockstate, 4);
            func_196319_d(iblockstate, p_196250_2_, p_196250_3_);
            return true;
         }
      } else {
         return super.func_196250_a(p_196250_1_, p_196250_2_, p_196250_3_, p_196250_4_, p_196250_5_, p_196250_6_, p_196250_7_, p_196250_8_, p_196250_9_);
      }
   }

   public boolean func_149686_d(IBlockState p_149686_1_) {
      return false;
   }

   public EnumBlockRenderType func_149645_b(IBlockState p_149645_1_) {
      return EnumBlockRenderType.MODEL;
   }

   public boolean func_149744_f(IBlockState p_149744_1_) {
      return true;
   }

   public TileEntity func_196283_a_(IBlockReader p_196283_1_) {
      return new TileEntityDaylightDetector();
   }

   protected void func_206840_a(StateContainer.Builder<Block, IBlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_176436_a, field_196320_b);
   }

   public BlockFaceShape func_193383_a(IBlockReader p_193383_1_, IBlockState p_193383_2_, BlockPos p_193383_3_, EnumFacing p_193383_4_) {
      return p_193383_4_ == EnumFacing.DOWN ? BlockFaceShape.SOLID : BlockFaceShape.UNDEFINED;
   }
}
