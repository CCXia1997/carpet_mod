package net.minecraft.block;

import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.state.IntegerProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.IItemProvider;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.IWorldReaderBase;
import net.minecraft.world.World;

public class BlockChorusFlower extends Block {
   public static final IntegerProperty field_185607_a = BlockStateProperties.field_208169_V;
   private final BlockChorusPlant field_196405_b;

   protected BlockChorusFlower(BlockChorusPlant p_i48429_1_, Block.Properties p_i48429_2_) {
      super(p_i48429_2_);
      this.field_196405_b = p_i48429_1_;
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_185607_a, Integer.valueOf(0)));
   }

   public IItemProvider func_199769_a(IBlockState p_199769_1_, World p_199769_2_, BlockPos p_199769_3_, int p_199769_4_) {
      return Items.field_190931_a;
   }

   public void func_196267_b(IBlockState p_196267_1_, World p_196267_2_, BlockPos p_196267_3_, Random p_196267_4_) {
      if (!p_196267_1_.func_196955_c(p_196267_2_, p_196267_3_)) {
         p_196267_2_.func_175655_b(p_196267_3_, true);
      } else {
         BlockPos blockpos = p_196267_3_.func_177984_a();
         if (p_196267_2_.func_175623_d(blockpos) && blockpos.func_177956_o() < 256) {
            int i = p_196267_1_.func_177229_b(field_185607_a);
            if (i < 5) {
               boolean flag = false;
               boolean flag1 = false;
               IBlockState iblockstate = p_196267_2_.func_180495_p(p_196267_3_.func_177977_b());
               Block block = iblockstate.func_177230_c();
               if (block == Blocks.field_150377_bs) {
                  flag = true;
               } else if (block == this.field_196405_b) {
                  int j = 1;

                  for(int k = 0; k < 4; ++k) {
                     Block block1 = p_196267_2_.func_180495_p(p_196267_3_.func_177979_c(j + 1)).func_177230_c();
                     if (block1 != this.field_196405_b) {
                        if (block1 == Blocks.field_150377_bs) {
                           flag1 = true;
                        }
                        break;
                     }

                     ++j;
                  }

                  if (j < 2 || j <= p_196267_4_.nextInt(flag1 ? 5 : 4)) {
                     flag = true;
                  }
               } else if (iblockstate.func_196958_f()) {
                  flag = true;
               }

               if (flag && func_185604_a(p_196267_2_, blockpos, (EnumFacing)null) && p_196267_2_.func_175623_d(p_196267_3_.func_177981_b(2))) {
                  p_196267_2_.func_180501_a(p_196267_3_, this.field_196405_b.func_196497_a(p_196267_2_, p_196267_3_), 2);
                  this.func_185602_a(p_196267_2_, blockpos, i);
               } else if (i < 4) {
                  int l = p_196267_4_.nextInt(4);
                  if (flag1) {
                     ++l;
                  }

                  boolean flag2 = false;

                  for(int i1 = 0; i1 < l; ++i1) {
                     EnumFacing enumfacing = EnumFacing.Plane.HORIZONTAL.func_179518_a(p_196267_4_);
                     BlockPos blockpos1 = p_196267_3_.func_177972_a(enumfacing);
                     if (p_196267_2_.func_175623_d(blockpos1) && p_196267_2_.func_175623_d(blockpos1.func_177977_b()) && func_185604_a(p_196267_2_, blockpos1, enumfacing.func_176734_d())) {
                        this.func_185602_a(p_196267_2_, blockpos1, i + 1);
                        flag2 = true;
                     }
                  }

                  if (flag2) {
                     p_196267_2_.func_180501_a(p_196267_3_, this.field_196405_b.func_196497_a(p_196267_2_, p_196267_3_), 2);
                  } else {
                     this.func_185605_c(p_196267_2_, p_196267_3_);
                  }
               } else {
                  this.func_185605_c(p_196267_2_, p_196267_3_);
               }

            }
         }
      }
   }

   private void func_185602_a(World p_185602_1_, BlockPos p_185602_2_, int p_185602_3_) {
      p_185602_1_.func_180501_a(p_185602_2_, this.func_176223_P().func_206870_a(field_185607_a, Integer.valueOf(p_185602_3_)), 2);
      p_185602_1_.func_175718_b(1033, p_185602_2_, 0);
   }

   private void func_185605_c(World p_185605_1_, BlockPos p_185605_2_) {
      p_185605_1_.func_180501_a(p_185605_2_, this.func_176223_P().func_206870_a(field_185607_a, Integer.valueOf(5)), 2);
      p_185605_1_.func_175718_b(1034, p_185605_2_, 0);
   }

   private static boolean func_185604_a(IWorldReaderBase p_185604_0_, BlockPos p_185604_1_, @Nullable EnumFacing p_185604_2_) {
      for(EnumFacing enumfacing : EnumFacing.Plane.HORIZONTAL) {
         if (enumfacing != p_185604_2_ && !p_185604_0_.func_175623_d(p_185604_1_.func_177972_a(enumfacing))) {
            return false;
         }
      }

      return true;
   }

   public boolean func_149686_d(IBlockState p_149686_1_) {
      return false;
   }

   public IBlockState func_196271_a(IBlockState p_196271_1_, EnumFacing p_196271_2_, IBlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      if (p_196271_2_ != EnumFacing.UP && !p_196271_1_.func_196955_c(p_196271_4_, p_196271_5_)) {
         p_196271_4_.func_205220_G_().func_205360_a(p_196271_5_, this, 1);
      }

      return super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
   }

   public boolean func_196260_a(IBlockState p_196260_1_, IWorldReaderBase p_196260_2_, BlockPos p_196260_3_) {
      IBlockState iblockstate = p_196260_2_.func_180495_p(p_196260_3_.func_177977_b());
      Block block = iblockstate.func_177230_c();
      if (block != this.field_196405_b && block != Blocks.field_150377_bs) {
         if (!iblockstate.func_196958_f()) {
            return false;
         } else {
            boolean flag = false;

            for(EnumFacing enumfacing : EnumFacing.Plane.HORIZONTAL) {
               IBlockState iblockstate1 = p_196260_2_.func_180495_p(p_196260_3_.func_177972_a(enumfacing));
               if (iblockstate1.func_177230_c() == this.field_196405_b) {
                  if (flag) {
                     return false;
                  }

                  flag = true;
               } else if (!iblockstate1.func_196958_f()) {
                  return false;
               }
            }

            return flag;
         }
      } else {
         return true;
      }
   }

   public void func_180657_a(World p_180657_1_, EntityPlayer p_180657_2_, BlockPos p_180657_3_, IBlockState p_180657_4_, @Nullable TileEntity p_180657_5_, ItemStack p_180657_6_) {
      super.func_180657_a(p_180657_1_, p_180657_2_, p_180657_3_, p_180657_4_, p_180657_5_, p_180657_6_);
      func_180635_a(p_180657_1_, p_180657_3_, new ItemStack(this));
   }

   protected ItemStack func_180643_i(IBlockState p_180643_1_) {
      return ItemStack.field_190927_a;
   }

   public BlockRenderLayer func_180664_k() {
      return BlockRenderLayer.CUTOUT;
   }

   protected void func_206840_a(StateContainer.Builder<Block, IBlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_185607_a);
   }

   public static void func_185603_a(IWorld p_185603_0_, BlockPos p_185603_1_, Random p_185603_2_, int p_185603_3_) {
      p_185603_0_.func_180501_a(p_185603_1_, ((BlockChorusPlant)Blocks.field_185765_cR).func_196497_a(p_185603_0_, p_185603_1_), 2);
      func_185601_a(p_185603_0_, p_185603_1_, p_185603_2_, p_185603_1_, p_185603_3_, 0);
   }

   private static void func_185601_a(IWorld p_185601_0_, BlockPos p_185601_1_, Random p_185601_2_, BlockPos p_185601_3_, int p_185601_4_, int p_185601_5_) {
      BlockChorusPlant blockchorusplant = (BlockChorusPlant)Blocks.field_185765_cR;
      int i = p_185601_2_.nextInt(4) + 1;
      if (p_185601_5_ == 0) {
         ++i;
      }

      for(int j = 0; j < i; ++j) {
         BlockPos blockpos = p_185601_1_.func_177981_b(j + 1);
         if (!func_185604_a(p_185601_0_, blockpos, (EnumFacing)null)) {
            return;
         }

         p_185601_0_.func_180501_a(blockpos, blockchorusplant.func_196497_a(p_185601_0_, blockpos), 2);
         p_185601_0_.func_180501_a(blockpos.func_177977_b(), blockchorusplant.func_196497_a(p_185601_0_, blockpos.func_177977_b()), 2);
      }

      boolean flag = false;
      if (p_185601_5_ < 4) {
         int l = p_185601_2_.nextInt(4);
         if (p_185601_5_ == 0) {
            ++l;
         }

         for(int k = 0; k < l; ++k) {
            EnumFacing enumfacing = EnumFacing.Plane.HORIZONTAL.func_179518_a(p_185601_2_);
            BlockPos blockpos1 = p_185601_1_.func_177981_b(i).func_177972_a(enumfacing);
            if (Math.abs(blockpos1.func_177958_n() - p_185601_3_.func_177958_n()) < p_185601_4_ && Math.abs(blockpos1.func_177952_p() - p_185601_3_.func_177952_p()) < p_185601_4_ && p_185601_0_.func_175623_d(blockpos1) && p_185601_0_.func_175623_d(blockpos1.func_177977_b()) && func_185604_a(p_185601_0_, blockpos1, enumfacing.func_176734_d())) {
               flag = true;
               p_185601_0_.func_180501_a(blockpos1, blockchorusplant.func_196497_a(p_185601_0_, blockpos1), 2);
               p_185601_0_.func_180501_a(blockpos1.func_177972_a(enumfacing.func_176734_d()), blockchorusplant.func_196497_a(p_185601_0_, blockpos1.func_177972_a(enumfacing.func_176734_d())), 2);
               func_185601_a(p_185601_0_, blockpos1, p_185601_2_, p_185601_3_, p_185601_4_, p_185601_5_ + 1);
            }
         }
      }

      if (!flag) {
         p_185601_0_.func_180501_a(p_185601_1_.func_177981_b(i), Blocks.field_185766_cS.func_176223_P().func_206870_a(field_185607_a, Integer.valueOf(5)), 2);
      }

   }

   public BlockFaceShape func_193383_a(IBlockReader p_193383_1_, IBlockState p_193383_2_, BlockPos p_193383_3_, EnumFacing p_193383_4_) {
      return BlockFaceShape.UNDEFINED;
   }
}
