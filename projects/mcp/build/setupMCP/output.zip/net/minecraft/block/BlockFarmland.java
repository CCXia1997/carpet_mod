package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.pathfinding.PathType;
import net.minecraft.state.IntegerProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.IItemProvider;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.IWorldReaderBase;
import net.minecraft.world.World;

public class BlockFarmland extends Block {
   public static final IntegerProperty field_176531_a = BlockStateProperties.field_208133_ah;
   protected static final VoxelShape field_196432_b = Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 15.0D, 16.0D);

   protected BlockFarmland(Block.Properties p_i48400_1_) {
      super(p_i48400_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_176531_a, Integer.valueOf(0)));
   }

   public IBlockState func_196271_a(IBlockState p_196271_1_, EnumFacing p_196271_2_, IBlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      if (p_196271_2_ == EnumFacing.UP && !p_196271_1_.func_196955_c(p_196271_4_, p_196271_5_)) {
         p_196271_4_.func_205220_G_().func_205360_a(p_196271_5_, this, 1);
      }

      return super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
   }

   public boolean func_196260_a(IBlockState p_196260_1_, IWorldReaderBase p_196260_2_, BlockPos p_196260_3_) {
      IBlockState iblockstate = p_196260_2_.func_180495_p(p_196260_3_.func_177984_a());
      return !iblockstate.func_185904_a().func_76220_a() || iblockstate.func_177230_c() instanceof BlockFenceGate;
   }

   public IBlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      return !this.func_176223_P().func_196955_c(p_196258_1_.func_195991_k(), p_196258_1_.func_195995_a()) ? Blocks.field_150346_d.func_176223_P() : super.func_196258_a(p_196258_1_);
   }

   public int func_200011_d(IBlockState p_200011_1_, IBlockReader p_200011_2_, BlockPos p_200011_3_) {
      return p_200011_2_.func_201572_C();
   }

   public VoxelShape func_196244_b(IBlockState p_196244_1_, IBlockReader p_196244_2_, BlockPos p_196244_3_) {
      return field_196432_b;
   }

   public boolean func_149686_d(IBlockState p_149686_1_) {
      return false;
   }

   public void func_196267_b(IBlockState p_196267_1_, World p_196267_2_, BlockPos p_196267_3_, Random p_196267_4_) {
      if (!p_196267_1_.func_196955_c(p_196267_2_, p_196267_3_)) {
         func_199610_d(p_196267_1_, p_196267_2_, p_196267_3_);
      } else {
         int i = p_196267_1_.func_177229_b(field_176531_a);
         if (!func_176530_e(p_196267_2_, p_196267_3_) && !p_196267_2_.func_175727_C(p_196267_3_.func_177984_a())) {
            if (i > 0) {
               p_196267_2_.func_180501_a(p_196267_3_, p_196267_1_.func_206870_a(field_176531_a, Integer.valueOf(i - 1)), 2);
            } else if (!func_176529_d(p_196267_2_, p_196267_3_)) {
               func_199610_d(p_196267_1_, p_196267_2_, p_196267_3_);
            }
         } else if (i < 7) {
            p_196267_2_.func_180501_a(p_196267_3_, p_196267_1_.func_206870_a(field_176531_a, Integer.valueOf(7)), 2);
         }

      }
   }

   public void func_180658_a(World p_180658_1_, BlockPos p_180658_2_, Entity p_180658_3_, float p_180658_4_) {
      if (!p_180658_1_.field_72995_K && p_180658_1_.field_73012_v.nextFloat() < p_180658_4_ - 0.5F && p_180658_3_ instanceof EntityLivingBase && (p_180658_3_ instanceof EntityPlayer || p_180658_1_.func_82736_K().func_82766_b("mobGriefing")) && p_180658_3_.field_70130_N * p_180658_3_.field_70130_N * p_180658_3_.field_70131_O > 0.512F) {
         func_199610_d(p_180658_1_.func_180495_p(p_180658_2_), p_180658_1_, p_180658_2_);
      }

      super.func_180658_a(p_180658_1_, p_180658_2_, p_180658_3_, p_180658_4_);
   }

   public static void func_199610_d(IBlockState p_199610_0_, World p_199610_1_, BlockPos p_199610_2_) {
      p_199610_1_.func_175656_a(p_199610_2_, func_199601_a(p_199610_0_, Blocks.field_150346_d.func_176223_P(), p_199610_1_, p_199610_2_));
   }

   private static boolean func_176529_d(IBlockReader p_176529_0_, BlockPos p_176529_1_) {
      Block block = p_176529_0_.func_180495_p(p_176529_1_.func_177984_a()).func_177230_c();
      return block instanceof BlockCrops || block instanceof BlockStem || block instanceof BlockAttachedStem;
   }

   private static boolean func_176530_e(IWorldReaderBase p_176530_0_, BlockPos p_176530_1_) {
      for(BlockPos.MutableBlockPos blockpos$mutableblockpos : BlockPos.func_177975_b(p_176530_1_.func_177982_a(-4, 0, -4), p_176530_1_.func_177982_a(4, 1, 4))) {
         if (p_176530_0_.func_204610_c(blockpos$mutableblockpos).func_206884_a(FluidTags.field_206959_a)) {
            return true;
         }
      }

      return false;
   }

   public IItemProvider func_199769_a(IBlockState p_199769_1_, World p_199769_2_, BlockPos p_199769_3_, int p_199769_4_) {
      return Blocks.field_150346_d;
   }

   protected void func_206840_a(StateContainer.Builder<Block, IBlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_176531_a);
   }

   public BlockFaceShape func_193383_a(IBlockReader p_193383_1_, IBlockState p_193383_2_, BlockPos p_193383_3_, EnumFacing p_193383_4_) {
      return p_193383_4_ == EnumFacing.DOWN ? BlockFaceShape.SOLID : BlockFaceShape.UNDEFINED;
   }

   public boolean func_196266_a(IBlockState p_196266_1_, IBlockReader p_196266_2_, BlockPos p_196266_3_, PathType p_196266_4_) {
      return false;
   }
}
