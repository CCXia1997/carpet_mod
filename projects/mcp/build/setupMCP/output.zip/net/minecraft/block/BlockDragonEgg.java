package net.minecraft.block;

import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Particles;
import net.minecraft.pathfinding.PathType;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorldReaderBase;
import net.minecraft.world.World;

public class BlockDragonEgg extends BlockFalling {
   protected static final VoxelShape field_196444_a = Block.func_208617_a(1.0D, 0.0D, 1.0D, 15.0D, 16.0D, 15.0D);

   public BlockDragonEgg(Block.Properties p_i48411_1_) {
      super(p_i48411_1_);
   }

   public VoxelShape func_196244_b(IBlockState p_196244_1_, IBlockReader p_196244_2_, BlockPos p_196244_3_) {
      return field_196444_a;
   }

   public boolean func_196250_a(IBlockState p_196250_1_, World p_196250_2_, BlockPos p_196250_3_, EntityPlayer p_196250_4_, EnumHand p_196250_5_, EnumFacing p_196250_6_, float p_196250_7_, float p_196250_8_, float p_196250_9_) {
      this.func_196443_d(p_196250_1_, p_196250_2_, p_196250_3_);
      return true;
   }

   public void func_196270_a(IBlockState p_196270_1_, World p_196270_2_, BlockPos p_196270_3_, EntityPlayer p_196270_4_) {
      this.func_196443_d(p_196270_1_, p_196270_2_, p_196270_3_);
   }

   private void func_196443_d(IBlockState p_196443_1_, World p_196443_2_, BlockPos p_196443_3_) {
      for(int i = 0; i < 1000; ++i) {
         BlockPos blockpos = p_196443_3_.func_177982_a(p_196443_2_.field_73012_v.nextInt(16) - p_196443_2_.field_73012_v.nextInt(16), p_196443_2_.field_73012_v.nextInt(8) - p_196443_2_.field_73012_v.nextInt(8), p_196443_2_.field_73012_v.nextInt(16) - p_196443_2_.field_73012_v.nextInt(16));
         if (p_196443_2_.func_180495_p(blockpos).func_196958_f()) {
            if (p_196443_2_.field_72995_K) {
               for(int j = 0; j < 128; ++j) {
                  double d0 = p_196443_2_.field_73012_v.nextDouble();
                  float f = (p_196443_2_.field_73012_v.nextFloat() - 0.5F) * 0.2F;
                  float f1 = (p_196443_2_.field_73012_v.nextFloat() - 0.5F) * 0.2F;
                  float f2 = (p_196443_2_.field_73012_v.nextFloat() - 0.5F) * 0.2F;
                  double d1 = (double)blockpos.func_177958_n() + (double)(p_196443_3_.func_177958_n() - blockpos.func_177958_n()) * d0 + (p_196443_2_.field_73012_v.nextDouble() - 0.5D) + 0.5D;
                  double d2 = (double)blockpos.func_177956_o() + (double)(p_196443_3_.func_177956_o() - blockpos.func_177956_o()) * d0 + p_196443_2_.field_73012_v.nextDouble() - 0.5D;
                  double d3 = (double)blockpos.func_177952_p() + (double)(p_196443_3_.func_177952_p() - blockpos.func_177952_p()) * d0 + (p_196443_2_.field_73012_v.nextDouble() - 0.5D) + 0.5D;
                  p_196443_2_.func_195594_a(Particles.field_197599_J, d1, d2, d3, (double)f, (double)f1, (double)f2);
               }
            } else {
               p_196443_2_.func_180501_a(blockpos, p_196443_1_, 2);
               p_196443_2_.func_175698_g(p_196443_3_);
            }

            return;
         }
      }

   }

   public int func_149738_a(IWorldReaderBase p_149738_1_) {
      return 5;
   }

   public boolean func_149686_d(IBlockState p_149686_1_) {
      return false;
   }

   public BlockFaceShape func_193383_a(IBlockReader p_193383_1_, IBlockState p_193383_2_, BlockPos p_193383_3_, EnumFacing p_193383_4_) {
      return BlockFaceShape.UNDEFINED;
   }

   public boolean func_196266_a(IBlockState p_196266_1_, IBlockReader p_196266_2_, BlockPos p_196266_3_, PathType p_196266_4_) {
      return false;
   }
}
