package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.state.IBlockState;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Particles;
import net.minecraft.init.SoundEvents;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.IWorldReader;
import net.minecraft.world.IWorldReaderBase;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class BlockMagma extends Block {
   public BlockMagma(Block.Properties p_i48366_1_) {
      super(p_i48366_1_);
   }

   public void func_176199_a(World p_176199_1_, BlockPos p_176199_2_, Entity p_176199_3_) {
      if (!p_176199_3_.func_70045_F() && p_176199_3_ instanceof EntityLivingBase && !EnchantmentHelper.func_189869_j((EntityLivingBase)p_176199_3_)) {
         p_176199_3_.func_70097_a(DamageSource.field_190095_e, 1.0F);
      }

      super.func_176199_a(p_176199_1_, p_176199_2_, p_176199_3_);
   }

   @OnlyIn(Dist.CLIENT)
   public int func_185484_c(IBlockState p_185484_1_, IWorldReader p_185484_2_, BlockPos p_185484_3_) {
      return 15728880;
   }

   public void func_196267_b(IBlockState p_196267_1_, World p_196267_2_, BlockPos p_196267_3_, Random p_196267_4_) {
      BlockBubbleColumn.func_203159_a(p_196267_2_, p_196267_3_.func_177984_a(), true);
   }

   public IBlockState func_196271_a(IBlockState p_196271_1_, EnumFacing p_196271_2_, IBlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      if (p_196271_2_ == EnumFacing.UP && p_196271_3_.func_177230_c() == Blocks.field_150355_j) {
         p_196271_4_.func_205220_G_().func_205360_a(p_196271_5_, this, this.func_149738_a(p_196271_4_));
      }

      return super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
   }

   public void func_196265_a(IBlockState p_196265_1_, World p_196265_2_, BlockPos p_196265_3_, Random p_196265_4_) {
      BlockPos blockpos = p_196265_3_.func_177984_a();
      if (p_196265_2_.func_204610_c(p_196265_3_).func_206884_a(FluidTags.field_206959_a)) {
         p_196265_2_.func_184133_a((EntityPlayer)null, p_196265_3_, SoundEvents.field_187646_bt, SoundCategory.BLOCKS, 0.5F, 2.6F + (p_196265_2_.field_73012_v.nextFloat() - p_196265_2_.field_73012_v.nextFloat()) * 0.8F);
         if (p_196265_2_ instanceof WorldServer) {
            ((WorldServer)p_196265_2_).func_195598_a(Particles.field_197594_E, (double)blockpos.func_177958_n() + 0.5D, (double)blockpos.func_177956_o() + 0.25D, (double)blockpos.func_177952_p() + 0.5D, 8, 0.5D, 0.25D, 0.5D, 0.0D);
         }
      }

   }

   public int func_149738_a(IWorldReaderBase p_149738_1_) {
      return 20;
   }

   public void func_196259_b(IBlockState p_196259_1_, World p_196259_2_, BlockPos p_196259_3_, IBlockState p_196259_4_) {
      p_196259_2_.func_205220_G_().func_205360_a(p_196259_3_, this, this.func_149738_a(p_196259_2_));
   }

   public boolean func_189872_a(IBlockState p_189872_1_, Entity p_189872_2_) {
      return p_189872_2_.func_70045_F();
   }

   public boolean func_201783_b(IBlockState p_201783_1_, IBlockReader p_201783_2_, BlockPos p_201783_3_) {
      return true;
   }
}
