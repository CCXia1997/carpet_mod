package net.minecraft.block;

import javax.annotation.Nullable;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.item.ItemStack;
import net.minecraft.state.EnumProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.state.properties.DoubleBlockHalf;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.IItemProvider;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.IWorld;
import net.minecraft.world.IWorldReaderBase;
import net.minecraft.world.World;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class BlockDoublePlant extends BlockBush {
   public static final EnumProperty<DoubleBlockHalf> field_176492_b = BlockStateProperties.field_208163_P;

   public BlockDoublePlant(Block.Properties p_i48412_1_) {
      super(p_i48412_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_176492_b, DoubleBlockHalf.LOWER));
   }

   public IBlockState func_196271_a(IBlockState p_196271_1_, EnumFacing p_196271_2_, IBlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      DoubleBlockHalf doubleblockhalf = p_196271_1_.func_177229_b(field_176492_b);
      if (p_196271_2_.func_176740_k() != EnumFacing.Axis.Y || doubleblockhalf == DoubleBlockHalf.LOWER != (p_196271_2_ == EnumFacing.UP) || p_196271_3_.func_177230_c() == this && p_196271_3_.func_177229_b(field_176492_b) != doubleblockhalf) {
         return doubleblockhalf == DoubleBlockHalf.LOWER && p_196271_2_ == EnumFacing.DOWN && !p_196271_1_.func_196955_c(p_196271_4_, p_196271_5_) ? Blocks.field_150350_a.func_176223_P() : super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
      } else {
         return Blocks.field_150350_a.func_176223_P();
      }
   }

   @Nullable
   public IBlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      BlockPos blockpos = p_196258_1_.func_195995_a();
      return blockpos.func_177956_o() < 255 && p_196258_1_.func_195991_k().func_180495_p(blockpos.func_177984_a()).func_196953_a(p_196258_1_) ? super.func_196258_a(p_196258_1_) : null;
   }

   public void func_180633_a(World p_180633_1_, BlockPos p_180633_2_, IBlockState p_180633_3_, EntityLivingBase p_180633_4_, ItemStack p_180633_5_) {
      p_180633_1_.func_180501_a(p_180633_2_.func_177984_a(), this.func_176223_P().func_206870_a(field_176492_b, DoubleBlockHalf.UPPER), 3);
   }

   public boolean func_196260_a(IBlockState p_196260_1_, IWorldReaderBase p_196260_2_, BlockPos p_196260_3_) {
      if (p_196260_1_.func_177229_b(field_176492_b) != DoubleBlockHalf.UPPER) {
         return super.func_196260_a(p_196260_1_, p_196260_2_, p_196260_3_);
      } else {
         IBlockState iblockstate = p_196260_2_.func_180495_p(p_196260_3_.func_177977_b());
         return iblockstate.func_177230_c() == this && iblockstate.func_177229_b(field_176492_b) == DoubleBlockHalf.LOWER;
      }
   }

   public void func_196390_a(IWorld p_196390_1_, BlockPos p_196390_2_, int p_196390_3_) {
      p_196390_1_.func_180501_a(p_196390_2_, this.func_176223_P().func_206870_a(field_176492_b, DoubleBlockHalf.LOWER), p_196390_3_);
      p_196390_1_.func_180501_a(p_196390_2_.func_177984_a(), this.func_176223_P().func_206870_a(field_176492_b, DoubleBlockHalf.UPPER), p_196390_3_);
   }

   public void func_180657_a(World p_180657_1_, EntityPlayer p_180657_2_, BlockPos p_180657_3_, IBlockState p_180657_4_, @Nullable TileEntity p_180657_5_, ItemStack p_180657_6_) {
      super.func_180657_a(p_180657_1_, p_180657_2_, p_180657_3_, Blocks.field_150350_a.func_176223_P(), p_180657_5_, p_180657_6_);
   }

   public void func_176208_a(World p_176208_1_, BlockPos p_176208_2_, IBlockState p_176208_3_, EntityPlayer p_176208_4_) {
      DoubleBlockHalf doubleblockhalf = p_176208_3_.func_177229_b(field_176492_b);
      boolean flag = doubleblockhalf == DoubleBlockHalf.LOWER;
      BlockPos blockpos = flag ? p_176208_2_.func_177984_a() : p_176208_2_.func_177977_b();
      IBlockState iblockstate = p_176208_1_.func_180495_p(blockpos);
      if (iblockstate.func_177230_c() == this && iblockstate.func_177229_b(field_176492_b) != doubleblockhalf) {
         p_176208_1_.func_180501_a(blockpos, Blocks.field_150350_a.func_176223_P(), 35);
         p_176208_1_.func_180498_a(p_176208_4_, 2001, blockpos, Block.func_196246_j(iblockstate));
         if (!p_176208_1_.field_72995_K && !p_176208_4_.func_184812_l_()) {
            if (flag) {
               this.func_196391_a(p_176208_3_, p_176208_1_, p_176208_2_, p_176208_4_.func_184614_ca());
            } else {
               this.func_196391_a(iblockstate, p_176208_1_, blockpos, p_176208_4_.func_184614_ca());
            }
         }
      }

      super.func_176208_a(p_176208_1_, p_176208_2_, p_176208_3_, p_176208_4_);
   }

   protected void func_196391_a(IBlockState p_196391_1_, World p_196391_2_, BlockPos p_196391_3_, ItemStack p_196391_4_) {
      p_196391_1_.func_196949_c(p_196391_2_, p_196391_3_, 0);
   }

   public IItemProvider func_199769_a(IBlockState p_199769_1_, World p_199769_2_, BlockPos p_199769_3_, int p_199769_4_) {
      return (IItemProvider)(p_199769_1_.func_177229_b(field_176492_b) == DoubleBlockHalf.LOWER ? super.func_199769_a(p_199769_1_, p_199769_2_, p_199769_3_, p_199769_4_) : Items.field_190931_a);
   }

   protected void func_206840_a(StateContainer.Builder<Block, IBlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_176492_b);
   }

   public Block.EnumOffsetType func_176218_Q() {
      return Block.EnumOffsetType.XZ;
   }

   @OnlyIn(Dist.CLIENT)
   public long func_209900_a(IBlockState p_209900_1_, BlockPos p_209900_2_) {
      return MathHelper.func_180187_c(p_209900_2_.func_177958_n(), p_209900_2_.func_177979_c(p_209900_1_.func_177229_b(field_176492_b) == DoubleBlockHalf.LOWER ? 0 : 1).func_177956_o(), p_209900_2_.func_177952_p());
   }
}
