package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.state.IBlockState;

public class BlockPackedIce extends Block {
   public BlockPackedIce(Block.Properties p_i48356_1_) {
      super(p_i48356_1_);
   }

   public int func_196264_a(IBlockState p_196264_1_, Random p_196264_2_) {
      return 0;
   }
}
