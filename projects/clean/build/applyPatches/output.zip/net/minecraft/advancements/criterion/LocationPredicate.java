package net.minecraft.advancements.criterion;

import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import javax.annotation.Nullable;
import net.minecraft.util.JsonUtils;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.registry.IRegistry;
import net.minecraft.world.WorldServer;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.dimension.DimensionType;
import net.minecraft.world.gen.feature.Feature;

public class LocationPredicate
{
    public static final LocationPredicate field_193455_a = new LocationPredicate(MinMaxBounds.FloatBound.field_211359_e, MinMaxBounds.FloatBound.field_211359_e, MinMaxBounds.FloatBound.field_211359_e, (Biome)null, (String)null, (DimensionType)null);
    private final MinMaxBounds.FloatBound field_193457_c;
    private final MinMaxBounds.FloatBound field_193458_d;
    private final MinMaxBounds.FloatBound field_193459_e;
    @Nullable
    private final Biome field_193456_b;
    @Nullable
    private final String field_193460_f;
    @Nullable
    private final DimensionType field_193461_g;

    public LocationPredicate(MinMaxBounds.FloatBound p_i49721_1_, MinMaxBounds.FloatBound p_i49721_2_, MinMaxBounds.FloatBound p_i49721_3_, @Nullable Biome p_i49721_4_, @Nullable String p_i49721_5_, @Nullable DimensionType p_i49721_6_)
    {
        this.field_193457_c = p_i49721_1_;
        this.field_193458_d = p_i49721_2_;
        this.field_193459_e = p_i49721_3_;
        this.field_193456_b = p_i49721_4_;
        this.field_193460_f = p_i49721_5_;
        this.field_193461_g = p_i49721_6_;
    }

    public static LocationPredicate func_204010_a(Biome p_204010_0_)
    {
        return new LocationPredicate(MinMaxBounds.FloatBound.field_211359_e, MinMaxBounds.FloatBound.field_211359_e, MinMaxBounds.FloatBound.field_211359_e, p_204010_0_, (String)null, (DimensionType)null);
    }

    public static LocationPredicate func_204008_a(DimensionType p_204008_0_)
    {
        return new LocationPredicate(MinMaxBounds.FloatBound.field_211359_e, MinMaxBounds.FloatBound.field_211359_e, MinMaxBounds.FloatBound.field_211359_e, (Biome)null, (String)null, p_204008_0_);
    }

    public static LocationPredicate func_204007_a(String p_204007_0_)
    {
        return new LocationPredicate(MinMaxBounds.FloatBound.field_211359_e, MinMaxBounds.FloatBound.field_211359_e, MinMaxBounds.FloatBound.field_211359_e, (Biome)null, p_204007_0_, (DimensionType)null);
    }

    public boolean func_193452_a(WorldServer p_193452_1_, double p_193452_2_, double p_193452_4_, double p_193452_6_)
    {
        return this.func_193453_a(p_193452_1_, (float)p_193452_2_, (float)p_193452_4_, (float)p_193452_6_);
    }

    public boolean func_193453_a(WorldServer p_193453_1_, float p_193453_2_, float p_193453_3_, float p_193453_4_)
    {
        if (!this.field_193457_c.func_211354_d(p_193453_2_))
        {
            return false;
        }
        else if (!this.field_193458_d.func_211354_d(p_193453_3_))
        {
            return false;
        }
        else if (!this.field_193459_e.func_211354_d(p_193453_4_))
        {
            return false;
        }
        else if (this.field_193461_g != null && this.field_193461_g != p_193453_1_.field_73011_w.func_186058_p())
        {
            return false;
        }
        else
        {
            BlockPos blockpos = new BlockPos((double)p_193453_2_, (double)p_193453_3_, (double)p_193453_4_);

            if (this.field_193456_b != null && this.field_193456_b != p_193453_1_.func_180494_b(blockpos))
            {
                return false;
            }
            else
            {
                return this.field_193460_f == null || Feature.func_202280_a(p_193453_1_, this.field_193460_f, blockpos);
            }
        }
    }

    public JsonElement func_204009_a()
    {
        if (this == field_193455_a)
        {
            return JsonNull.INSTANCE;
        }
        else
        {
            JsonObject jsonobject = new JsonObject();

            if (!this.field_193457_c.func_211335_c() || !this.field_193458_d.func_211335_c() || !this.field_193459_e.func_211335_c())
            {
                JsonObject jsonobject1 = new JsonObject();
                jsonobject1.add("x", this.field_193457_c.func_200321_c());
                jsonobject1.add("y", this.field_193458_d.func_200321_c());
                jsonobject1.add("z", this.field_193459_e.func_200321_c());
                jsonobject.add("position", jsonobject1);
            }

            if (this.field_193461_g != null)
            {
                jsonobject.addProperty("dimension", DimensionType.func_212678_a(this.field_193461_g).toString());
            }

            if (this.field_193460_f != null)
            {
                jsonobject.addProperty("feature", this.field_193460_f);
            }

            if (this.field_193456_b != null)
            {
                jsonobject.addProperty("biome", IRegistry.field_212624_m.func_177774_c(this.field_193456_b).toString());
            }

            return jsonobject;
        }
    }

    public static LocationPredicate func_193454_a(@Nullable JsonElement p_193454_0_)
    {
        if (p_193454_0_ != null && !p_193454_0_.isJsonNull())
        {
            JsonObject jsonobject = JsonUtils.func_151210_l(p_193454_0_, "location");
            JsonObject jsonobject1 = JsonUtils.func_151218_a(jsonobject, "position", new JsonObject());
            MinMaxBounds.FloatBound minmaxbounds$floatbound = MinMaxBounds.FloatBound.func_211356_a(jsonobject1.get("x"));
            MinMaxBounds.FloatBound minmaxbounds$floatbound1 = MinMaxBounds.FloatBound.func_211356_a(jsonobject1.get("y"));
            MinMaxBounds.FloatBound minmaxbounds$floatbound2 = MinMaxBounds.FloatBound.func_211356_a(jsonobject1.get("z"));
            DimensionType dimensiontype = jsonobject.has("dimension") ? DimensionType.func_193417_a(new ResourceLocation(JsonUtils.func_151200_h(jsonobject, "dimension"))) : null;
            String s = jsonobject.has("feature") ? JsonUtils.func_151200_h(jsonobject, "feature") : null;
            Biome biome = null;

            if (jsonobject.has("biome"))
            {
                ResourceLocation resourcelocation = new ResourceLocation(JsonUtils.func_151200_h(jsonobject, "biome"));
                biome = IRegistry.field_212624_m.func_212608_b(resourcelocation);

                if (biome == null)
                {
                    throw new JsonSyntaxException("Unknown biome '" + resourcelocation + "'");
                }
            }

            return new LocationPredicate(minmaxbounds$floatbound, minmaxbounds$floatbound1, minmaxbounds$floatbound2, biome, s, dimensiontype);
        }
        else
        {
            return field_193455_a;
        }
    }
}
