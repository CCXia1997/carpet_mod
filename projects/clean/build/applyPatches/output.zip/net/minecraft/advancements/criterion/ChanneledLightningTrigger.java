package net.minecraft.advancements.criterion;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.minecraft.advancements.ICriterionTrigger;
import net.minecraft.advancements.PlayerAdvancements;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.util.ResourceLocation;

public class ChanneledLightningTrigger implements ICriterionTrigger<ChanneledLightningTrigger.Instance>
{
    private static final ResourceLocation field_204815_a = new ResourceLocation("channeled_lightning");
    private final Map<PlayerAdvancements, ChanneledLightningTrigger.Listeners> field_204816_b = Maps.newHashMap();

    public ResourceLocation func_192163_a()
    {
        return field_204815_a;
    }

    public void func_192165_a(PlayerAdvancements p_192165_1_, ICriterionTrigger.Listener<ChanneledLightningTrigger.Instance> p_192165_2_)
    {
        ChanneledLightningTrigger.Listeners channeledlightningtrigger$listeners = this.field_204816_b.get(p_192165_1_);

        if (channeledlightningtrigger$listeners == null)
        {
            channeledlightningtrigger$listeners = new ChanneledLightningTrigger.Listeners(p_192165_1_);
            this.field_204816_b.put(p_192165_1_, channeledlightningtrigger$listeners);
        }

        channeledlightningtrigger$listeners.func_204843_a(p_192165_2_);
    }

    public void func_192164_b(PlayerAdvancements p_192164_1_, ICriterionTrigger.Listener<ChanneledLightningTrigger.Instance> p_192164_2_)
    {
        ChanneledLightningTrigger.Listeners channeledlightningtrigger$listeners = this.field_204816_b.get(p_192164_1_);

        if (channeledlightningtrigger$listeners != null)
        {
            channeledlightningtrigger$listeners.func_204845_b(p_192164_2_);

            if (channeledlightningtrigger$listeners.func_204844_a())
            {
                this.field_204816_b.remove(p_192164_1_);
            }
        }
    }

    public void func_192167_a(PlayerAdvancements p_192167_1_)
    {
        this.field_204816_b.remove(p_192167_1_);
    }

    public ChanneledLightningTrigger.Instance func_192166_a(JsonObject p_192166_1_, JsonDeserializationContext p_192166_2_)
    {
        EntityPredicate[] aentitypredicate = EntityPredicate.func_204849_b(p_192166_1_.get("victims"));
        return new ChanneledLightningTrigger.Instance(aentitypredicate);
    }

    public void func_204814_a(EntityPlayerMP p_204814_1_, Collection <? extends Entity > p_204814_2_)
    {
        ChanneledLightningTrigger.Listeners channeledlightningtrigger$listeners = this.field_204816_b.get(p_204814_1_.func_192039_O());

        if (channeledlightningtrigger$listeners != null)
        {
            channeledlightningtrigger$listeners.func_204846_a(p_204814_1_, p_204814_2_);
        }
    }

    public static class Instance extends AbstractCriterionInstance
        {
            private final EntityPredicate[] field_204825_a;

            public Instance(EntityPredicate[] p_i48921_1_)
            {
                super(ChanneledLightningTrigger.field_204815_a);
                this.field_204825_a = p_i48921_1_;
            }

            public static ChanneledLightningTrigger.Instance func_204824_a(EntityPredicate... p_204824_0_)
            {
                return new ChanneledLightningTrigger.Instance(p_204824_0_);
            }

            public boolean func_204823_a(EntityPlayerMP p_204823_1_, Collection <? extends Entity > p_204823_2_)
            {
                for (EntityPredicate entitypredicate : this.field_204825_a)
                {
                    boolean flag = false;

                    for (Entity entity : p_204823_2_)
                    {
                        if (entitypredicate.func_192482_a(p_204823_1_, entity))
                        {
                            flag = true;
                            break;
                        }
                    }

                    if (!flag)
                    {
                        return false;
                    }
                }

                return true;
            }

            public JsonElement func_200288_b()
            {
                JsonObject jsonobject = new JsonObject();
                jsonobject.add("victims", EntityPredicate.func_204850_a(this.field_204825_a));
                return jsonobject;
            }
        }

    static class Listeners
        {
            private final PlayerAdvancements field_204847_a;
            private final Set<ICriterionTrigger.Listener<ChanneledLightningTrigger.Instance>> field_204848_b = Sets.newHashSet();

            public Listeners(PlayerAdvancements p_i48922_1_)
            {
                this.field_204847_a = p_i48922_1_;
            }

            public boolean func_204844_a()
            {
                return this.field_204848_b.isEmpty();
            }

            public void func_204843_a(ICriterionTrigger.Listener<ChanneledLightningTrigger.Instance> p_204843_1_)
            {
                this.field_204848_b.add(p_204843_1_);
            }

            public void func_204845_b(ICriterionTrigger.Listener<ChanneledLightningTrigger.Instance> p_204845_1_)
            {
                this.field_204848_b.remove(p_204845_1_);
            }

            public void func_204846_a(EntityPlayerMP p_204846_1_, Collection <? extends Entity > p_204846_2_)
            {
                List<ICriterionTrigger.Listener<ChanneledLightningTrigger.Instance>> list = null;

                for (ICriterionTrigger.Listener<ChanneledLightningTrigger.Instance> listener : this.field_204848_b)
                {
                    if (listener.func_192158_a().func_204823_a(p_204846_1_, p_204846_2_))
                    {
                        if (list == null)
                        {
                            list = Lists.newArrayList();
                        }

                        list.add(listener);
                    }
                }

                if (list != null)
                {
                    for (ICriterionTrigger.Listener<ChanneledLightningTrigger.Instance> listener1 : list)
                    {
                        listener1.func_192159_a(this.field_204847_a);
                    }
                }
            }
        }
}
