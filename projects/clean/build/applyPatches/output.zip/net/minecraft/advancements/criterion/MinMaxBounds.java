package net.minecraft.advancements.criterion;

import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.DynamicCommandExceptionType;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Supplier;
import javax.annotation.Nullable;
import net.minecraft.util.JsonUtils;
import net.minecraft.util.text.TextComponentTranslation;

public abstract class MinMaxBounds<T extends Number>
{
    public static final SimpleCommandExceptionType field_196978_b = new SimpleCommandExceptionType(new TextComponentTranslation("argument.range.empty"));
    public static final SimpleCommandExceptionType field_196980_d = new SimpleCommandExceptionType(new TextComponentTranslation("argument.range.swapped"));
    protected final T field_192517_b;
    protected final T field_192518_c;

    protected MinMaxBounds(@Nullable T p_i49720_1_, @Nullable T p_i49720_2_)
    {
        this.field_192517_b = p_i49720_1_;
        this.field_192518_c = p_i49720_2_;
    }

    @Nullable
    public T func_196973_a()
    {
        return this.field_192517_b;
    }

    @Nullable
    public T func_196977_b()
    {
        return this.field_192518_c;
    }

    public boolean func_211335_c()
    {
        return this.field_192517_b == null && this.field_192518_c == null;
    }

    public JsonElement func_200321_c()
    {
        if (this.func_211335_c())
        {
            return JsonNull.INSTANCE;
        }
        else if (this.field_192517_b != null && this.field_192517_b.equals(this.field_192518_c))
        {
            return new JsonPrimitive(this.field_192517_b);
        }
        else
        {
            JsonObject jsonobject = new JsonObject();

            if (this.field_192517_b != null)
            {
                jsonobject.addProperty("min", this.field_192517_b);
            }

            if (this.field_192518_c != null)
            {
                jsonobject.addProperty("max", this.field_192517_b);
            }

            return jsonobject;
        }
    }

    protected static <T extends Number, R extends MinMaxBounds<T>> R func_211331_a(@Nullable JsonElement p_211331_0_, R p_211331_1_, BiFunction<JsonElement, String, T> p_211331_2_, MinMaxBounds.IBoundFactory<T, R> p_211331_3_)
    {
        if (p_211331_0_ != null && !p_211331_0_.isJsonNull())
        {
            if (JsonUtils.func_188175_b(p_211331_0_))
            {
                T t2 = p_211331_2_.apply(p_211331_0_, "value");
                return p_211331_3_.create(t2, t2);
            }
            else
            {
                JsonObject jsonobject = JsonUtils.func_151210_l(p_211331_0_, "value");
                T t = jsonobject.has("min") ? p_211331_2_.apply(jsonobject.get("min"), "min") : null;
                T t1 = jsonobject.has("max") ? p_211331_2_.apply(jsonobject.get("max"), "max") : null;
                return p_211331_3_.create(t, t1);
            }
        }
        else
        {
            return p_211331_1_;
        }
    }

    protected static <T extends Number, R extends MinMaxBounds<T>> R func_211337_a(StringReader p_211337_0_, MinMaxBounds.IBoundReader<T, R> p_211337_1_, Function<String, T> p_211337_2_, Supplier<DynamicCommandExceptionType> p_211337_3_, Function<T, T> p_211337_4_) throws CommandSyntaxException
    {
        if (!p_211337_0_.canRead())
        {
            throw field_196978_b.createWithContext(p_211337_0_);
        }
        else
        {
            int i = p_211337_0_.getCursor();

            try
            {
                T t = func_196972_a(func_196975_b(p_211337_0_, p_211337_2_, p_211337_3_), p_211337_4_);
                T t1;

                if (p_211337_0_.canRead(2) && p_211337_0_.peek() == '.' && p_211337_0_.peek(1) == '.')
                {
                    p_211337_0_.skip();
                    p_211337_0_.skip();
                    t1 = func_196972_a(func_196975_b(p_211337_0_, p_211337_2_, p_211337_3_), p_211337_4_);

                    if (t == null && t1 == null)
                    {
                        throw field_196978_b.createWithContext(p_211337_0_);
                    }
                }
                else
                {
                    t1 = t;
                }

                if (t == null && t1 == null)
                {
                    throw field_196978_b.createWithContext(p_211337_0_);
                }
                else
                {
                    return p_211337_1_.create(p_211337_0_, t, t1);
                }
            }
            catch (CommandSyntaxException commandsyntaxexception)
            {
                p_211337_0_.setCursor(i);
                throw new CommandSyntaxException(commandsyntaxexception.getType(), commandsyntaxexception.getRawMessage(), commandsyntaxexception.getInput(), i);
            }
        }
    }

    @Nullable
    private static <T extends Number> T func_196975_b(StringReader p_196975_0_, Function<String, T> p_196975_1_, Supplier<DynamicCommandExceptionType> p_196975_2_) throws CommandSyntaxException
    {
        int i = p_196975_0_.getCursor();

        while (p_196975_0_.canRead() && func_196970_c(p_196975_0_))
        {
            p_196975_0_.skip();
        }

        String s = p_196975_0_.getString().substring(i, p_196975_0_.getCursor());

        if (s.isEmpty())
        {
            return (T)null;
        }
        else
        {
            try
            {
                return (T)(p_196975_1_.apply(s));
            }
            catch (NumberFormatException var6)
            {
                throw p_196975_2_.get().createWithContext(p_196975_0_, s);
            }
        }
    }

    private static boolean func_196970_c(StringReader p_196970_0_)
    {
        char c0 = p_196970_0_.peek();

        if ((c0 < '0' || c0 > '9') && c0 != '-')
        {
            if (c0 != '.')
            {
                return false;
            }
            else
            {
                return !p_196970_0_.canRead(2) || p_196970_0_.peek(1) != '.';
            }
        }
        else
        {
            return true;
        }
    }

    @Nullable
    private static <T> T func_196972_a(@Nullable T p_196972_0_, Function<T, T> p_196972_1_)
    {
        return (T)(p_196972_0_ == null ? null : p_196972_1_.apply(p_196972_0_));
    }

    public static class FloatBound extends MinMaxBounds<Float>
        {
            public static final MinMaxBounds.FloatBound field_211359_e = new MinMaxBounds.FloatBound((Float)null, (Float)null);
            private final Double field_211360_f;
            private final Double field_211361_g;

            private static MinMaxBounds.FloatBound func_211352_a(StringReader p_211352_0_, @Nullable Float p_211352_1_, @Nullable Float p_211352_2_) throws CommandSyntaxException
            {
                if (p_211352_1_ != null && p_211352_2_ != null && p_211352_1_ > p_211352_2_)
                {
                    throw field_196980_d.createWithContext(p_211352_0_);
                }
                else
                {
                    return new MinMaxBounds.FloatBound(p_211352_1_, p_211352_2_);
                }
            }

            @Nullable
            private static Double func_211350_a(@Nullable Float p_211350_0_)
            {
                return p_211350_0_ == null ? null : p_211350_0_.doubleValue() * p_211350_0_.doubleValue();
            }

            private FloatBound(@Nullable Float p_i49717_1_, @Nullable Float p_i49717_2_)
            {
                super(p_i49717_1_, p_i49717_2_);
                this.field_211360_f = func_211350_a(p_i49717_1_);
                this.field_211361_g = func_211350_a(p_i49717_2_);
            }

            public static MinMaxBounds.FloatBound func_211355_b(float p_211355_0_)
            {
                return new MinMaxBounds.FloatBound(p_211355_0_, (Float)null);
            }

            public boolean func_211354_d(float p_211354_1_)
            {
                if (this.field_192517_b != null && this.field_192517_b > p_211354_1_)
                {
                    return false;
                }
                else
                {
                    return this.field_192518_c == null || !(this.field_192518_c < p_211354_1_);
                }
            }

            public boolean func_211351_a(double p_211351_1_)
            {
                if (this.field_211360_f != null && this.field_211360_f > p_211351_1_)
                {
                    return false;
                }
                else
                {
                    return this.field_211361_g == null || !(this.field_211361_g < p_211351_1_);
                }
            }

            public static MinMaxBounds.FloatBound func_211356_a(@Nullable JsonElement p_211356_0_)
            {
                return func_211331_a(p_211356_0_, field_211359_e, JsonUtils::func_151220_d, MinMaxBounds.FloatBound::new);
            }

            public static MinMaxBounds.FloatBound func_211357_a(StringReader p_211357_0_) throws CommandSyntaxException
            {
                return func_211353_a(p_211357_0_, (p_211358_0_) ->
                {
                    return p_211358_0_;
                });
            }

            public static MinMaxBounds.FloatBound func_211353_a(StringReader p_211353_0_, Function<Float, Float> p_211353_1_) throws CommandSyntaxException
            {
                return func_211337_a(p_211353_0_, MinMaxBounds.FloatBound::func_211352_a, Float::parseFloat, CommandSyntaxException.BUILT_IN_EXCEPTIONS::readerInvalidFloat, p_211353_1_);
            }
        }

    @FunctionalInterface
    public interface IBoundFactory<T extends Number, R extends MinMaxBounds<T>>
    {
        R create(@Nullable T p_create_1_, @Nullable T p_create_2_);
    }

    @FunctionalInterface
    public interface IBoundReader<T extends Number, R extends MinMaxBounds<T>>
    {
        R create(StringReader p_create_1_, @Nullable T p_create_2_, @Nullable T p_create_3_) throws CommandSyntaxException;
    }

    public static class IntBound extends MinMaxBounds<Integer>
        {
            public static final MinMaxBounds.IntBound field_211347_e = new MinMaxBounds.IntBound((Integer)null, (Integer)null);
            private final Long field_211348_f;
            private final Long field_211349_g;

            private static MinMaxBounds.IntBound func_211338_a(StringReader p_211338_0_, @Nullable Integer p_211338_1_, @Nullable Integer p_211338_2_) throws CommandSyntaxException
            {
                if (p_211338_1_ != null && p_211338_2_ != null && p_211338_1_ > p_211338_2_)
                {
                    throw field_196980_d.createWithContext(p_211338_0_);
                }
                else
                {
                    return new MinMaxBounds.IntBound(p_211338_1_, p_211338_2_);
                }
            }

            @Nullable
            private static Long func_211343_a(@Nullable Integer p_211343_0_)
            {
                return p_211343_0_ == null ? null : p_211343_0_.longValue() * p_211343_0_.longValue();
            }

            private IntBound(@Nullable Integer p_i49716_1_, @Nullable Integer p_i49716_2_)
            {
                super(p_i49716_1_, p_i49716_2_);
                this.field_211348_f = func_211343_a(p_i49716_1_);
                this.field_211349_g = func_211343_a(p_i49716_2_);
            }

            public static MinMaxBounds.IntBound func_211345_a(int p_211345_0_)
            {
                return new MinMaxBounds.IntBound(p_211345_0_, p_211345_0_);
            }

            public static MinMaxBounds.IntBound func_211340_b(int p_211340_0_)
            {
                return new MinMaxBounds.IntBound(p_211340_0_, (Integer)null);
            }

            public boolean func_211339_d(int p_211339_1_)
            {
                if (this.field_192517_b != null && this.field_192517_b > p_211339_1_)
                {
                    return false;
                }
                else
                {
                    return this.field_192518_c == null || this.field_192518_c >= p_211339_1_;
                }
            }

            public static MinMaxBounds.IntBound func_211344_a(@Nullable JsonElement p_211344_0_)
            {
                return func_211331_a(p_211344_0_, field_211347_e, JsonUtils::func_151215_f, MinMaxBounds.IntBound::new);
            }

            public static MinMaxBounds.IntBound func_211342_a(StringReader p_211342_0_) throws CommandSyntaxException
            {
                return func_211341_a(p_211342_0_, (p_211346_0_) ->
                {
                    return p_211346_0_;
                });
            }

            public static MinMaxBounds.IntBound func_211341_a(StringReader p_211341_0_, Function<Integer, Integer> p_211341_1_) throws CommandSyntaxException
            {
                return func_211337_a(p_211341_0_, MinMaxBounds.IntBound::func_211338_a, Integer::parseInt, CommandSyntaxException.BUILT_IN_EXCEPTIONS::readerInvalidInt, p_211341_1_);
            }
        }
}
