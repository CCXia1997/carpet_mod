package net.minecraft.advancements;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.mojang.brigadier.CommandDispatcher;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import javax.annotation.Nullable;
import net.minecraft.command.CommandSource;
import net.minecraft.command.FunctionObject;
import net.minecraft.resources.IResource;
import net.minecraft.resources.IResourceManager;
import net.minecraft.resources.IResourceManagerReloadListener;
import net.minecraft.resources.SimpleResource;
import net.minecraft.server.MinecraftServer;
import net.minecraft.tags.TagCollection;
import net.minecraft.util.ITickable;
import net.minecraft.util.ResourceLocation;
import org.apache.commons.io.IOUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class FunctionManager implements ITickable, IResourceManagerReloadListener
{
    private static final Logger field_193067_a = LogManager.getLogger();
    private static final ResourceLocation field_200001_d = new ResourceLocation("tick");
    private static final ResourceLocation field_200222_e = new ResourceLocation("load");
    public static final int field_195454_a = "functions/".length();
    public static final int field_195455_b = ".mcfunction".length();
    private final MinecraftServer field_193069_c;
    private final Map<ResourceLocation, FunctionObject> field_193070_d = Maps.newHashMap();
    private final ArrayDeque<FunctionManager.QueuedCommand> field_194020_g = new ArrayDeque<>();
    private boolean field_194021_h;
    private final TagCollection<FunctionObject> field_200002_i = new TagCollection<>((p_200107_1_) ->
    {
        return this.func_193058_a(p_200107_1_) != null;
    }, this::func_193058_a, "tags/functions", true, "function");
    private final List<FunctionObject> field_200003_j = Lists.newArrayList();
    private boolean field_200223_l;

    public FunctionManager(MinecraftServer p_i47920_1_)
    {
        this.field_193069_c = p_i47920_1_;
    }

    @Nullable
    public FunctionObject func_193058_a(ResourceLocation p_193058_1_)
    {
        return this.field_193070_d.get(p_193058_1_);
    }

    public MinecraftServer func_195450_a()
    {
        return this.field_193069_c;
    }

    public int func_193065_c()
    {
        return this.field_193069_c.func_200252_aR().func_180263_c("maxCommandChainLength");
    }

    public Map<ResourceLocation, FunctionObject> func_193066_d()
    {
        return this.field_193070_d;
    }

    public CommandDispatcher<CommandSource> func_195446_d()
    {
        return this.field_193069_c.func_195571_aL().func_197054_a();
    }

    public void func_73660_a()
    {
        this.field_193069_c.field_71304_b.func_194340_a(field_200001_d::toString);

        for (FunctionObject functionobject : this.field_200003_j)
        {
            this.func_195447_a(functionobject, this.func_195448_f());
        }

        this.field_193069_c.field_71304_b.func_76319_b();

        if (this.field_200223_l)
        {
            this.field_200223_l = false;
            Collection<FunctionObject> collection = this.func_200000_g().func_199915_b(field_200222_e).func_199885_a();
            this.field_193069_c.field_71304_b.func_194340_a(field_200222_e::toString);

            for (FunctionObject functionobject1 : collection)
            {
                this.func_195447_a(functionobject1, this.func_195448_f());
            }

            this.field_193069_c.field_71304_b.func_76319_b();
        }
    }

    public int func_195447_a(FunctionObject p_195447_1_, CommandSource p_195447_2_)
    {
        int i = this.func_193065_c();

        if (this.field_194021_h)
        {
            if (this.field_194020_g.size() < i)
            {
                this.field_194020_g.addFirst(new FunctionManager.QueuedCommand(this, p_195447_2_, new FunctionObject.FunctionEntry(p_195447_1_)));
            }

            return 0;
        }
        else
        {
            try
            {
                this.field_194021_h = true;
                int j = 0;
                FunctionObject.Entry[] afunctionobject$entry = p_195447_1_.func_193528_a();

                for (int k = afunctionobject$entry.length - 1; k >= 0; --k)
                {
                    this.field_194020_g.push(new FunctionManager.QueuedCommand(this, p_195447_2_, afunctionobject$entry[k]));
                }

                while (!this.field_194020_g.isEmpty())
                {
                    try
                    {
                        FunctionManager.QueuedCommand functionmanager$queuedcommand = this.field_194020_g.removeFirst();
                        this.field_193069_c.field_71304_b.func_194340_a(functionmanager$queuedcommand::toString);
                        functionmanager$queuedcommand.func_194222_a(this.field_194020_g, i);
                    }
                    finally
                    {
                        this.field_193069_c.field_71304_b.func_76319_b();
                    }

                    ++j;

                    if (j >= i)
                    {
                        int l = j;
                        return l;
                    }
                }

                int i1 = j;
                return i1;
            }
            finally
            {
                this.field_194020_g.clear();
                this.field_194021_h = false;
            }
        }
    }

    public void func_195410_a(IResourceManager p_195410_1_)
    {
        this.field_193070_d.clear();
        this.field_200003_j.clear();
        this.field_200002_i.func_199917_b();
        Collection<ResourceLocation> collection = p_195410_1_.func_199003_a("functions", (p_195453_0_) ->
        {
            return p_195453_0_.endsWith(".mcfunction");
        });
        List<CompletableFuture<FunctionObject>> list = Lists.newArrayList();

        for (ResourceLocation resourcelocation : collection)
        {
            String s = resourcelocation.func_110623_a();
            ResourceLocation resourcelocation1 = new ResourceLocation(resourcelocation.func_110624_b(), s.substring(field_195454_a, s.length() - field_195455_b));
            list.add(CompletableFuture.supplyAsync(() ->
            {
                return func_195449_a(p_195410_1_, resourcelocation);
            }, SimpleResource.field_199031_a).thenApplyAsync((p_195444_2_) ->
            {
                return FunctionObject.func_197000_a(resourcelocation1, this, p_195444_2_);
            }).handle((p_195451_2_, p_195451_3_) ->
            {
                return this.func_212250_a(p_195451_2_, p_195451_3_, resourcelocation);
            }));
        }

        CompletableFuture.allOf(list.toArray(new CompletableFuture[0])).join();

        if (!this.field_193070_d.isEmpty())
        {
            field_193067_a.info("Loaded {} custom command functions", (int)this.field_193070_d.size());
        }

        this.field_200002_i.func_199909_a(p_195410_1_);
        this.field_200003_j.addAll(this.field_200002_i.func_199915_b(field_200001_d).func_199885_a());
        this.field_200223_l = true;
    }

    @Nullable
    private FunctionObject func_212250_a(FunctionObject p_212250_1_, @Nullable Throwable p_212250_2_, ResourceLocation p_212250_3_)
    {
        if (p_212250_2_ != null)
        {
            field_193067_a.error("Couldn't load function at {}", p_212250_3_, p_212250_2_);
            return null;
        }
        else
        {
            synchronized (this.field_193070_d)
            {
                this.field_193070_d.put(p_212250_1_.func_197001_a(), p_212250_1_);
                return p_212250_1_;
            }
        }
    }

    private static List<String> func_195449_a(IResourceManager p_195449_0_, ResourceLocation p_195449_1_)
    {
        try (IResource iresource = p_195449_0_.func_199002_a(p_195449_1_))
        {
            List list = IOUtils.readLines(iresource.func_199027_b(), StandardCharsets.UTF_8);
            return list;
        }
        catch (IOException ioexception)
        {
            throw new CompletionException(ioexception);
        }
    }

    public CommandSource func_195448_f()
    {
        return this.field_193069_c.func_195573_aM().func_197033_a(2).func_197031_a();
    }

    public TagCollection<FunctionObject> func_200000_g()
    {
        return this.field_200002_i;
    }

    public static class QueuedCommand
        {
            private final FunctionManager field_194223_a;
            private final CommandSource field_194224_b;
            private final FunctionObject.Entry field_194225_c;

            public QueuedCommand(FunctionManager p_i48018_1_, CommandSource p_i48018_2_, FunctionObject.Entry p_i48018_3_)
            {
                this.field_194223_a = p_i48018_1_;
                this.field_194224_b = p_i48018_2_;
                this.field_194225_c = p_i48018_3_;
            }

            public void func_194222_a(ArrayDeque<FunctionManager.QueuedCommand> p_194222_1_, int p_194222_2_)
            {
                try
                {
                    this.field_194225_c.func_196998_a(this.field_194223_a, this.field_194224_b, p_194222_1_, p_194222_2_);
                }
                catch (Throwable var4)
                {
                    ;
                }
            }

            public String toString()
            {
                return this.field_194225_c.toString();
            }
        }
}
