package net.minecraft.client.gui.recipebook;

import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.resources.I18n;
import net.minecraft.inventory.ContainerRecipeBook;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.IRecipe;
import net.minecraft.item.crafting.RecipeBook;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class GuiButtonRecipe extends GuiButton
{
    private static final ResourceLocation field_191780_o = new ResourceLocation("textures/gui/recipe_book.png");
    private ContainerRecipeBook field_203401_p;
    private RecipeBook field_193930_p;
    private RecipeList field_191774_p;
    private float field_193931_r;
    private float field_191778_t;
    private int field_193932_t;

    public GuiButtonRecipe()
    {
        super(0, 0, 0, 25, 25, "");
    }

    public void func_203400_a(RecipeList p_203400_1_, RecipeBookPage p_203400_2_)
    {
        this.field_191774_p = p_203400_1_;
        this.field_203401_p = (ContainerRecipeBook)p_203400_2_.func_203411_d().field_71439_g.field_71070_bA;
        this.field_193930_p = p_203400_2_.func_203412_e();
        List<IRecipe> list = p_203400_1_.func_194208_a(this.field_193930_p.func_203432_a(this.field_203401_p));

        for (IRecipe irecipe : list)
        {
            if (this.field_193930_p.func_194076_e(irecipe))
            {
                p_203400_2_.func_194195_a(list);
                this.field_191778_t = 15.0F;
                break;
            }
        }
    }

    public RecipeList func_191771_c()
    {
        return this.field_191774_p;
    }

    public void func_191770_c(int p_191770_1_, int p_191770_2_)
    {
        this.field_146128_h = p_191770_1_;
        this.field_146129_i = p_191770_2_;
    }

    public void func_194828_a(int p_194828_1_, int p_194828_2_, float p_194828_3_)
    {
        if (this.field_146125_m)
        {
            if (!GuiScreen.func_146271_m())
            {
                this.field_193931_r += p_194828_3_;
            }

            this.field_146123_n = p_194828_1_ >= this.field_146128_h && p_194828_2_ >= this.field_146129_i && p_194828_1_ < this.field_146128_h + this.field_146120_f && p_194828_2_ < this.field_146129_i + this.field_146121_g;
            RenderHelper.func_74520_c();
            Minecraft minecraft = Minecraft.func_71410_x();
            minecraft.func_110434_K().func_110577_a(field_191780_o);
            GlStateManager.func_179140_f();
            int i = 29;

            if (!this.field_191774_p.func_192708_c())
            {
                i += 25;
            }

            int j = 206;

            if (this.field_191774_p.func_194208_a(this.field_193930_p.func_203432_a(this.field_203401_p)).size() > 1)
            {
                j += 25;
            }

            boolean flag = this.field_191778_t > 0.0F;

            if (flag)
            {
                float f = 1.0F + 0.1F * (float)Math.sin((double)(this.field_191778_t / 15.0F * (float)Math.PI));
                GlStateManager.func_179094_E();
                GlStateManager.func_179109_b((float)(this.field_146128_h + 8), (float)(this.field_146129_i + 12), 0.0F);
                GlStateManager.func_179152_a(f, f, 1.0F);
                GlStateManager.func_179109_b((float)(-(this.field_146128_h + 8)), (float)(-(this.field_146129_i + 12)), 0.0F);
                this.field_191778_t -= p_194828_3_;
            }

            this.func_73729_b(this.field_146128_h, this.field_146129_i, i, j, this.field_146120_f, this.field_146121_g);
            List<IRecipe> list = this.func_193927_f();
            this.field_193932_t = MathHelper.func_76141_d(this.field_193931_r / 30.0F) % list.size();
            ItemStack itemstack = list.get(this.field_193932_t).func_77571_b();
            int k = 4;

            if (this.field_191774_p.func_194211_e() && this.func_193927_f().size() > 1)
            {
                minecraft.func_175599_af().func_180450_b(itemstack, this.field_146128_h + k + 1, this.field_146129_i + k + 1);
                --k;
            }

            minecraft.func_175599_af().func_180450_b(itemstack, this.field_146128_h + k, this.field_146129_i + k);

            if (flag)
            {
                GlStateManager.func_179121_F();
            }

            GlStateManager.func_179145_e();
            RenderHelper.func_74518_a();
        }
    }

    private List<IRecipe> func_193927_f()
    {
        List<IRecipe> list = this.field_191774_p.func_194207_b(true);

        if (!this.field_193930_p.func_203432_a(this.field_203401_p))
        {
            list.addAll(this.field_191774_p.func_194207_b(false));
        }

        return list;
    }

    public boolean func_193929_d()
    {
        return this.func_193927_f().size() == 1;
    }

    public IRecipe func_193760_e()
    {
        List<IRecipe> list = this.func_193927_f();
        return list.get(this.field_193932_t);
    }

    public List<String> func_191772_a(GuiScreen p_191772_1_)
    {
        ItemStack itemstack = this.func_193927_f().get(this.field_193932_t).func_77571_b();
        List<String> list = p_191772_1_.func_191927_a(itemstack);

        if (this.field_191774_p.func_194208_a(this.field_193930_p.func_203432_a(this.field_203401_p)).size() > 1)
        {
            list.add(I18n.func_135052_a("gui.recipebook.moreRecipes"));
        }

        return list;
    }

    public int func_146117_b()
    {
        return 25;
    }

    public boolean mouseClicked(double p_mouseClicked_1_, double p_mouseClicked_3_, int p_mouseClicked_5_)
    {
        if (p_mouseClicked_5_ == 0 || p_mouseClicked_5_ == 1)
        {
            boolean flag = this.func_199400_c(p_mouseClicked_1_, p_mouseClicked_3_);

            if (flag)
            {
                this.func_146113_a(Minecraft.func_71410_x().func_147118_V());

                if (p_mouseClicked_5_ == 0)
                {
                    this.func_194829_a(p_mouseClicked_1_, p_mouseClicked_3_);
                }

                return true;
            }
        }

        return false;
    }
}
