package net.minecraft.client.gui.fonts.providers;

import com.google.common.collect.Lists;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import it.unimi.dsi.fastutil.chars.Char2ObjectMap;
import it.unimi.dsi.fastutil.chars.Char2ObjectOpenHashMap;
import java.io.IOException;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.client.gui.fonts.IGlyphInfo;
import net.minecraft.client.renderer.texture.NativeImage;
import net.minecraft.resources.IResource;
import net.minecraft.resources.IResourceManager;
import net.minecraft.util.JsonUtils;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@OnlyIn(Dist.CLIENT)
public class TextureGlyphProvider implements IGlyphProvider
{
    private static final Logger field_211609_a = LogManager.getLogger();
    private final NativeImage field_211610_b;
    private final Char2ObjectMap<TextureGlyphProvider.GlyphInfo> field_211267_a;

    public TextureGlyphProvider(NativeImage p_i49767_1_, Char2ObjectMap<TextureGlyphProvider.GlyphInfo> p_i49767_2_)
    {
        this.field_211610_b = p_i49767_1_;
        this.field_211267_a = p_i49767_2_;
    }

    public void close()
    {
        this.field_211610_b.close();
    }

    @Nullable
    public IGlyphInfo func_212248_a(char p_212248_1_)
    {
        return this.field_211267_a.get(p_212248_1_);
    }

    @OnlyIn(Dist.CLIENT)
    public static class Factory implements IGlyphProviderFactory
        {
            private final ResourceLocation field_211252_a;
            private final List<String> field_211634_b;
            private final int field_211635_c;
            private final int field_211636_d;

            public Factory(ResourceLocation p_i49750_1_, int p_i49750_2_, int p_i49750_3_, List<String> p_i49750_4_)
            {
                this.field_211252_a = new ResourceLocation(p_i49750_1_.func_110624_b(), "textures/" + p_i49750_1_.func_110623_a());
                this.field_211634_b = p_i49750_4_;
                this.field_211635_c = p_i49750_2_;
                this.field_211636_d = p_i49750_3_;
            }

            public static TextureGlyphProvider.Factory func_211633_a(JsonObject p_211633_0_)
            {
                int i = JsonUtils.func_151208_a(p_211633_0_, "height", 8);
                int j = JsonUtils.func_151203_m(p_211633_0_, "ascent");

                if (j > i)
                {
                    throw new JsonParseException("Ascent " + j + " higher than height " + i);
                }
                else
                {
                    List<String> list = Lists.newArrayList();
                    JsonArray jsonarray = JsonUtils.func_151214_t(p_211633_0_, "chars");

                    for (int k = 0; k < jsonarray.size(); ++k)
                    {
                        String s = JsonUtils.func_151206_a(jsonarray.get(k), "chars[" + k + "]");

                        if (k > 0)
                        {
                            int l = s.length();
                            int i1 = list.get(0).length();

                            if (l != i1)
                            {
                                throw new JsonParseException("Elements of chars have to be the same lenght (found: " + l + ", expected: " + i1 + "), pad with space or \\u0000");
                            }
                        }

                        list.add(s);
                    }

                    if (!list.isEmpty() && !list.get(0).isEmpty())
                    {
                        return new TextureGlyphProvider.Factory(new ResourceLocation(JsonUtils.func_151200_h(p_211633_0_, "file")), i, j, list);
                    }
                    else
                    {
                        throw new JsonParseException("Expected to find data in chars, found none.");
                    }
                }
            }

            @Nullable
            public IGlyphProvider func_211246_a(IResourceManager p_211246_1_)
            {
                try (IResource iresource = p_211246_1_.func_199002_a(this.field_211252_a))
                {
                    NativeImage nativeimage = NativeImage.func_211679_a(NativeImage.PixelFormat.RGBA, iresource.func_199027_b());
                    int i = nativeimage.func_195702_a();
                    int j = nativeimage.func_195714_b();
                    int k = i / this.field_211634_b.get(0).length();
                    int l = j / this.field_211634_b.size();
                    float f = (float)this.field_211635_c / (float)l;
                    Char2ObjectMap<TextureGlyphProvider.GlyphInfo> char2objectmap = new Char2ObjectOpenHashMap<>();

                    for (int i1 = 0; i1 < this.field_211634_b.size(); ++i1)
                    {
                        String s = this.field_211634_b.get(i1);

                        for (int j1 = 0; j1 < s.length(); ++j1)
                        {
                            char c0 = s.charAt(j1);

                            if (c0 != 0 && c0 != ' ')
                            {
                                int k1 = this.func_211632_a(nativeimage, k, l, j1, i1);
                                char2objectmap.put(c0, new TextureGlyphProvider.GlyphInfo(f, nativeimage, j1 * k, i1 * l, k, l, (int)(0.5D + (double)((float)k1 * f)) + 1, this.field_211636_d));
                            }
                        }
                    }

                    TextureGlyphProvider textureglyphprovider = new TextureGlyphProvider(nativeimage, char2objectmap);
                    return textureglyphprovider;
                }
                catch (IOException ioexception)
                {
                    throw new RuntimeException(ioexception.getMessage());
                }
            }

            private int func_211632_a(NativeImage p_211632_1_, int p_211632_2_, int p_211632_3_, int p_211632_4_, int p_211632_5_)
            {
                int i;

                for (i = p_211632_2_ - 1; i >= 0; --i)
                {
                    int j = p_211632_4_ * p_211632_2_ + i;

                    for (int k = 0; k < p_211632_3_; ++k)
                    {
                        int l = p_211632_5_ * p_211632_3_ + k;

                        if (p_211632_1_.func_211675_e(j, l) != 0)
                        {
                            return i + 1;
                        }
                    }
                }

                return i + 1;
            }
        }

    @OnlyIn(Dist.CLIENT)
    static final class GlyphInfo implements IGlyphInfo
        {
            private final float field_211582_a;
            private final NativeImage field_211583_b;
            private final int field_211584_c;
            private final int field_211585_d;
            private final int field_211586_e;
            private final int field_211587_f;
            private final int field_211588_g;
            private final int field_211589_h;

            private GlyphInfo(float p_i49748_1_, NativeImage p_i49748_2_, int p_i49748_3_, int p_i49748_4_, int p_i49748_5_, int p_i49748_6_, int p_i49748_7_, int p_i49748_8_)
            {
                this.field_211582_a = p_i49748_1_;
                this.field_211583_b = p_i49748_2_;
                this.field_211584_c = p_i49748_3_;
                this.field_211585_d = p_i49748_4_;
                this.field_211586_e = p_i49748_5_;
                this.field_211587_f = p_i49748_6_;
                this.field_211588_g = p_i49748_7_;
                this.field_211589_h = p_i49748_8_;
            }

            public float func_211578_g()
            {
                return 1.0F / this.field_211582_a;
            }

            public int func_211202_a()
            {
                return this.field_211586_e;
            }

            public int func_211203_b()
            {
                return this.field_211587_f;
            }

            public float getAdvance()
            {
                return (float)this.field_211588_g;
            }

            public float getBearingY()
            {
                return IGlyphInfo.super.getBearingY() + 7.0F - (float)this.field_211589_h;
            }

            public void func_211573_a(int p_211573_1_, int p_211573_2_)
            {
                this.field_211583_b.func_195706_a(0, p_211573_1_, p_211573_2_, this.field_211584_c, this.field_211585_d, this.field_211586_e, this.field_211587_f, false);
            }

            public boolean func_211579_f()
            {
                return this.field_211583_b.func_211678_c().func_211651_a() > 1;
            }
        }
}
