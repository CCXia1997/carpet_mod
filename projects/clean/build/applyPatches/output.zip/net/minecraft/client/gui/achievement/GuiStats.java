package net.minecraft.client.gui.achievement;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import javax.annotation.Nullable;
import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.client.audio.SimpleSound;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiSlot;
import net.minecraft.client.gui.IGuiEventListener;
import net.minecraft.client.gui.IGuiEventListenerDeferred;
import net.minecraft.client.gui.IProgressMeter;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.client.resources.I18n;
import net.minecraft.entity.EntityType;
import net.minecraft.init.Items;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.network.play.client.CPacketClientStatus;
import net.minecraft.stats.Stat;
import net.minecraft.stats.StatList;
import net.minecraft.stats.StatType;
import net.minecraft.stats.StatisticsManager;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.Util;
import net.minecraft.util.registry.IRegistry;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.util.text.TextFormatting;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class GuiStats extends GuiScreen implements IProgressMeter
{
    protected GuiScreen field_146549_a;
    protected String field_146542_f = "Select world";
    private GuiStats.StatsGeneral field_146550_h;
    private GuiStats.StatsItem field_146551_i;
    private GuiStats.StatsMobsList field_146547_s;
    private final StatisticsManager field_146546_t;
    private GuiSlot field_146545_u;
    private boolean field_146543_v = true;

    public GuiStats(GuiScreen p_i1071_1_, StatisticsManager p_i1071_2_)
    {
        this.field_146549_a = p_i1071_1_;
        this.field_146546_t = p_i1071_2_;
    }

    public IGuiEventListener getFocused()
    {
        return this.field_146545_u;
    }

    protected void func_73866_w_()
    {
        this.field_146542_f = I18n.func_135052_a("gui.stats");
        this.field_146543_v = true;
        this.field_146297_k.func_147114_u().func_147297_a(new CPacketClientStatus(CPacketClientStatus.State.REQUEST_STATS));
    }

    public void func_193028_a()
    {
        this.field_146550_h = new GuiStats.StatsGeneral(this.field_146297_k);
        this.field_146551_i = new GuiStats.StatsItem(this.field_146297_k);
        this.field_146547_s = new GuiStats.StatsMobsList(this.field_146297_k);
    }

    public void func_193029_f()
    {
        this.func_189646_b(new GuiButton(0, this.field_146294_l / 2 - 100, this.field_146295_m - 28, I18n.func_135052_a("gui.done"))
        {
            public void func_194829_a(double p_194829_1_, double p_194829_3_)
            {
                GuiStats.this.field_146297_k.func_147108_a(GuiStats.this.field_146549_a);
            }
        });
        this.func_189646_b(new GuiButton(1, this.field_146294_l / 2 - 120, this.field_146295_m - 52, 80, 20, I18n.func_135052_a("stat.generalButton"))
        {
            public void func_194829_a(double p_194829_1_, double p_194829_3_)
            {
                GuiStats.this.field_146545_u = GuiStats.this.field_146550_h;
            }
        });
        GuiButton guibutton = this.func_189646_b(new GuiButton(3, this.field_146294_l / 2 - 40, this.field_146295_m - 52, 80, 20, I18n.func_135052_a("stat.itemsButton"))
        {
            public void func_194829_a(double p_194829_1_, double p_194829_3_)
            {
                GuiStats.this.field_146545_u = GuiStats.this.field_146551_i;
            }
        });
        GuiButton guibutton1 = this.func_189646_b(new GuiButton(4, this.field_146294_l / 2 + 40, this.field_146295_m - 52, 80, 20, I18n.func_135052_a("stat.mobsButton"))
        {
            public void func_194829_a(double p_194829_1_, double p_194829_3_)
            {
                GuiStats.this.field_146545_u = GuiStats.this.field_146547_s;
            }
        });

        if (this.field_146551_i.func_148127_b() == 0)
        {
            guibutton.field_146124_l = false;
        }

        if (this.field_146547_s.func_148127_b() == 0)
        {
            guibutton1.field_146124_l = false;
        }

        this.field_195124_j.add((IGuiEventListenerDeferred)() ->
        {
            return this.field_146545_u;
        });
    }

    public void func_73863_a(int p_73863_1_, int p_73863_2_, float p_73863_3_)
    {
        if (this.field_146543_v)
        {
            this.func_146276_q_();
            this.func_73732_a(this.field_146289_q, I18n.func_135052_a("multiplayer.downloadingStats"), this.field_146294_l / 2, this.field_146295_m / 2, 16777215);
            this.func_73732_a(this.field_146289_q, field_146510_b_[(int)(Util.func_211177_b() / 150L % (long)field_146510_b_.length)], this.field_146294_l / 2, this.field_146295_m / 2 + this.field_146289_q.field_78288_b * 2, 16777215);
        }
        else
        {
            this.field_146545_u.func_148128_a(p_73863_1_, p_73863_2_, p_73863_3_);
            this.func_73732_a(this.field_146289_q, this.field_146542_f, this.field_146294_l / 2, 20, 16777215);
            super.func_73863_a(p_73863_1_, p_73863_2_, p_73863_3_);
        }
    }

    public void func_193026_g()
    {
        if (this.field_146543_v)
        {
            this.func_193028_a();
            this.func_193029_f();
            this.field_146545_u = this.field_146550_h;
            this.field_146543_v = false;
        }
    }

    public boolean func_73868_f()
    {
        return !this.field_146543_v;
    }

    private int func_195224_b(int p_195224_1_)
    {
        return 115 + 40 * p_195224_1_;
    }

    private void func_146521_a(int p_146521_1_, int p_146521_2_, Item p_146521_3_)
    {
        this.func_146531_b(p_146521_1_ + 1, p_146521_2_ + 1);
        GlStateManager.func_179091_B();
        RenderHelper.func_74520_c();
        this.field_146296_j.func_175042_a(p_146521_3_.func_190903_i(), p_146521_1_ + 2, p_146521_2_ + 2);
        RenderHelper.func_74518_a();
        GlStateManager.func_179101_C();
    }

    private void func_146531_b(int p_146531_1_, int p_146531_2_)
    {
        this.func_146527_c(p_146531_1_, p_146531_2_, 0, 0);
    }

    private void func_146527_c(int p_146527_1_, int p_146527_2_, int p_146527_3_, int p_146527_4_)
    {
        GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
        this.field_146297_k.func_110434_K().func_110577_a(field_110323_l);
        float f = 0.0078125F;
        float f1 = 0.0078125F;
        int i = 18;
        int j = 18;
        Tessellator tessellator = Tessellator.func_178181_a();
        BufferBuilder bufferbuilder = tessellator.func_178180_c();
        bufferbuilder.func_181668_a(7, DefaultVertexFormats.field_181707_g);
        bufferbuilder.func_181662_b((double)(p_146527_1_ + 0), (double)(p_146527_2_ + 18), (double)this.field_73735_i).func_187315_a((double)((float)(p_146527_3_ + 0) * 0.0078125F), (double)((float)(p_146527_4_ + 18) * 0.0078125F)).func_181675_d();
        bufferbuilder.func_181662_b((double)(p_146527_1_ + 18), (double)(p_146527_2_ + 18), (double)this.field_73735_i).func_187315_a((double)((float)(p_146527_3_ + 18) * 0.0078125F), (double)((float)(p_146527_4_ + 18) * 0.0078125F)).func_181675_d();
        bufferbuilder.func_181662_b((double)(p_146527_1_ + 18), (double)(p_146527_2_ + 0), (double)this.field_73735_i).func_187315_a((double)((float)(p_146527_3_ + 18) * 0.0078125F), (double)((float)(p_146527_4_ + 0) * 0.0078125F)).func_181675_d();
        bufferbuilder.func_181662_b((double)(p_146527_1_ + 0), (double)(p_146527_2_ + 0), (double)this.field_73735_i).func_187315_a((double)((float)(p_146527_3_ + 0) * 0.0078125F), (double)((float)(p_146527_4_ + 0) * 0.0078125F)).func_181675_d();
        tessellator.func_78381_a();
    }

    @OnlyIn(Dist.CLIENT)
    class StatsGeneral extends GuiSlot
    {
        private Iterator<Stat<ResourceLocation>> field_195102_w;

        public StatsGeneral(Minecraft p_i47553_2_)
        {
            super(p_i47553_2_, GuiStats.this.field_146294_l, GuiStats.this.field_146295_m, 32, GuiStats.this.field_146295_m - 64, 10);
            this.func_193651_b(false);
        }

        protected int func_148127_b()
        {
            return StatList.field_199092_j.func_199081_b();
        }

        protected boolean func_148131_a(int p_148131_1_)
        {
            return false;
        }

        protected int func_148138_e()
        {
            return this.func_148127_b() * 10;
        }

        protected void func_148123_a()
        {
            GuiStats.this.func_146276_q_();
        }

        protected void func_192637_a(int p_192637_1_, int p_192637_2_, int p_192637_3_, int p_192637_4_, int p_192637_5_, int p_192637_6_, float p_192637_7_)
        {
            if (p_192637_1_ == 0)
            {
                this.field_195102_w = StatList.field_199092_j.iterator();
            }

            Stat<ResourceLocation> stat = this.field_195102_w.next();
            ITextComponent itextcomponent = (new TextComponentTranslation("stat." + stat.func_197920_b().toString().replace(':', '.'))).func_211708_a(TextFormatting.GRAY);
            this.func_73731_b(GuiStats.this.field_146289_q, itextcomponent.getString(), p_192637_2_ + 2, p_192637_3_ + 1, p_192637_1_ % 2 == 0 ? 16777215 : 9474192);
            String s = stat.func_75968_a(GuiStats.this.field_146546_t.func_77444_a(stat));
            this.func_73731_b(GuiStats.this.field_146289_q, s, p_192637_2_ + 2 + 213 - GuiStats.this.field_146289_q.func_78256_a(s), p_192637_3_ + 1, p_192637_1_ % 2 == 0 ? 16777215 : 9474192);
        }
    }

    @OnlyIn(Dist.CLIENT)
    class StatsItem extends GuiSlot
    {
        protected final List<StatType<Block>> field_195113_v;
        protected final List<StatType<Item>> field_195114_w;
        private final int[] field_195112_D = new int[] {3, 4, 1, 2, 5, 6};
        protected int field_195115_x = -1;
        protected final List<Item> field_195116_y;
        protected final java.util.Comparator<Item> field_195117_z = new GuiStats.StatsItem.Comparator();
        @Nullable
        protected StatType<?> field_195110_A;
        protected int field_195111_B;

        public StatsItem(Minecraft p_i47552_2_)
        {
            super(p_i47552_2_, GuiStats.this.field_146294_l, GuiStats.this.field_146295_m, 32, GuiStats.this.field_146295_m - 64, 20);
            this.field_195113_v = Lists.newArrayList();
            this.field_195113_v.add(StatList.field_188065_ae);
            this.field_195114_w = Lists.newArrayList(StatList.field_199088_e, StatList.field_188066_af, StatList.field_75929_E, StatList.field_199089_f, StatList.field_188068_aj);
            this.func_193651_b(false);
            this.func_148133_a(true, 20);
            Set<Item> set = Sets.newIdentityHashSet();

            for (Item item : IRegistry.field_212630_s)
            {
                boolean flag = false;

                for (StatType<Item> stattype : this.field_195114_w)
                {
                    if (stattype.func_199079_a(item) && GuiStats.this.field_146546_t.func_77444_a(stattype.func_199076_b(item)) > 0)
                    {
                        flag = true;
                    }
                }

                if (flag)
                {
                    set.add(item);
                }
            }

            for (Block block : IRegistry.field_212618_g)
            {
                boolean flag1 = false;

                for (StatType<Block> stattype1 : this.field_195113_v)
                {
                    if (stattype1.func_199079_a(block) && GuiStats.this.field_146546_t.func_77444_a(stattype1.func_199076_b(block)) > 0)
                    {
                        flag1 = true;
                    }
                }

                if (flag1)
                {
                    set.add(block.func_199767_j());
                }
            }

            set.remove(Items.field_190931_a);
            this.field_195116_y = Lists.newArrayList(set);
        }

        protected void func_148129_a(int p_148129_1_, int p_148129_2_, Tessellator p_148129_3_)
        {
            if (!this.field_148161_k.field_71417_B.func_198030_b())
            {
                this.field_195115_x = -1;
            }

            for (int i = 0; i < this.field_195112_D.length; ++i)
            {
                GuiStats.this.func_146527_c(p_148129_1_ + GuiStats.this.func_195224_b(i) - 18, p_148129_2_ + 1, 0, this.field_195115_x == i ? 0 : 18);
            }

            if (this.field_195110_A != null)
            {
                int k = GuiStats.this.func_195224_b(this.func_195105_b(this.field_195110_A)) - 36;
                int j = this.field_195111_B == 1 ? 2 : 1;
                GuiStats.this.func_146527_c(p_148129_1_ + k, p_148129_2_ + 1, 18 * j, 0);
            }

            for (int l = 0; l < this.field_195112_D.length; ++l)
            {
                int i1 = this.field_195115_x != l ? 0 : 1;
                GuiStats.this.func_146527_c(p_148129_1_ + GuiStats.this.func_195224_b(l) - 18 + i1, p_148129_2_ + 1 + i1, 18 * this.field_195112_D[l], 18);
            }
        }

        protected void func_192637_a(int p_192637_1_, int p_192637_2_, int p_192637_3_, int p_192637_4_, int p_192637_5_, int p_192637_6_, float p_192637_7_)
        {
            Item item = this.func_195106_c(p_192637_1_);
            GuiStats.this.func_146521_a(p_192637_2_ + 40, p_192637_3_, item);

            for (int i = 0; i < this.field_195113_v.size(); ++i)
            {
                Stat<Block> stat;

                if (item instanceof ItemBlock)
                {
                    stat = this.field_195113_v.get(i).func_199076_b(((ItemBlock)item).func_179223_d());
                }
                else
                {
                    stat = null;
                }

                this.func_195103_a(stat, p_192637_2_ + GuiStats.this.func_195224_b(i), p_192637_3_, p_192637_1_ % 2 == 0);
            }

            for (int j = 0; j < this.field_195114_w.size(); ++j)
            {
                this.func_195103_a(this.field_195114_w.get(j).func_199076_b(item), p_192637_2_ + GuiStats.this.func_195224_b(j + this.field_195113_v.size()), p_192637_3_, p_192637_1_ % 2 == 0);
            }
        }

        protected boolean func_148131_a(int p_148131_1_)
        {
            return false;
        }

        public int func_148139_c()
        {
            return 375;
        }

        protected int func_148137_d()
        {
            return this.field_148155_a / 2 + 140;
        }

        protected void func_148123_a()
        {
            GuiStats.this.func_146276_q_();
        }

        protected void func_148132_a(int p_148132_1_, int p_148132_2_)
        {
            this.field_195115_x = -1;

            for (int i = 0; i < this.field_195112_D.length; ++i)
            {
                int j = p_148132_1_ - GuiStats.this.func_195224_b(i);

                if (j >= -36 && j <= 0)
                {
                    this.field_195115_x = i;
                    break;
                }
            }

            if (this.field_195115_x >= 0)
            {
                this.func_195107_a(this.func_195108_d(this.field_195115_x));
                this.field_148161_k.func_147118_V().func_147682_a(SimpleSound.func_184371_a(SoundEvents.field_187909_gi, 1.0F));
            }
        }

        private StatType<?> func_195108_d(int p_195108_1_)
        {
            return p_195108_1_ < this.field_195113_v.size() ? this.field_195113_v.get(p_195108_1_) : this.field_195114_w.get(p_195108_1_ - this.field_195113_v.size());
        }

        private int func_195105_b(StatType<?> p_195105_1_)
        {
            int i = this.field_195113_v.indexOf(p_195105_1_);

            if (i >= 0)
            {
                return i;
            }
            else
            {
                int j = this.field_195114_w.indexOf(p_195105_1_);
                return j >= 0 ? j + this.field_195113_v.size() : -1;
            }
        }

        protected final int func_148127_b()
        {
            return this.field_195116_y.size();
        }

        protected final Item func_195106_c(int p_195106_1_)
        {
            return this.field_195116_y.get(p_195106_1_);
        }

        protected void func_195103_a(@Nullable Stat<?> p_195103_1_, int p_195103_2_, int p_195103_3_, boolean p_195103_4_)
        {
            String s = p_195103_1_ == null ? "-" : p_195103_1_.func_75968_a(GuiStats.this.field_146546_t.func_77444_a(p_195103_1_));
            this.func_73731_b(GuiStats.this.field_146289_q, s, p_195103_2_ - GuiStats.this.field_146289_q.func_78256_a(s), p_195103_3_ + 5, p_195103_4_ ? 16777215 : 9474192);
        }

        protected void func_148142_b(int p_148142_1_, int p_148142_2_)
        {
            if (p_148142_2_ >= this.field_148153_b && p_148142_2_ <= this.field_148154_c)
            {
                int i = this.func_195083_a((double)p_148142_1_, (double)p_148142_2_);
                int j = (this.field_148155_a - this.func_148139_c()) / 2;

                if (i >= 0)
                {
                    if (p_148142_1_ < j + 40 || p_148142_1_ > j + 40 + 20)
                    {
                        return;
                    }

                    Item item = this.func_195106_c(i);
                    this.func_200207_a(this.func_200208_a(item), p_148142_1_, p_148142_2_);
                }
                else
                {
                    ITextComponent itextcomponent = null;
                    int k = p_148142_1_ - j;

                    for (int l = 0; l < this.field_195112_D.length; ++l)
                    {
                        int i1 = GuiStats.this.func_195224_b(l);

                        if (k >= i1 - 18 && k <= i1)
                        {
                            itextcomponent = new TextComponentTranslation(this.func_195108_d(l).func_199078_c());
                            break;
                        }
                    }

                    this.func_200207_a(itextcomponent, p_148142_1_, p_148142_2_);
                }
            }
        }

        protected void func_200207_a(@Nullable ITextComponent p_200207_1_, int p_200207_2_, int p_200207_3_)
        {
            if (p_200207_1_ != null)
            {
                String s = p_200207_1_.func_150254_d();
                int i = p_200207_2_ + 12;
                int j = p_200207_3_ - 12;
                int k = GuiStats.this.field_146289_q.func_78256_a(s);
                this.func_73733_a(i - 3, j - 3, i + k + 3, j + 8 + 3, -1073741824, -1073741824);
                GuiStats.this.field_146289_q.func_175063_a(s, (float)i, (float)j, -1);
            }
        }

        protected ITextComponent func_200208_a(Item p_200208_1_)
        {
            return p_200208_1_.func_200296_o();
        }

        protected void func_195107_a(StatType<?> p_195107_1_)
        {
            if (p_195107_1_ != this.field_195110_A)
            {
                this.field_195110_A = p_195107_1_;
                this.field_195111_B = -1;
            }
            else if (this.field_195111_B == -1)
            {
                this.field_195111_B = 1;
            }
            else
            {
                this.field_195110_A = null;
                this.field_195111_B = 0;
            }

            this.field_195116_y.sort(this.field_195117_z);
        }

        @OnlyIn(Dist.CLIENT)
        class Comparator implements java.util.Comparator<Item>
        {
            private Comparator()
            {
            }

            public int compare(Item p_compare_1_, Item p_compare_2_)
            {
                int i;
                int j;

                if (StatsItem.this.field_195110_A == null)
                {
                    i = 0;
                    j = 0;
                }
                else if (StatsItem.this.field_195113_v.contains(StatsItem.this.field_195110_A))
                {
                    StatType<Block> stattype = (StatType<Block>)StatsItem.this.field_195110_A;
                    i = p_compare_1_ instanceof ItemBlock ? GuiStats.this.field_146546_t.func_199060_a(stattype, ((ItemBlock)p_compare_1_).func_179223_d()) : -1;
                    j = p_compare_2_ instanceof ItemBlock ? GuiStats.this.field_146546_t.func_199060_a(stattype, ((ItemBlock)p_compare_2_).func_179223_d()) : -1;
                }
                else
                {
                    StatType<Item> stattype1 = (StatType<Item>)StatsItem.this.field_195110_A;
                    i = GuiStats.this.field_146546_t.func_199060_a(stattype1, p_compare_1_);
                    j = GuiStats.this.field_146546_t.func_199060_a(stattype1, p_compare_2_);
                }

                return i == j ? StatsItem.this.field_195111_B * Integer.compare(Item.func_150891_b(p_compare_1_), Item.func_150891_b(p_compare_2_)) : StatsItem.this.field_195111_B * Integer.compare(i, j);
            }
        }
    }

    @OnlyIn(Dist.CLIENT)
    class StatsMobsList extends GuiSlot
    {
        private final List < EntityType<? >> field_148222_l = Lists.newArrayList();

        public StatsMobsList(Minecraft p_i47551_2_)
        {
            super(p_i47551_2_, GuiStats.this.field_146294_l, GuiStats.this.field_146295_m, 32, GuiStats.this.field_146295_m - 64, GuiStats.this.field_146289_q.field_78288_b * 4);
            this.func_193651_b(false);

            for (EntityType<?> entitytype : IRegistry.field_212629_r)
            {
                if (GuiStats.this.field_146546_t.func_77444_a(StatList.field_199090_h.func_199076_b(entitytype)) > 0 || GuiStats.this.field_146546_t.func_77444_a(StatList.field_199091_i.func_199076_b(entitytype)) > 0)
                {
                    this.field_148222_l.add(entitytype);
                }
            }
        }

        protected int func_148127_b()
        {
            return this.field_148222_l.size();
        }

        protected boolean func_148131_a(int p_148131_1_)
        {
            return false;
        }

        protected int func_148138_e()
        {
            return this.func_148127_b() * GuiStats.this.field_146289_q.field_78288_b * 4;
        }

        protected void func_148123_a()
        {
            GuiStats.this.func_146276_q_();
        }

        protected void func_192637_a(int p_192637_1_, int p_192637_2_, int p_192637_3_, int p_192637_4_, int p_192637_5_, int p_192637_6_, float p_192637_7_)
        {
            EntityType<?> entitytype = this.field_148222_l.get(p_192637_1_);
            String s = I18n.func_135052_a(Util.func_200697_a("entity", EntityType.func_200718_a(entitytype)));
            int i = GuiStats.this.field_146546_t.func_77444_a(StatList.field_199090_h.func_199076_b(entitytype));
            int j = GuiStats.this.field_146546_t.func_77444_a(StatList.field_199091_i.func_199076_b(entitytype));
            this.func_73731_b(GuiStats.this.field_146289_q, s, p_192637_2_ + 2 - 10, p_192637_3_ + 1, 16777215);
            this.func_73731_b(GuiStats.this.field_146289_q, this.func_199707_a(s, i), p_192637_2_ + 2, p_192637_3_ + 1 + GuiStats.this.field_146289_q.field_78288_b, i == 0 ? 6316128 : 9474192);
            this.func_73731_b(GuiStats.this.field_146289_q, this.func_199706_b(s, j), p_192637_2_ + 2, p_192637_3_ + 1 + GuiStats.this.field_146289_q.field_78288_b * 2, j == 0 ? 6316128 : 9474192);
        }

        private String func_199707_a(String p_199707_1_, int p_199707_2_)
        {
            String s = StatList.field_199090_h.func_199078_c();
            return p_199707_2_ == 0 ? I18n.func_135052_a(s + ".none", p_199707_1_) : I18n.func_135052_a(s, p_199707_2_, p_199707_1_);
        }

        private String func_199706_b(String p_199706_1_, int p_199706_2_)
        {
            String s = StatList.field_199091_i.func_199078_c();
            return p_199706_2_ == 0 ? I18n.func_135052_a(s + ".none", p_199706_1_) : I18n.func_135052_a(s, p_199706_1_, p_199706_2_);
        }
    }
}
