package net.minecraft.client.gui;

import java.util.Collections;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public abstract class GuiSlot extends GuiEventHandler
{
    protected final Minecraft field_148161_k;
    protected int field_148155_a;
    protected int field_148158_l;
    protected int field_148153_b;
    protected int field_148154_c;
    protected int field_148151_d;
    protected int field_148152_e;
    protected final int field_148149_f;
    protected boolean field_148163_i = true;
    protected int field_148157_o = -2;
    protected double field_148169_q;
    protected int field_148168_r;
    protected long field_148167_s = Long.MIN_VALUE;
    protected boolean field_178041_q = true;
    protected boolean field_148166_t = true;
    protected boolean field_148165_u;
    protected int field_148160_j;
    private boolean field_195084_v;

    public GuiSlot(Minecraft p_i1052_1_, int p_i1052_2_, int p_i1052_3_, int p_i1052_4_, int p_i1052_5_, int p_i1052_6_)
    {
        this.field_148161_k = p_i1052_1_;
        this.field_148155_a = p_i1052_2_;
        this.field_148158_l = p_i1052_3_;
        this.field_148153_b = p_i1052_4_;
        this.field_148154_c = p_i1052_5_;
        this.field_148149_f = p_i1052_6_;
        this.field_148152_e = 0;
        this.field_148151_d = p_i1052_2_;
    }

    public void func_148122_a(int p_148122_1_, int p_148122_2_, int p_148122_3_, int p_148122_4_)
    {
        this.field_148155_a = p_148122_1_;
        this.field_148158_l = p_148122_2_;
        this.field_148153_b = p_148122_3_;
        this.field_148154_c = p_148122_4_;
        this.field_148152_e = 0;
        this.field_148151_d = p_148122_1_;
    }

    public void func_193651_b(boolean p_193651_1_)
    {
        this.field_148166_t = p_193651_1_;
    }

    protected void func_148133_a(boolean p_148133_1_, int p_148133_2_)
    {
        this.field_148165_u = p_148133_1_;
        this.field_148160_j = p_148133_2_;

        if (!p_148133_1_)
        {
            this.field_148160_j = 0;
        }
    }

    public boolean func_195082_l()
    {
        return this.field_178041_q;
    }

    protected abstract int func_148127_b();

    public void func_195080_b(int p_195080_1_)
    {
    }

    protected List <? extends IGuiEventListener > func_195074_b()
    {
        return Collections.emptyList();
    }

    protected boolean func_195078_a(int p_195078_1_, int p_195078_2_, double p_195078_3_, double p_195078_5_)
    {
        return true;
    }

    protected abstract boolean func_148131_a(int p_148131_1_);

    protected int func_148138_e()
    {
        return this.func_148127_b() * this.field_148149_f + this.field_148160_j;
    }

    protected abstract void func_148123_a();

    protected void func_192639_a(int p_192639_1_, int p_192639_2_, int p_192639_3_, float p_192639_4_)
    {
    }

    protected abstract void func_192637_a(int p_192637_1_, int p_192637_2_, int p_192637_3_, int p_192637_4_, int p_192637_5_, int p_192637_6_, float p_192637_7_);

    protected void func_148129_a(int p_148129_1_, int p_148129_2_, Tessellator p_148129_3_)
    {
    }

    protected void func_148132_a(int p_148132_1_, int p_148132_2_)
    {
    }

    protected void func_148142_b(int p_148142_1_, int p_148142_2_)
    {
    }

    public int func_195083_a(double p_195083_1_, double p_195083_3_)
    {
        int i = this.field_148152_e + this.field_148155_a / 2 - this.func_148139_c() / 2;
        int j = this.field_148152_e + this.field_148155_a / 2 + this.func_148139_c() / 2;
        int k = MathHelper.func_76128_c(p_195083_3_ - (double)this.field_148153_b) - this.field_148160_j + (int)this.field_148169_q - 4;
        int l = k / this.field_148149_f;
        return p_195083_1_ < (double)this.func_148137_d() && p_195083_1_ >= (double)i && p_195083_1_ <= (double)j && l >= 0 && k >= 0 && l < this.func_148127_b() ? l : -1;
    }

    protected void func_148121_k()
    {
        this.field_148169_q = MathHelper.func_151237_a(this.field_148169_q, 0.0D, (double)this.func_148135_f());
    }

    public int func_148135_f()
    {
        return Math.max(0, this.func_148138_e() - (this.field_148154_c - this.field_148153_b - 4));
    }

    public int func_148148_g()
    {
        return (int)this.field_148169_q;
    }

    public boolean func_195079_b(double p_195079_1_, double p_195079_3_)
    {
        return p_195079_3_ >= (double)this.field_148153_b && p_195079_3_ <= (double)this.field_148154_c && p_195079_1_ >= (double)this.field_148152_e && p_195079_1_ <= (double)this.field_148151_d;
    }

    public void func_148145_f(int p_148145_1_)
    {
        this.field_148169_q += (double)p_148145_1_;
        this.func_148121_k();
        this.field_148157_o = -2;
    }

    public void func_148128_a(int p_148128_1_, int p_148128_2_, float p_148128_3_)
    {
        if (this.field_178041_q)
        {
            this.func_148123_a();
            int i = this.func_148137_d();
            int j = i + 6;
            this.func_148121_k();
            GlStateManager.func_179140_f();
            GlStateManager.func_179106_n();
            Tessellator tessellator = Tessellator.func_178181_a();
            BufferBuilder bufferbuilder = tessellator.func_178180_c();
            this.field_148161_k.func_110434_K().func_110577_a(Gui.field_110325_k);
            GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
            float f = 32.0F;
            bufferbuilder.func_181668_a(7, DefaultVertexFormats.field_181709_i);
            bufferbuilder.func_181662_b((double)this.field_148152_e, (double)this.field_148154_c, 0.0D).func_187315_a((double)((float)this.field_148152_e / 32.0F), (double)((float)(this.field_148154_c + (int)this.field_148169_q) / 32.0F)).func_181669_b(32, 32, 32, 255).func_181675_d();
            bufferbuilder.func_181662_b((double)this.field_148151_d, (double)this.field_148154_c, 0.0D).func_187315_a((double)((float)this.field_148151_d / 32.0F), (double)((float)(this.field_148154_c + (int)this.field_148169_q) / 32.0F)).func_181669_b(32, 32, 32, 255).func_181675_d();
            bufferbuilder.func_181662_b((double)this.field_148151_d, (double)this.field_148153_b, 0.0D).func_187315_a((double)((float)this.field_148151_d / 32.0F), (double)((float)(this.field_148153_b + (int)this.field_148169_q) / 32.0F)).func_181669_b(32, 32, 32, 255).func_181675_d();
            bufferbuilder.func_181662_b((double)this.field_148152_e, (double)this.field_148153_b, 0.0D).func_187315_a((double)((float)this.field_148152_e / 32.0F), (double)((float)(this.field_148153_b + (int)this.field_148169_q) / 32.0F)).func_181669_b(32, 32, 32, 255).func_181675_d();
            tessellator.func_78381_a();
            int k = this.field_148152_e + this.field_148155_a / 2 - this.func_148139_c() / 2 + 2;
            int l = this.field_148153_b + 4 - (int)this.field_148169_q;

            if (this.field_148165_u)
            {
                this.func_148129_a(k, l, tessellator);
            }

            this.func_192638_a(k, l, p_148128_1_, p_148128_2_, p_148128_3_);
            GlStateManager.func_179097_i();
            this.func_148136_c(0, this.field_148153_b, 255, 255);
            this.func_148136_c(this.field_148154_c, this.field_148158_l, 255, 255);
            GlStateManager.func_179147_l();
            GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ZERO, GlStateManager.DestFactor.ONE);
            GlStateManager.func_179118_c();
            GlStateManager.func_179103_j(7425);
            GlStateManager.func_179090_x();
            int i1 = 4;
            bufferbuilder.func_181668_a(7, DefaultVertexFormats.field_181709_i);
            bufferbuilder.func_181662_b((double)this.field_148152_e, (double)(this.field_148153_b + 4), 0.0D).func_187315_a(0.0D, 1.0D).func_181669_b(0, 0, 0, 0).func_181675_d();
            bufferbuilder.func_181662_b((double)this.field_148151_d, (double)(this.field_148153_b + 4), 0.0D).func_187315_a(1.0D, 1.0D).func_181669_b(0, 0, 0, 0).func_181675_d();
            bufferbuilder.func_181662_b((double)this.field_148151_d, (double)this.field_148153_b, 0.0D).func_187315_a(1.0D, 0.0D).func_181669_b(0, 0, 0, 255).func_181675_d();
            bufferbuilder.func_181662_b((double)this.field_148152_e, (double)this.field_148153_b, 0.0D).func_187315_a(0.0D, 0.0D).func_181669_b(0, 0, 0, 255).func_181675_d();
            tessellator.func_78381_a();
            bufferbuilder.func_181668_a(7, DefaultVertexFormats.field_181709_i);
            bufferbuilder.func_181662_b((double)this.field_148152_e, (double)this.field_148154_c, 0.0D).func_187315_a(0.0D, 1.0D).func_181669_b(0, 0, 0, 255).func_181675_d();
            bufferbuilder.func_181662_b((double)this.field_148151_d, (double)this.field_148154_c, 0.0D).func_187315_a(1.0D, 1.0D).func_181669_b(0, 0, 0, 255).func_181675_d();
            bufferbuilder.func_181662_b((double)this.field_148151_d, (double)(this.field_148154_c - 4), 0.0D).func_187315_a(1.0D, 0.0D).func_181669_b(0, 0, 0, 0).func_181675_d();
            bufferbuilder.func_181662_b((double)this.field_148152_e, (double)(this.field_148154_c - 4), 0.0D).func_187315_a(0.0D, 0.0D).func_181669_b(0, 0, 0, 0).func_181675_d();
            tessellator.func_78381_a();
            int j1 = this.func_148135_f();

            if (j1 > 0)
            {
                int k1 = (int)((float)((this.field_148154_c - this.field_148153_b) * (this.field_148154_c - this.field_148153_b)) / (float)this.func_148138_e());
                k1 = MathHelper.func_76125_a(k1, 32, this.field_148154_c - this.field_148153_b - 8);
                int l1 = (int)this.field_148169_q * (this.field_148154_c - this.field_148153_b - k1) / j1 + this.field_148153_b;

                if (l1 < this.field_148153_b)
                {
                    l1 = this.field_148153_b;
                }

                bufferbuilder.func_181668_a(7, DefaultVertexFormats.field_181709_i);
                bufferbuilder.func_181662_b((double)i, (double)this.field_148154_c, 0.0D).func_187315_a(0.0D, 1.0D).func_181669_b(0, 0, 0, 255).func_181675_d();
                bufferbuilder.func_181662_b((double)j, (double)this.field_148154_c, 0.0D).func_187315_a(1.0D, 1.0D).func_181669_b(0, 0, 0, 255).func_181675_d();
                bufferbuilder.func_181662_b((double)j, (double)this.field_148153_b, 0.0D).func_187315_a(1.0D, 0.0D).func_181669_b(0, 0, 0, 255).func_181675_d();
                bufferbuilder.func_181662_b((double)i, (double)this.field_148153_b, 0.0D).func_187315_a(0.0D, 0.0D).func_181669_b(0, 0, 0, 255).func_181675_d();
                tessellator.func_78381_a();
                bufferbuilder.func_181668_a(7, DefaultVertexFormats.field_181709_i);
                bufferbuilder.func_181662_b((double)i, (double)(l1 + k1), 0.0D).func_187315_a(0.0D, 1.0D).func_181669_b(128, 128, 128, 255).func_181675_d();
                bufferbuilder.func_181662_b((double)j, (double)(l1 + k1), 0.0D).func_187315_a(1.0D, 1.0D).func_181669_b(128, 128, 128, 255).func_181675_d();
                bufferbuilder.func_181662_b((double)j, (double)l1, 0.0D).func_187315_a(1.0D, 0.0D).func_181669_b(128, 128, 128, 255).func_181675_d();
                bufferbuilder.func_181662_b((double)i, (double)l1, 0.0D).func_187315_a(0.0D, 0.0D).func_181669_b(128, 128, 128, 255).func_181675_d();
                tessellator.func_78381_a();
                bufferbuilder.func_181668_a(7, DefaultVertexFormats.field_181709_i);
                bufferbuilder.func_181662_b((double)i, (double)(l1 + k1 - 1), 0.0D).func_187315_a(0.0D, 1.0D).func_181669_b(192, 192, 192, 255).func_181675_d();
                bufferbuilder.func_181662_b((double)(j - 1), (double)(l1 + k1 - 1), 0.0D).func_187315_a(1.0D, 1.0D).func_181669_b(192, 192, 192, 255).func_181675_d();
                bufferbuilder.func_181662_b((double)(j - 1), (double)l1, 0.0D).func_187315_a(1.0D, 0.0D).func_181669_b(192, 192, 192, 255).func_181675_d();
                bufferbuilder.func_181662_b((double)i, (double)l1, 0.0D).func_187315_a(0.0D, 0.0D).func_181669_b(192, 192, 192, 255).func_181675_d();
                tessellator.func_78381_a();
            }

            this.func_148142_b(p_148128_1_, p_148128_2_);
            GlStateManager.func_179098_w();
            GlStateManager.func_179103_j(7424);
            GlStateManager.func_179141_d();
            GlStateManager.func_179084_k();
        }
    }

    protected void func_195077_a(double p_195077_1_, double p_195077_3_, int p_195077_5_)
    {
        this.field_195084_v = p_195077_5_ == 0 && p_195077_1_ >= (double)this.func_148137_d() && p_195077_1_ < (double)(this.func_148137_d() + 6);
    }

    public boolean mouseClicked(double p_mouseClicked_1_, double p_mouseClicked_3_, int p_mouseClicked_5_)
    {
        this.func_195077_a(p_mouseClicked_1_, p_mouseClicked_3_, p_mouseClicked_5_);

        if (this.func_195082_l() && this.func_195079_b(p_mouseClicked_1_, p_mouseClicked_3_))
        {
            int i = this.func_195083_a(p_mouseClicked_1_, p_mouseClicked_3_);

            if (i == -1 && p_mouseClicked_5_ == 0)
            {
                this.func_148132_a((int)(p_mouseClicked_1_ - (double)(this.field_148152_e + this.field_148155_a / 2 - this.func_148139_c() / 2)), (int)(p_mouseClicked_3_ - (double)this.field_148153_b) + (int)this.field_148169_q - 4);
                return true;
            }
            else if (i != -1 && this.func_195078_a(i, p_mouseClicked_5_, p_mouseClicked_1_, p_mouseClicked_3_))
            {
                if (this.func_195074_b().size() > i)
                {
                    this.func_195073_a(this.func_195074_b().get(i));
                }

                this.func_195072_d(true);
                this.func_195080_b(i);
                return true;
            }
            else
            {
                return this.field_195084_v;
            }
        }
        else
        {
            return false;
        }
    }

    public boolean mouseReleased(double p_mouseReleased_1_, double p_mouseReleased_3_, int p_mouseReleased_5_)
    {
        if (this.getFocused() != null)
        {
            this.getFocused().mouseReleased(p_mouseReleased_1_, p_mouseReleased_3_, p_mouseReleased_5_);
        }

        this.func_195074_b().forEach((p_195081_5_) ->
        {
            p_195081_5_.mouseReleased(p_mouseReleased_1_, p_mouseReleased_3_, p_mouseReleased_5_);
        });
        return false;
    }

    public boolean mouseDragged(double p_mouseDragged_1_, double p_mouseDragged_3_, int p_mouseDragged_5_, double p_mouseDragged_6_, double p_mouseDragged_8_)
    {
        if (super.mouseDragged(p_mouseDragged_1_, p_mouseDragged_3_, p_mouseDragged_5_, p_mouseDragged_6_, p_mouseDragged_8_))
        {
            return true;
        }
        else if (this.func_195082_l() && p_mouseDragged_5_ == 0 && this.field_195084_v)
        {
            if (p_mouseDragged_3_ < (double)this.field_148153_b)
            {
                this.field_148169_q = 0.0D;
            }
            else if (p_mouseDragged_3_ > (double)this.field_148154_c)
            {
                this.field_148169_q = (double)this.func_148135_f();
            }
            else
            {
                double d0 = (double)this.func_148135_f();

                if (d0 < 1.0D)
                {
                    d0 = 1.0D;
                }

                int i = (int)((float)((this.field_148154_c - this.field_148153_b) * (this.field_148154_c - this.field_148153_b)) / (float)this.func_148138_e());
                i = MathHelper.func_76125_a(i, 32, this.field_148154_c - this.field_148153_b - 8);
                double d1 = d0 / (double)(this.field_148154_c - this.field_148153_b - i);

                if (d1 < 1.0D)
                {
                    d1 = 1.0D;
                }

                this.field_148169_q += p_mouseDragged_8_ * d1;
                this.func_148121_k();
            }

            return true;
        }
        else
        {
            return false;
        }
    }

    public boolean mouseScrolled(double p_mouseScrolled_1_)
    {
        if (!this.func_195082_l())
        {
            return false;
        }
        else
        {
            this.field_148169_q -= p_mouseScrolled_1_ * (double)this.field_148149_f / 2.0D;
            return true;
        }
    }

    public boolean keyPressed(int p_keyPressed_1_, int p_keyPressed_2_, int p_keyPressed_3_)
    {
        return !this.func_195082_l() ? false : super.keyPressed(p_keyPressed_1_, p_keyPressed_2_, p_keyPressed_3_);
    }

    public boolean charTyped(char p_charTyped_1_, int p_charTyped_2_)
    {
        return !this.func_195082_l() ? false : super.charTyped(p_charTyped_1_, p_charTyped_2_);
    }

    public int func_148139_c()
    {
        return 220;
    }

    protected void func_192638_a(int p_192638_1_, int p_192638_2_, int p_192638_3_, int p_192638_4_, float p_192638_5_)
    {
        int i = this.func_148127_b();
        Tessellator tessellator = Tessellator.func_178181_a();
        BufferBuilder bufferbuilder = tessellator.func_178180_c();

        for (int j = 0; j < i; ++j)
        {
            int k = p_192638_2_ + j * this.field_148149_f + this.field_148160_j;
            int l = this.field_148149_f - 4;

            if (k > this.field_148154_c || k + l < this.field_148153_b)
            {
                this.func_192639_a(j, p_192638_1_, k, p_192638_5_);
            }

            if (this.field_148166_t && this.func_148131_a(j))
            {
                int i1 = this.field_148152_e + this.field_148155_a / 2 - this.func_148139_c() / 2;
                int j1 = this.field_148152_e + this.field_148155_a / 2 + this.func_148139_c() / 2;
                GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
                GlStateManager.func_179090_x();
                bufferbuilder.func_181668_a(7, DefaultVertexFormats.field_181709_i);
                bufferbuilder.func_181662_b((double)i1, (double)(k + l + 2), 0.0D).func_187315_a(0.0D, 1.0D).func_181669_b(128, 128, 128, 255).func_181675_d();
                bufferbuilder.func_181662_b((double)j1, (double)(k + l + 2), 0.0D).func_187315_a(1.0D, 1.0D).func_181669_b(128, 128, 128, 255).func_181675_d();
                bufferbuilder.func_181662_b((double)j1, (double)(k - 2), 0.0D).func_187315_a(1.0D, 0.0D).func_181669_b(128, 128, 128, 255).func_181675_d();
                bufferbuilder.func_181662_b((double)i1, (double)(k - 2), 0.0D).func_187315_a(0.0D, 0.0D).func_181669_b(128, 128, 128, 255).func_181675_d();
                bufferbuilder.func_181662_b((double)(i1 + 1), (double)(k + l + 1), 0.0D).func_187315_a(0.0D, 1.0D).func_181669_b(0, 0, 0, 255).func_181675_d();
                bufferbuilder.func_181662_b((double)(j1 - 1), (double)(k + l + 1), 0.0D).func_187315_a(1.0D, 1.0D).func_181669_b(0, 0, 0, 255).func_181675_d();
                bufferbuilder.func_181662_b((double)(j1 - 1), (double)(k - 1), 0.0D).func_187315_a(1.0D, 0.0D).func_181669_b(0, 0, 0, 255).func_181675_d();
                bufferbuilder.func_181662_b((double)(i1 + 1), (double)(k - 1), 0.0D).func_187315_a(0.0D, 0.0D).func_181669_b(0, 0, 0, 255).func_181675_d();
                tessellator.func_78381_a();
                GlStateManager.func_179098_w();
            }

            this.func_192637_a(j, p_192638_1_, k, l, p_192638_3_, p_192638_4_, p_192638_5_);
        }
    }

    protected int func_148137_d()
    {
        return this.field_148155_a / 2 + 124;
    }

    protected void func_148136_c(int p_148136_1_, int p_148136_2_, int p_148136_3_, int p_148136_4_)
    {
        Tessellator tessellator = Tessellator.func_178181_a();
        BufferBuilder bufferbuilder = tessellator.func_178180_c();
        this.field_148161_k.func_110434_K().func_110577_a(Gui.field_110325_k);
        GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
        float f = 32.0F;
        bufferbuilder.func_181668_a(7, DefaultVertexFormats.field_181709_i);
        bufferbuilder.func_181662_b((double)this.field_148152_e, (double)p_148136_2_, 0.0D).func_187315_a(0.0D, (double)((float)p_148136_2_ / 32.0F)).func_181669_b(64, 64, 64, p_148136_4_).func_181675_d();
        bufferbuilder.func_181662_b((double)(this.field_148152_e + this.field_148155_a), (double)p_148136_2_, 0.0D).func_187315_a((double)((float)this.field_148155_a / 32.0F), (double)((float)p_148136_2_ / 32.0F)).func_181669_b(64, 64, 64, p_148136_4_).func_181675_d();
        bufferbuilder.func_181662_b((double)(this.field_148152_e + this.field_148155_a), (double)p_148136_1_, 0.0D).func_187315_a((double)((float)this.field_148155_a / 32.0F), (double)((float)p_148136_1_ / 32.0F)).func_181669_b(64, 64, 64, p_148136_3_).func_181675_d();
        bufferbuilder.func_181662_b((double)this.field_148152_e, (double)p_148136_1_, 0.0D).func_187315_a(0.0D, (double)((float)p_148136_1_ / 32.0F)).func_181669_b(64, 64, 64, p_148136_3_).func_181675_d();
        tessellator.func_78381_a();
    }

    public void func_148140_g(int p_148140_1_)
    {
        this.field_148152_e = p_148140_1_;
        this.field_148151_d = p_148140_1_ + this.field_148155_a;
    }

    public int func_148146_j()
    {
        return this.field_148149_f;
    }
}
