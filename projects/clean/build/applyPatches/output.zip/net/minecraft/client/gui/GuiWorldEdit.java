package net.minecraft.client.gui;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.toasts.GuiToast;
import net.minecraft.client.gui.toasts.SystemToast;
import net.minecraft.client.resources.I18n;
import net.minecraft.util.Util;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.world.storage.ISaveFormat;
import net.minecraft.world.storage.WorldInfo;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.apache.commons.io.FileUtils;

@OnlyIn(Dist.CLIENT)
public class GuiWorldEdit extends GuiScreen
{
    private GuiButton field_195327_a;
    private final GuiYesNoCallback field_184858_a;
    private GuiTextField field_184859_f;
    private final String field_184860_g;

    public GuiWorldEdit(GuiYesNoCallback p_i49848_1_, String p_i49848_2_)
    {
        this.field_184858_a = p_i49848_1_;
        this.field_184860_g = p_i49848_2_;
    }

    public void func_73876_c()
    {
        this.field_184859_f.func_146178_a();
    }

    protected void func_73866_w_()
    {
        this.field_146297_k.field_195559_v.func_197967_a(true);
        GuiButton guibutton = this.func_189646_b(new GuiButton(3, this.field_146294_l / 2 - 100, this.field_146295_m / 4 + 24 + 5, I18n.func_135052_a("selectWorld.edit.resetIcon"))
        {
            public void func_194829_a(double p_194829_1_, double p_194829_3_)
            {
                ISaveFormat isaveformat1 = GuiWorldEdit.this.field_146297_k.func_71359_d();
                FileUtils.deleteQuietly(isaveformat1.func_186352_b(GuiWorldEdit.this.field_184860_g, "icon.png"));
                this.field_146124_l = false;
            }
        });
        this.func_189646_b(new GuiButton(4, this.field_146294_l / 2 - 100, this.field_146295_m / 4 + 48 + 5, I18n.func_135052_a("selectWorld.edit.openFolder"))
        {
            public void func_194829_a(double p_194829_1_, double p_194829_3_)
            {
                ISaveFormat isaveformat1 = GuiWorldEdit.this.field_146297_k.func_71359_d();
                Util.func_110647_a().func_195641_a(isaveformat1.func_186352_b(GuiWorldEdit.this.field_184860_g, "icon.png").getParentFile());
            }
        });
        this.func_189646_b(new GuiButton(5, this.field_146294_l / 2 - 100, this.field_146295_m / 4 + 72 + 5, I18n.func_135052_a("selectWorld.edit.backup"))
        {
            public void func_194829_a(double p_194829_1_, double p_194829_3_)
            {
                ISaveFormat isaveformat1 = GuiWorldEdit.this.field_146297_k.func_71359_d();
                GuiWorldEdit.func_200212_a(isaveformat1, GuiWorldEdit.this.field_184860_g);
                GuiWorldEdit.this.field_184858_a.confirmResult(false, 0);
            }
        });
        this.func_189646_b(new GuiButton(6, this.field_146294_l / 2 - 100, this.field_146295_m / 4 + 96 + 5, I18n.func_135052_a("selectWorld.edit.backupFolder"))
        {
            public void func_194829_a(double p_194829_1_, double p_194829_3_)
            {
                ISaveFormat isaveformat1 = GuiWorldEdit.this.field_146297_k.func_71359_d();
                Path path = isaveformat1.func_197712_e();

                try
                {
                    Files.createDirectories(Files.exists(path) ? path.toRealPath() : path);
                }
                catch (IOException ioexception)
                {
                    throw new RuntimeException(ioexception);
                }

                Util.func_110647_a().func_195641_a(path.toFile());
            }
        });
        this.func_189646_b(new GuiButton(7, this.field_146294_l / 2 - 100, this.field_146295_m / 4 + 120 + 5, I18n.func_135052_a("selectWorld.edit.optimize"))
        {
            public void func_194829_a(double p_194829_1_, double p_194829_3_)
            {
                GuiWorldEdit.this.field_146297_k.func_147108_a(new GuiConfirmBackup(GuiWorldEdit.this, (p_212103_1_) ->
                {

                    if (p_212103_1_)
                    {
                        GuiWorldEdit.func_200212_a(GuiWorldEdit.this.field_146297_k.func_71359_d(), GuiWorldEdit.this.field_184860_g);
                    }

                    GuiWorldEdit.this.field_146297_k.func_147108_a(new GuiOptimizeWorld(GuiWorldEdit.this.field_184858_a, GuiWorldEdit.this.field_184860_g, GuiWorldEdit.this.field_146297_k.func_71359_d()));
                }, I18n.func_135052_a("optimizeWorld.confirm.title"), I18n.func_135052_a("optimizeWorld.confirm.description")));
            }
        });
        this.field_195327_a = this.func_189646_b(new GuiButton(0, this.field_146294_l / 2 - 100, this.field_146295_m / 4 + 144 + 5, 98, 20, I18n.func_135052_a("selectWorld.edit.save"))
        {
            public void func_194829_a(double p_194829_1_, double p_194829_3_)
            {
                GuiWorldEdit.this.func_195317_h();
            }
        });
        this.func_189646_b(new GuiButton(1, this.field_146294_l / 2 + 2, this.field_146295_m / 4 + 144 + 5, 98, 20, I18n.func_135052_a("gui.cancel"))
        {
            public void func_194829_a(double p_194829_1_, double p_194829_3_)
            {
                GuiWorldEdit.this.field_184858_a.confirmResult(false, 0);
            }
        });
        guibutton.field_146124_l = this.field_146297_k.func_71359_d().func_186352_b(this.field_184860_g, "icon.png").isFile();
        ISaveFormat isaveformat = this.field_146297_k.func_71359_d();
        WorldInfo worldinfo = isaveformat.func_75803_c(this.field_184860_g);
        String s = worldinfo == null ? "" : worldinfo.func_76065_j();
        this.field_184859_f = new GuiTextField(2, this.field_146289_q, this.field_146294_l / 2 - 100, 53, 200, 20);
        this.field_184859_f.func_146195_b(true);
        this.field_184859_f.func_146180_a(s);
        this.field_195124_j.add(this.field_184859_f);
    }

    public void func_175273_b(Minecraft p_175273_1_, int p_175273_2_, int p_175273_3_)
    {
        String s = this.field_184859_f.func_146179_b();
        this.func_146280_a(p_175273_1_, p_175273_2_, p_175273_3_);
        this.field_184859_f.func_146180_a(s);
    }

    public void func_146281_b()
    {
        this.field_146297_k.field_195559_v.func_197967_a(false);
    }

    private void func_195317_h()
    {
        ISaveFormat isaveformat = this.field_146297_k.func_71359_d();
        isaveformat.func_75806_a(this.field_184860_g, this.field_184859_f.func_146179_b().trim());
        this.field_184858_a.confirmResult(true, 0);
    }

    public static void func_200212_a(ISaveFormat p_200212_0_, String p_200212_1_)
    {
        GuiToast guitoast = Minecraft.func_71410_x().func_193033_an();
        long i = 0L;
        IOException ioexception = null;

        try
        {
            i = p_200212_0_.func_197713_h(p_200212_1_);
        }
        catch (IOException ioexception1)
        {
            ioexception = ioexception1;
        }

        ITextComponent itextcomponent;
        ITextComponent itextcomponent1;

        if (ioexception != null)
        {
            itextcomponent = new TextComponentTranslation("selectWorld.edit.backupFailed");
            itextcomponent1 = new TextComponentString(ioexception.getMessage());
        }
        else
        {
            itextcomponent = new TextComponentTranslation("selectWorld.edit.backupCreated", p_200212_1_);
            itextcomponent1 = new TextComponentTranslation("selectWorld.edit.backupSize", MathHelper.func_76143_f((double)i / 1048576.0D));
        }

        guitoast.func_192988_a(new SystemToast(SystemToast.Type.WORLD_BACKUP, itextcomponent, itextcomponent1));
    }

    public boolean charTyped(char p_charTyped_1_, int p_charTyped_2_)
    {
        if (this.field_184859_f.charTyped(p_charTyped_1_, p_charTyped_2_))
        {
            this.field_195327_a.field_146124_l = !this.field_184859_f.func_146179_b().trim().isEmpty();
            return true;
        }
        else
        {
            return false;
        }
    }

    public boolean keyPressed(int p_keyPressed_1_, int p_keyPressed_2_, int p_keyPressed_3_)
    {
        if (this.field_184859_f.keyPressed(p_keyPressed_1_, p_keyPressed_2_, p_keyPressed_3_))
        {
            this.field_195327_a.field_146124_l = !this.field_184859_f.func_146179_b().trim().isEmpty();
            return true;
        }
        else if (p_keyPressed_1_ != 257 && p_keyPressed_1_ != 335)
        {
            return false;
        }
        else
        {
            this.func_195317_h();
            return true;
        }
    }

    public void func_73863_a(int p_73863_1_, int p_73863_2_, float p_73863_3_)
    {
        this.func_146276_q_();
        this.func_73732_a(this.field_146289_q, I18n.func_135052_a("selectWorld.edit.title"), this.field_146294_l / 2, 20, 16777215);
        this.func_73731_b(this.field_146289_q, I18n.func_135052_a("selectWorld.enterName"), this.field_146294_l / 2 - 100, 40, 10526880);
        this.field_184859_f.func_195608_a(p_73863_1_, p_73863_2_, p_73863_3_);
        super.func_73863_a(p_73863_1_, p_73863_2_, p_73863_3_);
    }
}
