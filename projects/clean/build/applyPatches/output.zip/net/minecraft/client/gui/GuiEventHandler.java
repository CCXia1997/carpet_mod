package net.minecraft.client.gui;

import java.util.List;
import javax.annotation.Nullable;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public abstract class GuiEventHandler extends Gui implements IGuiEventListenerDeferred
{
    @Nullable
    private IGuiEventListener field_195075_a;
    private boolean field_195076_f;

    protected abstract List <? extends IGuiEventListener > func_195074_b();

    private final boolean func_195071_s()
    {
        return this.field_195076_f;
    }

    protected final void func_195072_d(boolean p_195072_1_)
    {
        this.field_195076_f = p_195072_1_;
    }

    @Nullable
    public IGuiEventListener getFocused()
    {
        return this.field_195075_a;
    }

    protected void func_195073_a(@Nullable IGuiEventListener p_195073_1_)
    {
        this.field_195075_a = p_195073_1_;
    }

    public boolean mouseClicked(double p_mouseClicked_1_, double p_mouseClicked_3_, int p_mouseClicked_5_)
    {
        for (IGuiEventListener iguieventlistener : this.func_195074_b())
        {
            boolean flag = iguieventlistener.mouseClicked(p_mouseClicked_1_, p_mouseClicked_3_, p_mouseClicked_5_);

            if (flag)
            {
                this.func_205725_b(iguieventlistener);

                if (p_mouseClicked_5_ == 0)
                {
                    this.func_195072_d(true);
                }

                return true;
            }
        }

        return false;
    }

    public boolean keyPressed(int p_keyPressed_1_, int p_keyPressed_2_, int p_keyPressed_3_)
    {
        return IGuiEventListenerDeferred.super.keyPressed(p_keyPressed_1_, p_keyPressed_2_, p_keyPressed_3_);
    }

    public boolean mouseDragged(double p_mouseDragged_1_, double p_mouseDragged_3_, int p_mouseDragged_5_, double p_mouseDragged_6_, double p_mouseDragged_8_)
    {
        return this.getFocused() != null && this.func_195071_s() && p_mouseDragged_5_ == 0 ? this.getFocused().mouseDragged(p_mouseDragged_1_, p_mouseDragged_3_, p_mouseDragged_5_, p_mouseDragged_6_, p_mouseDragged_8_) : false;
    }

    public boolean mouseReleased(double p_mouseReleased_1_, double p_mouseReleased_3_, int p_mouseReleased_5_)
    {
        this.func_195072_d(false);
        return IGuiEventListenerDeferred.super.mouseReleased(p_mouseReleased_1_, p_mouseReleased_3_, p_mouseReleased_5_);
    }

    public void func_205725_b(@Nullable IGuiEventListener p_205725_1_)
    {
        this.func_205728_a(p_205725_1_, this.func_195074_b().indexOf(this.getFocused()));
    }

    public void func_207714_t()
    {
        int i = this.func_195074_b().indexOf(this.getFocused());
        int j = i == -1 ? 0 : (i + 1) % this.func_195074_b().size();
        this.func_205728_a(this.func_207713_a(j), i);
    }

    @Nullable
    private IGuiEventListener func_207713_a(int p_207713_1_)
    {
        List <? extends IGuiEventListener > list = this.func_195074_b();
        int i = list.size();

        for (int j = 0; j < i; ++j)
        {
            IGuiEventListener iguieventlistener = list.get((p_207713_1_ + j) % i);

            if (iguieventlistener.func_207704_ae_())
            {
                return iguieventlistener;
            }
        }

        return null;
    }

    private void func_205728_a(@Nullable IGuiEventListener p_205728_1_, int p_205728_2_)
    {
        IGuiEventListener iguieventlistener = p_205728_2_ == -1 ? null : this.func_195074_b().get(p_205728_2_);

        if (iguieventlistener != p_205728_1_)
        {
            if (iguieventlistener != null)
            {
                iguieventlistener.func_205700_b(false);
            }

            if (p_205728_1_ != null)
            {
                p_205728_1_.func_205700_b(true);
            }

            this.func_195073_a(p_205728_1_);
        }
    }
}
