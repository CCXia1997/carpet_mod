package net.minecraft.client.gui.fonts.providers;

import com.google.common.collect.Maps;
import com.google.gson.JsonObject;
import java.io.IOException;
import java.util.Arrays;
import java.util.Map;
import javax.annotation.Nullable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.fonts.IGlyphInfo;
import net.minecraft.client.renderer.texture.NativeImage;
import net.minecraft.resources.IResource;
import net.minecraft.resources.IResourceManager;
import net.minecraft.util.JsonUtils;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@OnlyIn(Dist.CLIENT)
public class TextureGlyphProviderUnicode implements IGlyphProvider
{
    private static final Logger field_211256_a = LogManager.getLogger();
    private final IResourceManager field_211257_b;
    private final byte[] field_211258_c;
    private final String field_211259_d;
    private final Map<ResourceLocation, NativeImage> field_211845_e = Maps.newHashMap();

    public TextureGlyphProviderUnicode(IResourceManager p_i49737_1_, byte[] p_i49737_2_, String p_i49737_3_)
    {
        this.field_211257_b = p_i49737_1_;
        this.field_211258_c = p_i49737_2_;
        this.field_211259_d = p_i49737_3_;
        label322:

        for (int i = 0; i < 256; ++i)
        {
            char c0 = (char)(i * 256);
            ResourceLocation resourcelocation = this.func_211623_c(c0);

            try (
                    IResource iresource = this.field_211257_b.func_199002_a(resourcelocation);
                    NativeImage nativeimage = NativeImage.func_211679_a(NativeImage.PixelFormat.RGBA, iresource.func_199027_b());
                )
            {
                if (nativeimage.func_195702_a() == 256 && nativeimage.func_195714_b() == 256)
                {
                    int j = 0;

                    while (true)
                    {
                        if (j >= 256)
                        {
                            continue label322;
                        }

                        byte b0 = p_i49737_2_[c0 + j];

                        if (b0 != 0 && func_212453_a(b0) > func_212454_b(b0))
                        {
                            p_i49737_2_[c0 + j] = 0;
                        }

                        ++j;
                    }
                }
            }
            catch (IOException var43)
            {
                ;
            }

            Arrays.fill(p_i49737_2_, c0, c0 + 256, (byte)0);
        }
    }

    public void close()
    {
        this.field_211845_e.values().forEach(NativeImage::close);
    }

    private ResourceLocation func_211623_c(char p_211623_1_)
    {
        ResourceLocation resourcelocation = new ResourceLocation(String.format(this.field_211259_d, String.format("%02x", p_211623_1_ / 256)));
        return new ResourceLocation(resourcelocation.func_110624_b(), "textures/" + resourcelocation.func_110623_a());
    }

    @Nullable
    public IGlyphInfo func_212248_a(char p_212248_1_)
    {
        byte b0 = this.field_211258_c[p_212248_1_];

        if (b0 != 0)
        {
            NativeImage nativeimage = this.field_211845_e.computeIfAbsent(this.func_211623_c(p_212248_1_), this::func_211255_a);

            if (nativeimage != null)
            {
                int i = func_212453_a(b0);
                return new TextureGlyphProviderUnicode.GlpyhInfo(p_212248_1_ % 16 * 16 + i, (p_212248_1_ & 255) / 16 * 16, func_212454_b(b0) - i, 16, nativeimage);
            }
        }

        return null;
    }

    @Nullable
    private NativeImage func_211255_a(ResourceLocation p_211255_1_)
    {
        try (IResource iresource = this.field_211257_b.func_199002_a(p_211255_1_))
        {
            NativeImage nativeimage = NativeImage.func_211679_a(NativeImage.PixelFormat.RGBA, iresource.func_199027_b());
            return nativeimage;
        }
        catch (IOException ioexception)
        {
            field_211256_a.error("Couldn't load texture {}", p_211255_1_, ioexception);
            return null;
        }
    }

    private static int func_212453_a(byte p_212453_0_)
    {
        return p_212453_0_ >> 4 & 15;
    }

    private static int func_212454_b(byte p_212454_0_)
    {
        return (p_212454_0_ & 15) + 1;
    }

    @OnlyIn(Dist.CLIENT)
    public static class Factory implements IGlyphProviderFactory
        {
            private final ResourceLocation field_211247_a;
            private final String field_211248_b;

            public Factory(ResourceLocation p_i49760_1_, String p_i49760_2_)
            {
                this.field_211247_a = p_i49760_1_;
                this.field_211248_b = p_i49760_2_;
            }

            public static IGlyphProviderFactory func_211629_a(JsonObject p_211629_0_)
            {
                return new TextureGlyphProviderUnicode.Factory(new ResourceLocation(JsonUtils.func_151200_h(p_211629_0_, "sizes")), JsonUtils.func_151200_h(p_211629_0_, "template"));
            }

            @Nullable
            public IGlyphProvider func_211246_a(IResourceManager p_211246_1_)
            {
                try (IResource iresource = Minecraft.func_71410_x().func_195551_G().func_199002_a(this.field_211247_a))
                {
                    byte[] abyte = new byte[65536];
                    iresource.func_199027_b().read(abyte);
                    TextureGlyphProviderUnicode textureglyphproviderunicode = new TextureGlyphProviderUnicode(p_211246_1_, abyte, this.field_211248_b);
                    return textureglyphproviderunicode;
                }
                catch (IOException var17)
                {
                    TextureGlyphProviderUnicode.field_211256_a.error("Cannot load {}, unicode glyphs will not render correctly", (Object)this.field_211247_a);
                    return null;
                }
            }
        }

    @OnlyIn(Dist.CLIENT)
    static class GlpyhInfo implements IGlyphInfo
        {
            private final int field_211210_a;
            private final int field_211211_b;
            private final int field_211212_c;
            private final int field_211213_d;
            private final NativeImage field_211214_e;

            private GlpyhInfo(int p_i49758_1_, int p_i49758_2_, int p_i49758_3_, int p_i49758_4_, NativeImage p_i49758_5_)
            {
                this.field_211210_a = p_i49758_3_;
                this.field_211211_b = p_i49758_4_;
                this.field_211212_c = p_i49758_1_;
                this.field_211213_d = p_i49758_2_;
                this.field_211214_e = p_i49758_5_;
            }

            public float func_211578_g()
            {
                return 2.0F;
            }

            public int func_211202_a()
            {
                return this.field_211210_a;
            }

            public int func_211203_b()
            {
                return this.field_211211_b;
            }

            public float getAdvance()
            {
                return (float)(this.field_211210_a / 2 + 1);
            }

            public void func_211573_a(int p_211573_1_, int p_211573_2_)
            {
                this.field_211214_e.func_195706_a(0, p_211573_1_, p_211573_2_, this.field_211212_c, this.field_211213_d, this.field_211210_a, this.field_211211_b, false);
            }

            public boolean func_211579_f()
            {
                return this.field_211214_e.func_211678_c().func_211651_a() > 1;
            }

            public float getShadowOffset()
            {
                return 0.5F;
            }

            public float getBoldOffset()
            {
                return 0.5F;
            }
        }
}
