package net.minecraft.client.audio;

import com.google.common.collect.Lists;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.LinkedList;
import javax.sound.sampled.AudioFormat;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.lwjgl.BufferUtils;
import org.lwjgl.openal.AL10;
import paulscode.sound.Channel;
import paulscode.sound.FilenameURL;
import paulscode.sound.SoundBuffer;
import paulscode.sound.SoundSystemConfig;
import paulscode.sound.Source;

@OnlyIn(Dist.CLIENT)
public class SourceLWJGL3 extends Source
{
    private ChannelLWJGL3 field_195861_a;
    private IntBuffer field_195862_b;
    private FloatBuffer field_195863_c;
    private FloatBuffer field_195864_d;
    private FloatBuffer field_195865_e;

    public SourceLWJGL3(FloatBuffer p_i48107_1_, IntBuffer p_i48107_2_, boolean p_i48107_3_, boolean p_i48107_4_, boolean p_i48107_5_, String p_i48107_6_, FilenameURL p_i48107_7_, SoundBuffer p_i48107_8_, float p_i48107_9_, float p_i48107_10_, float p_i48107_11_, int p_i48107_12_, float p_i48107_13_, boolean p_i48107_14_)
    {
        super(p_i48107_3_, p_i48107_4_, p_i48107_5_, p_i48107_6_, p_i48107_7_, p_i48107_8_, p_i48107_9_, p_i48107_10_, p_i48107_11_, p_i48107_12_, p_i48107_13_, p_i48107_14_);
        this.field_195861_a = (ChannelLWJGL3)this.channel;

        if (this.codec != null)
        {
            this.codec.reverseByteOrder(true);
        }

        this.field_195863_c = p_i48107_1_;
        this.field_195862_b = p_i48107_2_;
        this.libraryType = LibraryLWJGL3.class;
        this.pitch = 1.0F;
        this.func_195858_b();
    }

    public SourceLWJGL3(FloatBuffer p_i48108_1_, IntBuffer p_i48108_2_, Source p_i48108_3_, SoundBuffer p_i48108_4_)
    {
        super(p_i48108_3_, p_i48108_4_);
        this.field_195861_a = (ChannelLWJGL3)this.channel;

        if (this.codec != null)
        {
            this.codec.reverseByteOrder(true);
        }

        this.field_195863_c = p_i48108_1_;
        this.field_195862_b = p_i48108_2_;
        this.libraryType = LibraryLWJGL3.class;
        this.pitch = 1.0F;
        this.func_195858_b();
    }

    public SourceLWJGL3(FloatBuffer p_i48109_1_, AudioFormat p_i48109_2_, boolean p_i48109_3_, String p_i48109_4_, float p_i48109_5_, float p_i48109_6_, float p_i48109_7_, int p_i48109_8_, float p_i48109_9_)
    {
        super(p_i48109_2_, p_i48109_3_, p_i48109_4_, p_i48109_5_, p_i48109_6_, p_i48109_7_, p_i48109_8_, p_i48109_9_);
        this.field_195861_a = (ChannelLWJGL3)this.channel;
        this.field_195863_c = p_i48109_1_;
        this.libraryType = LibraryLWJGL3.class;
        this.pitch = 1.0F;
        this.func_195858_b();
    }

    public boolean incrementSoundSequence()
    {
        if (!this.toStream)
        {
            this.errorMessage("Method 'incrementSoundSequence' may only be used for streaming sources.");
            return false;
        }
        else
        {
            synchronized (this.soundSequenceLock)
            {
                if (this.soundSequenceQueue != null && !this.soundSequenceQueue.isEmpty())
                {
                    this.filenameURL = this.soundSequenceQueue.remove(0);

                    if (this.codec != null)
                    {
                        this.codec.cleanup();
                    }

                    this.codec = SoundSystemConfig.getCodec(this.filenameURL.getFilename());

                    if (this.codec == null)
                    {
                        return true;
                    }
                    else
                    {
                        this.codec.reverseByteOrder(true);

                        if (this.codec.getAudioFormat() == null)
                        {
                            this.codec.initialize(this.filenameURL.getURL());
                        }

                        AudioFormat audioformat = this.codec.getAudioFormat();

                        if (audioformat == null)
                        {
                            this.errorMessage("Audio Format null in method 'incrementSoundSequence'");
                            return false;
                        }
                        else
                        {
                            int i;

                            if (audioformat.getChannels() == 1)
                            {
                                if (audioformat.getSampleSizeInBits() == 8)
                                {
                                    i = 4352;
                                }
                                else
                                {
                                    if (audioformat.getSampleSizeInBits() != 16)
                                    {
                                        this.errorMessage("Illegal sample size in method 'incrementSoundSequence'");
                                        return false;
                                    }

                                    i = 4353;
                                }
                            }
                            else
                            {
                                if (audioformat.getChannels() != 2)
                                {
                                    this.errorMessage("Audio data neither mono nor stereo in method 'incrementSoundSequence'");
                                    return false;
                                }

                                if (audioformat.getSampleSizeInBits() == 8)
                                {
                                    i = 4354;
                                }
                                else
                                {
                                    if (audioformat.getSampleSizeInBits() != 16)
                                    {
                                        this.errorMessage("Illegal sample size in method 'incrementSoundSequence'");
                                        return false;
                                    }

                                    i = 4355;
                                }
                            }

                            this.field_195861_a.func_195848_a(i, (int)audioformat.getSampleRate());
                            this.preLoad = true;
                            return true;
                        }
                    }
                }
                else
                {
                    return false;
                }
            }
        }
    }

    public void listenerMoved()
    {
        this.positionChanged();
    }

    public void setPosition(float p_setPosition_1_, float p_setPosition_2_, float p_setPosition_3_)
    {
        super.setPosition(p_setPosition_1_, p_setPosition_2_, p_setPosition_3_);

        if (this.field_195864_d == null)
        {
            this.func_195858_b();
        }
        else
        {
            this.positionChanged();
        }

        this.field_195864_d.put(0, p_setPosition_1_);
        this.field_195864_d.put(1, p_setPosition_2_);
        this.field_195864_d.put(2, p_setPosition_3_);

        if (this.channel != null && this.channel.attachedSource == this && this.field_195861_a != null && this.field_195861_a.field_195851_a != null)
        {
            AL10.alSourcefv(this.field_195861_a.field_195851_a.get(0), 4100, this.field_195864_d);
            this.func_195857_e();
        }
    }

    public void positionChanged()
    {
        this.func_195859_c();
        this.func_195860_d();

        if (this.channel != null && this.channel.attachedSource == this && this.field_195861_a != null && this.field_195861_a.field_195851_a != null)
        {
            AL10.alSourcef(this.field_195861_a.field_195851_a.get(0), 4106, this.gain * this.sourceVolume * Math.abs(this.fadeOutGain) * this.fadeInGain);
            this.func_195857_e();
        }

        this.func_195856_a();
    }

    private void func_195856_a()
    {
        if (this.channel != null && this.channel.attachedSource == this && LibraryLWJGL3.func_195836_a() && this.field_195861_a != null && this.field_195861_a.field_195851_a != null)
        {
            AL10.alSourcef(this.field_195861_a.field_195851_a.get(0), 4099, this.pitch);
            this.func_195857_e();
        }
    }

    public void setLooping(boolean p_setLooping_1_)
    {
        super.setLooping(p_setLooping_1_);

        if (this.channel != null && this.channel.attachedSource == this && this.field_195861_a != null && this.field_195861_a.field_195851_a != null)
        {
            AL10.alSourcei(this.field_195861_a.field_195851_a.get(0), 4103, p_setLooping_1_ ? 1 : 0);
            this.func_195857_e();
        }
    }

    public void setAttenuation(int p_setAttenuation_1_)
    {
        super.setAttenuation(p_setAttenuation_1_);

        if (this.channel != null && this.channel.attachedSource == this && this.field_195861_a != null && this.field_195861_a.field_195851_a != null)
        {
            if (p_setAttenuation_1_ == 1)
            {
                AL10.alSourcef(this.field_195861_a.field_195851_a.get(0), 4129, this.distOrRoll);
            }
            else
            {
                AL10.alSourcef(this.field_195861_a.field_195851_a.get(0), 4129, 0.0F);
            }

            this.func_195857_e();
        }
    }

    public void setDistOrRoll(float p_setDistOrRoll_1_)
    {
        super.setDistOrRoll(p_setDistOrRoll_1_);

        if (this.channel != null && this.channel.attachedSource == this && this.field_195861_a != null && this.field_195861_a.field_195851_a != null)
        {
            if (this.attModel == 1)
            {
                AL10.alSourcef(this.field_195861_a.field_195851_a.get(0), 4129, p_setDistOrRoll_1_);
            }
            else
            {
                AL10.alSourcef(this.field_195861_a.field_195851_a.get(0), 4129, 0.0F);
            }

            this.func_195857_e();
        }
    }

    public void setVelocity(float p_setVelocity_1_, float p_setVelocity_2_, float p_setVelocity_3_)
    {
        super.setVelocity(p_setVelocity_1_, p_setVelocity_2_, p_setVelocity_3_);
        this.field_195865_e = BufferUtils.createFloatBuffer(3).put(new float[] {p_setVelocity_1_, p_setVelocity_2_, p_setVelocity_3_});
        this.field_195865_e.flip();

        if (this.channel != null && this.channel.attachedSource == this && this.field_195861_a != null && this.field_195861_a.field_195851_a != null)
        {
            AL10.alSourcefv(this.field_195861_a.field_195851_a.get(0), 4102, this.field_195865_e);
            this.func_195857_e();
        }
    }

    public void setPitch(float p_setPitch_1_)
    {
        super.setPitch(p_setPitch_1_);
        this.func_195856_a();
    }

    public void play(Channel p_play_1_)
    {
        if (!this.active())
        {
            if (this.toLoop)
            {
                this.toPlay = true;
            }
        }
        else if (p_play_1_ == null)
        {
            this.errorMessage("Unable to play source, because channel was null");
        }
        else
        {
            boolean flag = this.channel != p_play_1_;

            if (this.channel != null && this.channel.attachedSource != this)
            {
                flag = true;
            }

            boolean flag1 = this.paused();
            super.play(p_play_1_);
            this.field_195861_a = (ChannelLWJGL3)this.channel;

            if (flag)
            {
                this.setPosition(this.position.x, this.position.y, this.position.z);
                this.func_195856_a();

                if (this.field_195861_a != null && this.field_195861_a.field_195851_a != null)
                {
                    if (LibraryLWJGL3.func_195836_a())
                    {
                        AL10.alSourcef(this.field_195861_a.field_195851_a.get(0), 4099, this.pitch);
                        this.func_195857_e();
                    }

                    AL10.alSourcefv(this.field_195861_a.field_195851_a.get(0), 4100, this.field_195864_d);
                    this.func_195857_e();
                    AL10.alSourcefv(this.field_195861_a.field_195851_a.get(0), 4102, this.field_195865_e);
                    this.func_195857_e();

                    if (this.attModel == 1)
                    {
                        AL10.alSourcef(this.field_195861_a.field_195851_a.get(0), 4129, this.distOrRoll);
                    }
                    else
                    {
                        AL10.alSourcef(this.field_195861_a.field_195851_a.get(0), 4129, 0.0F);
                    }

                    this.func_195857_e();

                    if (this.toLoop && !this.toStream)
                    {
                        AL10.alSourcei(this.field_195861_a.field_195851_a.get(0), 4103, 1);
                    }
                    else
                    {
                        AL10.alSourcei(this.field_195861_a.field_195851_a.get(0), 4103, 0);
                    }

                    this.func_195857_e();
                }

                if (!this.toStream)
                {
                    if (this.field_195862_b == null)
                    {
                        this.errorMessage("No sound buffer to play");
                        return;
                    }

                    this.field_195861_a.func_195847_a(this.field_195862_b);
                }
            }

            if (!this.playing())
            {
                if (this.toStream && !flag1)
                {
                    if (this.codec == null)
                    {
                        this.errorMessage("Decoder null in method 'play'");
                        return;
                    }

                    if (this.codec.getAudioFormat() == null)
                    {
                        this.codec.initialize(this.filenameURL.getURL());
                    }

                    AudioFormat audioformat = this.codec.getAudioFormat();

                    if (audioformat == null)
                    {
                        this.errorMessage("Audio Format null in method 'play'");
                        return;
                    }

                    int i;

                    if (audioformat.getChannels() == 1)
                    {
                        if (audioformat.getSampleSizeInBits() == 8)
                        {
                            i = 4352;
                        }
                        else
                        {
                            if (audioformat.getSampleSizeInBits() != 16)
                            {
                                this.errorMessage("Illegal sample size in method 'play'");
                                return;
                            }

                            i = 4353;
                        }
                    }
                    else
                    {
                        if (audioformat.getChannels() != 2)
                        {
                            this.errorMessage("Audio data neither mono nor stereo in method 'play'");
                            return;
                        }

                        if (audioformat.getSampleSizeInBits() == 8)
                        {
                            i = 4354;
                        }
                        else
                        {
                            if (audioformat.getSampleSizeInBits() != 16)
                            {
                                this.errorMessage("Illegal sample size in method 'play'");
                                return;
                            }

                            i = 4355;
                        }
                    }

                    this.field_195861_a.func_195848_a(i, (int)audioformat.getSampleRate());
                    this.preLoad = true;
                }

                this.channel.play();

                if (this.pitch != 1.0F)
                {
                    this.func_195856_a();
                }
            }
        }
    }

    public boolean preLoad()
    {
        if (this.codec == null)
        {
            return false;
        }
        else
        {
            this.codec.initialize(this.filenameURL.getURL());
            LinkedList<byte[]> linkedlist = Lists.newLinkedList();

            for (int i = 0; i < SoundSystemConfig.getNumberStreamingBuffers(); ++i)
            {
                this.soundBuffer = this.codec.read();

                if (this.soundBuffer == null || this.soundBuffer.audioData == null)
                {
                    break;
                }

                linkedlist.add(this.soundBuffer.audioData);
            }

            this.positionChanged();
            this.channel.preLoadBuffers(linkedlist);
            this.preLoad = false;
            return true;
        }
    }

    private void func_195858_b()
    {
        this.field_195864_d = BufferUtils.createFloatBuffer(3).put(new float[] {this.position.x, this.position.y, this.position.z});
        this.field_195865_e = BufferUtils.createFloatBuffer(3).put(new float[] {this.velocity.x, this.velocity.y, this.velocity.z});
        this.field_195864_d.flip();
        this.field_195865_e.flip();
        this.positionChanged();
    }

    private void func_195859_c()
    {
        if (this.field_195863_c != null)
        {
            double d0 = (double)(this.position.x - this.field_195863_c.get(0));
            double d1 = (double)(this.position.y - this.field_195863_c.get(1));
            double d2 = (double)(this.position.z - this.field_195863_c.get(2));
            this.distanceFromListener = (float)Math.sqrt(d0 * d0 + d1 * d1 + d2 * d2);
        }
    }

    private void func_195860_d()
    {
        if (this.attModel == 2)
        {
            if (this.distanceFromListener <= 0.0F)
            {
                this.gain = 1.0F;
            }
            else if (this.distanceFromListener >= this.distOrRoll)
            {
                this.gain = 0.0F;
            }
            else
            {
                this.gain = 1.0F - this.distanceFromListener / this.distOrRoll;
            }

            if (this.gain > 1.0F)
            {
                this.gain = 1.0F;
            }

            if (this.gain < 0.0F)
            {
                this.gain = 0.0F;
            }
        }
        else
        {
            this.gain = 1.0F;
        }
    }

    private boolean func_195857_e()
    {
        switch (AL10.alGetError())
        {
            case 0:
                return false;
            case 40961:
                this.errorMessage("Invalid name parameter.");
                return true;
            case 40962:
                this.errorMessage("Invalid parameter.");
                return true;
            case 40963:
                this.errorMessage("Invalid enumerated parameter value.");
                return true;
            case 40964:
                this.errorMessage("Illegal call.");
                return true;
            case 40965:
                this.errorMessage("Unable to allocate memory.");
                return true;
            default:
                this.errorMessage("An unrecognized error occurred.");
                return true;
        }
    }
}
