package net.minecraft.client.gui.inventory;

import javax.annotation.Nullable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButtonImage;
import net.minecraft.client.gui.IGuiEventListener;
import net.minecraft.client.gui.recipebook.GuiRecipeBook;
import net.minecraft.client.gui.recipebook.IRecipeShownListener;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.InventoryEffectRenderer;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.resources.I18n;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.ClickType;
import net.minecraft.inventory.ContainerRecipeBook;
import net.minecraft.inventory.Slot;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class GuiInventory extends InventoryEffectRenderer implements IRecipeShownListener
{
    private static final ResourceLocation field_201555_w = new ResourceLocation("textures/gui/recipe_button.png");
    private float field_147048_u;
    private float field_147047_v;
    private final GuiRecipeBook field_192045_A = new GuiRecipeBook();
    private boolean field_212353_B;
    private boolean field_192046_B;
    private boolean field_194031_B;

    public GuiInventory(EntityPlayer p_i1094_1_)
    {
        super(p_i1094_1_.field_71069_bz);
        this.field_146291_p = true;
    }

    public void func_73876_c()
    {
        if (this.field_146297_k.field_71442_b.func_78758_h())
        {
            this.field_146297_k.func_147108_a(new GuiContainerCreative(this.field_146297_k.field_71439_g));
        }
        else
        {
            this.field_192045_A.func_193957_d();
        }
    }

    protected void func_73866_w_()
    {
        if (this.field_146297_k.field_71442_b.func_78758_h())
        {
            this.field_146297_k.func_147108_a(new GuiContainerCreative(this.field_146297_k.field_71439_g));
        }
        else
        {
            super.func_73866_w_();
            this.field_192046_B = this.field_146294_l < 379;
            this.field_192045_A.func_201520_a(this.field_146294_l, this.field_146295_m, this.field_146297_k, this.field_192046_B, (ContainerRecipeBook)this.field_147002_h);
            this.field_212353_B = true;
            this.field_147003_i = this.field_192045_A.func_193011_a(this.field_192046_B, this.field_146294_l, this.field_146999_f);
            this.field_195124_j.add(this.field_192045_A);
            this.func_189646_b(new GuiButtonImage(10, this.field_147003_i + 104, this.field_146295_m / 2 - 22, 20, 18, 0, 0, 19, field_201555_w)
            {
                public void func_194829_a(double p_194829_1_, double p_194829_3_)
                {
                    GuiInventory.this.field_192045_A.func_201518_a(GuiInventory.this.field_192046_B);
                    GuiInventory.this.field_192045_A.func_191866_a();
                    GuiInventory.this.field_147003_i = GuiInventory.this.field_192045_A.func_193011_a(GuiInventory.this.field_192046_B, GuiInventory.this.field_146294_l, GuiInventory.this.field_146999_f);
                    this.func_191746_c(GuiInventory.this.field_147003_i + 104, GuiInventory.this.field_146295_m / 2 - 22);
                    GuiInventory.this.field_194031_B = true;
                }
            });
        }
    }

    @Nullable
    public IGuiEventListener getFocused()
    {
        return this.field_192045_A;
    }

    protected void func_146979_b(int p_146979_1_, int p_146979_2_)
    {
        this.field_146289_q.func_211126_b(I18n.func_135052_a("container.crafting"), 97.0F, 8.0F, 4210752);
    }

    public void func_73863_a(int p_73863_1_, int p_73863_2_, float p_73863_3_)
    {
        this.func_146276_q_();
        this.field_147045_u = !this.field_192045_A.func_191878_b();

        if (this.field_192045_A.func_191878_b() && this.field_192046_B)
        {
            this.func_146976_a(p_73863_3_, p_73863_1_, p_73863_2_);
            this.field_192045_A.func_191861_a(p_73863_1_, p_73863_2_, p_73863_3_);
        }
        else
        {
            this.field_192045_A.func_191861_a(p_73863_1_, p_73863_2_, p_73863_3_);
            super.func_73863_a(p_73863_1_, p_73863_2_, p_73863_3_);
            this.field_192045_A.func_191864_a(this.field_147003_i, this.field_147009_r, false, p_73863_3_);
        }

        this.func_191948_b(p_73863_1_, p_73863_2_);
        this.field_192045_A.func_191876_c(this.field_147003_i, this.field_147009_r, p_73863_1_, p_73863_2_);
        this.field_147048_u = (float)p_73863_1_;
        this.field_147047_v = (float)p_73863_2_;
    }

    protected void func_146976_a(float p_146976_1_, int p_146976_2_, int p_146976_3_)
    {
        GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
        this.field_146297_k.func_110434_K().func_110577_a(field_147001_a);
        int i = this.field_147003_i;
        int j = this.field_147009_r;
        this.func_73729_b(i, j, 0, 0, this.field_146999_f, this.field_147000_g);
        func_147046_a(i + 51, j + 75, 30, (float)(i + 51) - this.field_147048_u, (float)(j + 75 - 50) - this.field_147047_v, this.field_146297_k.field_71439_g);
    }

    public static void func_147046_a(int p_147046_0_, int p_147046_1_, int p_147046_2_, float p_147046_3_, float p_147046_4_, EntityLivingBase p_147046_5_)
    {
        GlStateManager.func_179142_g();
        GlStateManager.func_179094_E();
        GlStateManager.func_179109_b((float)p_147046_0_, (float)p_147046_1_, 50.0F);
        GlStateManager.func_179152_a((float)(-p_147046_2_), (float)p_147046_2_, (float)p_147046_2_);
        GlStateManager.func_179114_b(180.0F, 0.0F, 0.0F, 1.0F);
        float f = p_147046_5_.field_70761_aq;
        float f1 = p_147046_5_.field_70177_z;
        float f2 = p_147046_5_.field_70125_A;
        float f3 = p_147046_5_.field_70758_at;
        float f4 = p_147046_5_.field_70759_as;
        GlStateManager.func_179114_b(135.0F, 0.0F, 1.0F, 0.0F);
        RenderHelper.func_74519_b();
        GlStateManager.func_179114_b(-135.0F, 0.0F, 1.0F, 0.0F);
        GlStateManager.func_179114_b(-((float)Math.atan((double)(p_147046_4_ / 40.0F))) * 20.0F, 1.0F, 0.0F, 0.0F);
        p_147046_5_.field_70761_aq = (float)Math.atan((double)(p_147046_3_ / 40.0F)) * 20.0F;
        p_147046_5_.field_70177_z = (float)Math.atan((double)(p_147046_3_ / 40.0F)) * 40.0F;
        p_147046_5_.field_70125_A = -((float)Math.atan((double)(p_147046_4_ / 40.0F))) * 20.0F;
        p_147046_5_.field_70759_as = p_147046_5_.field_70177_z;
        p_147046_5_.field_70758_at = p_147046_5_.field_70177_z;
        GlStateManager.func_179109_b(0.0F, 0.0F, 0.0F);
        RenderManager rendermanager = Minecraft.func_71410_x().func_175598_ae();
        rendermanager.func_178631_a(180.0F);
        rendermanager.func_178633_a(false);
        rendermanager.func_188391_a(p_147046_5_, 0.0D, 0.0D, 0.0D, 0.0F, 1.0F, false);
        rendermanager.func_178633_a(true);
        p_147046_5_.field_70761_aq = f;
        p_147046_5_.field_70177_z = f1;
        p_147046_5_.field_70125_A = f2;
        p_147046_5_.field_70758_at = f3;
        p_147046_5_.field_70759_as = f4;
        GlStateManager.func_179121_F();
        RenderHelper.func_74518_a();
        GlStateManager.func_179101_C();
        GlStateManager.func_179138_g(OpenGlHelper.field_77476_b);
        GlStateManager.func_179090_x();
        GlStateManager.func_179138_g(OpenGlHelper.field_77478_a);
    }

    protected boolean func_195359_a(int p_195359_1_, int p_195359_2_, int p_195359_3_, int p_195359_4_, double p_195359_5_, double p_195359_7_)
    {
        return (!this.field_192046_B || !this.field_192045_A.func_191878_b()) && super.func_195359_a(p_195359_1_, p_195359_2_, p_195359_3_, p_195359_4_, p_195359_5_, p_195359_7_);
    }

    public boolean mouseClicked(double p_mouseClicked_1_, double p_mouseClicked_3_, int p_mouseClicked_5_)
    {
        if (this.field_192045_A.mouseClicked(p_mouseClicked_1_, p_mouseClicked_3_, p_mouseClicked_5_))
        {
            return true;
        }
        else
        {
            return this.field_192046_B && this.field_192045_A.func_191878_b() ? false : super.mouseClicked(p_mouseClicked_1_, p_mouseClicked_3_, p_mouseClicked_5_);
        }
    }

    public boolean mouseReleased(double p_mouseReleased_1_, double p_mouseReleased_3_, int p_mouseReleased_5_)
    {
        if (this.field_194031_B)
        {
            this.field_194031_B = false;
            return true;
        }
        else
        {
            return super.mouseReleased(p_mouseReleased_1_, p_mouseReleased_3_, p_mouseReleased_5_);
        }
    }

    protected boolean func_195361_a(double p_195361_1_, double p_195361_3_, int p_195361_5_, int p_195361_6_, int p_195361_7_)
    {
        boolean flag = p_195361_1_ < (double)p_195361_5_ || p_195361_3_ < (double)p_195361_6_ || p_195361_1_ >= (double)(p_195361_5_ + this.field_146999_f) || p_195361_3_ >= (double)(p_195361_6_ + this.field_147000_g);
        return this.field_192045_A.func_195604_a(p_195361_1_, p_195361_3_, this.field_147003_i, this.field_147009_r, this.field_146999_f, this.field_147000_g, p_195361_7_) && flag;
    }

    protected void func_184098_a(Slot p_184098_1_, int p_184098_2_, int p_184098_3_, ClickType p_184098_4_)
    {
        super.func_184098_a(p_184098_1_, p_184098_2_, p_184098_3_, p_184098_4_);
        this.field_192045_A.func_191874_a(p_184098_1_);
    }

    public void func_192043_J_()
    {
        this.field_192045_A.func_193948_e();
    }

    public void func_146281_b()
    {
        if (this.field_212353_B)
        {
            this.field_192045_A.func_191871_c();
        }

        super.func_146281_b();
    }

    public GuiRecipeBook func_194310_f()
    {
        return this.field_192045_A;
    }
}
