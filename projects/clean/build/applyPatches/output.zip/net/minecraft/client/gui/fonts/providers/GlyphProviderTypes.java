package net.minecraft.client.gui.fonts.providers;

import com.google.common.collect.Maps;
import com.google.gson.JsonObject;
import java.util.Map;
import java.util.function.Function;
import net.minecraft.util.Util;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public enum GlyphProviderTypes
{
    BITMAP("bitmap", TextureGlyphProvider.Factory::func_211633_a),
    TTF("ttf", TrueTypeGlyphProvider.Factory::func_211624_a),
    LEGACY_UNICODE("legacy_unicode", TextureGlyphProviderUnicode.Factory::func_211629_a);

    private static final Map<String, GlyphProviderTypes> field_211640_d = Util.func_200696_a(Maps.newHashMap(), (p_211639_0_) -> {

        for (GlyphProviderTypes glyphprovidertypes : values())
        {
            p_211639_0_.put(glyphprovidertypes.field_211641_e, glyphprovidertypes);
        }

    });
    private final String field_211641_e;
    private final Function<JsonObject, IGlyphProviderFactory> field_211642_f;

    private GlyphProviderTypes(String p_i49766_3_, Function<JsonObject, IGlyphProviderFactory> p_i49766_4_)
    {
        this.field_211641_e = p_i49766_3_;
        this.field_211642_f = p_i49766_4_;
    }

    public static GlyphProviderTypes func_211638_a(String p_211638_0_)
    {
        GlyphProviderTypes glyphprovidertypes = field_211640_d.get(p_211638_0_);

        if (glyphprovidertypes == null)
        {
            throw new IllegalArgumentException("Invalid type: " + p_211638_0_);
        }
        else
        {
            return glyphprovidertypes;
        }
    }

    public IGlyphProviderFactory func_211637_a(JsonObject p_211637_1_)
    {
        return this.field_211642_f.apply(p_211637_1_);
    }
}
