package net.minecraft.block;

import java.util.Random;
import java.util.stream.IntStream;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.fluid.Fluid;
import net.minecraft.fluid.IFluidState;
import net.minecraft.init.Blocks;
import net.minecraft.init.Fluids;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.pathfinding.PathType;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.DirectionProperty;
import net.minecraft.state.EnumProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.state.properties.Half;
import net.minecraft.state.properties.StairsShape;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.shapes.VoxelShapes;
import net.minecraft.world.Explosion;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.IWorldReader;
import net.minecraft.world.IWorldReaderBase;
import net.minecraft.world.World;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class BlockStairs extends Block implements IBucketPickupHandler, ILiquidContainer
{
    public static final DirectionProperty field_176309_a = BlockHorizontal.field_185512_D;
    public static final EnumProperty<Half> field_176308_b = BlockStateProperties.field_208164_Q;
    public static final EnumProperty<StairsShape> field_176310_M = BlockStateProperties.field_208146_au;
    public static final BooleanProperty field_204513_t = BlockStateProperties.field_208198_y;
    protected static final VoxelShape field_185712_d = BlockSlab.field_196507_c;
    protected static final VoxelShape field_185719_G = BlockSlab.field_196506_b;
    protected static final VoxelShape field_196512_A = Block.func_208617_a(0.0D, 0.0D, 0.0D, 8.0D, 8.0D, 8.0D);
    protected static final VoxelShape field_196513_B = Block.func_208617_a(0.0D, 0.0D, 8.0D, 8.0D, 8.0D, 16.0D);
    protected static final VoxelShape field_196514_C = Block.func_208617_a(0.0D, 8.0D, 0.0D, 8.0D, 16.0D, 8.0D);
    protected static final VoxelShape field_196515_D = Block.func_208617_a(0.0D, 8.0D, 8.0D, 8.0D, 16.0D, 16.0D);
    protected static final VoxelShape field_196516_E = Block.func_208617_a(8.0D, 0.0D, 0.0D, 16.0D, 8.0D, 8.0D);
    protected static final VoxelShape field_196517_F = Block.func_208617_a(8.0D, 0.0D, 8.0D, 16.0D, 8.0D, 16.0D);
    protected static final VoxelShape field_196518_G = Block.func_208617_a(8.0D, 8.0D, 0.0D, 16.0D, 16.0D, 8.0D);
    protected static final VoxelShape field_196519_H = Block.func_208617_a(8.0D, 8.0D, 8.0D, 16.0D, 16.0D, 16.0D);
    protected static final VoxelShape[] field_196520_I = func_199779_a(field_185712_d, field_196512_A, field_196516_E, field_196513_B, field_196517_F);
    protected static final VoxelShape[] field_196521_J = func_199779_a(field_185719_G, field_196514_C, field_196518_G, field_196515_D, field_196519_H);
    private static final int[] field_196522_K = new int[] {12, 5, 3, 10, 14, 13, 7, 11, 13, 7, 11, 14, 8, 4, 1, 2, 4, 1, 2, 8};
    private final Block field_150149_b;
    private final IBlockState field_150151_M;

    private static VoxelShape[] func_199779_a(VoxelShape p_199779_0_, VoxelShape p_199779_1_, VoxelShape p_199779_2_, VoxelShape p_199779_3_, VoxelShape p_199779_4_)
    {
        return IntStream.range(0, 16).mapToObj((p_199780_5_) ->
        {
            return func_199781_a(p_199780_5_, p_199779_0_, p_199779_1_, p_199779_2_, p_199779_3_, p_199779_4_);
        }).toArray((p_199778_0_) ->
        {
            return new VoxelShape[p_199778_0_];
        });
    }

    private static VoxelShape func_199781_a(int p_199781_0_, VoxelShape p_199781_1_, VoxelShape p_199781_2_, VoxelShape p_199781_3_, VoxelShape p_199781_4_, VoxelShape p_199781_5_)
    {
        VoxelShape voxelshape = p_199781_1_;

        if ((p_199781_0_ & 1) != 0)
        {
            voxelshape = VoxelShapes.func_197872_a(p_199781_1_, p_199781_2_);
        }

        if ((p_199781_0_ & 2) != 0)
        {
            voxelshape = VoxelShapes.func_197872_a(voxelshape, p_199781_3_);
        }

        if ((p_199781_0_ & 4) != 0)
        {
            voxelshape = VoxelShapes.func_197872_a(voxelshape, p_199781_4_);
        }

        if ((p_199781_0_ & 8) != 0)
        {
            voxelshape = VoxelShapes.func_197872_a(voxelshape, p_199781_5_);
        }

        return voxelshape;
    }

    protected BlockStairs(IBlockState p_i48321_1_, Block.Properties p_i48321_2_)
    {
        super(p_i48321_2_);
        this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_176309_a, EnumFacing.NORTH).func_206870_a(field_176308_b, Half.BOTTOM).func_206870_a(field_176310_M, StairsShape.STRAIGHT).func_206870_a(field_204513_t, Boolean.valueOf(false)));
        this.field_150149_b = p_i48321_1_.func_177230_c();
        this.field_150151_M = p_i48321_1_;
    }

    public int func_200011_d(IBlockState p_200011_1_, IBlockReader p_200011_2_, BlockPos p_200011_3_)
    {
        return p_200011_2_.func_201572_C();
    }

    public VoxelShape func_196244_b(IBlockState p_196244_1_, IBlockReader p_196244_2_, BlockPos p_196244_3_)
    {
        return (p_196244_1_.func_177229_b(field_176308_b) == Half.TOP ? field_196520_I : field_196521_J)[field_196522_K[this.func_196511_x(p_196244_1_)]];
    }

    private int func_196511_x(IBlockState p_196511_1_)
    {
        return p_196511_1_.func_177229_b(field_176310_M).ordinal() * 4 + p_196511_1_.func_177229_b(field_176309_a).func_176736_b();
    }

    public BlockFaceShape func_193383_a(IBlockReader p_193383_1_, IBlockState p_193383_2_, BlockPos p_193383_3_, EnumFacing p_193383_4_)
    {
        if (p_193383_4_.func_176740_k() == EnumFacing.Axis.Y)
        {
            return p_193383_4_ == EnumFacing.UP == (p_193383_2_.func_177229_b(field_176308_b) == Half.TOP) ? BlockFaceShape.SOLID : BlockFaceShape.UNDEFINED;
        }
        else
        {
            StairsShape stairsshape = p_193383_2_.func_177229_b(field_176310_M);

            if (stairsshape != StairsShape.OUTER_LEFT && stairsshape != StairsShape.OUTER_RIGHT)
            {
                EnumFacing enumfacing = p_193383_2_.func_177229_b(field_176309_a);

                switch (stairsshape)
                {
                    case STRAIGHT:
                        return enumfacing == p_193383_4_ ? BlockFaceShape.SOLID : BlockFaceShape.UNDEFINED;
                    case INNER_LEFT:
                        return enumfacing != p_193383_4_ && enumfacing != p_193383_4_.func_176746_e() ? BlockFaceShape.UNDEFINED : BlockFaceShape.SOLID;
                    case INNER_RIGHT:
                        return enumfacing != p_193383_4_ && enumfacing != p_193383_4_.func_176735_f() ? BlockFaceShape.UNDEFINED : BlockFaceShape.SOLID;
                    default:
                        return BlockFaceShape.UNDEFINED;
                }
            }
            else
            {
                return BlockFaceShape.UNDEFINED;
            }
        }
    }

    public boolean func_149686_d(IBlockState p_149686_1_)
    {
        return false;
    }

    @OnlyIn(Dist.CLIENT)
    public void func_180655_c(IBlockState p_180655_1_, World p_180655_2_, BlockPos p_180655_3_, Random p_180655_4_)
    {
        this.field_150149_b.func_180655_c(p_180655_1_, p_180655_2_, p_180655_3_, p_180655_4_);
    }

    public void func_196270_a(IBlockState p_196270_1_, World p_196270_2_, BlockPos p_196270_3_, EntityPlayer p_196270_4_)
    {
        this.field_150151_M.func_196942_a(p_196270_2_, p_196270_3_, p_196270_4_);
    }

    public void func_176206_d(IWorld p_176206_1_, BlockPos p_176206_2_, IBlockState p_176206_3_)
    {
        this.field_150149_b.func_176206_d(p_176206_1_, p_176206_2_, p_176206_3_);
    }

    @OnlyIn(Dist.CLIENT)
    public int func_185484_c(IBlockState p_185484_1_, IWorldReader p_185484_2_, BlockPos p_185484_3_)
    {
        return this.field_150151_M.func_185889_a(p_185484_2_, p_185484_3_);
    }

    public float func_149638_a()
    {
        return this.field_150149_b.func_149638_a();
    }

    public BlockRenderLayer func_180664_k()
    {
        return this.field_150149_b.func_180664_k();
    }

    public int func_149738_a(IWorldReaderBase p_149738_1_)
    {
        return this.field_150149_b.func_149738_a(p_149738_1_);
    }

    public boolean func_149703_v()
    {
        return this.field_150149_b.func_149703_v();
    }

    public boolean func_200293_a(IBlockState p_200293_1_)
    {
        return this.field_150149_b.func_200293_a(p_200293_1_);
    }

    public void func_196259_b(IBlockState p_196259_1_, World p_196259_2_, BlockPos p_196259_3_, IBlockState p_196259_4_)
    {
        if (p_196259_1_.func_177230_c() != p_196259_1_.func_177230_c())
        {
            this.field_150151_M.func_189546_a(p_196259_2_, p_196259_3_, Blocks.field_150350_a, p_196259_3_);
            this.field_150149_b.func_196259_b(this.field_150151_M, p_196259_2_, p_196259_3_, p_196259_4_);
        }
    }

    public void func_196243_a(IBlockState p_196243_1_, World p_196243_2_, BlockPos p_196243_3_, IBlockState p_196243_4_, boolean p_196243_5_)
    {
        if (p_196243_1_.func_177230_c() != p_196243_4_.func_177230_c())
        {
            this.field_150151_M.func_196947_b(p_196243_2_, p_196243_3_, p_196243_4_, p_196243_5_);
        }
    }

    public void func_176199_a(World p_176199_1_, BlockPos p_176199_2_, Entity p_176199_3_)
    {
        this.field_150149_b.func_176199_a(p_176199_1_, p_176199_2_, p_176199_3_);
    }

    public void func_196267_b(IBlockState p_196267_1_, World p_196267_2_, BlockPos p_196267_3_, Random p_196267_4_)
    {
        this.field_150149_b.func_196267_b(p_196267_1_, p_196267_2_, p_196267_3_, p_196267_4_);
    }

    public boolean func_196250_a(IBlockState p_196250_1_, World p_196250_2_, BlockPos p_196250_3_, EntityPlayer p_196250_4_, EnumHand p_196250_5_, EnumFacing p_196250_6_, float p_196250_7_, float p_196250_8_, float p_196250_9_)
    {
        return this.field_150151_M.func_196943_a(p_196250_2_, p_196250_3_, p_196250_4_, p_196250_5_, EnumFacing.DOWN, 0.0F, 0.0F, 0.0F);
    }

    public void func_180652_a(World p_180652_1_, BlockPos p_180652_2_, Explosion p_180652_3_)
    {
        this.field_150149_b.func_180652_a(p_180652_1_, p_180652_2_, p_180652_3_);
    }

    public boolean func_185481_k(IBlockState p_185481_1_)
    {
        return p_185481_1_.func_177229_b(field_176308_b) == Half.TOP;
    }

    public IBlockState func_196258_a(BlockItemUseContext p_196258_1_)
    {
        EnumFacing enumfacing = p_196258_1_.func_196000_l();
        IFluidState ifluidstate = p_196258_1_.func_195991_k().func_204610_c(p_196258_1_.func_195995_a());
        IBlockState iblockstate = this.func_176223_P().func_206870_a(field_176309_a, p_196258_1_.func_195992_f()).func_206870_a(field_176308_b, enumfacing != EnumFacing.DOWN && (enumfacing == EnumFacing.UP || !((double)p_196258_1_.func_195993_n() > 0.5D)) ? Half.BOTTOM : Half.TOP).func_206870_a(field_204513_t, Boolean.valueOf(ifluidstate.func_206886_c() == Fluids.field_204546_a));
        return iblockstate.func_206870_a(field_176310_M, func_208064_n(iblockstate, p_196258_1_.func_195991_k(), p_196258_1_.func_195995_a()));
    }

    public IBlockState func_196271_a(IBlockState p_196271_1_, EnumFacing p_196271_2_, IBlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_)
    {
        if (p_196271_1_.func_177229_b(field_204513_t))
        {
            p_196271_4_.func_205219_F_().func_205360_a(p_196271_5_, Fluids.field_204546_a, Fluids.field_204546_a.func_205569_a(p_196271_4_));
        }

        return p_196271_2_.func_176740_k().func_176722_c() ? p_196271_1_.func_206870_a(field_176310_M, func_208064_n(p_196271_1_, p_196271_4_, p_196271_5_)) : super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
    }

    private static StairsShape func_208064_n(IBlockState p_208064_0_, IBlockReader p_208064_1_, BlockPos p_208064_2_)
    {
        EnumFacing enumfacing = p_208064_0_.func_177229_b(field_176309_a);
        IBlockState iblockstate = p_208064_1_.func_180495_p(p_208064_2_.func_177972_a(enumfacing));

        if (func_185709_i(iblockstate) && p_208064_0_.func_177229_b(field_176308_b) == iblockstate.func_177229_b(field_176308_b))
        {
            EnumFacing enumfacing1 = iblockstate.func_177229_b(field_176309_a);

            if (enumfacing1.func_176740_k() != p_208064_0_.func_177229_b(field_176309_a).func_176740_k() && func_185704_d(p_208064_0_, p_208064_1_, p_208064_2_, enumfacing1.func_176734_d()))
            {
                if (enumfacing1 == enumfacing.func_176735_f())
                {
                    return StairsShape.OUTER_LEFT;
                }

                return StairsShape.OUTER_RIGHT;
            }
        }

        IBlockState iblockstate1 = p_208064_1_.func_180495_p(p_208064_2_.func_177972_a(enumfacing.func_176734_d()));

        if (func_185709_i(iblockstate1) && p_208064_0_.func_177229_b(field_176308_b) == iblockstate1.func_177229_b(field_176308_b))
        {
            EnumFacing enumfacing2 = iblockstate1.func_177229_b(field_176309_a);

            if (enumfacing2.func_176740_k() != p_208064_0_.func_177229_b(field_176309_a).func_176740_k() && func_185704_d(p_208064_0_, p_208064_1_, p_208064_2_, enumfacing2))
            {
                if (enumfacing2 == enumfacing.func_176735_f())
                {
                    return StairsShape.INNER_LEFT;
                }

                return StairsShape.INNER_RIGHT;
            }
        }

        return StairsShape.STRAIGHT;
    }

    private static boolean func_185704_d(IBlockState p_185704_0_, IBlockReader p_185704_1_, BlockPos p_185704_2_, EnumFacing p_185704_3_)
    {
        IBlockState iblockstate = p_185704_1_.func_180495_p(p_185704_2_.func_177972_a(p_185704_3_));
        return !func_185709_i(iblockstate) || iblockstate.func_177229_b(field_176309_a) != p_185704_0_.func_177229_b(field_176309_a) || iblockstate.func_177229_b(field_176308_b) != p_185704_0_.func_177229_b(field_176308_b);
    }

    public static boolean func_185709_i(IBlockState p_185709_0_)
    {
        return p_185709_0_.func_177230_c() instanceof BlockStairs;
    }

    public IBlockState func_185499_a(IBlockState p_185499_1_, Rotation p_185499_2_)
    {
        return p_185499_1_.func_206870_a(field_176309_a, p_185499_2_.func_185831_a(p_185499_1_.func_177229_b(field_176309_a)));
    }

    public IBlockState func_185471_a(IBlockState p_185471_1_, Mirror p_185471_2_)
    {
        EnumFacing enumfacing = p_185471_1_.func_177229_b(field_176309_a);
        StairsShape stairsshape = p_185471_1_.func_177229_b(field_176310_M);

        switch (p_185471_2_)
        {
            case LEFT_RIGHT:

                if (enumfacing.func_176740_k() == EnumFacing.Axis.Z)
                {
                    switch (stairsshape)
                    {
                        case INNER_LEFT:
                            return p_185471_1_.func_185907_a(Rotation.CLOCKWISE_180).func_206870_a(field_176310_M, StairsShape.INNER_RIGHT);
                        case INNER_RIGHT:
                            return p_185471_1_.func_185907_a(Rotation.CLOCKWISE_180).func_206870_a(field_176310_M, StairsShape.INNER_LEFT);
                        case OUTER_LEFT:
                            return p_185471_1_.func_185907_a(Rotation.CLOCKWISE_180).func_206870_a(field_176310_M, StairsShape.OUTER_RIGHT);
                        case OUTER_RIGHT:
                            return p_185471_1_.func_185907_a(Rotation.CLOCKWISE_180).func_206870_a(field_176310_M, StairsShape.OUTER_LEFT);
                        default:
                            return p_185471_1_.func_185907_a(Rotation.CLOCKWISE_180);
                    }
                }

                break;
            case FRONT_BACK:

                if (enumfacing.func_176740_k() == EnumFacing.Axis.X)
                {
                    switch (stairsshape)
                    {
                        case STRAIGHT:
                            return p_185471_1_.func_185907_a(Rotation.CLOCKWISE_180);
                        case INNER_LEFT:
                            return p_185471_1_.func_185907_a(Rotation.CLOCKWISE_180).func_206870_a(field_176310_M, StairsShape.INNER_LEFT);
                        case INNER_RIGHT:
                            return p_185471_1_.func_185907_a(Rotation.CLOCKWISE_180).func_206870_a(field_176310_M, StairsShape.INNER_RIGHT);
                        case OUTER_LEFT:
                            return p_185471_1_.func_185907_a(Rotation.CLOCKWISE_180).func_206870_a(field_176310_M, StairsShape.OUTER_RIGHT);
                        case OUTER_RIGHT:
                            return p_185471_1_.func_185907_a(Rotation.CLOCKWISE_180).func_206870_a(field_176310_M, StairsShape.OUTER_LEFT);
                    }
                }
        }

        return super.func_185471_a(p_185471_1_, p_185471_2_);
    }

    protected void func_206840_a(StateContainer.Builder<Block, IBlockState> p_206840_1_)
    {
        p_206840_1_.func_206894_a(field_176309_a, field_176308_b, field_176310_M, field_204513_t);
    }

    public Fluid func_204508_a(IWorld p_204508_1_, BlockPos p_204508_2_, IBlockState p_204508_3_)
    {
        if (p_204508_3_.func_177229_b(field_204513_t))
        {
            p_204508_1_.func_180501_a(p_204508_2_, p_204508_3_.func_206870_a(field_204513_t, Boolean.valueOf(false)), 3);
            return Fluids.field_204546_a;
        }
        else
        {
            return Fluids.field_204541_a;
        }
    }

    public IFluidState func_204507_t(IBlockState p_204507_1_)
    {
        return p_204507_1_.func_177229_b(field_204513_t) ? Fluids.field_204546_a.func_207204_a(false) : super.func_204507_t(p_204507_1_);
    }

    public boolean func_204510_a(IBlockReader p_204510_1_, BlockPos p_204510_2_, IBlockState p_204510_3_, Fluid p_204510_4_)
    {
        return !p_204510_3_.func_177229_b(field_204513_t) && p_204510_4_ == Fluids.field_204546_a;
    }

    public boolean func_204509_a(IWorld p_204509_1_, BlockPos p_204509_2_, IBlockState p_204509_3_, IFluidState p_204509_4_)
    {
        if (!p_204509_3_.func_177229_b(field_204513_t) && p_204509_4_.func_206886_c() == Fluids.field_204546_a)
        {
            if (!p_204509_1_.func_201670_d())
            {
                p_204509_1_.func_180501_a(p_204509_2_, p_204509_3_.func_206870_a(field_204513_t, Boolean.valueOf(true)), 3);
                p_204509_1_.func_205219_F_().func_205360_a(p_204509_2_, p_204509_4_.func_206886_c(), p_204509_4_.func_206886_c().func_205569_a(p_204509_1_));
            }

            return true;
        }
        else
        {
            return false;
        }
    }

    public boolean func_196266_a(IBlockState p_196266_1_, IBlockReader p_196266_2_, BlockPos p_196266_3_, PathType p_196266_4_)
    {
        return false;
    }
}
