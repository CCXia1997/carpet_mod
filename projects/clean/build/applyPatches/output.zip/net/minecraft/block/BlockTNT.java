package net.minecraft.block;

import javax.annotation.Nullable;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityTNTPrimed;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.Explosion;
import net.minecraft.world.World;

public class BlockTNT extends Block
{
    public static final BooleanProperty field_212569_a = BlockStateProperties.field_212646_x;

    public BlockTNT(Block.Properties p_i48309_1_)
    {
        super(p_i48309_1_);
        this.func_180632_j(this.func_176223_P().func_206870_a(field_212569_a, Boolean.valueOf(false)));
    }

    public void func_196259_b(IBlockState p_196259_1_, World p_196259_2_, BlockPos p_196259_3_, IBlockState p_196259_4_)
    {
        if (p_196259_4_.func_177230_c() != p_196259_1_.func_177230_c())
        {
            if (p_196259_2_.func_175640_z(p_196259_3_))
            {
                this.func_196534_a(p_196259_2_, p_196259_3_);
                p_196259_2_.func_175698_g(p_196259_3_);
            }
        }
    }

    public void func_189540_a(IBlockState p_189540_1_, World p_189540_2_, BlockPos p_189540_3_, Block p_189540_4_, BlockPos p_189540_5_)
    {
        if (p_189540_2_.func_175640_z(p_189540_3_))
        {
            this.func_196534_a(p_189540_2_, p_189540_3_);
            p_189540_2_.func_175698_g(p_189540_3_);
        }
    }

    public void func_196255_a(IBlockState p_196255_1_, World p_196255_2_, BlockPos p_196255_3_, float p_196255_4_, int p_196255_5_)
    {
        if (!p_196255_1_.func_177229_b(field_212569_a))
        {
            super.func_196255_a(p_196255_1_, p_196255_2_, p_196255_3_, p_196255_4_, p_196255_5_);
        }
    }

    public void func_176208_a(World p_176208_1_, BlockPos p_176208_2_, IBlockState p_176208_3_, EntityPlayer p_176208_4_)
    {
        if (!p_176208_1_.func_201670_d() && !p_176208_4_.func_184812_l_() && p_176208_3_.func_177229_b(field_212569_a))
        {
            this.func_196534_a(p_176208_1_, p_176208_2_);
        }

        super.func_176208_a(p_176208_1_, p_176208_2_, p_176208_3_, p_176208_4_);
    }

    public void func_180652_a(World p_180652_1_, BlockPos p_180652_2_, Explosion p_180652_3_)
    {
        if (!p_180652_1_.field_72995_K)
        {
            EntityTNTPrimed entitytntprimed = new EntityTNTPrimed(p_180652_1_, (double)((float)p_180652_2_.func_177958_n() + 0.5F), (double)p_180652_2_.func_177956_o(), (double)((float)p_180652_2_.func_177952_p() + 0.5F), p_180652_3_.func_94613_c());
            entitytntprimed.func_184534_a((short)(p_180652_1_.field_73012_v.nextInt(entitytntprimed.func_184536_l() / 4) + entitytntprimed.func_184536_l() / 8));
            p_180652_1_.func_72838_d(entitytntprimed);
        }
    }

    public void func_196534_a(World p_196534_1_, BlockPos p_196534_2_)
    {
        this.func_196535_a(p_196534_1_, p_196534_2_, (EntityLivingBase)null);
    }

    private void func_196535_a(World p_196535_1_, BlockPos p_196535_2_, @Nullable EntityLivingBase p_196535_3_)
    {
        if (!p_196535_1_.field_72995_K)
        {
            EntityTNTPrimed entitytntprimed = new EntityTNTPrimed(p_196535_1_, (double)((float)p_196535_2_.func_177958_n() + 0.5F), (double)p_196535_2_.func_177956_o(), (double)((float)p_196535_2_.func_177952_p() + 0.5F), p_196535_3_);
            p_196535_1_.func_72838_d(entitytntprimed);
            p_196535_1_.func_184148_a((EntityPlayer)null, entitytntprimed.field_70165_t, entitytntprimed.field_70163_u, entitytntprimed.field_70161_v, SoundEvents.field_187904_gd, SoundCategory.BLOCKS, 1.0F, 1.0F);
        }
    }

    public boolean func_196250_a(IBlockState p_196250_1_, World p_196250_2_, BlockPos p_196250_3_, EntityPlayer p_196250_4_, EnumHand p_196250_5_, EnumFacing p_196250_6_, float p_196250_7_, float p_196250_8_, float p_196250_9_)
    {
        ItemStack itemstack = p_196250_4_.func_184586_b(p_196250_5_);
        Item item = itemstack.func_77973_b();

        if (item != Items.field_151033_d && item != Items.field_151059_bz)
        {
            return super.func_196250_a(p_196250_1_, p_196250_2_, p_196250_3_, p_196250_4_, p_196250_5_, p_196250_6_, p_196250_7_, p_196250_8_, p_196250_9_);
        }
        else
        {
            this.func_196535_a(p_196250_2_, p_196250_3_, p_196250_4_);
            p_196250_2_.func_180501_a(p_196250_3_, Blocks.field_150350_a.func_176223_P(), 11);

            if (item == Items.field_151033_d)
            {
                itemstack.func_77972_a(1, p_196250_4_);
            }
            else
            {
                itemstack.func_190918_g(1);
            }

            return true;
        }
    }

    public void func_196262_a(IBlockState p_196262_1_, World p_196262_2_, BlockPos p_196262_3_, Entity p_196262_4_)
    {
        if (!p_196262_2_.field_72995_K && p_196262_4_ instanceof EntityArrow)
        {
            EntityArrow entityarrow = (EntityArrow)p_196262_4_;
            Entity entity = entityarrow.func_212360_k();

            if (entityarrow.func_70027_ad())
            {
                this.func_196535_a(p_196262_2_, p_196262_3_, entity instanceof EntityLivingBase ? (EntityLivingBase)entity : null);
                p_196262_2_.func_175698_g(p_196262_3_);
            }
        }
    }

    public boolean func_149659_a(Explosion p_149659_1_)
    {
        return false;
    }

    protected void func_206840_a(StateContainer.Builder<Block, IBlockState> p_206840_1_)
    {
        p_206840_1_.func_206894_a(field_212569_a);
    }
}
