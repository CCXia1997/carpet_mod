package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.particles.RedstoneParticleData;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.AttachFace;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.World;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class BlockLever extends BlockHorizontalFace
{
    public static final BooleanProperty field_176359_b = BlockStateProperties.field_208194_u;
    protected static final VoxelShape field_185692_c = Block.func_208617_a(5.0D, 4.0D, 10.0D, 11.0D, 12.0D, 16.0D);
    protected static final VoxelShape field_185693_d = Block.func_208617_a(5.0D, 4.0D, 0.0D, 11.0D, 12.0D, 6.0D);
    protected static final VoxelShape field_185694_e = Block.func_208617_a(10.0D, 4.0D, 5.0D, 16.0D, 12.0D, 11.0D);
    protected static final VoxelShape field_185695_f = Block.func_208617_a(0.0D, 4.0D, 5.0D, 6.0D, 12.0D, 11.0D);
    protected static final VoxelShape field_209348_r = Block.func_208617_a(5.0D, 0.0D, 4.0D, 11.0D, 6.0D, 12.0D);
    protected static final VoxelShape field_209349_s = Block.func_208617_a(4.0D, 0.0D, 5.0D, 12.0D, 6.0D, 11.0D);
    protected static final VoxelShape field_209350_t = Block.func_208617_a(5.0D, 10.0D, 4.0D, 11.0D, 16.0D, 12.0D);
    protected static final VoxelShape field_209351_u = Block.func_208617_a(4.0D, 10.0D, 5.0D, 12.0D, 16.0D, 11.0D);

    protected BlockLever(Block.Properties p_i48369_1_)
    {
        super(p_i48369_1_);
        this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_185512_D, EnumFacing.NORTH).func_206870_a(field_176359_b, Boolean.valueOf(false)).func_206870_a(field_196366_M, AttachFace.WALL));
    }

    public boolean func_149686_d(IBlockState p_149686_1_)
    {
        return false;
    }

    public VoxelShape func_196244_b(IBlockState p_196244_1_, IBlockReader p_196244_2_, BlockPos p_196244_3_)
    {
        switch ((AttachFace)p_196244_1_.func_177229_b(field_196366_M))
        {
            case FLOOR:

                switch (p_196244_1_.func_177229_b(field_185512_D).func_176740_k())
                {
                    case X:
                        return field_209349_s;
                    case Z:
                    default:
                        return field_209348_r;
                }

            case WALL:

                switch ((EnumFacing)p_196244_1_.func_177229_b(field_185512_D))
                {
                    case EAST:
                        return field_185695_f;
                    case WEST:
                        return field_185694_e;
                    case SOUTH:
                        return field_185693_d;
                    case NORTH:
                    default:
                        return field_185692_c;
                }

            case CEILING:
            default:

                switch (p_196244_1_.func_177229_b(field_185512_D).func_176740_k())
                {
                    case X:
                        return field_209351_u;
                    case Z:
                    default:
                        return field_209350_t;
                }
        }
    }

    public boolean func_196250_a(IBlockState p_196250_1_, World p_196250_2_, BlockPos p_196250_3_, EntityPlayer p_196250_4_, EnumHand p_196250_5_, EnumFacing p_196250_6_, float p_196250_7_, float p_196250_8_, float p_196250_9_)
    {
        p_196250_1_ = p_196250_1_.func_177231_a(field_176359_b);
        boolean flag = p_196250_1_.func_177229_b(field_176359_b);

        if (p_196250_2_.field_72995_K)
        {
            if (flag)
            {
                func_196379_a(p_196250_1_, p_196250_2_, p_196250_3_, 1.0F);
            }

            return true;
        }
        else
        {
            p_196250_2_.func_180501_a(p_196250_3_, p_196250_1_, 3);
            float f = flag ? 0.6F : 0.5F;
            p_196250_2_.func_184133_a((EntityPlayer)null, p_196250_3_, SoundEvents.field_187750_dc, SoundCategory.BLOCKS, 0.3F, f);
            this.func_196378_d(p_196250_1_, p_196250_2_, p_196250_3_);
            return true;
        }
    }

    private static void func_196379_a(IBlockState p_196379_0_, IWorld p_196379_1_, BlockPos p_196379_2_, float p_196379_3_)
    {
        EnumFacing enumfacing = p_196379_0_.func_177229_b(field_185512_D).func_176734_d();
        EnumFacing enumfacing1 = func_196365_i(p_196379_0_).func_176734_d();
        double d0 = (double)p_196379_2_.func_177958_n() + 0.5D + 0.1D * (double)enumfacing.func_82601_c() + 0.2D * (double)enumfacing1.func_82601_c();
        double d1 = (double)p_196379_2_.func_177956_o() + 0.5D + 0.1D * (double)enumfacing.func_96559_d() + 0.2D * (double)enumfacing1.func_96559_d();
        double d2 = (double)p_196379_2_.func_177952_p() + 0.5D + 0.1D * (double)enumfacing.func_82599_e() + 0.2D * (double)enumfacing1.func_82599_e();
        p_196379_1_.func_195594_a(new RedstoneParticleData(1.0F, 0.0F, 0.0F, p_196379_3_), d0, d1, d2, 0.0D, 0.0D, 0.0D);
    }

    @OnlyIn(Dist.CLIENT)
    public void func_180655_c(IBlockState p_180655_1_, World p_180655_2_, BlockPos p_180655_3_, Random p_180655_4_)
    {
        if (p_180655_1_.func_177229_b(field_176359_b) && p_180655_4_.nextFloat() < 0.25F)
        {
            func_196379_a(p_180655_1_, p_180655_2_, p_180655_3_, 0.5F);
        }
    }

    public void func_196243_a(IBlockState p_196243_1_, World p_196243_2_, BlockPos p_196243_3_, IBlockState p_196243_4_, boolean p_196243_5_)
    {
        if (!p_196243_5_ && p_196243_1_.func_177230_c() != p_196243_4_.func_177230_c())
        {
            if (p_196243_1_.func_177229_b(field_176359_b))
            {
                this.func_196378_d(p_196243_1_, p_196243_2_, p_196243_3_);
            }

            super.func_196243_a(p_196243_1_, p_196243_2_, p_196243_3_, p_196243_4_, p_196243_5_);
        }
    }

    public int func_180656_a(IBlockState p_180656_1_, IBlockReader p_180656_2_, BlockPos p_180656_3_, EnumFacing p_180656_4_)
    {
        return p_180656_1_.func_177229_b(field_176359_b) ? 15 : 0;
    }

    public int func_176211_b(IBlockState p_176211_1_, IBlockReader p_176211_2_, BlockPos p_176211_3_, EnumFacing p_176211_4_)
    {
        return p_176211_1_.func_177229_b(field_176359_b) && func_196365_i(p_176211_1_) == p_176211_4_ ? 15 : 0;
    }

    public boolean func_149744_f(IBlockState p_149744_1_)
    {
        return true;
    }

    private void func_196378_d(IBlockState p_196378_1_, World p_196378_2_, BlockPos p_196378_3_)
    {
        p_196378_2_.func_195593_d(p_196378_3_, this);
        p_196378_2_.func_195593_d(p_196378_3_.func_177972_a(func_196365_i(p_196378_1_).func_176734_d()), this);
    }

    protected void func_206840_a(StateContainer.Builder<Block, IBlockState> p_206840_1_)
    {
        p_206840_1_.func_206894_a(field_196366_M, field_185512_D, field_176359_b);
    }

    public BlockFaceShape func_193383_a(IBlockReader p_193383_1_, IBlockState p_193383_2_, BlockPos p_193383_3_, EnumFacing p_193383_4_)
    {
        return BlockFaceShape.UNDEFINED;
    }
}
