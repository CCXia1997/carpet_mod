package net.minecraft.block;

import net.minecraft.block.state.IBlockState;
import net.minecraft.state.DirectionProperty;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;

public abstract class BlockHorizontal extends Block
{
    public static final DirectionProperty field_185512_D = BlockStateProperties.field_208157_J;

    protected BlockHorizontal(Block.Properties p_i48377_1_)
    {
        super(p_i48377_1_);
    }

    public IBlockState func_185499_a(IBlockState p_185499_1_, Rotation p_185499_2_)
    {
        return p_185499_1_.func_206870_a(field_185512_D, p_185499_2_.func_185831_a(p_185499_1_.func_177229_b(field_185512_D)));
    }

    public IBlockState func_185471_a(IBlockState p_185471_1_, Mirror p_185471_2_)
    {
        return p_185471_1_.func_185907_a(p_185471_2_.func_185800_a(p_185471_1_.func_177229_b(field_185512_D)));
    }
}
