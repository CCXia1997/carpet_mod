package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.material.EnumPushReaction;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Particles;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.state.StateContainer;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.World;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class BlockEndRod extends BlockDirectional
{
    protected static final VoxelShape field_185630_a = Block.func_208617_a(6.0D, 0.0D, 6.0D, 10.0D, 16.0D, 10.0D);
    protected static final VoxelShape field_185631_b = Block.func_208617_a(6.0D, 6.0D, 0.0D, 10.0D, 10.0D, 16.0D);
    protected static final VoxelShape field_185632_c = Block.func_208617_a(0.0D, 6.0D, 6.0D, 16.0D, 10.0D, 10.0D);

    protected BlockEndRod(Block.Properties p_i48404_1_)
    {
        super(p_i48404_1_);
        this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_176387_N, EnumFacing.UP));
    }

    public IBlockState func_185499_a(IBlockState p_185499_1_, Rotation p_185499_2_)
    {
        return p_185499_1_.func_206870_a(field_176387_N, p_185499_2_.func_185831_a(p_185499_1_.func_177229_b(field_176387_N)));
    }

    public IBlockState func_185471_a(IBlockState p_185471_1_, Mirror p_185471_2_)
    {
        return p_185471_1_.func_206870_a(field_176387_N, p_185471_2_.func_185803_b(p_185471_1_.func_177229_b(field_176387_N)));
    }

    public VoxelShape func_196244_b(IBlockState p_196244_1_, IBlockReader p_196244_2_, BlockPos p_196244_3_)
    {
        switch (p_196244_1_.func_177229_b(field_176387_N).func_176740_k())
        {
            case X:
            default:
                return field_185632_c;
            case Z:
                return field_185631_b;
            case Y:
                return field_185630_a;
        }
    }

    public boolean func_149686_d(IBlockState p_149686_1_)
    {
        return false;
    }

    public IBlockState func_196258_a(BlockItemUseContext p_196258_1_)
    {
        EnumFacing enumfacing = p_196258_1_.func_196000_l();
        IBlockState iblockstate = p_196258_1_.func_195991_k().func_180495_p(p_196258_1_.func_195995_a().func_177972_a(enumfacing.func_176734_d()));
        return iblockstate.func_177230_c() == this && iblockstate.func_177229_b(field_176387_N) == enumfacing ? this.func_176223_P().func_206870_a(field_176387_N, enumfacing.func_176734_d()) : this.func_176223_P().func_206870_a(field_176387_N, enumfacing);
    }

    @OnlyIn(Dist.CLIENT)
    public void func_180655_c(IBlockState p_180655_1_, World p_180655_2_, BlockPos p_180655_3_, Random p_180655_4_)
    {
        EnumFacing enumfacing = p_180655_1_.func_177229_b(field_176387_N);
        double d0 = (double)p_180655_3_.func_177958_n() + 0.55D - (double)(p_180655_4_.nextFloat() * 0.1F);
        double d1 = (double)p_180655_3_.func_177956_o() + 0.55D - (double)(p_180655_4_.nextFloat() * 0.1F);
        double d2 = (double)p_180655_3_.func_177952_p() + 0.55D - (double)(p_180655_4_.nextFloat() * 0.1F);
        double d3 = (double)(0.4F - (p_180655_4_.nextFloat() + p_180655_4_.nextFloat()) * 0.4F);

        if (p_180655_4_.nextInt(5) == 0)
        {
            p_180655_2_.func_195594_a(Particles.field_197624_q, d0 + (double)enumfacing.func_82601_c() * d3, d1 + (double)enumfacing.func_96559_d() * d3, d2 + (double)enumfacing.func_82599_e() * d3, p_180655_4_.nextGaussian() * 0.005D, p_180655_4_.nextGaussian() * 0.005D, p_180655_4_.nextGaussian() * 0.005D);
        }
    }

    public BlockRenderLayer func_180664_k()
    {
        return BlockRenderLayer.CUTOUT;
    }

    protected void func_206840_a(StateContainer.Builder<Block, IBlockState> p_206840_1_)
    {
        p_206840_1_.func_206894_a(field_176387_N);
    }

    public EnumPushReaction func_149656_h(IBlockState p_149656_1_)
    {
        return EnumPushReaction.NORMAL;
    }

    public BlockFaceShape func_193383_a(IBlockReader p_193383_1_, IBlockState p_193383_2_, BlockPos p_193383_3_, EnumFacing p_193383_4_)
    {
        return BlockFaceShape.UNDEFINED;
    }
}
