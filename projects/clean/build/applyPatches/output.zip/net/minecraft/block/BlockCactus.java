package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.init.Blocks;
import net.minecraft.pathfinding.PathType;
import net.minecraft.state.IntegerProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.IWorldReaderBase;
import net.minecraft.world.World;

public class BlockCactus extends Block
{
    public static final IntegerProperty field_176587_a = BlockStateProperties.field_208171_X;
    protected static final VoxelShape field_196400_b = Block.func_208617_a(1.0D, 0.0D, 1.0D, 15.0D, 15.0D, 15.0D);
    protected static final VoxelShape field_196401_c = Block.func_208617_a(1.0D, 0.0D, 1.0D, 15.0D, 16.0D, 15.0D);

    protected BlockCactus(Block.Properties p_i48435_1_)
    {
        super(p_i48435_1_);
        this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_176587_a, Integer.valueOf(0)));
    }

    public void func_196267_b(IBlockState p_196267_1_, World p_196267_2_, BlockPos p_196267_3_, Random p_196267_4_)
    {
        if (!p_196267_1_.func_196955_c(p_196267_2_, p_196267_3_))
        {
            p_196267_2_.func_175655_b(p_196267_3_, true);
        }
        else
        {
            BlockPos blockpos = p_196267_3_.func_177984_a();

            if (p_196267_2_.func_175623_d(blockpos))
            {
                int i;

                for (i = 1; p_196267_2_.func_180495_p(p_196267_3_.func_177979_c(i)).func_177230_c() == this; ++i)
                {
                    ;
                }

                if (i < 3)
                {
                    int j = p_196267_1_.func_177229_b(field_176587_a);

                    if (j == 15)
                    {
                        p_196267_2_.func_175656_a(blockpos, this.func_176223_P());
                        IBlockState iblockstate = p_196267_1_.func_206870_a(field_176587_a, Integer.valueOf(0));
                        p_196267_2_.func_180501_a(p_196267_3_, iblockstate, 4);
                        iblockstate.func_189546_a(p_196267_2_, blockpos, this, p_196267_3_);
                    }
                    else
                    {
                        p_196267_2_.func_180501_a(p_196267_3_, p_196267_1_.func_206870_a(field_176587_a, Integer.valueOf(j + 1)), 4);
                    }
                }
            }
        }
    }

    public VoxelShape func_196268_f(IBlockState p_196268_1_, IBlockReader p_196268_2_, BlockPos p_196268_3_)
    {
        return field_196400_b;
    }

    public VoxelShape func_196244_b(IBlockState p_196244_1_, IBlockReader p_196244_2_, BlockPos p_196244_3_)
    {
        return field_196401_c;
    }

    public boolean func_200124_e(IBlockState p_200124_1_)
    {
        return true;
    }

    public boolean func_149686_d(IBlockState p_149686_1_)
    {
        return false;
    }

    public IBlockState func_196271_a(IBlockState p_196271_1_, EnumFacing p_196271_2_, IBlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_)
    {
        if (!p_196271_1_.func_196955_c(p_196271_4_, p_196271_5_))
        {
            p_196271_4_.func_205220_G_().func_205360_a(p_196271_5_, this, 1);
        }

        return super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
    }

    public boolean func_196260_a(IBlockState p_196260_1_, IWorldReaderBase p_196260_2_, BlockPos p_196260_3_)
    {
        for (EnumFacing enumfacing : EnumFacing.Plane.HORIZONTAL)
        {
            IBlockState iblockstate = p_196260_2_.func_180495_p(p_196260_3_.func_177972_a(enumfacing));
            Material material = iblockstate.func_185904_a();

            if (material.func_76220_a() || p_196260_2_.func_204610_c(p_196260_3_.func_177972_a(enumfacing)).func_206884_a(FluidTags.field_206960_b))
            {
                return false;
            }
        }

        Block block = p_196260_2_.func_180495_p(p_196260_3_.func_177977_b()).func_177230_c();
        return (block == Blocks.field_150434_aF || block == Blocks.field_150354_m || block == Blocks.field_196611_F) && !p_196260_2_.func_180495_p(p_196260_3_.func_177984_a()).func_185904_a().func_76224_d();
    }

    public void func_196262_a(IBlockState p_196262_1_, World p_196262_2_, BlockPos p_196262_3_, Entity p_196262_4_)
    {
        p_196262_4_.func_70097_a(DamageSource.field_76367_g, 1.0F);
    }

    public BlockRenderLayer func_180664_k()
    {
        return BlockRenderLayer.CUTOUT;
    }

    protected void func_206840_a(StateContainer.Builder<Block, IBlockState> p_206840_1_)
    {
        p_206840_1_.func_206894_a(field_176587_a);
    }

    public BlockFaceShape func_193383_a(IBlockReader p_193383_1_, IBlockState p_193383_2_, BlockPos p_193383_3_, EnumFacing p_193383_4_)
    {
        return BlockFaceShape.UNDEFINED;
    }

    public boolean func_196266_a(IBlockState p_196266_1_, IBlockReader p_196266_2_, BlockPos p_196266_3_, PathType p_196266_4_)
    {
        return false;
    }
}
