package net.minecraft.block.trees;

import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.gen.feature.AbstractTreeFeature;
import net.minecraft.world.gen.feature.IFeatureConfig;
import net.minecraft.world.gen.feature.NoFeatureConfig;

public abstract class AbstractBigTree extends AbstractTree
{
    public boolean func_196935_a(IWorld p_196935_1_, BlockPos p_196935_2_, IBlockState p_196935_3_, Random p_196935_4_)
    {
        for (int i = 0; i >= -1; --i)
        {
            for (int j = 0; j >= -1; --j)
            {
                if (func_196937_a(p_196935_3_, p_196935_1_, p_196935_2_, i, j))
                {
                    return this.func_196939_a(p_196935_1_, p_196935_2_, p_196935_3_, p_196935_4_, i, j);
                }
            }
        }

        return super.func_196935_a(p_196935_1_, p_196935_2_, p_196935_3_, p_196935_4_);
    }

    @Nullable
    protected abstract AbstractTreeFeature<NoFeatureConfig> func_196938_a(Random p_196938_1_);

    public boolean func_196939_a(IWorld p_196939_1_, BlockPos p_196939_2_, IBlockState p_196939_3_, Random p_196939_4_, int p_196939_5_, int p_196939_6_)
    {
        AbstractTreeFeature<NoFeatureConfig> abstracttreefeature = this.func_196938_a(p_196939_4_);

        if (abstracttreefeature == null)
        {
            return false;
        }
        else
        {
            IBlockState iblockstate = Blocks.field_150350_a.func_176223_P();
            p_196939_1_.func_180501_a(p_196939_2_.func_177982_a(p_196939_5_, 0, p_196939_6_), iblockstate, 4);
            p_196939_1_.func_180501_a(p_196939_2_.func_177982_a(p_196939_5_ + 1, 0, p_196939_6_), iblockstate, 4);
            p_196939_1_.func_180501_a(p_196939_2_.func_177982_a(p_196939_5_, 0, p_196939_6_ + 1), iblockstate, 4);
            p_196939_1_.func_180501_a(p_196939_2_.func_177982_a(p_196939_5_ + 1, 0, p_196939_6_ + 1), iblockstate, 4);

            if (abstracttreefeature.func_212245_a(p_196939_1_, p_196939_1_.func_72863_F().func_201711_g(), p_196939_4_, p_196939_2_.func_177982_a(p_196939_5_, 0, p_196939_6_), IFeatureConfig.field_202429_e))
            {
                return true;
            }
            else
            {
                p_196939_1_.func_180501_a(p_196939_2_.func_177982_a(p_196939_5_, 0, p_196939_6_), p_196939_3_, 4);
                p_196939_1_.func_180501_a(p_196939_2_.func_177982_a(p_196939_5_ + 1, 0, p_196939_6_), p_196939_3_, 4);
                p_196939_1_.func_180501_a(p_196939_2_.func_177982_a(p_196939_5_, 0, p_196939_6_ + 1), p_196939_3_, 4);
                p_196939_1_.func_180501_a(p_196939_2_.func_177982_a(p_196939_5_ + 1, 0, p_196939_6_ + 1), p_196939_3_, 4);
                return false;
            }
        }
    }

    public static boolean func_196937_a(IBlockState p_196937_0_, IBlockReader p_196937_1_, BlockPos p_196937_2_, int p_196937_3_, int p_196937_4_)
    {
        Block block = p_196937_0_.func_177230_c();
        return block == p_196937_1_.func_180495_p(p_196937_2_.func_177982_a(p_196937_3_, 0, p_196937_4_)).func_177230_c() && block == p_196937_1_.func_180495_p(p_196937_2_.func_177982_a(p_196937_3_ + 1, 0, p_196937_4_)).func_177230_c() && block == p_196937_1_.func_180495_p(p_196937_2_.func_177982_a(p_196937_3_, 0, p_196937_4_ + 1)).func_177230_c() && block == p_196937_1_.func_180495_p(p_196937_2_.func_177982_a(p_196937_3_ + 1, 0, p_196937_4_ + 1)).func_177230_c();
    }
}
