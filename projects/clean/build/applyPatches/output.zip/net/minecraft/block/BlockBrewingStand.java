package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Particles;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.InventoryHelper;
import net.minecraft.item.ItemStack;
import net.minecraft.pathfinding.PathType;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.stats.StatList;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityBrewingStand;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.EnumBlockRenderType;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.shapes.VoxelShapes;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.World;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class BlockBrewingStand extends BlockContainer
{
    public static final BooleanProperty[] field_176451_a = new BooleanProperty[] {BlockStateProperties.field_208184_k, BlockStateProperties.field_208185_l, BlockStateProperties.field_208186_m};
    protected static final VoxelShape field_196308_b = VoxelShapes.func_197872_a(Block.func_208617_a(1.0D, 0.0D, 1.0D, 15.0D, 2.0D, 15.0D), Block.func_208617_a(7.0D, 0.0D, 7.0D, 9.0D, 14.0D, 9.0D));

    public BlockBrewingStand(Block.Properties p_i48438_1_)
    {
        super(p_i48438_1_);
        this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_176451_a[0], Boolean.valueOf(false)).func_206870_a(field_176451_a[1], Boolean.valueOf(false)).func_206870_a(field_176451_a[2], Boolean.valueOf(false)));
    }

    public EnumBlockRenderType func_149645_b(IBlockState p_149645_1_)
    {
        return EnumBlockRenderType.MODEL;
    }

    public TileEntity func_196283_a_(IBlockReader p_196283_1_)
    {
        return new TileEntityBrewingStand();
    }

    public boolean func_149686_d(IBlockState p_149686_1_)
    {
        return false;
    }

    public VoxelShape func_196244_b(IBlockState p_196244_1_, IBlockReader p_196244_2_, BlockPos p_196244_3_)
    {
        return field_196308_b;
    }

    public boolean func_196250_a(IBlockState p_196250_1_, World p_196250_2_, BlockPos p_196250_3_, EntityPlayer p_196250_4_, EnumHand p_196250_5_, EnumFacing p_196250_6_, float p_196250_7_, float p_196250_8_, float p_196250_9_)
    {
        if (p_196250_2_.field_72995_K)
        {
            return true;
        }
        else
        {
            TileEntity tileentity = p_196250_2_.func_175625_s(p_196250_3_);

            if (tileentity instanceof TileEntityBrewingStand)
            {
                p_196250_4_.func_71007_a((TileEntityBrewingStand)tileentity);
                p_196250_4_.func_195066_a(StatList.field_188081_O);
            }

            return true;
        }
    }

    public void func_180633_a(World p_180633_1_, BlockPos p_180633_2_, IBlockState p_180633_3_, EntityLivingBase p_180633_4_, ItemStack p_180633_5_)
    {
        if (p_180633_5_.func_82837_s())
        {
            TileEntity tileentity = p_180633_1_.func_175625_s(p_180633_2_);

            if (tileentity instanceof TileEntityBrewingStand)
            {
                ((TileEntityBrewingStand)tileentity).func_200224_a(p_180633_5_.func_200301_q());
            }
        }
    }

    @OnlyIn(Dist.CLIENT)
    public void func_180655_c(IBlockState p_180655_1_, World p_180655_2_, BlockPos p_180655_3_, Random p_180655_4_)
    {
        double d0 = (double)((float)p_180655_3_.func_177958_n() + 0.4F + p_180655_4_.nextFloat() * 0.2F);
        double d1 = (double)((float)p_180655_3_.func_177956_o() + 0.7F + p_180655_4_.nextFloat() * 0.3F);
        double d2 = (double)((float)p_180655_3_.func_177952_p() + 0.4F + p_180655_4_.nextFloat() * 0.2F);
        p_180655_2_.func_195594_a(Particles.field_197601_L, d0, d1, d2, 0.0D, 0.0D, 0.0D);
    }

    public void func_196243_a(IBlockState p_196243_1_, World p_196243_2_, BlockPos p_196243_3_, IBlockState p_196243_4_, boolean p_196243_5_)
    {
        if (p_196243_1_.func_177230_c() != p_196243_4_.func_177230_c())
        {
            TileEntity tileentity = p_196243_2_.func_175625_s(p_196243_3_);

            if (tileentity instanceof TileEntityBrewingStand)
            {
                InventoryHelper.func_180175_a(p_196243_2_, p_196243_3_, (TileEntityBrewingStand)tileentity);
            }

            super.func_196243_a(p_196243_1_, p_196243_2_, p_196243_3_, p_196243_4_, p_196243_5_);
        }
    }

    public boolean func_149740_M(IBlockState p_149740_1_)
    {
        return true;
    }

    public int func_180641_l(IBlockState p_180641_1_, World p_180641_2_, BlockPos p_180641_3_)
    {
        return Container.func_178144_a(p_180641_2_.func_175625_s(p_180641_3_));
    }

    public BlockRenderLayer func_180664_k()
    {
        return BlockRenderLayer.CUTOUT;
    }

    protected void func_206840_a(StateContainer.Builder<Block, IBlockState> p_206840_1_)
    {
        p_206840_1_.func_206894_a(field_176451_a[0], field_176451_a[1], field_176451_a[2]);
    }

    public BlockFaceShape func_193383_a(IBlockReader p_193383_1_, IBlockState p_193383_2_, BlockPos p_193383_3_, EnumFacing p_193383_4_)
    {
        return BlockFaceShape.UNDEFINED;
    }

    public boolean func_196266_a(IBlockState p_196266_1_, IBlockReader p_196266_2_, BlockPos p_196266_3_, PathType p_196266_4_)
    {
        return false;
    }
}
