package net.minecraft.block.trees;

import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IWorld;
import net.minecraft.world.gen.feature.AbstractTreeFeature;
import net.minecraft.world.gen.feature.IFeatureConfig;
import net.minecraft.world.gen.feature.NoFeatureConfig;

public abstract class AbstractTree
{
    @Nullable
    protected abstract AbstractTreeFeature<NoFeatureConfig> func_196936_b(Random p_196936_1_);

    public boolean func_196935_a(IWorld p_196935_1_, BlockPos p_196935_2_, IBlockState p_196935_3_, Random p_196935_4_)
    {
        AbstractTreeFeature<NoFeatureConfig> abstracttreefeature = this.func_196936_b(p_196935_4_);

        if (abstracttreefeature == null)
        {
            return false;
        }
        else
        {
            p_196935_1_.func_180501_a(p_196935_2_, Blocks.field_150350_a.func_176223_P(), 4);

            if (abstracttreefeature.func_212245_a(p_196935_1_, p_196935_1_.func_72863_F().func_201711_g(), p_196935_4_, p_196935_2_, IFeatureConfig.field_202429_e))
            {
                return true;
            }
            else
            {
                p_196935_1_.func_180501_a(p_196935_2_, p_196935_3_, 4);
                return false;
            }
        }
    }
}
