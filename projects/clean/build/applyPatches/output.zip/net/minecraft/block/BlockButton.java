package net.minecraft.block;

import java.util.List;
import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.AttachFace;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.IWorldReaderBase;
import net.minecraft.world.World;

public abstract class BlockButton extends BlockHorizontalFace
{
    public static final BooleanProperty field_176584_b = BlockStateProperties.field_208194_u;
    protected static final VoxelShape field_196370_b = Block.func_208617_a(6.0D, 14.0D, 5.0D, 10.0D, 16.0D, 11.0D);
    protected static final VoxelShape field_196371_c = Block.func_208617_a(5.0D, 14.0D, 6.0D, 11.0D, 16.0D, 10.0D);
    protected static final VoxelShape field_196376_y = Block.func_208617_a(6.0D, 0.0D, 5.0D, 10.0D, 2.0D, 11.0D);
    protected static final VoxelShape field_196377_z = Block.func_208617_a(5.0D, 0.0D, 6.0D, 11.0D, 2.0D, 10.0D);
    protected static final VoxelShape field_185622_d = Block.func_208617_a(5.0D, 6.0D, 14.0D, 11.0D, 10.0D, 16.0D);
    protected static final VoxelShape field_185624_e = Block.func_208617_a(5.0D, 6.0D, 0.0D, 11.0D, 10.0D, 2.0D);
    protected static final VoxelShape field_185626_f = Block.func_208617_a(14.0D, 6.0D, 5.0D, 16.0D, 10.0D, 11.0D);
    protected static final VoxelShape field_185628_g = Block.func_208617_a(0.0D, 6.0D, 5.0D, 2.0D, 10.0D, 11.0D);
    protected static final VoxelShape field_196372_E = Block.func_208617_a(6.0D, 15.0D, 5.0D, 10.0D, 16.0D, 11.0D);
    protected static final VoxelShape field_196373_F = Block.func_208617_a(5.0D, 15.0D, 6.0D, 11.0D, 16.0D, 10.0D);
    protected static final VoxelShape field_196374_G = Block.func_208617_a(6.0D, 0.0D, 5.0D, 10.0D, 1.0D, 11.0D);
    protected static final VoxelShape field_196375_H = Block.func_208617_a(5.0D, 0.0D, 6.0D, 11.0D, 1.0D, 10.0D);
    protected static final VoxelShape field_185623_D = Block.func_208617_a(5.0D, 6.0D, 15.0D, 11.0D, 10.0D, 16.0D);
    protected static final VoxelShape field_185625_E = Block.func_208617_a(5.0D, 6.0D, 0.0D, 11.0D, 10.0D, 1.0D);
    protected static final VoxelShape field_185627_F = Block.func_208617_a(15.0D, 6.0D, 5.0D, 16.0D, 10.0D, 11.0D);
    protected static final VoxelShape field_185629_G = Block.func_208617_a(0.0D, 6.0D, 5.0D, 1.0D, 10.0D, 11.0D);
    private final boolean field_150047_a;

    protected BlockButton(boolean p_i48436_1_, Block.Properties p_i48436_2_)
    {
        super(p_i48436_2_);
        this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_185512_D, EnumFacing.NORTH).func_206870_a(field_176584_b, Boolean.valueOf(false)).func_206870_a(field_196366_M, AttachFace.WALL));
        this.field_150047_a = p_i48436_1_;
    }

    public int func_149738_a(IWorldReaderBase p_149738_1_)
    {
        return this.field_150047_a ? 30 : 20;
    }

    public boolean func_149686_d(IBlockState p_149686_1_)
    {
        return false;
    }

    public VoxelShape func_196244_b(IBlockState p_196244_1_, IBlockReader p_196244_2_, BlockPos p_196244_3_)
    {
        EnumFacing enumfacing = p_196244_1_.func_177229_b(field_185512_D);
        boolean flag = p_196244_1_.func_177229_b(field_176584_b);

        switch ((AttachFace)p_196244_1_.func_177229_b(field_196366_M))
        {
            case FLOOR:

                if (enumfacing.func_176740_k() == EnumFacing.Axis.X)
                {
                    return flag ? field_196374_G : field_196376_y;
                }

                return flag ? field_196375_H : field_196377_z;
            case WALL:

                switch (enumfacing)
                {
                    case EAST:
                        return flag ? field_185629_G : field_185628_g;
                    case WEST:
                        return flag ? field_185627_F : field_185626_f;
                    case SOUTH:
                        return flag ? field_185625_E : field_185624_e;
                    case NORTH:
                    default:
                        return flag ? field_185623_D : field_185622_d;
                }

            case CEILING:
            default:

                if (enumfacing.func_176740_k() == EnumFacing.Axis.X)
                {
                    return flag ? field_196372_E : field_196370_b;
                }
                else
                {
                    return flag ? field_196373_F : field_196371_c;
                }
        }
    }

    public boolean func_196250_a(IBlockState p_196250_1_, World p_196250_2_, BlockPos p_196250_3_, EntityPlayer p_196250_4_, EnumHand p_196250_5_, EnumFacing p_196250_6_, float p_196250_7_, float p_196250_8_, float p_196250_9_)
    {
        if (p_196250_1_.func_177229_b(field_176584_b))
        {
            return true;
        }
        else
        {
            p_196250_2_.func_180501_a(p_196250_3_, p_196250_1_.func_206870_a(field_176584_b, Boolean.valueOf(true)), 3);
            this.func_196367_a(p_196250_4_, p_196250_2_, p_196250_3_, true);
            this.func_196368_e(p_196250_1_, p_196250_2_, p_196250_3_);
            p_196250_2_.func_205220_G_().func_205360_a(p_196250_3_, this, this.func_149738_a(p_196250_2_));
            return true;
        }
    }

    protected void func_196367_a(@Nullable EntityPlayer p_196367_1_, IWorld p_196367_2_, BlockPos p_196367_3_, boolean p_196367_4_)
    {
        p_196367_2_.func_184133_a(p_196367_4_ ? p_196367_1_ : null, p_196367_3_, this.func_196369_b(p_196367_4_), SoundCategory.BLOCKS, 0.3F, p_196367_4_ ? 0.6F : 0.5F);
    }

    protected abstract SoundEvent func_196369_b(boolean p_196369_1_);

    public void func_196243_a(IBlockState p_196243_1_, World p_196243_2_, BlockPos p_196243_3_, IBlockState p_196243_4_, boolean p_196243_5_)
    {
        if (!p_196243_5_ && p_196243_1_.func_177230_c() != p_196243_4_.func_177230_c())
        {
            if (p_196243_1_.func_177229_b(field_176584_b))
            {
                this.func_196368_e(p_196243_1_, p_196243_2_, p_196243_3_);
            }

            super.func_196243_a(p_196243_1_, p_196243_2_, p_196243_3_, p_196243_4_, p_196243_5_);
        }
    }

    public int func_180656_a(IBlockState p_180656_1_, IBlockReader p_180656_2_, BlockPos p_180656_3_, EnumFacing p_180656_4_)
    {
        return p_180656_1_.func_177229_b(field_176584_b) ? 15 : 0;
    }

    public int func_176211_b(IBlockState p_176211_1_, IBlockReader p_176211_2_, BlockPos p_176211_3_, EnumFacing p_176211_4_)
    {
        return p_176211_1_.func_177229_b(field_176584_b) && func_196365_i(p_176211_1_) == p_176211_4_ ? 15 : 0;
    }

    public boolean func_149744_f(IBlockState p_149744_1_)
    {
        return true;
    }

    public void func_196267_b(IBlockState p_196267_1_, World p_196267_2_, BlockPos p_196267_3_, Random p_196267_4_)
    {
        if (!p_196267_2_.field_72995_K && p_196267_1_.func_177229_b(field_176584_b))
        {
            if (this.field_150047_a)
            {
                this.func_185616_e(p_196267_1_, p_196267_2_, p_196267_3_);
            }
            else
            {
                p_196267_2_.func_180501_a(p_196267_3_, p_196267_1_.func_206870_a(field_176584_b, Boolean.valueOf(false)), 3);
                this.func_196368_e(p_196267_1_, p_196267_2_, p_196267_3_);
                this.func_196367_a((EntityPlayer)null, p_196267_2_, p_196267_3_, false);
            }
        }
    }

    public void func_196262_a(IBlockState p_196262_1_, World p_196262_2_, BlockPos p_196262_3_, Entity p_196262_4_)
    {
        if (!p_196262_2_.field_72995_K && this.field_150047_a && !p_196262_1_.func_177229_b(field_176584_b))
        {
            this.func_185616_e(p_196262_1_, p_196262_2_, p_196262_3_);
        }
    }

    private void func_185616_e(IBlockState p_185616_1_, World p_185616_2_, BlockPos p_185616_3_)
    {
        List <? extends Entity > list = p_185616_2_.func_72872_a(EntityArrow.class, p_185616_1_.func_196954_c(p_185616_2_, p_185616_3_).func_197752_a().func_186670_a(p_185616_3_));
        boolean flag = !list.isEmpty();
        boolean flag1 = p_185616_1_.func_177229_b(field_176584_b);

        if (flag != flag1)
        {
            p_185616_2_.func_180501_a(p_185616_3_, p_185616_1_.func_206870_a(field_176584_b, Boolean.valueOf(flag)), 3);
            this.func_196368_e(p_185616_1_, p_185616_2_, p_185616_3_);
            this.func_196367_a((EntityPlayer)null, p_185616_2_, p_185616_3_, flag);
        }

        if (flag)
        {
            p_185616_2_.func_205220_G_().func_205360_a(new BlockPos(p_185616_3_), this, this.func_149738_a(p_185616_2_));
        }
    }

    private void func_196368_e(IBlockState p_196368_1_, World p_196368_2_, BlockPos p_196368_3_)
    {
        p_196368_2_.func_195593_d(p_196368_3_, this);
        p_196368_2_.func_195593_d(p_196368_3_.func_177972_a(func_196365_i(p_196368_1_).func_176734_d()), this);
    }

    protected void func_206840_a(StateContainer.Builder<Block, IBlockState> p_206840_1_)
    {
        p_206840_1_.func_206894_a(field_185512_D, field_176584_b, field_196366_M);
    }

    public BlockFaceShape func_193383_a(IBlockReader p_193383_1_, IBlockState p_193383_2_, BlockPos p_193383_3_, EnumFacing p_193383_4_)
    {
        return BlockFaceShape.UNDEFINED;
    }
}
