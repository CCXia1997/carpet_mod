package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.state.IBlockState;
import net.minecraft.item.ItemStack;
import net.minecraft.state.IntegerProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.World;

public class BlockFrostedIce extends BlockIce
{
    public static final IntegerProperty field_185682_a = BlockStateProperties.field_208168_U;

    public BlockFrostedIce(Block.Properties p_i48394_1_)
    {
        super(p_i48394_1_);
        this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_185682_a, Integer.valueOf(0)));
    }

    public void func_196267_b(IBlockState p_196267_1_, World p_196267_2_, BlockPos p_196267_3_, Random p_196267_4_)
    {
        if ((p_196267_4_.nextInt(3) == 0 || this.func_196456_a(p_196267_2_, p_196267_3_, 4)) && p_196267_2_.func_201696_r(p_196267_3_) > 11 - p_196267_1_.func_177229_b(field_185682_a) - p_196267_1_.func_200016_a(p_196267_2_, p_196267_3_) && this.func_196455_e(p_196267_1_, p_196267_2_, p_196267_3_))
        {
            try (BlockPos.PooledMutableBlockPos blockpos$pooledmutableblockpos = BlockPos.PooledMutableBlockPos.func_185346_s())
            {
                for (EnumFacing enumfacing : EnumFacing.values())
                {
                    blockpos$pooledmutableblockpos.func_189533_g(p_196267_3_).func_189536_c(enumfacing);
                    IBlockState iblockstate = p_196267_2_.func_180495_p(blockpos$pooledmutableblockpos);

                    if (iblockstate.func_177230_c() == this && !this.func_196455_e(iblockstate, p_196267_2_, blockpos$pooledmutableblockpos))
                    {
                        p_196267_2_.func_205220_G_().func_205360_a(blockpos$pooledmutableblockpos, this, MathHelper.func_76136_a(p_196267_4_, 20, 40));
                    }
                }
            }
        }
        else
        {
            p_196267_2_.func_205220_G_().func_205360_a(p_196267_3_, this, MathHelper.func_76136_a(p_196267_4_, 20, 40));
        }
    }

    private boolean func_196455_e(IBlockState p_196455_1_, World p_196455_2_, BlockPos p_196455_3_)
    {
        int i = p_196455_1_.func_177229_b(field_185682_a);

        if (i < 3)
        {
            p_196455_2_.func_180501_a(p_196455_3_, p_196455_1_.func_206870_a(field_185682_a, Integer.valueOf(i + 1)), 2);
            return false;
        }
        else
        {
            this.func_196454_d(p_196455_1_, p_196455_2_, p_196455_3_);
            return true;
        }
    }

    public void func_189540_a(IBlockState p_189540_1_, World p_189540_2_, BlockPos p_189540_3_, Block p_189540_4_, BlockPos p_189540_5_)
    {
        if (p_189540_4_ == this && this.func_196456_a(p_189540_2_, p_189540_3_, 2))
        {
            this.func_196454_d(p_189540_1_, p_189540_2_, p_189540_3_);
        }

        super.func_189540_a(p_189540_1_, p_189540_2_, p_189540_3_, p_189540_4_, p_189540_5_);
    }

    private boolean func_196456_a(IBlockReader p_196456_1_, BlockPos p_196456_2_, int p_196456_3_)
    {
        int i = 0;

        try (BlockPos.PooledMutableBlockPos blockpos$pooledmutableblockpos = BlockPos.PooledMutableBlockPos.func_185346_s())
        {
            for (EnumFacing enumfacing : EnumFacing.values())
            {
                blockpos$pooledmutableblockpos.func_189533_g(p_196456_2_).func_189536_c(enumfacing);

                if (p_196456_1_.func_180495_p(blockpos$pooledmutableblockpos).func_177230_c() == this)
                {
                    ++i;

                    if (i >= p_196456_3_)
                    {
                        boolean flag = false;
                        return flag;
                    }
                }
            }

            return true;
        }
    }

    protected void func_206840_a(StateContainer.Builder<Block, IBlockState> p_206840_1_)
    {
        p_206840_1_.func_206894_a(field_185682_a);
    }

    public ItemStack func_185473_a(IBlockReader p_185473_1_, BlockPos p_185473_2_, IBlockState p_185473_3_)
    {
        return ItemStack.field_190927_a;
    }
}
