package net.minecraft.block;

import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.material.EnumPushReaction;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Enchantments;
import net.minecraft.item.ItemStack;
import net.minecraft.stats.StatList;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.EnumLightType;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.World;

public class BlockIce extends BlockBreakable
{
    public BlockIce(Block.Properties p_i48375_1_)
    {
        super(p_i48375_1_);
    }

    public int func_200011_d(IBlockState p_200011_1_, IBlockReader p_200011_2_, BlockPos p_200011_3_)
    {
        return Blocks.field_150355_j.func_176223_P().func_200016_a(p_200011_2_, p_200011_3_);
    }

    public BlockRenderLayer func_180664_k()
    {
        return BlockRenderLayer.TRANSLUCENT;
    }

    public void func_180657_a(World p_180657_1_, EntityPlayer p_180657_2_, BlockPos p_180657_3_, IBlockState p_180657_4_, @Nullable TileEntity p_180657_5_, ItemStack p_180657_6_)
    {
        p_180657_2_.func_71029_a(StatList.field_188065_ae.func_199076_b(this));
        p_180657_2_.func_71020_j(0.005F);

        if (this.func_149700_E() && EnchantmentHelper.func_77506_a(Enchantments.field_185306_r, p_180657_6_) > 0)
        {
            func_180635_a(p_180657_1_, p_180657_3_, this.func_180643_i(p_180657_4_));
        }
        else
        {
            if (p_180657_1_.field_73011_w.func_177500_n())
            {
                p_180657_1_.func_175698_g(p_180657_3_);
                return;
            }

            int i = EnchantmentHelper.func_77506_a(Enchantments.field_185308_t, p_180657_6_);
            p_180657_4_.func_196949_c(p_180657_1_, p_180657_3_, i);
            Material material = p_180657_1_.func_180495_p(p_180657_3_.func_177977_b()).func_185904_a();

            if (material.func_76230_c() || material.func_76224_d())
            {
                p_180657_1_.func_175656_a(p_180657_3_, Blocks.field_150355_j.func_176223_P());
            }
        }
    }

    public int func_196264_a(IBlockState p_196264_1_, Random p_196264_2_)
    {
        return 0;
    }

    public void func_196267_b(IBlockState p_196267_1_, World p_196267_2_, BlockPos p_196267_3_, Random p_196267_4_)
    {
        if (p_196267_2_.func_175642_b(EnumLightType.BLOCK, p_196267_3_) > 11 - p_196267_1_.func_200016_a(p_196267_2_, p_196267_3_))
        {
            this.func_196454_d(p_196267_1_, p_196267_2_, p_196267_3_);
        }
    }

    protected void func_196454_d(IBlockState p_196454_1_, World p_196454_2_, BlockPos p_196454_3_)
    {
        if (p_196454_2_.field_73011_w.func_177500_n())
        {
            p_196454_2_.func_175698_g(p_196454_3_);
        }
        else
        {
            p_196454_1_.func_196949_c(p_196454_2_, p_196454_3_, 0);
            p_196454_2_.func_175656_a(p_196454_3_, Blocks.field_150355_j.func_176223_P());
            p_196454_2_.func_190524_a(p_196454_3_, Blocks.field_150355_j, p_196454_3_);
        }
    }

    public EnumPushReaction func_149656_h(IBlockState p_149656_1_)
    {
        return EnumPushReaction.NORMAL;
    }
}
