package net.minecraft.block;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Maps;
import java.util.Map;
import net.minecraft.block.state.IBlockState;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.state.DirectionProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.IBlockReader;

public class BlockSkullWall extends BlockAbstractSkull
{
    public static final DirectionProperty field_196302_a = BlockHorizontal.field_185512_D;
    private static final Map<EnumFacing, VoxelShape> field_196303_A = Maps.newEnumMap(ImmutableMap.of(EnumFacing.NORTH, Block.func_208617_a(4.0D, 4.0D, 8.0D, 12.0D, 12.0D, 16.0D), EnumFacing.SOUTH, Block.func_208617_a(4.0D, 4.0D, 0.0D, 12.0D, 12.0D, 8.0D), EnumFacing.EAST, Block.func_208617_a(0.0D, 4.0D, 4.0D, 8.0D, 12.0D, 12.0D), EnumFacing.WEST, Block.func_208617_a(8.0D, 4.0D, 4.0D, 16.0D, 12.0D, 12.0D)));

    protected BlockSkullWall(BlockSkull.ISkullType p_i48299_1_, Block.Properties p_i48299_2_)
    {
        super(p_i48299_1_, p_i48299_2_);
        this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_196302_a, EnumFacing.NORTH));
    }

    public String func_149739_a()
    {
        return this.func_199767_j().func_77658_a();
    }

    public VoxelShape func_196244_b(IBlockState p_196244_1_, IBlockReader p_196244_2_, BlockPos p_196244_3_)
    {
        return field_196303_A.get(p_196244_1_.func_177229_b(field_196302_a));
    }

    public IBlockState func_196258_a(BlockItemUseContext p_196258_1_)
    {
        IBlockState iblockstate = this.func_176223_P();
        IBlockReader iblockreader = p_196258_1_.func_195991_k();
        BlockPos blockpos = p_196258_1_.func_195995_a();
        EnumFacing[] aenumfacing = p_196258_1_.func_196009_e();

        for (EnumFacing enumfacing : aenumfacing)
        {
            if (enumfacing.func_176740_k().func_176722_c())
            {
                EnumFacing enumfacing1 = enumfacing.func_176734_d();
                iblockstate = iblockstate.func_206870_a(field_196302_a, enumfacing1);

                if (!iblockreader.func_180495_p(blockpos.func_177972_a(enumfacing)).func_196953_a(p_196258_1_))
                {
                    return iblockstate;
                }
            }
        }

        return null;
    }

    public IBlockState func_185499_a(IBlockState p_185499_1_, Rotation p_185499_2_)
    {
        return p_185499_1_.func_206870_a(field_196302_a, p_185499_2_.func_185831_a(p_185499_1_.func_177229_b(field_196302_a)));
    }

    public IBlockState func_185471_a(IBlockState p_185471_1_, Mirror p_185471_2_)
    {
        return p_185471_1_.func_185907_a(p_185471_2_.func_185800_a(p_185471_1_.func_177229_b(field_196302_a)));
    }

    protected void func_206840_a(StateContainer.Builder<Block, IBlockState> p_206840_1_)
    {
        p_206840_1_.func_206894_a(field_196302_a);
    }
}
