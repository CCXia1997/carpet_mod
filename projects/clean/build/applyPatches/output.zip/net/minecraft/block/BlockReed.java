package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.IBlockState;
import net.minecraft.fluid.IFluidState;
import net.minecraft.init.Blocks;
import net.minecraft.state.IntegerProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.IWorldReaderBase;
import net.minecraft.world.World;

public class BlockReed extends Block
{
    public static final IntegerProperty field_176355_a = BlockStateProperties.field_208171_X;
    protected static final VoxelShape field_196503_b = Block.func_208617_a(2.0D, 0.0D, 2.0D, 14.0D, 16.0D, 14.0D);

    protected BlockReed(Block.Properties p_i48312_1_)
    {
        super(p_i48312_1_);
        this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_176355_a, Integer.valueOf(0)));
    }

    public VoxelShape func_196244_b(IBlockState p_196244_1_, IBlockReader p_196244_2_, BlockPos p_196244_3_)
    {
        return field_196503_b;
    }

    public void func_196267_b(IBlockState p_196267_1_, World p_196267_2_, BlockPos p_196267_3_, Random p_196267_4_)
    {
        if (p_196267_1_.func_196955_c(p_196267_2_, p_196267_3_) && p_196267_2_.func_175623_d(p_196267_3_.func_177984_a()))
        {
            int i;

            for (i = 1; p_196267_2_.func_180495_p(p_196267_3_.func_177979_c(i)).func_177230_c() == this; ++i)
            {
                ;
            }

            if (i < 3)
            {
                int j = p_196267_1_.func_177229_b(field_176355_a);

                if (j == 15)
                {
                    p_196267_2_.func_175656_a(p_196267_3_.func_177984_a(), this.func_176223_P());
                    p_196267_2_.func_180501_a(p_196267_3_, p_196267_1_.func_206870_a(field_176355_a, Integer.valueOf(0)), 4);
                }
                else
                {
                    p_196267_2_.func_180501_a(p_196267_3_, p_196267_1_.func_206870_a(field_176355_a, Integer.valueOf(j + 1)), 4);
                }
            }
        }
    }

    public IBlockState func_196271_a(IBlockState p_196271_1_, EnumFacing p_196271_2_, IBlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_)
    {
        return !p_196271_1_.func_196955_c(p_196271_4_, p_196271_5_) ? Blocks.field_150350_a.func_176223_P() : super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
    }

    public boolean func_196260_a(IBlockState p_196260_1_, IWorldReaderBase p_196260_2_, BlockPos p_196260_3_)
    {
        Block block = p_196260_2_.func_180495_p(p_196260_3_.func_177977_b()).func_177230_c();

        if (block == this)
        {
            return true;
        }
        else
        {
            if (block == Blocks.field_196658_i || block == Blocks.field_150346_d || block == Blocks.field_196660_k || block == Blocks.field_196661_l || block == Blocks.field_150354_m || block == Blocks.field_196611_F)
            {
                BlockPos blockpos = p_196260_3_.func_177977_b();

                for (EnumFacing enumfacing : EnumFacing.Plane.HORIZONTAL)
                {
                    IBlockState iblockstate = p_196260_2_.func_180495_p(blockpos.func_177972_a(enumfacing));
                    IFluidState ifluidstate = p_196260_2_.func_204610_c(blockpos.func_177972_a(enumfacing));

                    if (ifluidstate.func_206884_a(FluidTags.field_206959_a) || iblockstate.func_177230_c() == Blocks.field_185778_de)
                    {
                        return true;
                    }
                }
            }

            return false;
        }
    }

    public boolean func_149686_d(IBlockState p_149686_1_)
    {
        return false;
    }

    public BlockRenderLayer func_180664_k()
    {
        return BlockRenderLayer.CUTOUT;
    }

    protected void func_206840_a(StateContainer.Builder<Block, IBlockState> p_206840_1_)
    {
        p_206840_1_.func_206894_a(field_176355_a);
    }

    public BlockFaceShape func_193383_a(IBlockReader p_193383_1_, IBlockState p_193383_2_, BlockPos p_193383_3_, EnumFacing p_193383_4_)
    {
        return BlockFaceShape.UNDEFINED;
    }
}
