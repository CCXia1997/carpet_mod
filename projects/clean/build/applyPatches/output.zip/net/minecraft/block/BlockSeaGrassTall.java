package net.minecraft.block;

import javax.annotation.Nullable;
import net.minecraft.block.state.IBlockState;
import net.minecraft.fluid.Fluid;
import net.minecraft.fluid.IFluidState;
import net.minecraft.init.Blocks;
import net.minecraft.init.Fluids;
import net.minecraft.init.Items;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.item.ItemStack;
import net.minecraft.state.EnumProperty;
import net.minecraft.state.properties.DoubleBlockHalf;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.IItemProvider;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.IWorldReaderBase;
import net.minecraft.world.World;

public class BlockSeaGrassTall extends BlockShearableDoublePlant implements ILiquidContainer
{
    public static final EnumProperty<DoubleBlockHalf> field_208065_c = BlockShearableDoublePlant.field_208063_b;
    protected static final VoxelShape field_207799_b = Block.func_208617_a(2.0D, 0.0D, 2.0D, 14.0D, 16.0D, 14.0D);

    public BlockSeaGrassTall(Block p_i48779_1_, Block.Properties p_i48779_2_)
    {
        super(p_i48779_1_, p_i48779_2_);
    }

    public VoxelShape func_196244_b(IBlockState p_196244_1_, IBlockReader p_196244_2_, BlockPos p_196244_3_)
    {
        return field_207799_b;
    }

    protected boolean func_200014_a_(IBlockState p_200014_1_, IBlockReader p_200014_2_, BlockPos p_200014_3_)
    {
        return Block.func_208061_a(p_200014_1_.func_196952_d(p_200014_2_, p_200014_3_), EnumFacing.UP) && p_200014_1_.func_177230_c() != Blocks.field_196814_hQ;
    }

    public IItemProvider func_199769_a(IBlockState p_199769_1_, World p_199769_2_, BlockPos p_199769_3_, int p_199769_4_)
    {
        return Items.field_190931_a;
    }

    public ItemStack func_185473_a(IBlockReader p_185473_1_, BlockPos p_185473_2_, IBlockState p_185473_3_)
    {
        return new ItemStack(Blocks.field_203198_aQ);
    }

    @Nullable
    public IBlockState func_196258_a(BlockItemUseContext p_196258_1_)
    {
        IBlockState iblockstate = super.func_196258_a(p_196258_1_);

        if (iblockstate != null)
        {
            IFluidState ifluidstate = p_196258_1_.func_195991_k().func_204610_c(p_196258_1_.func_195995_a().func_177984_a());

            if (ifluidstate.func_206884_a(FluidTags.field_206959_a) && ifluidstate.func_206882_g() == 8)
            {
                return iblockstate;
            }
        }

        return null;
    }

    public boolean func_196260_a(IBlockState p_196260_1_, IWorldReaderBase p_196260_2_, BlockPos p_196260_3_)
    {
        if (p_196260_1_.func_177229_b(field_208065_c) == DoubleBlockHalf.UPPER)
        {
            IBlockState iblockstate = p_196260_2_.func_180495_p(p_196260_3_.func_177977_b());
            return iblockstate.func_177230_c() == this && iblockstate.func_177229_b(field_208065_c) == DoubleBlockHalf.LOWER;
        }
        else
        {
            IFluidState ifluidstate = p_196260_2_.func_204610_c(p_196260_3_);
            return super.func_196260_a(p_196260_1_, p_196260_2_, p_196260_3_) && ifluidstate.func_206884_a(FluidTags.field_206959_a) && ifluidstate.func_206882_g() == 8;
        }
    }

    public IFluidState func_204507_t(IBlockState p_204507_1_)
    {
        return Fluids.field_204546_a.func_207204_a(false);
    }

    public boolean func_204510_a(IBlockReader p_204510_1_, BlockPos p_204510_2_, IBlockState p_204510_3_, Fluid p_204510_4_)
    {
        return false;
    }

    public boolean func_204509_a(IWorld p_204509_1_, BlockPos p_204509_2_, IBlockState p_204509_3_, IFluidState p_204509_4_)
    {
        return false;
    }

    public int func_200011_d(IBlockState p_200011_1_, IBlockReader p_200011_2_, BlockPos p_200011_3_)
    {
        return Blocks.field_150355_j.func_176223_P().func_200016_a(p_200011_2_, p_200011_3_);
    }
}
