package net.minecraft.block;

import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.init.PotionTypes;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemArmorDyeable;
import net.minecraft.item.ItemBanner;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.pathfinding.PathType;
import net.minecraft.potion.PotionUtils;
import net.minecraft.state.IntegerProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.stats.StatList;
import net.minecraft.tileentity.TileEntityBanner;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.shapes.IBooleanFunction;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.shapes.VoxelShapes;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.World;

public class BlockCauldron extends Block
{
    public static final IntegerProperty field_176591_a = BlockStateProperties.field_208130_ae;
    protected static final VoxelShape field_196403_b = Block.func_208617_a(2.0D, 4.0D, 2.0D, 14.0D, 16.0D, 14.0D);
    protected static final VoxelShape field_196404_c = VoxelShapes.func_197878_a(VoxelShapes.func_197868_b(), field_196403_b, IBooleanFunction.ONLY_FIRST);

    public BlockCauldron(Block.Properties p_i48431_1_)
    {
        super(p_i48431_1_);
        this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_176591_a, Integer.valueOf(0)));
    }

    public VoxelShape func_196244_b(IBlockState p_196244_1_, IBlockReader p_196244_2_, BlockPos p_196244_3_)
    {
        return field_196404_c;
    }

    public boolean func_200124_e(IBlockState p_200124_1_)
    {
        return false;
    }

    public VoxelShape func_199600_g(IBlockState p_199600_1_, IBlockReader p_199600_2_, BlockPos p_199600_3_)
    {
        return field_196403_b;
    }

    public boolean func_149686_d(IBlockState p_149686_1_)
    {
        return false;
    }

    public void func_196262_a(IBlockState p_196262_1_, World p_196262_2_, BlockPos p_196262_3_, Entity p_196262_4_)
    {
        int i = p_196262_1_.func_177229_b(field_176591_a);
        float f = (float)p_196262_3_.func_177956_o() + (6.0F + (float)(3 * i)) / 16.0F;

        if (!p_196262_2_.field_72995_K && p_196262_4_.func_70027_ad() && i > 0 && p_196262_4_.func_174813_aQ().field_72338_b <= (double)f)
        {
            p_196262_4_.func_70066_B();
            this.func_176590_a(p_196262_2_, p_196262_3_, p_196262_1_, i - 1);
        }
    }

    public boolean func_196250_a(IBlockState p_196250_1_, World p_196250_2_, BlockPos p_196250_3_, EntityPlayer p_196250_4_, EnumHand p_196250_5_, EnumFacing p_196250_6_, float p_196250_7_, float p_196250_8_, float p_196250_9_)
    {
        ItemStack itemstack = p_196250_4_.func_184586_b(p_196250_5_);

        if (itemstack.func_190926_b())
        {
            return true;
        }
        else
        {
            int i = p_196250_1_.func_177229_b(field_176591_a);
            Item item = itemstack.func_77973_b();

            if (item == Items.field_151131_as)
            {
                if (i < 3 && !p_196250_2_.field_72995_K)
                {
                    if (!p_196250_4_.field_71075_bZ.field_75098_d)
                    {
                        p_196250_4_.func_184611_a(p_196250_5_, new ItemStack(Items.field_151133_ar));
                    }

                    p_196250_4_.func_195066_a(StatList.field_188077_K);
                    this.func_176590_a(p_196250_2_, p_196250_3_, p_196250_1_, 3);
                    p_196250_2_.func_184133_a((EntityPlayer)null, p_196250_3_, SoundEvents.field_187624_K, SoundCategory.BLOCKS, 1.0F, 1.0F);
                }

                return true;
            }
            else if (item == Items.field_151133_ar)
            {
                if (i == 3 && !p_196250_2_.field_72995_K)
                {
                    if (!p_196250_4_.field_71075_bZ.field_75098_d)
                    {
                        itemstack.func_190918_g(1);

                        if (itemstack.func_190926_b())
                        {
                            p_196250_4_.func_184611_a(p_196250_5_, new ItemStack(Items.field_151131_as));
                        }
                        else if (!p_196250_4_.field_71071_by.func_70441_a(new ItemStack(Items.field_151131_as)))
                        {
                            p_196250_4_.func_71019_a(new ItemStack(Items.field_151131_as), false);
                        }
                    }

                    p_196250_4_.func_195066_a(StatList.field_188078_L);
                    this.func_176590_a(p_196250_2_, p_196250_3_, p_196250_1_, 0);
                    p_196250_2_.func_184133_a((EntityPlayer)null, p_196250_3_, SoundEvents.field_187630_M, SoundCategory.BLOCKS, 1.0F, 1.0F);
                }

                return true;
            }
            else if (item == Items.field_151069_bo)
            {
                if (i > 0 && !p_196250_2_.field_72995_K)
                {
                    if (!p_196250_4_.field_71075_bZ.field_75098_d)
                    {
                        ItemStack itemstack4 = PotionUtils.func_185188_a(new ItemStack(Items.field_151068_bn), PotionTypes.field_185230_b);
                        p_196250_4_.func_195066_a(StatList.field_188078_L);
                        itemstack.func_190918_g(1);

                        if (itemstack.func_190926_b())
                        {
                            p_196250_4_.func_184611_a(p_196250_5_, itemstack4);
                        }
                        else if (!p_196250_4_.field_71071_by.func_70441_a(itemstack4))
                        {
                            p_196250_4_.func_71019_a(itemstack4, false);
                        }
                        else if (p_196250_4_ instanceof EntityPlayerMP)
                        {
                            ((EntityPlayerMP)p_196250_4_).func_71120_a(p_196250_4_.field_71069_bz);
                        }
                    }

                    p_196250_2_.func_184133_a((EntityPlayer)null, p_196250_3_, SoundEvents.field_187615_H, SoundCategory.BLOCKS, 1.0F, 1.0F);
                    this.func_176590_a(p_196250_2_, p_196250_3_, p_196250_1_, i - 1);
                }

                return true;
            }
            else if (item == Items.field_151068_bn && PotionUtils.func_185191_c(itemstack) == PotionTypes.field_185230_b)
            {
                if (i < 3 && !p_196250_2_.field_72995_K)
                {
                    if (!p_196250_4_.field_71075_bZ.field_75098_d)
                    {
                        ItemStack itemstack3 = new ItemStack(Items.field_151069_bo);
                        p_196250_4_.func_195066_a(StatList.field_188078_L);
                        p_196250_4_.func_184611_a(p_196250_5_, itemstack3);

                        if (p_196250_4_ instanceof EntityPlayerMP)
                        {
                            ((EntityPlayerMP)p_196250_4_).func_71120_a(p_196250_4_.field_71069_bz);
                        }
                    }

                    p_196250_2_.func_184133_a((EntityPlayer)null, p_196250_3_, SoundEvents.field_191241_J, SoundCategory.BLOCKS, 1.0F, 1.0F);
                    this.func_176590_a(p_196250_2_, p_196250_3_, p_196250_1_, i + 1);
                }

                return true;
            }
            else
            {
                if (i > 0 && item instanceof ItemArmorDyeable)
                {
                    ItemArmorDyeable itemarmordyeable = (ItemArmorDyeable)item;

                    if (itemarmordyeable.func_200883_f_(itemstack) && !p_196250_2_.field_72995_K)
                    {
                        itemarmordyeable.func_200884_g(itemstack);
                        this.func_176590_a(p_196250_2_, p_196250_3_, p_196250_1_, i - 1);
                        p_196250_4_.func_195066_a(StatList.field_188079_M);
                        return true;
                    }
                }

                if (i > 0 && item instanceof ItemBanner)
                {
                    if (TileEntityBanner.func_175113_c(itemstack) > 0 && !p_196250_2_.field_72995_K)
                    {
                        ItemStack itemstack2 = itemstack.func_77946_l();
                        itemstack2.func_190920_e(1);
                        TileEntityBanner.func_175117_e(itemstack2);
                        p_196250_4_.func_195066_a(StatList.field_188080_N);

                        if (!p_196250_4_.field_71075_bZ.field_75098_d)
                        {
                            itemstack.func_190918_g(1);
                            this.func_176590_a(p_196250_2_, p_196250_3_, p_196250_1_, i - 1);
                        }

                        if (itemstack.func_190926_b())
                        {
                            p_196250_4_.func_184611_a(p_196250_5_, itemstack2);
                        }
                        else if (!p_196250_4_.field_71071_by.func_70441_a(itemstack2))
                        {
                            p_196250_4_.func_71019_a(itemstack2, false);
                        }
                        else if (p_196250_4_ instanceof EntityPlayerMP)
                        {
                            ((EntityPlayerMP)p_196250_4_).func_71120_a(p_196250_4_.field_71069_bz);
                        }
                    }

                    return true;
                }
                else if (i > 0 && item instanceof ItemBlock)
                {
                    Block block = ((ItemBlock)item).func_179223_d();

                    if (block instanceof BlockShulkerBox && !p_196250_2_.func_201670_d())
                    {
                        ItemStack itemstack1 = new ItemStack(Blocks.field_204409_il, 1);

                        if (itemstack.func_77942_o())
                        {
                            itemstack1.func_77982_d(itemstack.func_77978_p().func_74737_b());
                        }

                        p_196250_4_.func_184611_a(p_196250_5_, itemstack1);
                        this.func_176590_a(p_196250_2_, p_196250_3_, p_196250_1_, i - 1);
                        p_196250_4_.func_195066_a(StatList.field_212740_X);
                    }

                    return true;
                }
                else
                {
                    return false;
                }
            }
        }
    }

    public void func_176590_a(World p_176590_1_, BlockPos p_176590_2_, IBlockState p_176590_3_, int p_176590_4_)
    {
        p_176590_1_.func_180501_a(p_176590_2_, p_176590_3_.func_206870_a(field_176591_a, Integer.valueOf(MathHelper.func_76125_a(p_176590_4_, 0, 3))), 2);
        p_176590_1_.func_175666_e(p_176590_2_, this);
    }

    public void func_176224_k(World p_176224_1_, BlockPos p_176224_2_)
    {
        if (p_176224_1_.field_73012_v.nextInt(20) == 1)
        {
            float f = p_176224_1_.func_180494_b(p_176224_2_).func_180626_a(p_176224_2_);

            if (!(f < 0.15F))
            {
                IBlockState iblockstate = p_176224_1_.func_180495_p(p_176224_2_);

                if (iblockstate.func_177229_b(field_176591_a) < 3)
                {
                    p_176224_1_.func_180501_a(p_176224_2_, iblockstate.func_177231_a(field_176591_a), 2);
                }
            }
        }
    }

    public boolean func_149740_M(IBlockState p_149740_1_)
    {
        return true;
    }

    public int func_180641_l(IBlockState p_180641_1_, World p_180641_2_, BlockPos p_180641_3_)
    {
        return p_180641_1_.func_177229_b(field_176591_a);
    }

    protected void func_206840_a(StateContainer.Builder<Block, IBlockState> p_206840_1_)
    {
        p_206840_1_.func_206894_a(field_176591_a);
    }

    public BlockFaceShape func_193383_a(IBlockReader p_193383_1_, IBlockState p_193383_2_, BlockPos p_193383_3_, EnumFacing p_193383_4_)
    {
        if (p_193383_4_ == EnumFacing.UP)
        {
            return BlockFaceShape.BOWL;
        }
        else
        {
            return p_193383_4_ == EnumFacing.DOWN ? BlockFaceShape.UNDEFINED : BlockFaceShape.SOLID;
        }
    }

    public boolean func_196266_a(IBlockState p_196266_1_, IBlockReader p_196266_2_, BlockPos p_196266_3_, PathType p_196266_4_)
    {
        return false;
    }
}
