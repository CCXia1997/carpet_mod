package net.minecraft.block;

import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemRecord;
import net.minecraft.item.ItemStack;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityJukebox;
import net.minecraft.util.EnumBlockRenderType;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.World;

public class BlockJukebox extends BlockContainer
{
    public static final BooleanProperty field_176432_a = BlockStateProperties.field_208187_n;

    protected BlockJukebox(Block.Properties p_i48372_1_)
    {
        super(p_i48372_1_);
        this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_176432_a, Boolean.valueOf(false)));
    }

    public boolean func_196250_a(IBlockState p_196250_1_, World p_196250_2_, BlockPos p_196250_3_, EntityPlayer p_196250_4_, EnumHand p_196250_5_, EnumFacing p_196250_6_, float p_196250_7_, float p_196250_8_, float p_196250_9_)
    {
        if (p_196250_1_.func_177229_b(field_176432_a))
        {
            this.func_203419_a(p_196250_2_, p_196250_3_);
            p_196250_1_ = p_196250_1_.func_206870_a(field_176432_a, Boolean.valueOf(false));
            p_196250_2_.func_180501_a(p_196250_3_, p_196250_1_, 2);
            return true;
        }
        else
        {
            return false;
        }
    }

    public void func_176431_a(IWorld p_176431_1_, BlockPos p_176431_2_, IBlockState p_176431_3_, ItemStack p_176431_4_)
    {
        TileEntity tileentity = p_176431_1_.func_175625_s(p_176431_2_);

        if (tileentity instanceof TileEntityJukebox)
        {
            ((TileEntityJukebox)tileentity).func_195535_a(p_176431_4_.func_77946_l());
            p_176431_1_.func_180501_a(p_176431_2_, p_176431_3_.func_206870_a(field_176432_a, Boolean.valueOf(true)), 2);
        }
    }

    private void func_203419_a(World p_203419_1_, BlockPos p_203419_2_)
    {
        if (!p_203419_1_.field_72995_K)
        {
            TileEntity tileentity = p_203419_1_.func_175625_s(p_203419_2_);

            if (tileentity instanceof TileEntityJukebox)
            {
                TileEntityJukebox tileentityjukebox = (TileEntityJukebox)tileentity;
                ItemStack itemstack = tileentityjukebox.func_195537_c();

                if (!itemstack.func_190926_b())
                {
                    p_203419_1_.func_175718_b(1010, p_203419_2_, 0);
                    p_203419_1_.func_184149_a(p_203419_2_, (SoundEvent)null);
                    tileentityjukebox.func_195535_a(ItemStack.field_190927_a);
                    float f = 0.7F;
                    double d0 = (double)(p_203419_1_.field_73012_v.nextFloat() * 0.7F) + (double)0.15F;
                    double d1 = (double)(p_203419_1_.field_73012_v.nextFloat() * 0.7F) + (double)0.060000002F + 0.6D;
                    double d2 = (double)(p_203419_1_.field_73012_v.nextFloat() * 0.7F) + (double)0.15F;
                    ItemStack itemstack1 = itemstack.func_77946_l();
                    EntityItem entityitem = new EntityItem(p_203419_1_, (double)p_203419_2_.func_177958_n() + d0, (double)p_203419_2_.func_177956_o() + d1, (double)p_203419_2_.func_177952_p() + d2, itemstack1);
                    entityitem.func_174869_p();
                    p_203419_1_.func_72838_d(entityitem);
                }
            }
        }
    }

    public void func_196243_a(IBlockState p_196243_1_, World p_196243_2_, BlockPos p_196243_3_, IBlockState p_196243_4_, boolean p_196243_5_)
    {
        if (p_196243_1_.func_177230_c() != p_196243_4_.func_177230_c())
        {
            this.func_203419_a(p_196243_2_, p_196243_3_);
            super.func_196243_a(p_196243_1_, p_196243_2_, p_196243_3_, p_196243_4_, p_196243_5_);
        }
    }

    public void func_196255_a(IBlockState p_196255_1_, World p_196255_2_, BlockPos p_196255_3_, float p_196255_4_, int p_196255_5_)
    {
        if (!p_196255_2_.field_72995_K)
        {
            super.func_196255_a(p_196255_1_, p_196255_2_, p_196255_3_, p_196255_4_, 0);
        }
    }

    public TileEntity func_196283_a_(IBlockReader p_196283_1_)
    {
        return new TileEntityJukebox();
    }

    public boolean func_149740_M(IBlockState p_149740_1_)
    {
        return true;
    }

    public int func_180641_l(IBlockState p_180641_1_, World p_180641_2_, BlockPos p_180641_3_)
    {
        TileEntity tileentity = p_180641_2_.func_175625_s(p_180641_3_);

        if (tileentity instanceof TileEntityJukebox)
        {
            Item item = ((TileEntityJukebox)tileentity).func_195537_c().func_77973_b();

            if (item instanceof ItemRecord)
            {
                return ((ItemRecord)item).func_195975_g();
            }
        }

        return 0;
    }

    public EnumBlockRenderType func_149645_b(IBlockState p_149645_1_)
    {
        return EnumBlockRenderType.MODEL;
    }

    protected void func_206840_a(StateContainer.Builder<Block, IBlockState> p_206840_1_)
    {
        p_206840_1_.func_206894_a(field_176432_a);
    }
}
