package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.pathfinding.PathType;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.IItemProvider;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.IWorldReaderBase;
import net.minecraft.world.World;

public class BlockGrassPath extends Block
{
    protected static final VoxelShape field_196453_a = BlockFarmland.field_196432_b;

    protected BlockGrassPath(Block.Properties p_i48386_1_)
    {
        super(p_i48386_1_);
    }

    public int func_200011_d(IBlockState p_200011_1_, IBlockReader p_200011_2_, BlockPos p_200011_3_)
    {
        return p_200011_2_.func_201572_C();
    }

    public IBlockState func_196258_a(BlockItemUseContext p_196258_1_)
    {
        return !this.func_176223_P().func_196955_c(p_196258_1_.func_195991_k(), p_196258_1_.func_195995_a()) ? Block.func_199601_a(this.func_176223_P(), Blocks.field_150346_d.func_176223_P(), p_196258_1_.func_195991_k(), p_196258_1_.func_195995_a()) : super.func_196258_a(p_196258_1_);
    }

    public IBlockState func_196271_a(IBlockState p_196271_1_, EnumFacing p_196271_2_, IBlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_)
    {
        if (p_196271_2_ == EnumFacing.UP && !p_196271_1_.func_196955_c(p_196271_4_, p_196271_5_))
        {
            p_196271_4_.func_205220_G_().func_205360_a(p_196271_5_, this, 1);
        }

        return super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
    }

    public void func_196267_b(IBlockState p_196267_1_, World p_196267_2_, BlockPos p_196267_3_, Random p_196267_4_)
    {
        BlockFarmland.func_199610_d(p_196267_1_, p_196267_2_, p_196267_3_);
    }

    public boolean func_196260_a(IBlockState p_196260_1_, IWorldReaderBase p_196260_2_, BlockPos p_196260_3_)
    {
        IBlockState iblockstate = p_196260_2_.func_180495_p(p_196260_3_.func_177984_a());
        return !iblockstate.func_185904_a().func_76220_a() || iblockstate.func_177230_c() instanceof BlockFenceGate;
    }

    public VoxelShape func_196244_b(IBlockState p_196244_1_, IBlockReader p_196244_2_, BlockPos p_196244_3_)
    {
        return field_196453_a;
    }

    public boolean func_149686_d(IBlockState p_149686_1_)
    {
        return false;
    }

    public IItemProvider func_199769_a(IBlockState p_199769_1_, World p_199769_2_, BlockPos p_199769_3_, int p_199769_4_)
    {
        return Blocks.field_150346_d;
    }

    public BlockFaceShape func_193383_a(IBlockReader p_193383_1_, IBlockState p_193383_2_, BlockPos p_193383_3_, EnumFacing p_193383_4_)
    {
        return p_193383_4_ == EnumFacing.DOWN ? BlockFaceShape.SOLID : BlockFaceShape.UNDEFINED;
    }

    public boolean func_196266_a(IBlockState p_196266_1_, IBlockReader p_196266_2_, BlockPos p_196266_3_, PathType p_196266_4_)
    {
        return false;
    }
}
