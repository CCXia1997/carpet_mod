package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.state.IntegerProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.util.IItemProvider;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.World;

public class BlockNetherWart extends BlockBush
{
    public static final IntegerProperty field_176486_a = BlockStateProperties.field_208168_U;
    private static final VoxelShape[] field_196399_b = new VoxelShape[] {Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 5.0D, 16.0D), Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 8.0D, 16.0D), Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 11.0D, 16.0D), Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 14.0D, 16.0D)};

    protected BlockNetherWart(Block.Properties p_i48361_1_)
    {
        super(p_i48361_1_);
        this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_176486_a, Integer.valueOf(0)));
    }

    public VoxelShape func_196244_b(IBlockState p_196244_1_, IBlockReader p_196244_2_, BlockPos p_196244_3_)
    {
        return field_196399_b[p_196244_1_.func_177229_b(field_176486_a)];
    }

    protected boolean func_200014_a_(IBlockState p_200014_1_, IBlockReader p_200014_2_, BlockPos p_200014_3_)
    {
        return p_200014_1_.func_177230_c() == Blocks.field_150425_aM;
    }

    public void func_196267_b(IBlockState p_196267_1_, World p_196267_2_, BlockPos p_196267_3_, Random p_196267_4_)
    {
        int i = p_196267_1_.func_177229_b(field_176486_a);

        if (i < 3 && p_196267_4_.nextInt(10) == 0)
        {
            p_196267_1_ = p_196267_1_.func_206870_a(field_176486_a, Integer.valueOf(i + 1));
            p_196267_2_.func_180501_a(p_196267_3_, p_196267_1_, 2);
        }

        super.func_196267_b(p_196267_1_, p_196267_2_, p_196267_3_, p_196267_4_);
    }

    public void func_196255_a(IBlockState p_196255_1_, World p_196255_2_, BlockPos p_196255_3_, float p_196255_4_, int p_196255_5_)
    {
        if (!p_196255_2_.field_72995_K)
        {
            int i = 1;

            if (p_196255_1_.func_177229_b(field_176486_a) >= 3)
            {
                i = 2 + p_196255_2_.field_73012_v.nextInt(3);

                if (p_196255_5_ > 0)
                {
                    i += p_196255_2_.field_73012_v.nextInt(p_196255_5_ + 1);
                }
            }

            for (int j = 0; j < i; ++j)
            {
                func_180635_a(p_196255_2_, p_196255_3_, new ItemStack(Items.field_151075_bm));
            }
        }
    }

    public IItemProvider func_199769_a(IBlockState p_199769_1_, World p_199769_2_, BlockPos p_199769_3_, int p_199769_4_)
    {
        return Items.field_190931_a;
    }

    public ItemStack func_185473_a(IBlockReader p_185473_1_, BlockPos p_185473_2_, IBlockState p_185473_3_)
    {
        return new ItemStack(Items.field_151075_bm);
    }

    protected void func_206840_a(StateContainer.Builder<Block, IBlockState> p_206840_1_)
    {
        p_206840_1_.func_206894_a(field_176486_a);
    }
}
