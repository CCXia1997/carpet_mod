package net.minecraft.block;

import net.minecraft.block.state.IBlockState;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.World;

public class BlockConcretePowder extends BlockFalling
{
    private final IBlockState field_200294_a;

    public BlockConcretePowder(Block p_i48423_1_, Block.Properties p_i48423_2_)
    {
        super(p_i48423_2_);
        this.field_200294_a = p_i48423_1_.func_176223_P();
    }

    public void func_176502_a_(World p_176502_1_, BlockPos p_176502_2_, IBlockState p_176502_3_, IBlockState p_176502_4_)
    {
        if (func_212566_x(p_176502_4_))
        {
            p_176502_1_.func_180501_a(p_176502_2_, this.field_200294_a, 3);
        }
    }

    public IBlockState func_196258_a(BlockItemUseContext p_196258_1_)
    {
        IBlockReader iblockreader = p_196258_1_.func_195991_k();
        BlockPos blockpos = p_196258_1_.func_195995_a();
        return !func_212566_x(iblockreader.func_180495_p(blockpos)) && !func_196441_b(iblockreader, blockpos) ? super.func_196258_a(p_196258_1_) : this.field_200294_a;
    }

    private static boolean func_196441_b(IBlockReader p_196441_0_, BlockPos p_196441_1_)
    {
        boolean flag = false;
        BlockPos.MutableBlockPos blockpos$mutableblockpos = new BlockPos.MutableBlockPos(p_196441_1_);

        for (EnumFacing enumfacing : EnumFacing.values())
        {
            IBlockState iblockstate = p_196441_0_.func_180495_p(blockpos$mutableblockpos);

            if (enumfacing != EnumFacing.DOWN || func_212566_x(iblockstate))
            {
                blockpos$mutableblockpos.func_189533_g(p_196441_1_).func_189536_c(enumfacing);
                iblockstate = p_196441_0_.func_180495_p(blockpos$mutableblockpos);

                if (func_212566_x(iblockstate) && !Block.func_208061_a(iblockstate.func_196952_d(p_196441_0_, p_196441_1_), enumfacing.func_176734_d()))
                {
                    flag = true;
                    break;
                }
            }
        }

        return flag;
    }

    private static boolean func_212566_x(IBlockState p_212566_0_)
    {
        return p_212566_0_.func_204520_s().func_206884_a(FluidTags.field_206959_a);
    }

    public IBlockState func_196271_a(IBlockState p_196271_1_, EnumFacing p_196271_2_, IBlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_)
    {
        return func_196441_b(p_196271_4_, p_196271_5_) ? this.field_200294_a : super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
    }
}
