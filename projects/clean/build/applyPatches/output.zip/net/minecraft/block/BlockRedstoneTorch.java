package net.minecraft.block;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import java.util.List;
import java.util.Map;
import java.util.Random;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Particles;
import net.minecraft.init.SoundEvents;
import net.minecraft.particles.RedstoneParticleData;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorldReaderBase;
import net.minecraft.world.World;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class BlockRedstoneTorch extends BlockTorch
{
    public static final BooleanProperty field_196528_a = BlockStateProperties.field_208190_q;
    private static final Map<IBlockReader, List<BlockRedstoneTorch.Toggle>> field_196529_b = Maps.newHashMap();

    protected BlockRedstoneTorch(Block.Properties p_i48342_1_)
    {
        super(p_i48342_1_);
        this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_196528_a, Boolean.valueOf(true)));
    }

    public int func_149738_a(IWorldReaderBase p_149738_1_)
    {
        return 2;
    }

    public void func_196259_b(IBlockState p_196259_1_, World p_196259_2_, BlockPos p_196259_3_, IBlockState p_196259_4_)
    {
        for (EnumFacing enumfacing : EnumFacing.values())
        {
            p_196259_2_.func_195593_d(p_196259_3_.func_177972_a(enumfacing), this);
        }
    }

    public void func_196243_a(IBlockState p_196243_1_, World p_196243_2_, BlockPos p_196243_3_, IBlockState p_196243_4_, boolean p_196243_5_)
    {
        if (!p_196243_5_)
        {
            for (EnumFacing enumfacing : EnumFacing.values())
            {
                p_196243_2_.func_195593_d(p_196243_3_.func_177972_a(enumfacing), this);
            }
        }
    }

    public int func_180656_a(IBlockState p_180656_1_, IBlockReader p_180656_2_, BlockPos p_180656_3_, EnumFacing p_180656_4_)
    {
        return p_180656_1_.func_177229_b(field_196528_a) && EnumFacing.UP != p_180656_4_ ? 15 : 0;
    }

    protected boolean func_176597_g(World p_176597_1_, BlockPos p_176597_2_, IBlockState p_176597_3_)
    {
        return p_176597_1_.func_175709_b(p_176597_2_.func_177977_b(), EnumFacing.DOWN);
    }

    public void func_196267_b(IBlockState p_196267_1_, World p_196267_2_, BlockPos p_196267_3_, Random p_196267_4_)
    {
        func_196527_a(p_196267_1_, p_196267_2_, p_196267_3_, p_196267_4_, this.func_176597_g(p_196267_2_, p_196267_3_, p_196267_1_));
    }

    public static void func_196527_a(IBlockState p_196527_0_, World p_196527_1_, BlockPos p_196527_2_, Random p_196527_3_, boolean p_196527_4_)
    {
        List<BlockRedstoneTorch.Toggle> list = field_196529_b.get(p_196527_1_);

        while (list != null && !list.isEmpty() && p_196527_1_.func_82737_E() - (list.get(0)).field_150844_d > 60L)
        {
            list.remove(0);
        }

        if (p_196527_0_.func_177229_b(field_196528_a))
        {
            if (p_196527_4_)
            {
                p_196527_1_.func_180501_a(p_196527_2_, p_196527_0_.func_206870_a(field_196528_a, Boolean.valueOf(false)), 3);

                if (func_176598_a(p_196527_1_, p_196527_2_, true))
                {
                    p_196527_1_.func_184133_a((EntityPlayer)null, p_196527_2_, SoundEvents.field_187745_eA, SoundCategory.BLOCKS, 0.5F, 2.6F + (p_196527_1_.field_73012_v.nextFloat() - p_196527_1_.field_73012_v.nextFloat()) * 0.8F);

                    for (int i = 0; i < 5; ++i)
                    {
                        double d0 = (double)p_196527_2_.func_177958_n() + p_196527_3_.nextDouble() * 0.6D + 0.2D;
                        double d1 = (double)p_196527_2_.func_177956_o() + p_196527_3_.nextDouble() * 0.6D + 0.2D;
                        double d2 = (double)p_196527_2_.func_177952_p() + p_196527_3_.nextDouble() * 0.6D + 0.2D;
                        p_196527_1_.func_195594_a(Particles.field_197601_L, d0, d1, d2, 0.0D, 0.0D, 0.0D);
                    }

                    p_196527_1_.func_205220_G_().func_205360_a(p_196527_2_, p_196527_1_.func_180495_p(p_196527_2_).func_177230_c(), 160);
                }
            }
        }
        else if (!p_196527_4_ && !func_176598_a(p_196527_1_, p_196527_2_, false))
        {
            p_196527_1_.func_180501_a(p_196527_2_, p_196527_0_.func_206870_a(field_196528_a, Boolean.valueOf(true)), 3);
        }
    }

    public void func_189540_a(IBlockState p_189540_1_, World p_189540_2_, BlockPos p_189540_3_, Block p_189540_4_, BlockPos p_189540_5_)
    {
        if (p_189540_1_.func_177229_b(field_196528_a) == this.func_176597_g(p_189540_2_, p_189540_3_, p_189540_1_) && !p_189540_2_.func_205220_G_().func_205361_b(p_189540_3_, this))
        {
            p_189540_2_.func_205220_G_().func_205360_a(p_189540_3_, this, this.func_149738_a(p_189540_2_));
        }
    }

    public int func_176211_b(IBlockState p_176211_1_, IBlockReader p_176211_2_, BlockPos p_176211_3_, EnumFacing p_176211_4_)
    {
        return p_176211_4_ == EnumFacing.DOWN ? p_176211_1_.func_185911_a(p_176211_2_, p_176211_3_, p_176211_4_) : 0;
    }

    public boolean func_149744_f(IBlockState p_149744_1_)
    {
        return true;
    }

    @OnlyIn(Dist.CLIENT)
    public void func_180655_c(IBlockState p_180655_1_, World p_180655_2_, BlockPos p_180655_3_, Random p_180655_4_)
    {
        if (p_180655_1_.func_177229_b(field_196528_a))
        {
            double d0 = (double)p_180655_3_.func_177958_n() + 0.5D + (p_180655_4_.nextDouble() - 0.5D) * 0.2D;
            double d1 = (double)p_180655_3_.func_177956_o() + 0.7D + (p_180655_4_.nextDouble() - 0.5D) * 0.2D;
            double d2 = (double)p_180655_3_.func_177952_p() + 0.5D + (p_180655_4_.nextDouble() - 0.5D) * 0.2D;
            p_180655_2_.func_195594_a(RedstoneParticleData.field_197564_a, d0, d1, d2, 0.0D, 0.0D, 0.0D);
        }
    }

    public int func_149750_m(IBlockState p_149750_1_)
    {
        return p_149750_1_.func_177229_b(field_196528_a) ? super.func_149750_m(p_149750_1_) : 0;
    }

    protected void func_206840_a(StateContainer.Builder<Block, IBlockState> p_206840_1_)
    {
        p_206840_1_.func_206894_a(field_196528_a);
    }

    private static boolean func_176598_a(World p_176598_0_, BlockPos p_176598_1_, boolean p_176598_2_)
    {
        List<BlockRedstoneTorch.Toggle> list = field_196529_b.get(p_176598_0_);

        if (list == null)
        {
            list = Lists.newArrayList();
            field_196529_b.put(p_176598_0_, list);
        }

        if (p_176598_2_)
        {
            list.add(new BlockRedstoneTorch.Toggle(p_176598_1_.func_185334_h(), p_176598_0_.func_82737_E()));
        }

        int i = 0;

        for (int j = 0; j < list.size(); ++j)
        {
            BlockRedstoneTorch.Toggle blockredstonetorch$toggle = list.get(j);

            if (blockredstonetorch$toggle.field_180111_a.equals(p_176598_1_))
            {
                ++i;

                if (i >= 8)
                {
                    return true;
                }
            }
        }

        return false;
    }

    public static class Toggle
        {
            private final BlockPos field_180111_a;
            private final long field_150844_d;

            public Toggle(BlockPos p_i45688_1_, long p_i45688_2_)
            {
                this.field_180111_a = p_i45688_1_;
                this.field_150844_d = p_i45688_2_;
            }
        }
}
