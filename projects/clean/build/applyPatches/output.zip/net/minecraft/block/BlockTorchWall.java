package net.minecraft.block;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Maps;
import java.util.Map;
import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.init.Particles;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.state.DirectionProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.IWorldReaderBase;
import net.minecraft.world.World;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class BlockTorchWall extends BlockTorch
{
    public static final DirectionProperty field_196532_a = BlockHorizontal.field_185512_D;
    private static final Map<EnumFacing, VoxelShape> field_196533_b = Maps.newEnumMap(ImmutableMap.of(EnumFacing.NORTH, Block.func_208617_a(5.5D, 3.0D, 11.0D, 10.5D, 13.0D, 16.0D), EnumFacing.SOUTH, Block.func_208617_a(5.5D, 3.0D, 0.0D, 10.5D, 13.0D, 5.0D), EnumFacing.WEST, Block.func_208617_a(11.0D, 3.0D, 5.5D, 16.0D, 13.0D, 10.5D), EnumFacing.EAST, Block.func_208617_a(0.0D, 3.0D, 5.5D, 5.0D, 13.0D, 10.5D)));

    protected BlockTorchWall(Block.Properties p_i48298_1_)
    {
        super(p_i48298_1_);
        this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_196532_a, EnumFacing.NORTH));
    }

    public String func_149739_a()
    {
        return this.func_199767_j().func_77658_a();
    }

    public VoxelShape func_196244_b(IBlockState p_196244_1_, IBlockReader p_196244_2_, BlockPos p_196244_3_)
    {
        return field_196533_b.get(p_196244_1_.func_177229_b(field_196532_a));
    }

    public boolean func_196260_a(IBlockState p_196260_1_, IWorldReaderBase p_196260_2_, BlockPos p_196260_3_)
    {
        EnumFacing enumfacing = p_196260_1_.func_177229_b(field_196532_a);
        BlockPos blockpos = p_196260_3_.func_177972_a(enumfacing.func_176734_d());
        IBlockState iblockstate = p_196260_2_.func_180495_p(blockpos);
        return iblockstate.func_193401_d(p_196260_2_, blockpos, enumfacing) == BlockFaceShape.SOLID && !func_193382_c(iblockstate.func_177230_c());
    }

    @Nullable
    public IBlockState func_196258_a(BlockItemUseContext p_196258_1_)
    {
        IBlockState iblockstate = this.func_176223_P();
        IWorldReaderBase iworldreaderbase = p_196258_1_.func_195991_k();
        BlockPos blockpos = p_196258_1_.func_195995_a();
        EnumFacing[] aenumfacing = p_196258_1_.func_196009_e();

        for (EnumFacing enumfacing : aenumfacing)
        {
            if (enumfacing.func_176740_k().func_176722_c())
            {
                EnumFacing enumfacing1 = enumfacing.func_176734_d();
                iblockstate = iblockstate.func_206870_a(field_196532_a, enumfacing1);

                if (iblockstate.func_196955_c(iworldreaderbase, blockpos))
                {
                    return iblockstate;
                }
            }
        }

        return null;
    }

    public IBlockState func_196271_a(IBlockState p_196271_1_, EnumFacing p_196271_2_, IBlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_)
    {
        return p_196271_2_.func_176734_d() == p_196271_1_.func_177229_b(field_196532_a) && !p_196271_1_.func_196955_c(p_196271_4_, p_196271_5_) ? Blocks.field_150350_a.func_176223_P() : p_196271_1_;
    }

    @OnlyIn(Dist.CLIENT)
    public void func_180655_c(IBlockState p_180655_1_, World p_180655_2_, BlockPos p_180655_3_, Random p_180655_4_)
    {
        EnumFacing enumfacing = p_180655_1_.func_177229_b(field_196532_a);
        double d0 = (double)p_180655_3_.func_177958_n() + 0.5D;
        double d1 = (double)p_180655_3_.func_177956_o() + 0.7D;
        double d2 = (double)p_180655_3_.func_177952_p() + 0.5D;
        double d3 = 0.22D;
        double d4 = 0.27D;
        EnumFacing enumfacing1 = enumfacing.func_176734_d();
        p_180655_2_.func_195594_a(Particles.field_197601_L, d0 + 0.27D * (double)enumfacing1.func_82601_c(), d1 + 0.22D, d2 + 0.27D * (double)enumfacing1.func_82599_e(), 0.0D, 0.0D, 0.0D);
        p_180655_2_.func_195594_a(Particles.field_197631_x, d0 + 0.27D * (double)enumfacing1.func_82601_c(), d1 + 0.22D, d2 + 0.27D * (double)enumfacing1.func_82599_e(), 0.0D, 0.0D, 0.0D);
    }

    public IBlockState func_185499_a(IBlockState p_185499_1_, Rotation p_185499_2_)
    {
        return p_185499_1_.func_206870_a(field_196532_a, p_185499_2_.func_185831_a(p_185499_1_.func_177229_b(field_196532_a)));
    }

    public IBlockState func_185471_a(IBlockState p_185471_1_, Mirror p_185471_2_)
    {
        return p_185471_1_.func_185907_a(p_185471_2_.func_185800_a(p_185471_1_.func_177229_b(field_196532_a)));
    }

    protected void func_206840_a(StateContainer.Builder<Block, IBlockState> p_206840_1_)
    {
        p_206840_1_.func_206894_a(field_196532_a);
    }
}
