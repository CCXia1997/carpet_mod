package net.minecraft.block.state.pattern;

import java.util.function.Predicate;
import javax.annotation.Nullable;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;

public class BlockMaterialMatcher implements Predicate<IBlockState>
{
    private static final BlockMaterialMatcher field_196961_a = new BlockMaterialMatcher(Material.field_151579_a)
    {
        public boolean test(@Nullable IBlockState p_test_1_)
        {
            return p_test_1_ != null && p_test_1_.func_196958_f();
        }
    };
    private final Material field_189887_a;

    private BlockMaterialMatcher(Material p_i47150_1_)
    {
        this.field_189887_a = p_i47150_1_;
    }

    public static BlockMaterialMatcher func_189886_a(Material p_189886_0_)
    {
        return p_189886_0_ == Material.field_151579_a ? field_196961_a : new BlockMaterialMatcher(p_189886_0_);
    }

    public boolean test(@Nullable IBlockState p_test_1_)
    {
        return p_test_1_ != null && p_test_1_.func_185904_a() == this.field_189887_a;
    }
}
