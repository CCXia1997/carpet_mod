package net.minecraft.block;

import javax.annotation.Nullable;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.EnumDyeColor;
import net.minecraft.item.ItemStack;
import net.minecraft.stats.StatList;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityBanner;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.IItemProvider;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.World;

public abstract class BlockAbstractBanner extends BlockContainer
{
    private final EnumDyeColor field_196286_a;

    protected BlockAbstractBanner(EnumDyeColor p_i48453_1_, Block.Properties p_i48453_2_)
    {
        super(p_i48453_2_);
        this.field_196286_a = p_i48453_1_;
    }

    public boolean func_149686_d(IBlockState p_149686_1_)
    {
        return false;
    }

    public boolean func_181623_g()
    {
        return true;
    }

    public TileEntity func_196283_a_(IBlockReader p_196283_1_)
    {
        return new TileEntityBanner(this.field_196286_a);
    }

    public IItemProvider func_199769_a(IBlockState p_199769_1_, World p_199769_2_, BlockPos p_199769_3_, int p_199769_4_)
    {
        return Items.field_196191_eg;
    }

    public BlockFaceShape func_193383_a(IBlockReader p_193383_1_, IBlockState p_193383_2_, BlockPos p_193383_3_, EnumFacing p_193383_4_)
    {
        return BlockFaceShape.UNDEFINED;
    }

    public ItemStack func_185473_a(IBlockReader p_185473_1_, BlockPos p_185473_2_, IBlockState p_185473_3_)
    {
        TileEntity tileentity = p_185473_1_.func_175625_s(p_185473_2_);
        return tileentity instanceof TileEntityBanner ? ((TileEntityBanner)tileentity).func_190615_l(p_185473_3_) : super.func_185473_a(p_185473_1_, p_185473_2_, p_185473_3_);
    }

    public void func_196255_a(IBlockState p_196255_1_, World p_196255_2_, BlockPos p_196255_3_, float p_196255_4_, int p_196255_5_)
    {
        func_180635_a(p_196255_2_, p_196255_3_, this.func_185473_a(p_196255_2_, p_196255_3_, p_196255_1_));
    }

    public void func_180657_a(World p_180657_1_, EntityPlayer p_180657_2_, BlockPos p_180657_3_, IBlockState p_180657_4_, @Nullable TileEntity p_180657_5_, ItemStack p_180657_6_)
    {
        if (p_180657_5_ instanceof TileEntityBanner)
        {
            func_180635_a(p_180657_1_, p_180657_3_, ((TileEntityBanner)p_180657_5_).func_190615_l(p_180657_4_));
            p_180657_2_.func_71029_a(StatList.field_188065_ae.func_199076_b(this));
        }
        else
        {
            super.func_180657_a(p_180657_1_, p_180657_2_, p_180657_3_, p_180657_4_, (TileEntity)null, p_180657_6_);
        }
    }

    public void func_180633_a(World p_180633_1_, BlockPos p_180633_2_, IBlockState p_180633_3_, @Nullable EntityLivingBase p_180633_4_, ItemStack p_180633_5_)
    {
        TileEntity tileentity = p_180633_1_.func_175625_s(p_180633_2_);

        if (tileentity instanceof TileEntityBanner)
        {
            ((TileEntityBanner)tileentity).func_195534_a(p_180633_5_, this.field_196286_a);
        }
    }

    public EnumDyeColor func_196285_M_()
    {
        return this.field_196286_a;
    }
}
