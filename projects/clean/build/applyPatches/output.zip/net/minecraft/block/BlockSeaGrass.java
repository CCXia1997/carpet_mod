package net.minecraft.block;

import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.fluid.Fluid;
import net.minecraft.fluid.IFluidState;
import net.minecraft.init.Blocks;
import net.minecraft.init.Fluids;
import net.minecraft.init.Items;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.item.ItemStack;
import net.minecraft.state.properties.DoubleBlockHalf;
import net.minecraft.stats.StatList;
import net.minecraft.tags.FluidTags;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.IItemProvider;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.World;

public class BlockSeaGrass extends BlockBush implements IGrowable, ILiquidContainer
{
    protected static final VoxelShape field_207798_a = Block.func_208617_a(2.0D, 0.0D, 2.0D, 14.0D, 12.0D, 14.0D);

    protected BlockSeaGrass(Block.Properties p_i48780_1_)
    {
        super(p_i48780_1_);
    }

    public VoxelShape func_196244_b(IBlockState p_196244_1_, IBlockReader p_196244_2_, BlockPos p_196244_3_)
    {
        return field_207798_a;
    }

    protected boolean func_200014_a_(IBlockState p_200014_1_, IBlockReader p_200014_2_, BlockPos p_200014_3_)
    {
        return Block.func_208061_a(p_200014_1_.func_196952_d(p_200014_2_, p_200014_3_), EnumFacing.UP) && p_200014_1_.func_177230_c() != Blocks.field_196814_hQ;
    }

    @Nullable
    public IBlockState func_196258_a(BlockItemUseContext p_196258_1_)
    {
        IFluidState ifluidstate = p_196258_1_.func_195991_k().func_204610_c(p_196258_1_.func_195995_a());
        return ifluidstate.func_206884_a(FluidTags.field_206959_a) && ifluidstate.func_206882_g() == 8 ? super.func_196258_a(p_196258_1_) : null;
    }

    public IBlockState func_196271_a(IBlockState p_196271_1_, EnumFacing p_196271_2_, IBlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_)
    {
        IBlockState iblockstate = super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);

        if (!iblockstate.func_196958_f())
        {
            p_196271_4_.func_205219_F_().func_205360_a(p_196271_5_, Fluids.field_204546_a, Fluids.field_204546_a.func_205569_a(p_196271_4_));
        }

        return iblockstate;
    }

    public void func_180657_a(World p_180657_1_, EntityPlayer p_180657_2_, BlockPos p_180657_3_, IBlockState p_180657_4_, @Nullable TileEntity p_180657_5_, ItemStack p_180657_6_)
    {
        if (!p_180657_1_.field_72995_K && p_180657_6_.func_77973_b() == Items.field_151097_aZ)
        {
            p_180657_2_.func_71029_a(StatList.field_188065_ae.func_199076_b(this));
            p_180657_2_.func_71020_j(0.005F);
            func_180635_a(p_180657_1_, p_180657_3_, new ItemStack(this));
        }
        else
        {
            super.func_180657_a(p_180657_1_, p_180657_2_, p_180657_3_, p_180657_4_, p_180657_5_, p_180657_6_);
        }
    }

    public IItemProvider func_199769_a(IBlockState p_199769_1_, World p_199769_2_, BlockPos p_199769_3_, int p_199769_4_)
    {
        return Items.field_190931_a;
    }

    public boolean func_176473_a(IBlockReader p_176473_1_, BlockPos p_176473_2_, IBlockState p_176473_3_, boolean p_176473_4_)
    {
        return true;
    }

    public boolean func_180670_a(World p_180670_1_, Random p_180670_2_, BlockPos p_180670_3_, IBlockState p_180670_4_)
    {
        return true;
    }

    public IFluidState func_204507_t(IBlockState p_204507_1_)
    {
        return Fluids.field_204546_a.func_207204_a(false);
    }

    public void func_176474_b(World p_176474_1_, Random p_176474_2_, BlockPos p_176474_3_, IBlockState p_176474_4_)
    {
        IBlockState iblockstate = Blocks.field_203199_aR.func_176223_P();
        IBlockState iblockstate1 = iblockstate.func_206870_a(BlockSeaGrassTall.field_208065_c, DoubleBlockHalf.UPPER);
        BlockPos blockpos = p_176474_3_.func_177984_a();

        if (p_176474_1_.func_180495_p(blockpos).func_177230_c() == Blocks.field_150355_j)
        {
            p_176474_1_.func_180501_a(p_176474_3_, iblockstate, 2);
            p_176474_1_.func_180501_a(blockpos, iblockstate1, 2);
        }
    }

    public boolean func_204510_a(IBlockReader p_204510_1_, BlockPos p_204510_2_, IBlockState p_204510_3_, Fluid p_204510_4_)
    {
        return false;
    }

    public boolean func_204509_a(IWorld p_204509_1_, BlockPos p_204509_2_, IBlockState p_204509_3_, IFluidState p_204509_4_)
    {
        return false;
    }

    public int func_200011_d(IBlockState p_200011_1_, IBlockReader p_200011_2_, BlockPos p_200011_3_)
    {
        return Blocks.field_150355_j.func_176223_P().func_200016_a(p_200011_2_, p_200011_3_);
    }
}
