package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.IWorldReaderBase;
import net.minecraft.world.World;
import net.minecraft.world.gen.feature.Feature;
import net.minecraft.world.gen.feature.IFeatureConfig;
import net.minecraft.world.gen.feature.NoFeatureConfig;

public class BlockMushroom extends BlockBush implements IGrowable
{
    protected static final VoxelShape field_196385_a = Block.func_208617_a(5.0D, 0.0D, 5.0D, 11.0D, 6.0D, 11.0D);

    public BlockMushroom(Block.Properties p_i48363_1_)
    {
        super(p_i48363_1_);
    }

    public VoxelShape func_196244_b(IBlockState p_196244_1_, IBlockReader p_196244_2_, BlockPos p_196244_3_)
    {
        return field_196385_a;
    }

    public void func_196267_b(IBlockState p_196267_1_, World p_196267_2_, BlockPos p_196267_3_, Random p_196267_4_)
    {
        if (p_196267_4_.nextInt(25) == 0)
        {
            int i = 5;
            int j = 4;

            for (BlockPos blockpos : BlockPos.func_177975_b(p_196267_3_.func_177982_a(-4, -1, -4), p_196267_3_.func_177982_a(4, 1, 4)))
            {
                if (p_196267_2_.func_180495_p(blockpos).func_177230_c() == this)
                {
                    --i;

                    if (i <= 0)
                    {
                        return;
                    }
                }
            }

            BlockPos blockpos1 = p_196267_3_.func_177982_a(p_196267_4_.nextInt(3) - 1, p_196267_4_.nextInt(2) - p_196267_4_.nextInt(2), p_196267_4_.nextInt(3) - 1);

            for (int k = 0; k < 4; ++k)
            {
                if (p_196267_2_.func_175623_d(blockpos1) && p_196267_1_.func_196955_c(p_196267_2_, blockpos1))
                {
                    p_196267_3_ = blockpos1;
                }

                blockpos1 = p_196267_3_.func_177982_a(p_196267_4_.nextInt(3) - 1, p_196267_4_.nextInt(2) - p_196267_4_.nextInt(2), p_196267_4_.nextInt(3) - 1);
            }

            if (p_196267_2_.func_175623_d(blockpos1) && p_196267_1_.func_196955_c(p_196267_2_, blockpos1))
            {
                p_196267_2_.func_180501_a(blockpos1, p_196267_1_, 2);
            }
        }
    }

    protected boolean func_200014_a_(IBlockState p_200014_1_, IBlockReader p_200014_2_, BlockPos p_200014_3_)
    {
        return p_200014_1_.func_200015_d(p_200014_2_, p_200014_3_);
    }

    public boolean func_196260_a(IBlockState p_196260_1_, IWorldReaderBase p_196260_2_, BlockPos p_196260_3_)
    {
        BlockPos blockpos = p_196260_3_.func_177977_b();
        IBlockState iblockstate = p_196260_2_.func_180495_p(blockpos);
        Block block = iblockstate.func_177230_c();

        if (block != Blocks.field_150391_bh && block != Blocks.field_196661_l)
        {
            return p_196260_2_.func_201669_a(p_196260_3_, 0) < 13 && this.func_200014_a_(iblockstate, p_196260_2_, blockpos);
        }
        else
        {
            return true;
        }
    }

    public boolean func_176485_d(IWorld p_176485_1_, BlockPos p_176485_2_, IBlockState p_176485_3_, Random p_176485_4_)
    {
        p_176485_1_.func_175698_g(p_176485_2_);
        Feature<NoFeatureConfig> feature = null;

        if (this == Blocks.field_150338_P)
        {
            feature = Feature.field_202319_S;
        }
        else if (this == Blocks.field_150337_Q)
        {
            feature = Feature.field_202318_R;
        }

        if (feature != null && feature.func_212245_a(p_176485_1_, p_176485_1_.func_72863_F().func_201711_g(), p_176485_4_, p_176485_2_, IFeatureConfig.field_202429_e))
        {
            return true;
        }
        else
        {
            p_176485_1_.func_180501_a(p_176485_2_, p_176485_3_, 3);
            return false;
        }
    }

    public boolean func_176473_a(IBlockReader p_176473_1_, BlockPos p_176473_2_, IBlockState p_176473_3_, boolean p_176473_4_)
    {
        return true;
    }

    public boolean func_180670_a(World p_180670_1_, Random p_180670_2_, BlockPos p_180670_3_, IBlockState p_180670_4_)
    {
        return (double)p_180670_2_.nextFloat() < 0.4D;
    }

    public void func_176474_b(World p_176474_1_, Random p_176474_2_, BlockPos p_176474_3_, IBlockState p_176474_4_)
    {
        this.func_176485_d(p_176474_1_, p_176474_3_, p_176474_4_, p_176474_2_);
    }

    public boolean func_201783_b(IBlockState p_201783_1_, IBlockReader p_201783_2_, BlockPos p_201783_3_)
    {
        return true;
    }
}
