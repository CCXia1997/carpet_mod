package net.minecraft.block;

import com.mojang.authlib.GameProfile;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTUtil;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntitySkull;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import org.apache.commons.lang3.StringUtils;

public class BlockSkullPlayer extends BlockSkull
{
    protected BlockSkullPlayer(Block.Properties p_i48354_1_)
    {
        super(BlockSkull.Types.PLAYER, p_i48354_1_);
    }

    public void func_180633_a(World p_180633_1_, BlockPos p_180633_2_, IBlockState p_180633_3_, @Nullable EntityLivingBase p_180633_4_, ItemStack p_180633_5_)
    {
        super.func_180633_a(p_180633_1_, p_180633_2_, p_180633_3_, p_180633_4_, p_180633_5_);
        TileEntity tileentity = p_180633_1_.func_175625_s(p_180633_2_);

        if (tileentity instanceof TileEntitySkull)
        {
            TileEntitySkull tileentityskull = (TileEntitySkull)tileentity;
            GameProfile gameprofile = null;

            if (p_180633_5_.func_77942_o())
            {
                NBTTagCompound nbttagcompound = p_180633_5_.func_77978_p();

                if (nbttagcompound.func_150297_b("SkullOwner", 10))
                {
                    gameprofile = NBTUtil.func_152459_a(nbttagcompound.func_74775_l("SkullOwner"));
                }
                else if (nbttagcompound.func_150297_b("SkullOwner", 8) && !StringUtils.isBlank(nbttagcompound.func_74779_i("SkullOwner")))
                {
                    gameprofile = new GameProfile((UUID)null, nbttagcompound.func_74779_i("SkullOwner"));
                }
            }

            tileentityskull.func_195485_a(gameprofile);
        }
    }
}
