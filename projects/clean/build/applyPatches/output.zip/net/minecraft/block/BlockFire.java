package net.minecraft.block;

import it.unimi.dsi.fastutil.objects.Object2IntMap;
import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
import java.util.Map;
import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.init.Particles;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.IntegerProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.Util;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.shapes.VoxelShapes;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.IWorldReaderBase;
import net.minecraft.world.World;
import net.minecraft.world.dimension.DimensionType;
import net.minecraft.world.dimension.EndDimension;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class BlockFire extends Block
{
    public static final IntegerProperty field_176543_a = BlockStateProperties.field_208171_X;
    public static final BooleanProperty field_176545_N = BlockSixWay.field_196488_a;
    public static final BooleanProperty field_176546_O = BlockSixWay.field_196490_b;
    public static final BooleanProperty field_176541_P = BlockSixWay.field_196492_c;
    public static final BooleanProperty field_176539_Q = BlockSixWay.field_196495_y;
    public static final BooleanProperty field_176542_R = BlockSixWay.field_196496_z;
    private static final Map<EnumFacing, BooleanProperty> field_196449_B = BlockSixWay.field_196491_B.entrySet().stream().filter((p_199776_0_) ->
    {
        return p_199776_0_.getKey() != EnumFacing.DOWN;
    }).collect(Util.func_199749_a());
    private final Object2IntMap<Block> field_149849_a = new Object2IntOpenHashMap<>();
    private final Object2IntMap<Block> field_149848_b = new Object2IntOpenHashMap<>();

    protected BlockFire(Block.Properties p_i48397_1_)
    {
        super(p_i48397_1_);
        this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_176543_a, Integer.valueOf(0)).func_206870_a(field_176545_N, Boolean.valueOf(false)).func_206870_a(field_176546_O, Boolean.valueOf(false)).func_206870_a(field_176541_P, Boolean.valueOf(false)).func_206870_a(field_176539_Q, Boolean.valueOf(false)).func_206870_a(field_176542_R, Boolean.valueOf(false)));
    }

    public VoxelShape func_196244_b(IBlockState p_196244_1_, IBlockReader p_196244_2_, BlockPos p_196244_3_)
    {
        return VoxelShapes.func_197880_a();
    }

    public IBlockState func_196271_a(IBlockState p_196271_1_, EnumFacing p_196271_2_, IBlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_)
    {
        return this.func_196260_a(p_196271_1_, p_196271_4_, p_196271_5_) ? this.func_196448_a(p_196271_4_, p_196271_5_).func_206870_a(field_176543_a, p_196271_1_.func_177229_b(field_176543_a)) : Blocks.field_150350_a.func_176223_P();
    }

    @Nullable
    public IBlockState func_196258_a(BlockItemUseContext p_196258_1_)
    {
        return this.func_196448_a(p_196258_1_.func_195991_k(), p_196258_1_.func_195995_a());
    }

    public IBlockState func_196448_a(IBlockReader p_196448_1_, BlockPos p_196448_2_)
    {
        IBlockState iblockstate = p_196448_1_.func_180495_p(p_196448_2_.func_177977_b());

        if (!iblockstate.func_185896_q() && !this.func_196446_i(iblockstate))
        {
            IBlockState iblockstate1 = this.func_176223_P();

            for (EnumFacing enumfacing : EnumFacing.values())
            {
                BooleanProperty booleanproperty = field_196449_B.get(enumfacing);

                if (booleanproperty != null)
                {
                    iblockstate1 = iblockstate1.func_206870_a(booleanproperty, Boolean.valueOf(this.func_196446_i(p_196448_1_.func_180495_p(p_196448_2_.func_177972_a(enumfacing)))));
                }
            }

            return iblockstate1;
        }
        else
        {
            return this.func_176223_P();
        }
    }

    public boolean func_196260_a(IBlockState p_196260_1_, IWorldReaderBase p_196260_2_, BlockPos p_196260_3_)
    {
        return p_196260_2_.func_180495_p(p_196260_3_.func_177977_b()).func_185896_q() || this.func_196447_a(p_196260_2_, p_196260_3_);
    }

    public boolean func_149686_d(IBlockState p_149686_1_)
    {
        return false;
    }

    public int func_196264_a(IBlockState p_196264_1_, Random p_196264_2_)
    {
        return 0;
    }

    public int func_149738_a(IWorldReaderBase p_149738_1_)
    {
        return 30;
    }

    public void func_196267_b(IBlockState p_196267_1_, World p_196267_2_, BlockPos p_196267_3_, Random p_196267_4_)
    {
        if (p_196267_2_.func_82736_K().func_82766_b("doFireTick"))
        {
            if (!p_196267_1_.func_196955_c(p_196267_2_, p_196267_3_))
            {
                p_196267_2_.func_175698_g(p_196267_3_);
            }

            Block block = p_196267_2_.func_180495_p(p_196267_3_.func_177977_b()).func_177230_c();
            boolean flag = p_196267_2_.field_73011_w instanceof EndDimension && block == Blocks.field_150357_h || block == Blocks.field_150424_aL || block == Blocks.field_196814_hQ;
            int i = p_196267_1_.func_177229_b(field_176543_a);

            if (!flag && p_196267_2_.func_72896_J() && this.func_176537_d(p_196267_2_, p_196267_3_) && p_196267_4_.nextFloat() < 0.2F + (float)i * 0.03F)
            {
                p_196267_2_.func_175698_g(p_196267_3_);
            }
            else
            {
                int j = Math.min(15, i + p_196267_4_.nextInt(3) / 2);

                if (i != j)
                {
                    p_196267_1_ = p_196267_1_.func_206870_a(field_176543_a, Integer.valueOf(j));
                    p_196267_2_.func_180501_a(p_196267_3_, p_196267_1_, 4);
                }

                if (!flag)
                {
                    p_196267_2_.func_205220_G_().func_205360_a(p_196267_3_, this, this.func_149738_a(p_196267_2_) + p_196267_4_.nextInt(10));

                    if (!this.func_196447_a(p_196267_2_, p_196267_3_))
                    {
                        if (!p_196267_2_.func_180495_p(p_196267_3_.func_177977_b()).func_185896_q() || i > 3)
                        {
                            p_196267_2_.func_175698_g(p_196267_3_);
                        }

                        return;
                    }

                    if (i == 15 && p_196267_4_.nextInt(4) == 0 && !this.func_196446_i(p_196267_2_.func_180495_p(p_196267_3_.func_177977_b())))
                    {
                        p_196267_2_.func_175698_g(p_196267_3_);
                        return;
                    }
                }

                boolean flag1 = p_196267_2_.func_180502_D(p_196267_3_);
                int k = flag1 ? -50 : 0;
                this.func_176536_a(p_196267_2_, p_196267_3_.func_177974_f(), 300 + k, p_196267_4_, i);
                this.func_176536_a(p_196267_2_, p_196267_3_.func_177976_e(), 300 + k, p_196267_4_, i);
                this.func_176536_a(p_196267_2_, p_196267_3_.func_177977_b(), 250 + k, p_196267_4_, i);
                this.func_176536_a(p_196267_2_, p_196267_3_.func_177984_a(), 250 + k, p_196267_4_, i);
                this.func_176536_a(p_196267_2_, p_196267_3_.func_177978_c(), 300 + k, p_196267_4_, i);
                this.func_176536_a(p_196267_2_, p_196267_3_.func_177968_d(), 300 + k, p_196267_4_, i);
                BlockPos.MutableBlockPos blockpos$mutableblockpos = new BlockPos.MutableBlockPos();

                for (int l = -1; l <= 1; ++l)
                {
                    for (int i1 = -1; i1 <= 1; ++i1)
                    {
                        for (int j1 = -1; j1 <= 4; ++j1)
                        {
                            if (l != 0 || j1 != 0 || i1 != 0)
                            {
                                int k1 = 100;

                                if (j1 > 1)
                                {
                                    k1 += (j1 - 1) * 100;
                                }

                                blockpos$mutableblockpos.func_189533_g(p_196267_3_).func_196234_d(l, j1, i1);
                                int l1 = this.func_176538_m(p_196267_2_, blockpos$mutableblockpos);

                                if (l1 > 0)
                                {
                                    int i2 = (l1 + 40 + p_196267_2_.func_175659_aa().func_151525_a() * 7) / (i + 30);

                                    if (flag1)
                                    {
                                        i2 /= 2;
                                    }

                                    if (i2 > 0 && p_196267_4_.nextInt(k1) <= i2 && (!p_196267_2_.func_72896_J() || !this.func_176537_d(p_196267_2_, blockpos$mutableblockpos)))
                                    {
                                        int j2 = Math.min(15, i + p_196267_4_.nextInt(5) / 4);
                                        p_196267_2_.func_180501_a(blockpos$mutableblockpos, this.func_196448_a(p_196267_2_, blockpos$mutableblockpos).func_206870_a(field_176543_a, Integer.valueOf(j2)), 3);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    protected boolean func_176537_d(World p_176537_1_, BlockPos p_176537_2_)
    {
        return p_176537_1_.func_175727_C(p_176537_2_) || p_176537_1_.func_175727_C(p_176537_2_.func_177976_e()) || p_176537_1_.func_175727_C(p_176537_2_.func_177974_f()) || p_176537_1_.func_175727_C(p_176537_2_.func_177978_c()) || p_176537_1_.func_175727_C(p_176537_2_.func_177968_d());
    }

    private int func_176532_c(Block p_176532_1_)
    {
        return this.field_149848_b.getInt(p_176532_1_);
    }

    private int func_176534_d(Block p_176534_1_)
    {
        return this.field_149849_a.getInt(p_176534_1_);
    }

    private void func_176536_a(World p_176536_1_, BlockPos p_176536_2_, int p_176536_3_, Random p_176536_4_, int p_176536_5_)
    {
        int i = this.func_176532_c(p_176536_1_.func_180495_p(p_176536_2_).func_177230_c());

        if (p_176536_4_.nextInt(p_176536_3_) < i)
        {
            IBlockState iblockstate = p_176536_1_.func_180495_p(p_176536_2_);

            if (p_176536_4_.nextInt(p_176536_5_ + 10) < 5 && !p_176536_1_.func_175727_C(p_176536_2_))
            {
                int j = Math.min(p_176536_5_ + p_176536_4_.nextInt(5) / 4, 15);
                p_176536_1_.func_180501_a(p_176536_2_, this.func_196448_a(p_176536_1_, p_176536_2_).func_206870_a(field_176543_a, Integer.valueOf(j)), 3);
            }
            else
            {
                p_176536_1_.func_175698_g(p_176536_2_);
            }

            Block block = iblockstate.func_177230_c();

            if (block instanceof BlockTNT)
            {
                ((BlockTNT)block).func_196534_a(p_176536_1_, p_176536_2_);
            }
        }
    }

    private boolean func_196447_a(IBlockReader p_196447_1_, BlockPos p_196447_2_)
    {
        for (EnumFacing enumfacing : EnumFacing.values())
        {
            if (this.func_196446_i(p_196447_1_.func_180495_p(p_196447_2_.func_177972_a(enumfacing))))
            {
                return true;
            }
        }

        return false;
    }

    private int func_176538_m(IWorldReaderBase p_176538_1_, BlockPos p_176538_2_)
    {
        if (!p_176538_1_.func_175623_d(p_176538_2_))
        {
            return 0;
        }
        else
        {
            int i = 0;

            for (EnumFacing enumfacing : EnumFacing.values())
            {
                i = Math.max(this.func_176534_d(p_176538_1_.func_180495_p(p_176538_2_.func_177972_a(enumfacing)).func_177230_c()), i);
            }

            return i;
        }
    }

    public boolean func_149703_v()
    {
        return false;
    }

    public boolean func_196446_i(IBlockState p_196446_1_)
    {
        return this.func_176534_d(p_196446_1_.func_177230_c()) > 0;
    }

    public void func_196259_b(IBlockState p_196259_1_, World p_196259_2_, BlockPos p_196259_3_, IBlockState p_196259_4_)
    {
        if (p_196259_4_.func_177230_c() != p_196259_1_.func_177230_c())
        {
            if (p_196259_2_.field_73011_w.func_186058_p() != DimensionType.OVERWORLD && p_196259_2_.field_73011_w.func_186058_p() != DimensionType.NETHER || !((BlockPortal)Blocks.field_150427_aO).func_176548_d(p_196259_2_, p_196259_3_))
            {
                if (!p_196259_1_.func_196955_c(p_196259_2_, p_196259_3_))
                {
                    p_196259_2_.func_175698_g(p_196259_3_);
                }
                else
                {
                    p_196259_2_.func_205220_G_().func_205360_a(p_196259_3_, this, this.func_149738_a(p_196259_2_) + p_196259_2_.field_73012_v.nextInt(10));
                }
            }
        }
    }

    @OnlyIn(Dist.CLIENT)
    public void func_180655_c(IBlockState p_180655_1_, World p_180655_2_, BlockPos p_180655_3_, Random p_180655_4_)
    {
        if (p_180655_4_.nextInt(24) == 0)
        {
            p_180655_2_.func_184134_a((double)((float)p_180655_3_.func_177958_n() + 0.5F), (double)((float)p_180655_3_.func_177956_o() + 0.5F), (double)((float)p_180655_3_.func_177952_p() + 0.5F), SoundEvents.field_187643_bs, SoundCategory.BLOCKS, 1.0F + p_180655_4_.nextFloat(), p_180655_4_.nextFloat() * 0.7F + 0.3F, false);
        }

        if (!p_180655_2_.func_180495_p(p_180655_3_.func_177977_b()).func_185896_q() && !this.func_196446_i(p_180655_2_.func_180495_p(p_180655_3_.func_177977_b())))
        {
            if (this.func_196446_i(p_180655_2_.func_180495_p(p_180655_3_.func_177976_e())))
            {
                for (int j = 0; j < 2; ++j)
                {
                    double d3 = (double)p_180655_3_.func_177958_n() + p_180655_4_.nextDouble() * (double)0.1F;
                    double d8 = (double)p_180655_3_.func_177956_o() + p_180655_4_.nextDouble();
                    double d13 = (double)p_180655_3_.func_177952_p() + p_180655_4_.nextDouble();
                    p_180655_2_.func_195594_a(Particles.field_197594_E, d3, d8, d13, 0.0D, 0.0D, 0.0D);
                }
            }

            if (this.func_196446_i(p_180655_2_.func_180495_p(p_180655_3_.func_177974_f())))
            {
                for (int k = 0; k < 2; ++k)
                {
                    double d4 = (double)(p_180655_3_.func_177958_n() + 1) - p_180655_4_.nextDouble() * (double)0.1F;
                    double d9 = (double)p_180655_3_.func_177956_o() + p_180655_4_.nextDouble();
                    double d14 = (double)p_180655_3_.func_177952_p() + p_180655_4_.nextDouble();
                    p_180655_2_.func_195594_a(Particles.field_197594_E, d4, d9, d14, 0.0D, 0.0D, 0.0D);
                }
            }

            if (this.func_196446_i(p_180655_2_.func_180495_p(p_180655_3_.func_177978_c())))
            {
                for (int l = 0; l < 2; ++l)
                {
                    double d5 = (double)p_180655_3_.func_177958_n() + p_180655_4_.nextDouble();
                    double d10 = (double)p_180655_3_.func_177956_o() + p_180655_4_.nextDouble();
                    double d15 = (double)p_180655_3_.func_177952_p() + p_180655_4_.nextDouble() * (double)0.1F;
                    p_180655_2_.func_195594_a(Particles.field_197594_E, d5, d10, d15, 0.0D, 0.0D, 0.0D);
                }
            }

            if (this.func_196446_i(p_180655_2_.func_180495_p(p_180655_3_.func_177968_d())))
            {
                for (int i1 = 0; i1 < 2; ++i1)
                {
                    double d6 = (double)p_180655_3_.func_177958_n() + p_180655_4_.nextDouble();
                    double d11 = (double)p_180655_3_.func_177956_o() + p_180655_4_.nextDouble();
                    double d16 = (double)(p_180655_3_.func_177952_p() + 1) - p_180655_4_.nextDouble() * (double)0.1F;
                    p_180655_2_.func_195594_a(Particles.field_197594_E, d6, d11, d16, 0.0D, 0.0D, 0.0D);
                }
            }

            if (this.func_196446_i(p_180655_2_.func_180495_p(p_180655_3_.func_177984_a())))
            {
                for (int j1 = 0; j1 < 2; ++j1)
                {
                    double d7 = (double)p_180655_3_.func_177958_n() + p_180655_4_.nextDouble();
                    double d12 = (double)(p_180655_3_.func_177956_o() + 1) - p_180655_4_.nextDouble() * (double)0.1F;
                    double d17 = (double)p_180655_3_.func_177952_p() + p_180655_4_.nextDouble();
                    p_180655_2_.func_195594_a(Particles.field_197594_E, d7, d12, d17, 0.0D, 0.0D, 0.0D);
                }
            }
        }
        else
        {
            for (int i = 0; i < 3; ++i)
            {
                double d0 = (double)p_180655_3_.func_177958_n() + p_180655_4_.nextDouble();
                double d1 = (double)p_180655_3_.func_177956_o() + p_180655_4_.nextDouble() * 0.5D + 0.5D;
                double d2 = (double)p_180655_3_.func_177952_p() + p_180655_4_.nextDouble();
                p_180655_2_.func_195594_a(Particles.field_197594_E, d0, d1, d2, 0.0D, 0.0D, 0.0D);
            }
        }
    }

    public BlockRenderLayer func_180664_k()
    {
        return BlockRenderLayer.CUTOUT;
    }

    protected void func_206840_a(StateContainer.Builder<Block, IBlockState> p_206840_1_)
    {
        p_206840_1_.func_206894_a(field_176543_a, field_176545_N, field_176546_O, field_176541_P, field_176539_Q, field_176542_R);
    }

    public BlockFaceShape func_193383_a(IBlockReader p_193383_1_, IBlockState p_193383_2_, BlockPos p_193383_3_, EnumFacing p_193383_4_)
    {
        return BlockFaceShape.UNDEFINED;
    }

    public void func_180686_a(Block p_180686_1_, int p_180686_2_, int p_180686_3_)
    {
        this.field_149849_a.put(p_180686_1_, p_180686_2_);
        this.field_149848_b.put(p_180686_1_, p_180686_3_);
    }

    public static void func_149843_e()
    {
        BlockFire blockfire = (BlockFire)Blocks.field_150480_ab;
        blockfire.func_180686_a(Blocks.field_196662_n, 5, 20);
        blockfire.func_180686_a(Blocks.field_196664_o, 5, 20);
        blockfire.func_180686_a(Blocks.field_196666_p, 5, 20);
        blockfire.func_180686_a(Blocks.field_196668_q, 5, 20);
        blockfire.func_180686_a(Blocks.field_196670_r, 5, 20);
        blockfire.func_180686_a(Blocks.field_196672_s, 5, 20);
        blockfire.func_180686_a(Blocks.field_196622_bq, 5, 20);
        blockfire.func_180686_a(Blocks.field_196624_br, 5, 20);
        blockfire.func_180686_a(Blocks.field_196627_bs, 5, 20);
        blockfire.func_180686_a(Blocks.field_196630_bt, 5, 20);
        blockfire.func_180686_a(Blocks.field_196632_bu, 5, 20);
        blockfire.func_180686_a(Blocks.field_196635_bv, 5, 20);
        blockfire.func_180686_a(Blocks.field_180390_bo, 5, 20);
        blockfire.func_180686_a(Blocks.field_180391_bp, 5, 20);
        blockfire.func_180686_a(Blocks.field_180392_bq, 5, 20);
        blockfire.func_180686_a(Blocks.field_180386_br, 5, 20);
        blockfire.func_180686_a(Blocks.field_180385_bs, 5, 20);
        blockfire.func_180686_a(Blocks.field_180387_bt, 5, 20);
        blockfire.func_180686_a(Blocks.field_180407_aO, 5, 20);
        blockfire.func_180686_a(Blocks.field_180408_aP, 5, 20);
        blockfire.func_180686_a(Blocks.field_180404_aQ, 5, 20);
        blockfire.func_180686_a(Blocks.field_180403_aR, 5, 20);
        blockfire.func_180686_a(Blocks.field_180406_aS, 5, 20);
        blockfire.func_180686_a(Blocks.field_180405_aT, 5, 20);
        blockfire.func_180686_a(Blocks.field_150476_ad, 5, 20);
        blockfire.func_180686_a(Blocks.field_150487_bG, 5, 20);
        blockfire.func_180686_a(Blocks.field_150485_bF, 5, 20);
        blockfire.func_180686_a(Blocks.field_150481_bH, 5, 20);
        blockfire.func_180686_a(Blocks.field_150400_ck, 5, 20);
        blockfire.func_180686_a(Blocks.field_150401_cl, 5, 20);
        blockfire.func_180686_a(Blocks.field_196617_K, 5, 5);
        blockfire.func_180686_a(Blocks.field_196618_L, 5, 5);
        blockfire.func_180686_a(Blocks.field_196619_M, 5, 5);
        blockfire.func_180686_a(Blocks.field_196620_N, 5, 5);
        blockfire.func_180686_a(Blocks.field_196621_O, 5, 5);
        blockfire.func_180686_a(Blocks.field_196623_P, 5, 5);
        blockfire.func_180686_a(Blocks.field_203204_R, 5, 5);
        blockfire.func_180686_a(Blocks.field_203205_S, 5, 5);
        blockfire.func_180686_a(Blocks.field_203206_T, 5, 5);
        blockfire.func_180686_a(Blocks.field_203207_U, 5, 5);
        blockfire.func_180686_a(Blocks.field_203208_V, 5, 5);
        blockfire.func_180686_a(Blocks.field_203209_W, 5, 5);
        blockfire.func_180686_a(Blocks.field_209389_ab, 5, 5);
        blockfire.func_180686_a(Blocks.field_209390_ac, 5, 5);
        blockfire.func_180686_a(Blocks.field_209391_ad, 5, 5);
        blockfire.func_180686_a(Blocks.field_209392_ae, 5, 5);
        blockfire.func_180686_a(Blocks.field_209393_af, 5, 5);
        blockfire.func_180686_a(Blocks.field_209394_ag, 5, 5);
        blockfire.func_180686_a(Blocks.field_196626_Q, 5, 5);
        blockfire.func_180686_a(Blocks.field_196629_R, 5, 5);
        blockfire.func_180686_a(Blocks.field_196631_S, 5, 5);
        blockfire.func_180686_a(Blocks.field_196634_T, 5, 5);
        blockfire.func_180686_a(Blocks.field_196637_U, 5, 5);
        blockfire.func_180686_a(Blocks.field_196639_V, 5, 5);
        blockfire.func_180686_a(Blocks.field_196642_W, 30, 60);
        blockfire.func_180686_a(Blocks.field_196645_X, 30, 60);
        blockfire.func_180686_a(Blocks.field_196647_Y, 30, 60);
        blockfire.func_180686_a(Blocks.field_196648_Z, 30, 60);
        blockfire.func_180686_a(Blocks.field_196572_aa, 30, 60);
        blockfire.func_180686_a(Blocks.field_196574_ab, 30, 60);
        blockfire.func_180686_a(Blocks.field_150342_X, 30, 20);
        blockfire.func_180686_a(Blocks.field_150335_W, 15, 100);
        blockfire.func_180686_a(Blocks.field_150349_c, 60, 100);
        blockfire.func_180686_a(Blocks.field_196554_aH, 60, 100);
        blockfire.func_180686_a(Blocks.field_196555_aI, 60, 100);
        blockfire.func_180686_a(Blocks.field_196800_gd, 60, 100);
        blockfire.func_180686_a(Blocks.field_196801_ge, 60, 100);
        blockfire.func_180686_a(Blocks.field_196802_gf, 60, 100);
        blockfire.func_180686_a(Blocks.field_196803_gg, 60, 100);
        blockfire.func_180686_a(Blocks.field_196804_gh, 60, 100);
        blockfire.func_180686_a(Blocks.field_196805_gi, 60, 100);
        blockfire.func_180686_a(Blocks.field_196605_bc, 60, 100);
        blockfire.func_180686_a(Blocks.field_196606_bd, 60, 100);
        blockfire.func_180686_a(Blocks.field_196607_be, 60, 100);
        blockfire.func_180686_a(Blocks.field_196609_bf, 60, 100);
        blockfire.func_180686_a(Blocks.field_196610_bg, 60, 100);
        blockfire.func_180686_a(Blocks.field_196612_bh, 60, 100);
        blockfire.func_180686_a(Blocks.field_196613_bi, 60, 100);
        blockfire.func_180686_a(Blocks.field_196614_bj, 60, 100);
        blockfire.func_180686_a(Blocks.field_196615_bk, 60, 100);
        blockfire.func_180686_a(Blocks.field_196616_bl, 60, 100);
        blockfire.func_180686_a(Blocks.field_196556_aL, 30, 60);
        blockfire.func_180686_a(Blocks.field_196557_aM, 30, 60);
        blockfire.func_180686_a(Blocks.field_196558_aN, 30, 60);
        blockfire.func_180686_a(Blocks.field_196559_aO, 30, 60);
        blockfire.func_180686_a(Blocks.field_196560_aP, 30, 60);
        blockfire.func_180686_a(Blocks.field_196561_aQ, 30, 60);
        blockfire.func_180686_a(Blocks.field_196562_aR, 30, 60);
        blockfire.func_180686_a(Blocks.field_196563_aS, 30, 60);
        blockfire.func_180686_a(Blocks.field_196564_aT, 30, 60);
        blockfire.func_180686_a(Blocks.field_196565_aU, 30, 60);
        blockfire.func_180686_a(Blocks.field_196566_aV, 30, 60);
        blockfire.func_180686_a(Blocks.field_196567_aW, 30, 60);
        blockfire.func_180686_a(Blocks.field_196568_aX, 30, 60);
        blockfire.func_180686_a(Blocks.field_196569_aY, 30, 60);
        blockfire.func_180686_a(Blocks.field_196570_aZ, 30, 60);
        blockfire.func_180686_a(Blocks.field_196602_ba, 30, 60);
        blockfire.func_180686_a(Blocks.field_150395_bd, 15, 100);
        blockfire.func_180686_a(Blocks.field_150402_ci, 5, 5);
        blockfire.func_180686_a(Blocks.field_150407_cf, 60, 20);
        blockfire.func_180686_a(Blocks.field_196724_fH, 60, 20);
        blockfire.func_180686_a(Blocks.field_196725_fI, 60, 20);
        blockfire.func_180686_a(Blocks.field_196727_fJ, 60, 20);
        blockfire.func_180686_a(Blocks.field_196729_fK, 60, 20);
        blockfire.func_180686_a(Blocks.field_196731_fL, 60, 20);
        blockfire.func_180686_a(Blocks.field_196733_fM, 60, 20);
        blockfire.func_180686_a(Blocks.field_196735_fN, 60, 20);
        blockfire.func_180686_a(Blocks.field_196737_fO, 60, 20);
        blockfire.func_180686_a(Blocks.field_196739_fP, 60, 20);
        blockfire.func_180686_a(Blocks.field_196741_fQ, 60, 20);
        blockfire.func_180686_a(Blocks.field_196743_fR, 60, 20);
        blockfire.func_180686_a(Blocks.field_196745_fS, 60, 20);
        blockfire.func_180686_a(Blocks.field_196747_fT, 60, 20);
        blockfire.func_180686_a(Blocks.field_196749_fU, 60, 20);
        blockfire.func_180686_a(Blocks.field_196751_fV, 60, 20);
        blockfire.func_180686_a(Blocks.field_196753_fW, 60, 20);
        blockfire.func_180686_a(Blocks.field_203216_jz, 30, 60);
    }
}
